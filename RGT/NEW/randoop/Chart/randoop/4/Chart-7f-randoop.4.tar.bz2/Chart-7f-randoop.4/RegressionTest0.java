import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        java.lang.Object obj3 = null;
        try {
            int int4 = simpleTimePeriod2.compareTo(obj3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        timePeriodValues3.setNotify(true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test016");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getMiddleMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, (int) (byte) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        java.util.TimeZone timeZone12 = null;
        try {
            org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        try {
            java.lang.Number number7 = timePeriodValues3.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        try {
            java.lang.Number number12 = timePeriodValues3.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 11, (long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1L, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        try {
            timePeriodValues3.update((-1), (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        long long12 = simpleTimePeriod8.getEndMillis();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.fireSeriesChanged();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        try {
            timePeriodValues3.delete((int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + "hi!" + "'", comparable7.equals("hi!"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 100, (long) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues6.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        long long13 = day12.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-57600000L) + "'", long13 == (-57600000L));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (5) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue5 = timePeriodValues3.getDataItem(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1577865599999L, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, 10.0d);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 13);
        try {
            java.lang.Number number40 = timePeriodValues3.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod8.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        timePeriodValues3.setDescription("hi!");
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test051");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (-1.0d) + "'", obj3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (-1.0d) + "'", obj4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (-1.0d) + "'", obj5.equals((-1.0d)));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = null;
        try {
            timePeriodValues3.add(timePeriodValue10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '4', (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 13, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        int int11 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        try {
            java.lang.Number number7 = timePeriodValues3.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        try {
            java.lang.Number number30 = timePeriodValues3.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str26.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, 10.0d);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener37);
        java.lang.String str39 = timePeriodValues16.getDomainDescription();
        timePeriodValues16.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener42);
        try {
            int int44 = simpleTimePeriod8.compareTo((java.lang.Object) timePeriodValues16);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str39.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test065");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getMonth();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        try {
            timePeriodValues3.update((int) (byte) 0, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (52) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        int int24 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener25);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day12.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.lang.String str2 = day1.toString();
//        long long3 = day1.getSerialIndex();
//        long long4 = day1.getLastMillisecond();
//        java.util.Date date5 = day1.getStart();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues10.addPropertyChangeListener(propertyChangeListener11);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) simpleTimePeriod15, 10.0d);
//        java.lang.Class<?> wildcardClass18 = simpleTimePeriod15.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timePeriodValues23.addPropertyChangeListener(propertyChangeListener24);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, 10.0d);
//        java.util.Date date31 = simpleTimePeriod28.getEnd();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31);
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 10.0d);
//        java.util.Date date45 = simpleTimePeriod42.getEnd();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45);
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date45, timeZone48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date31, timeZone48);
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date5, timeZone48);
//        try {
//            org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date0, timeZone48);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("hi!");
        try {
            org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues3.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 2019);
        boolean boolean5 = timePeriodValue3.equals((java.lang.Object) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date11, timeZone14);
        java.util.Calendar calendar16 = null;
        try {
            day15.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (int) (short) 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues3.getDataItem(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("31-December-1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues11.addChangeListener(seriesChangeListener12);
        timePeriodValues11.setRangeDescription("13-June-2019");
        timePeriodValues11.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
        java.util.Date date29 = simpleTimePeriod26.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod26);
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod26, (java.lang.Number) (byte) 10);
        timePeriodValues11.add(timePeriodValue32);
        timePeriodValues6.add(timePeriodValue32);
        org.jfree.data.time.TimePeriod timePeriod35 = timePeriodValue32.getPeriod();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timePeriod35);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1.0d) + "'", obj2.equals((-1.0d)));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setNotify(false);
        try {
            timePeriodValues3.delete(3, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues3.getItemCount();
        java.lang.Number number11 = null;
        try {
            timePeriodValues3.update(11, number11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, 10.0d);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 13);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue40 = timePeriodValues3.getDataItem(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 1.0f + "'", comparable14.equals(1.0f));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        timePeriodValues6.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues6.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (8) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        long long6 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560452399999L + "'", long6 == 1560452399999L);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues3.getTimePeriod(0);
        boolean boolean28 = timePeriodValues3.getNotify();
        try {
            timePeriodValues3.update(11, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        int int8 = timePeriodValues3.getMinEndIndex();
        int int9 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "org.jfree.data.time.TimePeriodFormatException: ", "13-June-2019");
        boolean boolean5 = year0.equals((java.lang.Object) 13);
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        timePeriodValues3.setDescription("");
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, 10.0d);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 13);
        java.lang.String str39 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(str39);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        try {
            org.jfree.data.time.TimePeriod timePeriod19 = timePeriodValues3.getTimePeriod(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.lang.String str13 = day12.toString();
        java.util.Calendar calendar14 = null;
        try {
            day12.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, 10.0d);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 13);
        timePeriodValues3.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
//        java.lang.Class<?> wildcardClass17 = simpleTimePeriod14.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
//        java.util.Date date30 = simpleTimePeriod27.getEnd();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30);
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timePeriodValues36.addPropertyChangeListener(propertyChangeListener37);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues36.add((org.jfree.data.time.TimePeriod) simpleTimePeriod41, 10.0d);
//        java.util.Date date44 = simpleTimePeriod41.getEnd();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date44);
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date44, timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date30, timeZone47);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date4, timeZone47);
//        java.util.TimeZone timeZone51 = null;
//        try {
//            org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date4, timeZone51);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        java.lang.Object obj17 = timePeriodValues3.clone();
        java.lang.String str18 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = regularTimePeriod3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date11);
        java.util.Date date15 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date11, date15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue11 = timePeriodValues3.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 2019);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        long long6 = day0.getMiddleMillisecond();
//        java.util.Date date7 = day0.getEnd();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560452399999L + "'", long6 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) str2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 2019L);
        java.lang.Object obj35 = timePeriodValue34.clone();
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        java.util.Date date33 = simpleTimePeriod14.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues37.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 10.0d);
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date45, timeZone48);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date33, date45);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod50);
        int int52 = timePeriodValues51.getItemCount();
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.lang.String str13 = day12.toString();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day12.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 2019);
        java.lang.Number number4 = timePeriodValue3.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2019.0d + "'", number4.equals(2019.0d));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8, "13-June-2019", "13-June-2019");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        try {
            java.lang.Number number17 = timePeriodValues13.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '4', (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, 10.0d);
        java.lang.Class<?> wildcardClass23 = simpleTimePeriod20.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) simpleTimePeriod33, 10.0d);
        java.util.Date date36 = simpleTimePeriod33.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues42.addPropertyChangeListener(propertyChangeListener43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues42.add((org.jfree.data.time.TimePeriod) simpleTimePeriod47, 10.0d);
        java.util.Date date50 = simpleTimePeriod47.getEnd();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date50, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date36, timeZone53);
        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        boolean boolean57 = simpleTimePeriod8.equals((java.lang.Object) wildcardClass23);
        long long58 = simpleTimePeriod8.getStartMillis();
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        java.util.Date date2 = year1.getStart();
        int int3 = year1.getYear();
        long long4 = year1.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable throwable7 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        java.util.Date date33 = simpleTimePeriod14.getStart();
        long long34 = simpleTimePeriod14.getStartMillis();
        long long35 = simpleTimePeriod14.getStartMillis();
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (byte) 10);
        java.lang.Number number15 = timePeriodValue14.getValue();
        java.lang.Object obj16 = timePeriodValue14.clone();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) 10 + "'", number15.equals((byte) 10));
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        java.util.Date date18 = simpleTimePeriod14.getEnd();
        java.util.Date date19 = simpleTimePeriod14.getEnd();
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year9.next();
        long long33 = year9.getFirstMillisecond();
        java.util.Calendar calendar34 = null;
        try {
            long long35 = year9.getLastMillisecond(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues3.getTimePeriod(0);
        boolean boolean28 = timePeriodValues3.getNotify();
        timePeriodValues3.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener31);
        try {
            timePeriodValues3.update((int) (byte) 100, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        int int4 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        java.lang.String str12 = timePeriodValues3.getDescription();
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year9.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year9.previous();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("");
//        int int9 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        boolean boolean13 = timePeriodValues3.equals((java.lang.Object) day10);
//        java.lang.String str14 = timePeriodValues3.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str14.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        java.util.Date date11 = simpleTimePeriod8.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date11, timeZone59);
//        int int64 = day63.getYear();
//        java.util.Calendar calendar65 = null;
//        try {
//            long long66 = day63.getMiddleMillisecond(calendar65);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1969 + "'", int64 == 1969);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        int int13 = year9.getYear();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        java.lang.Object obj17 = timePeriodValues3.clone();
        int int18 = timePeriodValues3.getMinStartIndex();
        int int19 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod19);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) 43629L);
        java.util.Date date26 = simpleTimePeriod19.getStart();
        java.util.TimeZone timeZone27 = null;
        try {
            org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date26, timeZone27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener26);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day12.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        int int24 = timePeriodValues3.getMaxStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue26 = timePeriodValues3.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        int int7 = day0.compareTo((java.lang.Object) (short) 1);
//        java.util.Calendar calendar8 = null;
//        try {
//            day0.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) -1);
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        int int4 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        int int6 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 2019L);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        try {
            int int37 = simpleTimePeriod14.compareTo((java.lang.Object) timePeriodFormatException36);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodFormatException cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        java.lang.String str27 = timePeriodValues3.getRangeDescription();
        try {
            timePeriodValues3.delete(3, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str26.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: 2019"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        java.util.Date date18 = simpleTimePeriod14.getEnd();
        java.lang.Class class19 = null;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.previous();
        java.util.Date date23 = regularTimePeriod22.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, 10.0d);
        java.util.Date date35 = simpleTimePeriod32.getEnd();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date35);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date35, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date23, timeZone38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date18, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
        timePeriodValues45.addChangeListener(seriesChangeListener46);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timePeriodValues51.addPropertyChangeListener(propertyChangeListener52);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues51.add((org.jfree.data.time.TimePeriod) simpleTimePeriod56, 10.0d);
        timePeriodValues45.setKey((java.lang.Comparable) simpleTimePeriod56);
        org.jfree.data.time.TimePeriodValues timePeriodValues63 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timePeriodValues63.addPropertyChangeListener(propertyChangeListener64);
        timePeriodValues63.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener68 = null;
        timePeriodValues63.removeChangeListener(seriesChangeListener68);
        timePeriodValues63.setKey((java.lang.Comparable) 1.0f);
        int int72 = timePeriodValues63.getMinMiddleIndex();
        int int73 = timePeriodValues63.getMinMiddleIndex();
        boolean boolean74 = simpleTimePeriod56.equals((java.lang.Object) timePeriodValues63);
        java.util.Date date75 = simpleTimePeriod56.getStart();
        java.util.Date date76 = simpleTimePeriod56.getStart();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod77 = new org.jfree.data.time.SimpleTimePeriod(date18, date76);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(date76);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        int int27 = timePeriodValues3.getItemCount();
        boolean boolean28 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str26.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Object obj9 = timePeriodValues3.clone();
        java.lang.String str10 = timePeriodValues3.getDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues3.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy((int) (short) 10, 5);
        java.lang.String str9 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        java.util.Date date33 = simpleTimePeriod14.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues37.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 10.0d);
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date45, timeZone48);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date33, date45);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod50);
        long long52 = simpleTimePeriod50.getStartMillis();
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 10L);
        java.lang.String str9 = timePeriodValues3.getDescription();
        java.lang.String str10 = timePeriodValues3.getDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues3.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues3.getTimePeriod(0);
        boolean boolean28 = timePeriodValues3.getNotify();
        timePeriodValues3.setNotify(true);
        java.lang.Comparable comparable31 = null;
        try {
            timePeriodValues3.setKey(comparable31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        long long11 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod20, "13-June-2019", "13-June-2019");
        timePeriodValues25.fireSeriesChanged();
        int int27 = timePeriodValues25.getMinEndIndex();
        try {
            int int28 = simpleTimePeriod8.compareTo((java.lang.Object) timePeriodValues25);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (byte) 10);
        java.lang.String str15 = timePeriodValue14.toString();
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.lang.String str10 = timePeriodValues3.getDescription();
        try {
            java.lang.Number number12 = timePeriodValues3.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
//        java.util.Date date10 = day9.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(date10);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        boolean boolean9 = day0.equals((java.lang.Object) (byte) -1);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, 10.0d);
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date11, date25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = year28.getLastMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        timePeriodValues6.fireSeriesChanged();
        java.lang.String str8 = timePeriodValues6.getDomainDescription();
        org.jfree.data.time.TimePeriod timePeriod9 = null;
        try {
            timePeriodValues6.add(timePeriod9, (java.lang.Number) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        int int13 = timePeriodValues3.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, 10.0d);
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod22);
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod22, (java.lang.Number) (byte) 10);
        java.lang.Number number29 = timePeriodValue28.getValue();
        timePeriodValues3.add(timePeriodValue28);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) 10 + "'", number29.equals((byte) 10));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod19);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) 43629L);
        java.util.Date date26 = simpleTimePeriod19.getStart();
        java.util.Date date27 = simpleTimePeriod19.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.Class<?> wildcardClass30 = seriesChangeEvent29.getClass();
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
        try {
            int int32 = simpleTimePeriod19.compareTo((java.lang.Object) class31);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Class cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(class31);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (byte) 10);
        java.util.Date date15 = simpleTimePeriod8.getEnd();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (9) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        java.util.Date date33 = simpleTimePeriod14.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues37.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 10.0d);
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date45, timeZone48);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date33, date45);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod50);
        try {
            java.lang.Number number53 = timePeriodValues51.getValue(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone48);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        java.util.Date date2 = year1.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod11, 10.0d);
        java.lang.Class<?> wildcardClass14 = simpleTimePeriod11.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues19.add((org.jfree.data.time.TimePeriod) simpleTimePeriod24, 10.0d);
        java.util.Date date27 = simpleTimePeriod24.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues33.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues33.add((org.jfree.data.time.TimePeriod) simpleTimePeriod38, 10.0d);
        java.util.Date date41 = simpleTimePeriod38.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date41);
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date41, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date27, timeZone44);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date2, timeZone44);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod46);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.String str5 = seriesChangeEvent1.toString();
        java.lang.String str6 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (-1.0d) + "'", obj3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (-1.0d) + "'", obj4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 3, (long) 5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9);
        int int15 = timePeriodValues14.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day0.equals(obj8);
//        java.util.Calendar calendar10 = null;
//        try {
//            day0.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        java.lang.String str27 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues31.addChangeListener(seriesChangeListener32);
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues37.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 10.0d);
        timePeriodValues31.setKey((java.lang.Comparable) simpleTimePeriod42);
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timePeriodValues49.addPropertyChangeListener(propertyChangeListener50);
        timePeriodValues49.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
        timePeriodValues49.removeChangeListener(seriesChangeListener54);
        timePeriodValues49.setKey((java.lang.Comparable) 1.0f);
        int int58 = timePeriodValues49.getMinMiddleIndex();
        int int59 = timePeriodValues49.getMinMiddleIndex();
        boolean boolean60 = simpleTimePeriod42.equals((java.lang.Object) timePeriodValues49);
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timePeriodValues64.addPropertyChangeListener(propertyChangeListener65);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod69 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues64.add((org.jfree.data.time.TimePeriod) simpleTimePeriod69, 10.0d);
        java.util.Date date72 = simpleTimePeriod69.getEnd();
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date72);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date72);
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date72);
        java.util.Date date76 = day75.getStart();
        int int77 = simpleTimePeriod42.compareTo((java.lang.Object) day75);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, (java.lang.Number) 1562097599999L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str26.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8, "13-June-2019", "13-June-2019");
        timePeriodValues13.fireSeriesChanged();
        java.lang.Comparable comparable15 = timePeriodValues13.getKey();
        try {
            timePeriodValues13.delete((int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(comparable15);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy(0, (int) '4');
        boolean boolean5 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertNotNull(timePeriodValues4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
        timePeriodValues15.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues15.removeChangeListener(seriesChangeListener20);
        int int22 = timePeriodValues15.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues26.addPropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues26.add((org.jfree.data.time.TimePeriod) simpleTimePeriod31, 10.0d);
        java.util.Date date34 = simpleTimePeriod31.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod31);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod31, (java.lang.Number) 43629L);
        java.util.Date date38 = simpleTimePeriod31.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
        timePeriodValues42.addChangeListener(seriesChangeListener43);
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
        timePeriodValues42.setKey((java.lang.Comparable) simpleTimePeriod53);
        java.util.Date date57 = simpleTimePeriod53.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timePeriodValues61.addPropertyChangeListener(propertyChangeListener62);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues61.add((org.jfree.data.time.TimePeriod) simpleTimePeriod66, 10.0d);
        java.util.Date date69 = simpleTimePeriod66.getEnd();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date69);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod71 = new org.jfree.data.time.SimpleTimePeriod(date57, date69);
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date57, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date38, timeZone72);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNull(regularTimePeriod74);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8, "13-June-2019", "13-June-2019");
        timePeriodValues13.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue16 = timePeriodValues13.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues11.addPropertyChangeListener(propertyChangeListener12);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues11.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, 10.0d);
//        java.util.Date date19 = simpleTimePeriod16.getEnd();
//        long long20 = simpleTimePeriod16.getStartMillis();
//        java.util.Date date21 = simpleTimePeriod16.getEnd();
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date7, date21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(date21);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues3.getTimePeriod(0);
        boolean boolean28 = timePeriodValues3.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener29);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener31);
        org.junit.Assert.assertNotNull(timePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = day0.equals(obj8);
//        int int10 = day0.getYear();
//        java.util.Date date11 = day0.getEnd();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day0.getMiddleMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(date11);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener12);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        java.util.Calendar calendar6 = null;
//        try {
//            day5.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
//        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
//        int int9 = year1.compareTo((java.lang.Object) timePeriodFormatException3);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        long long12 = day10.getSerialIndex();
//        java.lang.Object obj13 = null;
//        int int14 = day10.compareTo(obj13);
//        int int15 = day10.getMonth();
//        org.jfree.data.time.SerialDate serialDate16 = day10.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate16);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate16);
//        int int20 = year1.compareTo((java.lang.Object) day19);
//        int int21 = day19.getDayOfMonth();
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        java.lang.Class<?> wildcardClass18 = simpleTimePeriod14.getClass();
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9);
        long long15 = year9.getSerialIndex();
        long long16 = year9.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues6.addPropertyChangeListener(propertyChangeListener8);
//        int int10 = timePeriodValues6.getMinEndIndex();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getSerialIndex();
//        java.util.Date date13 = day11.getEnd();
//        long long14 = day11.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (short) -1);
//        java.lang.Number number17 = null;
//        timePeriodValue16.setValue(number17);
//        timePeriodValues6.add(timePeriodValue16);
//        java.lang.Number number20 = timePeriodValue16.getValue();
//        try {
//            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) number20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//        org.junit.Assert.assertNull(number20);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        int int13 = timePeriodValues3.getItemCount();
        timePeriodValues3.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        java.util.Date date18 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        java.util.Date date30 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date18, date30);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date18, timeZone33);
        java.util.Calendar calendar35 = null;
        try {
            long long36 = year34.getFirstMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone33);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        int int9 = year1.compareTo((java.lang.Object) timePeriodFormatException3);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year1.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues6.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        java.util.Date date12 = day10.getEnd();
//        long long13 = day10.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (short) -1);
//        java.lang.Number number16 = null;
//        timePeriodValue15.setValue(number16);
//        timePeriodValues6.add(timePeriodValue15);
//        java.lang.String str19 = timePeriodValue15.toString();
//        org.jfree.data.time.TimePeriod timePeriod20 = timePeriodValue15.getPeriod();
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str19.equals("TimePeriodValue[13-June-2019,null]"));
//        org.junit.Assert.assertNotNull(timePeriod20);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        long long4 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        int int17 = year14.getYear();
        java.util.Date date18 = year14.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.previous();
        long long20 = year14.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        int int17 = year14.getYear();
        java.util.Date date18 = year14.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.next();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, 10.0d);
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date11, date25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year29, "2019", "hi!");
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date25);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getDayOfMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("TimePeriodValue[13-June-2019,null]");
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getMonth();
//        long long8 = day0.getFirstMillisecond();
//        java.lang.String str9 = day0.toString();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day0.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        java.util.Date date2 = year1.getStart();
        int int3 = year1.getYear();
        java.lang.Class class4 = null;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = regularTimePeriod7.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod17, 10.0d);
        java.util.Date date20 = simpleTimePeriod17.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date20, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date8, timeZone23);
        int int26 = year1.compareTo((java.lang.Object) regularTimePeriod25);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.fireSeriesChanged();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        timePeriodValues3.fireSeriesChanged();
        int int9 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + "hi!" + "'", comparable7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date11);
        java.util.Date date15 = day14.getStart();
        long long16 = day14.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
//        java.lang.String str9 = day8.toString();
//        java.util.Calendar calendar10 = null;
//        try {
//            day8.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, (int) (short) 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues3.getRangeDescription();
//        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        java.lang.String str10 = year9.toString();
//        int int11 = year9.getYear();
//        timePeriodValues3.setKey((java.lang.Comparable) year9);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        java.util.Date date15 = day13.getEnd();
//        long long16 = day13.getLastMillisecond();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        long long19 = day17.getSerialIndex();
//        long long20 = day17.getLastMillisecond();
//        boolean boolean22 = day17.equals((java.lang.Object) "hi!");
//        boolean boolean23 = day13.equals((java.lang.Object) boolean22);
//        boolean boolean25 = day13.equals((java.lang.Object) 13);
//        java.util.Date date26 = day13.getStart();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
//        boolean boolean28 = timePeriodValues3.equals((java.lang.Object) day27);
//        try {
//            java.lang.Number number30 = timePeriodValues3.getValue((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560495599999L + "'", long20 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        long long11 = simpleTimePeriod8.getEndMillis();
        long long12 = simpleTimePeriod8.getEndMillis();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, 13, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues6.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        timePeriodValues6.setKey((java.lang.Comparable) day10);
//        int int14 = timePeriodValues6.getMaxMiddleIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues18.addPropertyChangeListener(propertyChangeListener19);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues18.add((org.jfree.data.time.TimePeriod) simpleTimePeriod23, 10.0d);
//        java.util.Date date26 = simpleTimePeriod23.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod23);
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod23, (java.lang.Number) (byte) 10);
//        java.lang.Number number30 = timePeriodValue29.getValue();
//        java.lang.String str31 = timePeriodValue29.toString();
//        java.lang.Number number32 = null;
//        timePeriodValue29.setValue(number32);
//        timePeriodValue29.setValue((java.lang.Number) 1562097599999L);
//        timePeriodValues6.add(timePeriodValue29);
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (byte) 10 + "'", number30.equals((byte) 10));
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod8.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
        java.util.Date date24 = simpleTimePeriod21.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues30.add((org.jfree.data.time.TimePeriod) simpleTimePeriod35, 10.0d);
        java.util.Date date38 = simpleTimePeriod35.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date38, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date24, timeZone41);
        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize(class44);
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize(class44);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(class44);
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertNotNull(class46);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) 0.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(12, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        int int6 = day0.getMonth();
//        boolean boolean8 = day0.equals((java.lang.Object) 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues3.getRangeDescription();
//        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        java.lang.String str10 = year9.toString();
//        int int11 = year9.getYear();
//        timePeriodValues3.setKey((java.lang.Comparable) year9);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        java.util.Date date15 = day13.getEnd();
//        long long16 = day13.getLastMillisecond();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        long long19 = day17.getSerialIndex();
//        long long20 = day17.getLastMillisecond();
//        boolean boolean22 = day17.equals((java.lang.Object) "hi!");
//        boolean boolean23 = day13.equals((java.lang.Object) boolean22);
//        boolean boolean25 = day13.equals((java.lang.Object) 13);
//        java.util.Date date26 = day13.getStart();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
//        boolean boolean28 = timePeriodValues3.equals((java.lang.Object) day27);
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue30 = timePeriodValues3.getDataItem(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560495599999L + "'", long20 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        java.lang.String str2 = year1.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
//        java.util.Date date4 = regularTimePeriod3.getEnd();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getSerialIndex();
//        java.lang.Class<?> wildcardClass7 = day5.getClass();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        long long10 = day8.getSerialIndex();
//        long long11 = day8.getLastMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        long long15 = day13.getSerialIndex();
//        long long16 = day13.getLastMillisecond();
//        java.util.Date date17 = day13.getStart();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
//        java.lang.Class<?> wildcardClass30 = simpleTimePeriod27.getClass();
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
//        java.util.Date date43 = simpleTimePeriod40.getEnd();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date43);
//        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener50 = null;
//        timePeriodValues49.addPropertyChangeListener(propertyChangeListener50);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues49.add((org.jfree.data.time.TimePeriod) simpleTimePeriod54, 10.0d);
//        java.util.Date date57 = simpleTimePeriod54.getEnd();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date57);
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date57, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date43, timeZone60);
//        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date17, timeZone60);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date12, timeZone60);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date4, timeZone60);
//        try {
//            org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date0, timeZone60);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560495599999L + "'", long16 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        int int5 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        long long12 = simpleTimePeriod8.getStartMillis();
        java.lang.Object obj13 = null;
        boolean boolean14 = simpleTimePeriod8.equals(obj13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) boolean14);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, 10.0d);
        java.lang.Class<?> wildcardClass23 = simpleTimePeriod20.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) simpleTimePeriod33, 10.0d);
        java.util.Date date36 = simpleTimePeriod33.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues42.addPropertyChangeListener(propertyChangeListener43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues42.add((org.jfree.data.time.TimePeriod) simpleTimePeriod47, 10.0d);
        java.util.Date date50 = simpleTimePeriod47.getEnd();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date50, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date36, timeZone53);
        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        boolean boolean57 = simpleTimePeriod8.equals((java.lang.Object) wildcardClass23);
        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timePeriodValues61.addPropertyChangeListener(propertyChangeListener62);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues61.add((org.jfree.data.time.TimePeriod) simpleTimePeriod66, 10.0d);
        int int69 = timePeriodValues61.getMaxMiddleIndex();
        boolean boolean70 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues61);
        java.lang.Class<?> wildcardClass71 = timePeriodValues61.getClass();
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(wildcardClass71);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 2019);
        timePeriodValue3.setValue((java.lang.Number) 10.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        int int4 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        java.lang.String str6 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        long long5 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        long long13 = day12.getMiddleMillisecond();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 2019);
        boolean boolean18 = day12.equals((java.lang.Object) timePeriodValue17);
        boolean boolean20 = timePeriodValue17.equals((java.lang.Object) 3);
        boolean boolean22 = timePeriodValue17.equals((java.lang.Object) 2);
        java.lang.Number number23 = timePeriodValue17.getValue();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        timePeriodValues27.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues27.removeChangeListener(seriesChangeListener32);
        timePeriodValues27.setKey((java.lang.Comparable) 1.0f);
        int int36 = timePeriodValues27.getMinMiddleIndex();
        int int37 = timePeriodValues27.getMinMiddleIndex();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.lang.String str39 = year38.toString();
        boolean boolean40 = timePeriodValues27.equals((java.lang.Object) year38);
        java.lang.Object obj41 = timePeriodValues27.clone();
        timePeriodValues27.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        boolean boolean44 = timePeriodValue17.equals((java.lang.Object) timePeriodValues27);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-14400001L) + "'", long13 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 2019.0d + "'", number23.equals(2019.0d));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "2019" + "'", str39.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        long long44 = simpleTimePeriod40.getStartMillis();
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod40.equals(obj45);
        boolean boolean47 = year9.equals((java.lang.Object) simpleTimePeriod40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year9.next();
        java.util.Date date49 = regularTimePeriod48.getStart();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, 10.0d);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 13);
        int int39 = timePeriodValues3.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener40);
        java.lang.String str42 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        int int7 = day0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "hi!", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: 2019");
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        long long3 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
//        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues3.getTimePeriod(0);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.String str29 = day28.toString();
//        long long30 = day28.getSerialIndex();
//        long long31 = day28.getLastMillisecond();
//        boolean boolean33 = day28.equals((java.lang.Object) "hi!");
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) 1560452399999L);
//        java.util.Calendar calendar36 = null;
//        try {
//            long long37 = day28.getLastMillisecond(calendar36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timePeriod27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43629L + "'", long30 == 43629L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560495599999L + "'", long31 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date11, timeZone14);
        long long16 = day15.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, 10.0d);
        java.util.Date date19 = simpleTimePeriod16.getEnd();
        long long20 = simpleTimePeriod16.getStartMillis();
        boolean boolean21 = timePeriodValues6.equals((java.lang.Object) simpleTimePeriod16);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        long long44 = simpleTimePeriod40.getStartMillis();
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod40.equals(obj45);
        boolean boolean47 = year9.equals((java.lang.Object) simpleTimePeriod40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year9.next();
        java.util.Calendar calendar49 = null;
        try {
            year9.peg(calendar49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 2019);
        org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValue3.getPeriod();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(timePeriod4);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        int int7 = day0.compareTo((java.lang.Object) (short) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '4', (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "org.jfree.data.time.TimePeriodFormatException: ", "13-June-2019");
        timePeriodValues3.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue6 = timePeriodValues3.getDataItem(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.lang.Comparable comparable4 = null;
        try {
            timePeriodValues3.setKey(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) 0.0f);
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        boolean boolean12 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + "hi!" + "'", comparable11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        java.lang.Object obj7 = timePeriodValues6.clone();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues6.createCopy((int) '4', (-1));
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues14.createCopy(11, 11);
        boolean boolean18 = timePeriodValues17.getNotify();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(timePeriodValues14);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
//        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues3.getTimePeriod(0);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.String str29 = day28.toString();
//        long long30 = day28.getSerialIndex();
//        long long31 = day28.getLastMillisecond();
//        boolean boolean33 = day28.equals((java.lang.Object) "hi!");
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) 1560452399999L);
//        try {
//            java.lang.Object obj36 = timePeriodValues3.clone();
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(timePeriod27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43629L + "'", long30 == 43629L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560495599999L + "'", long31 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9);
        long long15 = year9.getSerialIndex();
        java.lang.String str16 = year9.toString();
        java.util.Calendar calendar17 = null;
        try {
            year9.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
        timePeriodValues3.add(timePeriodValue24);
        java.lang.Object obj26 = timePeriodValue24.clone();
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        java.lang.Object obj17 = timePeriodValues3.clone();
        int int18 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = null;
        try {
            timePeriodValues3.add(timePeriodValue21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
//        java.lang.Class<?> wildcardClass17 = simpleTimePeriod14.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
//        java.util.Date date30 = simpleTimePeriod27.getEnd();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30);
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timePeriodValues36.addPropertyChangeListener(propertyChangeListener37);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues36.add((org.jfree.data.time.TimePeriod) simpleTimePeriod41, 10.0d);
//        java.util.Date date44 = simpleTimePeriod41.getEnd();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date44);
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date44, timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date30, timeZone47);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date4, timeZone47);
//        int int51 = year50.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
        timePeriodValues3.add(timePeriodValue24);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        boolean boolean28 = timePeriodValue24.equals((java.lang.Object) timePeriodValues27);
        java.lang.Number number29 = timePeriodValue24.getValue();
        timePeriodValue24.setValue((java.lang.Number) 100.0f);
        timePeriodValue24.setValue((java.lang.Number) (byte) 10);
        org.jfree.data.time.TimePeriod timePeriod34 = timePeriodValue24.getPeriod();
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) 10 + "'", number29.equals((byte) 10));
        org.junit.Assert.assertNotNull(timePeriod34);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setRangeDescription("hi!");
//        java.lang.Object obj9 = timePeriodValues3.clone();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod18, "13-June-2019", "13-June-2019");
//        java.util.Date date24 = simpleTimePeriod18.getStart();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.lang.String str26 = day25.toString();
//        long long27 = day25.getSerialIndex();
//        java.lang.Object obj28 = null;
//        int int29 = day25.compareTo(obj28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day25.next();
//        java.util.Date date31 = regularTimePeriod30.getEnd();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
//        boolean boolean33 = simpleTimePeriod18.equals((java.lang.Object) date31);
//        java.lang.Number number34 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, number34);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (double) 100.0f);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43629L + "'", long27 == 43629L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        long long11 = simpleTimePeriod8.getEndMillis();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        java.lang.Object obj15 = null;
//        int int16 = day12.compareTo(obj15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day12.next();
//        long long18 = day12.getMiddleMillisecond();
//        try {
//            int int19 = simpleTimePeriod8.compareTo((java.lang.Object) long18);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560452399999L + "'", long18 == 1560452399999L);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMinStartIndex();
        int int7 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        int int4 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        long long9 = day7.getSerialIndex();
//        java.lang.Object obj10 = null;
//        int int11 = day7.compareTo(obj10);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
//        boolean boolean15 = day6.equals((java.lang.Object) day14);
//        long long16 = day14.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43629L + "'", long16 == 43629L);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        java.util.Date date18 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        java.util.Date date30 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date18, date30);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30);
        java.util.Calendar calendar34 = null;
        try {
            long long35 = day33.getLastMillisecond(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date30);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        java.util.Date date11 = simpleTimePeriod8.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date11, timeZone59);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year64.next();
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        try {
            timePeriodValues3.delete((-1), 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, 10.0d);
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date11, date25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues33.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues33.add((org.jfree.data.time.TimePeriod) simpleTimePeriod38, 10.0d);
        java.util.Date date41 = simpleTimePeriod38.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        long long43 = day42.getMiddleMillisecond();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        long long45 = year44.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year44, (double) 2019);
        boolean boolean48 = day42.equals((java.lang.Object) timePeriodValue47);
        boolean boolean49 = year29.equals((java.lang.Object) timePeriodValue47);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-14400001L) + "'", long43 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
//        long long10 = day9.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 8);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day9.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        int int17 = year14.getYear();
        boolean boolean19 = year14.equals((java.lang.Object) "TimePeriodValue[13-June-2019,null]");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.lang.String str10 = timePeriodValues3.getDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues3.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str10);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
//        long long10 = day9.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 8);
//        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue12.getPeriod();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNotNull(timePeriod13);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        java.util.Date date33 = simpleTimePeriod14.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues37.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 10.0d);
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date45, timeZone48);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date33, date45);
        java.util.Date date51 = simpleTimePeriod50.getEnd();
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(date51);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues6.getClass();
        java.lang.Object obj9 = timePeriodValues6.clone();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "org.jfree.data.time.TimePeriodFormatException: ", "13-June-2019");
        timePeriodValues3.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValues3.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.lang.String str10 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1969, (int) (byte) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        java.lang.String str27 = timePeriodValues3.getRangeDescription();
        int int28 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str26.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: 2019");
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (-1.0d) + "'", obj3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        int int4 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        long long6 = day0.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        java.lang.String str17 = timePeriodValues3.getDescription();
        int int18 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        long long44 = simpleTimePeriod40.getStartMillis();
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod40.equals(obj45);
        boolean boolean47 = year9.equals((java.lang.Object) simpleTimePeriod40);
        java.util.Date date48 = simpleTimePeriod40.getStart();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(2019);
        java.util.Date date51 = year50.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod(date48, date51);
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues59 = timePeriodValues56.createCopy((int) (short) -1, 11);
        int int60 = timePeriodValues59.getMaxStartIndex();
        java.lang.Class<?> wildcardClass61 = timePeriodValues59.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues65 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timePeriodValues65.addPropertyChangeListener(propertyChangeListener66);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues65.add((org.jfree.data.time.TimePeriod) simpleTimePeriod70, 10.0d);
        java.util.Date date73 = simpleTimePeriod70.getEnd();
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date73);
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date73);
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date73, timeZone76);
        java.util.TimeZone timeZone78 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date73, timeZone78);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod80 = new org.jfree.data.time.SimpleTimePeriod(date51, date73);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timePeriodValues59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNull(regularTimePeriod79);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("");
        int int9 = timePeriodValues3.getMinStartIndex();
        int int10 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod19);
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) (byte) 10);
        java.lang.Number number26 = timePeriodValue25.getValue();
        java.lang.String str27 = timePeriodValue25.toString();
        java.lang.Number number28 = null;
        timePeriodValue25.setValue(number28);
        timePeriodValues3.add(timePeriodValue25);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
        java.lang.String str37 = timePeriodValues34.getRangeDescription();
        timePeriodValues34.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        java.lang.String str41 = year40.toString();
        int int42 = year40.getYear();
        timePeriodValues34.setKey((java.lang.Comparable) year40);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year40, (java.lang.Number) 2019.0d);
        java.util.Calendar calendar46 = null;
        try {
            year40.peg(calendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (byte) 10 + "'", number26.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2019" + "'", str41.equals("2019"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        int int3 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues17.addChangeListener(seriesChangeListener18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues23.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, 10.0d);
        timePeriodValues17.setKey((java.lang.Comparable) simpleTimePeriod28);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        timePeriodValues35.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
        timePeriodValues35.removeChangeListener(seriesChangeListener40);
        timePeriodValues35.setKey((java.lang.Comparable) 1.0f);
        int int44 = timePeriodValues35.getMinMiddleIndex();
        int int45 = timePeriodValues35.getMinMiddleIndex();
        boolean boolean46 = simpleTimePeriod28.equals((java.lang.Object) timePeriodValues35);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (java.lang.Number) 1562097599999L);
        long long49 = simpleTimePeriod28.getEndMillis();
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues3.getRangeDescription();
//        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        java.lang.String str10 = year9.toString();
//        int int11 = year9.getYear();
//        timePeriodValues3.setKey((java.lang.Comparable) year9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
//        timePeriodValues16.addChangeListener(seriesChangeListener17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
//        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
//        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year9.next();
//        long long33 = year9.getFirstMillisecond();
//        long long34 = year9.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) 13);
//        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues43 = timePeriodValues40.createCopy((int) (short) -1, 11);
//        java.lang.Object obj44 = timePeriodValues43.clone();
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timePeriodValues43.addPropertyChangeListener(propertyChangeListener45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        long long48 = day47.getSerialIndex();
//        java.util.Date date49 = day47.getEnd();
//        long long50 = day47.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue52 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day47, (java.lang.Number) (short) -1);
//        java.lang.Number number53 = null;
//        timePeriodValue52.setValue(number53);
//        timePeriodValues43.add(timePeriodValue52);
//        int int56 = year9.compareTo((java.lang.Object) timePeriodValue52);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2019L + "'", long34 == 2019L);
//        org.junit.Assert.assertNotNull(timePeriodValues43);
//        org.junit.Assert.assertNotNull(obj44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 43629L + "'", long48 == 43629L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560495599999L + "'", long50 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("");
//        int int9 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        boolean boolean13 = timePeriodValues3.equals((java.lang.Object) day10);
//        java.lang.String str14 = day10.toString();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        java.lang.Class<?> wildcardClass11 = simpleTimePeriod8.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getSerialIndex();
//        java.util.Date date15 = day13.getEnd();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        long long18 = day16.getSerialIndex();
//        long long19 = day16.getLastMillisecond();
//        java.util.Date date20 = day16.getStart();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        java.util.Date date22 = day21.getStart();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getSerialIndex();
//        java.lang.Class<?> wildcardClass25 = day23.getClass();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        long long28 = day26.getSerialIndex();
//        long long29 = day26.getLastMillisecond();
//        java.util.Date date30 = day26.getStart();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        long long33 = day31.getSerialIndex();
//        long long34 = day31.getLastMillisecond();
//        java.util.Date date35 = day31.getStart();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
//        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener41 = null;
//        timePeriodValues40.addPropertyChangeListener(propertyChangeListener41);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues40.add((org.jfree.data.time.TimePeriod) simpleTimePeriod45, 10.0d);
//        java.lang.Class<?> wildcardClass48 = simpleTimePeriod45.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener54 = null;
//        timePeriodValues53.addPropertyChangeListener(propertyChangeListener54);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues53.add((org.jfree.data.time.TimePeriod) simpleTimePeriod58, 10.0d);
//        java.util.Date date61 = simpleTimePeriod58.getEnd();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date61);
//        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener68 = null;
//        timePeriodValues67.addPropertyChangeListener(propertyChangeListener68);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod72 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues67.add((org.jfree.data.time.TimePeriod) simpleTimePeriod72, 10.0d);
//        java.util.Date date75 = simpleTimePeriod72.getEnd();
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date75);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date75);
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date75, timeZone78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date61, timeZone78);
//        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year(date35, timeZone78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date30, timeZone78);
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date22, timeZone78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone78);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43629L + "'", long24 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43629L + "'", long28 == 43629L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560495599999L + "'", long29 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13-June-2019" + "'", str32.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560495599999L + "'", long34 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNull(regularTimePeriod84);
//    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test306");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        timePeriodValues3.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener8);
//        int int10 = timePeriodValues3.getMinEndIndex();
//        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        java.lang.Object obj15 = null;
//        int int16 = day12.compareTo(obj15);
//        int int17 = day12.getMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate18);
//        java.lang.String str21 = day20.toString();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day20, (double) 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + "hi!" + "'", comparable11.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("");
//        int int9 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        boolean boolean13 = timePeriodValues3.equals((java.lang.Object) day10);
//        int int14 = day10.getMonth();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setNotify(false);
        int int16 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        int int17 = year14.getYear();
        java.util.Date date18 = year14.getEnd();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year14.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues3.getMaxEndIndex();
        java.lang.Object obj32 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
        timePeriodValues36.addChangeListener(seriesChangeListener37);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues42.addPropertyChangeListener(propertyChangeListener43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues42.add((org.jfree.data.time.TimePeriod) simpleTimePeriod47, 10.0d);
        timePeriodValues36.setKey((java.lang.Comparable) simpleTimePeriod47);
        java.util.Date date51 = simpleTimePeriod47.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues55.addPropertyChangeListener(propertyChangeListener56);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) simpleTimePeriod60, 10.0d);
        java.util.Date date63 = simpleTimePeriod60.getEnd();
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date63);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod65 = new org.jfree.data.time.SimpleTimePeriod(date51, date63);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date63);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day66, (double) 100.0f);
        java.lang.String str69 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.TimePeriodValue timePeriodValue71 = timePeriodValues3.getDataItem(0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str26.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "hi!" + "'", str69.equals("hi!"));
        org.junit.Assert.assertNotNull(timePeriodValue71);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.lang.String str13 = day12.toString();
        java.util.Date date14 = day12.getEnd();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(date14);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8, "13-June-2019", "13-June-2019");
//        timePeriodValues13.fireSeriesChanged();
//        java.lang.Comparable comparable15 = timePeriodValues13.getKey();
//        timePeriodValues13.setNotify(false);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        long long19 = day18.getSerialIndex();
//        java.util.Date date20 = day18.getEnd();
//        long long21 = day18.getLastMillisecond();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        long long24 = day22.getSerialIndex();
//        long long25 = day22.getLastMillisecond();
//        boolean boolean27 = day22.equals((java.lang.Object) "hi!");
//        boolean boolean28 = day18.equals((java.lang.Object) boolean27);
//        boolean boolean30 = day18.equals((java.lang.Object) 13);
//        java.util.Date date31 = day18.getStart();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
//        boolean boolean33 = timePeriodValues13.equals((java.lang.Object) date31);
//        java.lang.Object obj34 = timePeriodValues13.clone();
//        int int35 = timePeriodValues13.getMinStartIndex();
//        org.junit.Assert.assertNotNull(comparable15);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560495599999L + "'", long21 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43629L + "'", long24 == 43629L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560495599999L + "'", long25 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
//    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = day4.getClass();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        long long9 = day7.getSerialIndex();
//        long long10 = day7.getLastMillisecond();
//        java.util.Date date11 = day7.getStart();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date11, timeZone59);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date3, timeZone59);
//        java.lang.Class<?> wildcardClass65 = day64.getClass();
//        java.util.Calendar calendar66 = null;
//        try {
//            long long67 = day64.getLastMillisecond(calendar66);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(wildcardClass65);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        boolean boolean10 = timePeriodValues3.equals((java.lang.Object) 0.0f);
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        boolean boolean12 = timePeriodValues3.isEmpty();
        int int13 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + "hi!" + "'", comparable11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        int int9 = year1.compareTo((java.lang.Object) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        java.lang.String str16 = timePeriodValues13.getRangeDescription();
        timePeriodValues13.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.lang.String str20 = year19.toString();
        int int21 = year19.getYear();
        timePeriodValues13.setKey((java.lang.Comparable) year19);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timePeriodValues26.addChangeListener(seriesChangeListener27);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues32.addPropertyChangeListener(propertyChangeListener33);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues32.add((org.jfree.data.time.TimePeriod) simpleTimePeriod37, 10.0d);
        timePeriodValues26.setKey((java.lang.Comparable) simpleTimePeriod37);
        boolean boolean41 = year19.equals((java.lang.Object) timePeriodValues26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year19.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year19.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues47.addPropertyChangeListener(propertyChangeListener48);
        timePeriodValues47.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener52 = null;
        timePeriodValues47.removeChangeListener(seriesChangeListener52);
        timePeriodValues47.setKey((java.lang.Comparable) 1.0f);
        int int56 = timePeriodValues47.getMinMiddleIndex();
        int int57 = timePeriodValues47.getMinMiddleIndex();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        java.lang.String str59 = year58.toString();
        boolean boolean60 = timePeriodValues47.equals((java.lang.Object) year58);
        java.lang.Object obj61 = timePeriodValues47.clone();
        int int62 = timePeriodValues47.getMinStartIndex();
        timePeriodValues47.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        boolean boolean65 = year19.equals((java.lang.Object) timePeriodValues47);
        boolean boolean66 = year1.equals((java.lang.Object) boolean65);
        long long67 = year1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "2019" + "'", str59.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(obj61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1546329600000L + "'", long67 == 1546329600000L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.fireSeriesChanged();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues3.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + "hi!" + "'", comparable7.equals("hi!"));
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 3);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMinEndIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        java.lang.Object obj17 = timePeriodValues3.clone();
        int int18 = timePeriodValues3.getMinStartIndex();
        boolean boolean19 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        java.lang.String str7 = timePeriodValues6.getDescription();
        int int8 = timePeriodValues6.getMinEndIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        java.util.Date date11 = simpleTimePeriod8.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date11);
//        java.util.Date date15 = day14.getStart();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        long long18 = day16.getSerialIndex();
//        long long19 = day16.getLastMillisecond();
//        java.util.Date date20 = day16.getStart();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues25.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, 10.0d);
//        java.lang.Class<?> wildcardClass33 = simpleTimePeriod30.getClass();
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timePeriodValues38.addPropertyChangeListener(propertyChangeListener39);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues38.add((org.jfree.data.time.TimePeriod) simpleTimePeriod43, 10.0d);
//        java.util.Date date46 = simpleTimePeriod43.getEnd();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date46);
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener53 = null;
//        timePeriodValues52.addPropertyChangeListener(propertyChangeListener53);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues52.add((org.jfree.data.time.TimePeriod) simpleTimePeriod57, 10.0d);
//        java.util.Date date60 = simpleTimePeriod57.getEnd();
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date60);
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date60, timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date46, timeZone63);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date20, timeZone63);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date15, timeZone63);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Date date6 = regularTimePeriod5.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues10.addChangeListener(seriesChangeListener11);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
//        timePeriodValues10.setKey((java.lang.Comparable) simpleTimePeriod21);
//        java.util.Date date25 = simpleTimePeriod21.getEnd();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.lang.String str28 = year27.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
//        java.util.Date date30 = regularTimePeriod29.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date42, timeZone45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date30, timeZone45);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date25, timeZone45);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date6, timeZone45);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        java.lang.String str51 = day50.toString();
//        long long52 = day50.getSerialIndex();
//        java.lang.Object obj53 = null;
//        int int54 = day50.compareTo(obj53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day50.next();
//        java.util.Date date56 = regularTimePeriod55.getEnd();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod(date6, date56);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "13-June-2019" + "'", str51.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 43629L + "'", long52 == 43629L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(date56);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        long long44 = simpleTimePeriod40.getStartMillis();
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod40.equals(obj45);
        boolean boolean47 = year9.equals((java.lang.Object) simpleTimePeriod40);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod40, "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesException: hi!");
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str51.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        int int4 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setNotify(true);
        boolean boolean7 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 4, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
//        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
//        java.util.Date date18 = simpleTimePeriod14.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
//        java.util.Date date30 = simpleTimePeriod27.getEnd();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date18, date30);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        long long35 = day33.getSerialIndex();
//        java.lang.Object obj36 = null;
//        int int37 = day33.compareTo(obj36);
//        int int38 = day33.getMonth();
//        org.jfree.data.time.SerialDate serialDate39 = day33.getSerialDate();
//        java.util.Date date40 = day33.getEnd();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40, timeZone41);
//        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener47 = null;
//        timePeriodValues46.addPropertyChangeListener(propertyChangeListener47);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues46.add((org.jfree.data.time.TimePeriod) simpleTimePeriod51, 10.0d);
//        java.lang.Class<?> wildcardClass54 = simpleTimePeriod51.getClass();
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
//        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener60 = null;
//        timePeriodValues59.addPropertyChangeListener(propertyChangeListener60);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues59.add((org.jfree.data.time.TimePeriod) simpleTimePeriod64, 10.0d);
//        java.util.Date date67 = simpleTimePeriod64.getEnd();
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date67);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date67);
//        org.jfree.data.time.TimePeriodValues timePeriodValues73 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener74 = null;
//        timePeriodValues73.addPropertyChangeListener(propertyChangeListener74);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod78 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues73.add((org.jfree.data.time.TimePeriod) simpleTimePeriod78, 10.0d);
//        java.util.Date date81 = simpleTimePeriod78.getEnd();
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date81);
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date81);
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date81, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date67, timeZone84);
//        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(date40, timeZone84);
//        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date30, timeZone84);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43629L + "'", long35 == 43629L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(class55);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        int int4 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day7.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        java.util.Date date11 = simpleTimePeriod8.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        long long13 = day12.getMiddleMillisecond();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 2019);
//        boolean boolean18 = day12.equals((java.lang.Object) timePeriodValue17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        java.lang.String str20 = year19.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
//        java.util.Date date22 = regularTimePeriod21.getEnd();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getSerialIndex();
//        java.lang.Class<?> wildcardClass25 = day23.getClass();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        long long28 = day26.getSerialIndex();
//        long long29 = day26.getLastMillisecond();
//        java.util.Date date30 = day26.getStart();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        long long33 = day31.getSerialIndex();
//        long long34 = day31.getLastMillisecond();
//        java.util.Date date35 = day31.getStart();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
//        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener41 = null;
//        timePeriodValues40.addPropertyChangeListener(propertyChangeListener41);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues40.add((org.jfree.data.time.TimePeriod) simpleTimePeriod45, 10.0d);
//        java.lang.Class<?> wildcardClass48 = simpleTimePeriod45.getClass();
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener54 = null;
//        timePeriodValues53.addPropertyChangeListener(propertyChangeListener54);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues53.add((org.jfree.data.time.TimePeriod) simpleTimePeriod58, 10.0d);
//        java.util.Date date61 = simpleTimePeriod58.getEnd();
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date61);
//        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener68 = null;
//        timePeriodValues67.addPropertyChangeListener(propertyChangeListener68);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod72 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues67.add((org.jfree.data.time.TimePeriod) simpleTimePeriod72, 10.0d);
//        java.util.Date date75 = simpleTimePeriod72.getEnd();
//        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date75);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date75);
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date75, timeZone78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date61, timeZone78);
//        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year(date35, timeZone78);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date30, timeZone78);
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date22, timeZone78);
//        boolean boolean84 = timePeriodValue17.equals((java.lang.Object) date22);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-14400001L) + "'", long13 == (-14400001L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43629L + "'", long24 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43629L + "'", long28 == 43629L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560495599999L + "'", long29 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13-June-2019" + "'", str32.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560495599999L + "'", long34 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        long long13 = day12.getMiddleMillisecond();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day12.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-14400001L) + "'", long13 == (-14400001L));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "org.jfree.data.time.TimePeriodFormatException: ", "13-June-2019");
        boolean boolean5 = year0.equals((java.lang.Object) 13);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        long long6 = day4.getSerialIndex();
//        long long7 = day4.getLastMillisecond();
//        boolean boolean9 = day4.equals((java.lang.Object) "hi!");
//        boolean boolean10 = day0.equals((java.lang.Object) boolean9);
//        boolean boolean12 = day0.equals((java.lang.Object) 13);
//        java.util.Date date13 = day0.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.SerialDate serialDate15 = day14.getSerialDate();
//        java.util.Calendar calendar16 = null;
//        try {
//            day14.peg(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate15);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        java.lang.Object obj7 = timePeriodValues6.clone();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener8);
        java.lang.String str10 = timePeriodValues6.getDescription();
        boolean boolean11 = timePeriodValues6.getNotify();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        timePeriodValues3.setKey((java.lang.Comparable) 11);
        int int31 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str26.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        long long11 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, 10.0d);
        int int23 = simpleTimePeriod8.compareTo((java.lang.Object) simpleTimePeriod20);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        java.lang.String str30 = timePeriodValues27.getRangeDescription();
        timePeriodValues27.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        java.lang.String str34 = year33.toString();
        int int35 = year33.getYear();
        timePeriodValues27.setKey((java.lang.Comparable) year33);
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        timePeriodValues40.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timePeriodValues46.addPropertyChangeListener(propertyChangeListener47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues46.add((org.jfree.data.time.TimePeriod) simpleTimePeriod51, 10.0d);
        timePeriodValues40.setKey((java.lang.Comparable) simpleTimePeriod51);
        boolean boolean55 = year33.equals((java.lang.Object) timePeriodValues40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year33.next();
        long long57 = year33.getFirstMillisecond();
        long long58 = year33.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue60 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (double) 13);
        try {
            int int61 = simpleTimePeriod8.compareTo((java.lang.Object) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1546329600000L + "'", long57 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 2019L + "'", long58 == 2019L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod17, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues23.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, 10.0d);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener33);
        java.lang.String str35 = timePeriodValues12.getDomainDescription();
        timePeriodValues12.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        timePeriodValues12.setKey((java.lang.Comparable) 11);
        timePeriodValues12.fireSeriesChanged();
        boolean boolean41 = timePeriodValues3.equals((java.lang.Object) timePeriodValues12);
        int int42 = timePeriodValues12.getMinEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod44 = timePeriodValues12.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str35.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        java.lang.Class<?> wildcardClass3 = year0.getClass();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
//        int int7 = timePeriodValues6.getMaxStartIndex();
//        java.lang.Class<?> wildcardClass8 = timePeriodValues6.getClass();
//        int int9 = timePeriodValues6.getMaxEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues13.createCopy((int) (short) -1, 11);
//        java.lang.Object obj17 = timePeriodValues16.clone();
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues16.addPropertyChangeListener(propertyChangeListener18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getSerialIndex();
//        java.util.Date date22 = day20.getEnd();
//        long long23 = day20.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) (short) -1);
//        java.lang.Number number26 = null;
//        timePeriodValue25.setValue(number26);
//        timePeriodValues16.add(timePeriodValue25);
//        timePeriodValues6.add(timePeriodValue25);
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues16);
//        org.junit.Assert.assertNotNull(obj17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43629L + "'", long21 == 43629L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560495599999L + "'", long23 == 1560495599999L);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: 2019");
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues36.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues36.add((org.jfree.data.time.TimePeriod) simpleTimePeriod41, 10.0d);
        java.util.Date date44 = simpleTimePeriod41.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod41);
        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod41, (java.lang.Number) (byte) 10);
        boolean boolean49 = timePeriodValue47.equals((java.lang.Object) 1560495599999L);
        org.jfree.data.time.TimePeriod timePeriod50 = timePeriodValue47.getPeriod();
        timePeriodValues21.add(timePeriodValue47);
        java.lang.String str52 = timePeriodValue47.toString();
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(timePeriod50);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        try {
            timePeriodValues1.delete(6, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        try {
//            day0.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        int int13 = timePeriodValues3.getItemCount();
        java.lang.String str14 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str14.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Object obj9 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getLastMillisecond();
        java.lang.Object obj4 = null;
        boolean boolean5 = year0.equals(obj4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues6.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod17, 10.0d);
        java.util.Date date20 = simpleTimePeriod17.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date20, timeZone23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date20, timeZone25);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues30.add((org.jfree.data.time.TimePeriod) simpleTimePeriod35, 10.0d);
        java.util.Date date38 = simpleTimePeriod35.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timePeriodValues44.addPropertyChangeListener(propertyChangeListener45);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues44.add((org.jfree.data.time.TimePeriod) simpleTimePeriod49, 10.0d);
        java.util.Date date52 = simpleTimePeriod49.getEnd();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date38, date52);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod55 = new org.jfree.data.time.SimpleTimePeriod(date20, date52);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date52);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date52);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = day4.getClass();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        long long9 = day7.getSerialIndex();
//        long long10 = day7.getLastMillisecond();
//        java.util.Date date11 = day7.getStart();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date11, timeZone59);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date3, timeZone59);
//        org.jfree.data.time.TimePeriodValues timePeriodValues68 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener69 = null;
//        timePeriodValues68.addPropertyChangeListener(propertyChangeListener69);
//        timePeriodValues68.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener73 = null;
//        timePeriodValues68.removeChangeListener(seriesChangeListener73);
//        timePeriodValues68.setKey((java.lang.Comparable) 1.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener77 = null;
//        timePeriodValues68.removeChangeListener(seriesChangeListener77);
//        java.lang.Object obj79 = timePeriodValues68.clone();
//        int int80 = day64.compareTo(obj79);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(obj79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
//    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
//        java.lang.Class<?> wildcardClass17 = simpleTimePeriod14.getClass();
//        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
//        java.util.Date date30 = simpleTimePeriod27.getEnd();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30);
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timePeriodValues36.addPropertyChangeListener(propertyChangeListener37);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues36.add((org.jfree.data.time.TimePeriod) simpleTimePeriod41, 10.0d);
//        java.util.Date date44 = simpleTimePeriod41.getEnd();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date44);
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date44, timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date30, timeZone47);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date4, timeZone47);
//        java.lang.String str51 = year50.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(class18);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2019" + "'", str51.equals("2019"));
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener4);
//        timePeriodValues3.setRangeDescription("13-June-2019");
//        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
//        java.util.Date date21 = simpleTimePeriod18.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
//        timePeriodValues3.add(timePeriodValue24);
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
//        boolean boolean28 = timePeriodValue24.equals((java.lang.Object) timePeriodValues27);
//        java.lang.Number number29 = timePeriodValue24.getValue();
//        org.jfree.data.time.TimePeriod timePeriod30 = timePeriodValue24.getPeriod();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        long long32 = day31.getSerialIndex();
//        java.util.Date date33 = day31.getEnd();
//        long long34 = day31.getLastMillisecond();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        long long37 = day35.getSerialIndex();
//        long long38 = day35.getLastMillisecond();
//        boolean boolean40 = day35.equals((java.lang.Object) "hi!");
//        boolean boolean41 = day31.equals((java.lang.Object) boolean40);
//        boolean boolean43 = day31.equals((java.lang.Object) 13);
//        org.jfree.data.time.SerialDate serialDate44 = day31.getSerialDate();
//        boolean boolean45 = timePeriodValue24.equals((java.lang.Object) serialDate44);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) 10 + "'", number29.equals((byte) 10));
//        org.junit.Assert.assertNotNull(timePeriod30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43629L + "'", long32 == 43629L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560495599999L + "'", long34 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 43629L + "'", long37 == 43629L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560495599999L + "'", long38 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        long long32 = year9.getFirstMillisecond();
        long long33 = year9.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1562097599999L + "'", long33 == 1562097599999L);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener8);
//        int int10 = timePeriodValues7.getMaxStartIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
//        java.lang.String str26 = timePeriodValues3.getDomainDescription();
//        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener29);
//        int int31 = timePeriodValues3.getMaxEndIndex();
//        java.lang.Object obj32 = timePeriodValues3.clone();
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timePeriodValues36.addChangeListener(seriesChangeListener37);
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener43 = null;
//        timePeriodValues42.addPropertyChangeListener(propertyChangeListener43);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues42.add((org.jfree.data.time.TimePeriod) simpleTimePeriod47, 10.0d);
//        timePeriodValues36.setKey((java.lang.Comparable) simpleTimePeriod47);
//        java.util.Date date51 = simpleTimePeriod47.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener56 = null;
//        timePeriodValues55.addPropertyChangeListener(propertyChangeListener56);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues55.add((org.jfree.data.time.TimePeriod) simpleTimePeriod60, 10.0d);
//        java.util.Date date63 = simpleTimePeriod60.getEnd();
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date63);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod65 = new org.jfree.data.time.SimpleTimePeriod(date51, date63);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date63);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day66, (double) 100.0f);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        long long70 = day69.getSerialIndex();
//        java.util.Date date71 = day69.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day69.previous();
//        int int73 = day69.getMonth();
//        org.jfree.data.time.SerialDate serialDate74 = day69.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue76 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day69, (java.lang.Number) 4);
//        org.jfree.data.time.TimePeriod timePeriod77 = timePeriodValue76.getPeriod();
//        boolean boolean78 = day66.equals((java.lang.Object) timePeriodValue76);
//        timePeriodValue76.setValue((java.lang.Number) 0.0f);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str26.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(obj32);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 43629L + "'", long70 == 43629L);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 6 + "'", int73 == 6);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(timePeriod77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        int int24 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.update(0, (java.lang.Number) 1.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod17, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues23.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, 10.0d);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener33);
        java.lang.String str35 = timePeriodValues12.getDomainDescription();
        timePeriodValues12.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        timePeriodValues12.setKey((java.lang.Comparable) 11);
        timePeriodValues12.fireSeriesChanged();
        boolean boolean41 = timePeriodValues3.equals((java.lang.Object) timePeriodValues12);
        timePeriodValues12.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str35.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        long long44 = simpleTimePeriod40.getStartMillis();
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod40.equals(obj45);
        boolean boolean47 = year9.equals((java.lang.Object) simpleTimePeriod40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year9.next();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        java.util.Date date6 = day5.getStart();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = day7.getClass();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        long long12 = day10.getSerialIndex();
//        long long13 = day10.getLastMillisecond();
//        java.util.Date date14 = day10.getStart();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        long long17 = day15.getSerialIndex();
//        long long18 = day15.getLastMillisecond();
//        java.util.Date date19 = day15.getStart();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timePeriodValues24.addPropertyChangeListener(propertyChangeListener25);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues24.add((org.jfree.data.time.TimePeriod) simpleTimePeriod29, 10.0d);
//        java.lang.Class<?> wildcardClass32 = simpleTimePeriod29.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 10.0d);
//        java.util.Date date45 = simpleTimePeriod42.getEnd();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45);
//        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener52 = null;
//        timePeriodValues51.addPropertyChangeListener(propertyChangeListener52);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues51.add((org.jfree.data.time.TimePeriod) simpleTimePeriod56, 10.0d);
//        java.util.Date date59 = simpleTimePeriod56.getEnd();
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date59);
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date59, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date45, timeZone62);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date19, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone62);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date6, timeZone62);
//        java.util.Calendar calendar68 = null;
//        try {
//            long long69 = day67.getFirstMillisecond(calendar68);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560495599999L + "'", long18 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        int int17 = year14.getYear();
        java.lang.String str18 = year14.toString();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9);
        long long15 = year9.getSerialIndex();
        java.lang.String str16 = year9.toString();
        long long17 = year9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year9.previous();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        java.util.Date date6 = day5.getStart();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        long long8 = day7.getSerialIndex();
//        java.lang.Class<?> wildcardClass9 = day7.getClass();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        long long12 = day10.getSerialIndex();
//        long long13 = day10.getLastMillisecond();
//        java.util.Date date14 = day10.getStart();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        long long17 = day15.getSerialIndex();
//        long long18 = day15.getLastMillisecond();
//        java.util.Date date19 = day15.getStart();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timePeriodValues24.addPropertyChangeListener(propertyChangeListener25);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues24.add((org.jfree.data.time.TimePeriod) simpleTimePeriod29, 10.0d);
//        java.lang.Class<?> wildcardClass32 = simpleTimePeriod29.getClass();
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 10.0d);
//        java.util.Date date45 = simpleTimePeriod42.getEnd();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45);
//        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener52 = null;
//        timePeriodValues51.addPropertyChangeListener(propertyChangeListener52);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues51.add((org.jfree.data.time.TimePeriod) simpleTimePeriod56, 10.0d);
//        java.util.Date date59 = simpleTimePeriod56.getEnd();
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date59);
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date59, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date45, timeZone62);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date19, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone62);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date6, timeZone62);
//        java.util.Date date68 = day67.getEnd();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560495599999L + "'", long18 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(date68);
//    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        java.lang.Object obj7 = timePeriodValues6.clone();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues6.getMinEndIndex();
        java.lang.Comparable comparable11 = timePeriodValues6.getKey();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + "hi!" + "'", comparable11.equals("hi!"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.fireSeriesChanged();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) simpleTimePeriod16, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod16, "13-June-2019", "13-June-2019");
        timePeriodValues21.fireSeriesChanged();
        java.lang.Comparable comparable23 = timePeriodValues21.getKey();
        java.lang.Object obj24 = timePeriodValues21.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) simpleTimePeriod33, 10.0d);
        java.util.Date date36 = simpleTimePeriod33.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        long long38 = day37.getMiddleMillisecond();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year39, (double) 2019);
        boolean boolean43 = day37.equals((java.lang.Object) timePeriodValue42);
        boolean boolean45 = timePeriodValue42.equals((java.lang.Object) 3);
        timePeriodValues21.add(timePeriodValue42);
        timePeriodValues3.add(timePeriodValue42);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + "hi!" + "'", comparable7.equals("hi!"));
        org.junit.Assert.assertNotNull(comparable23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-14400001L) + "'", long38 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate6);
//        int int10 = day9.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        int int17 = year14.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year14.previous();
        java.util.Calendar calendar19 = null;
        try {
            year14.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("31-December-1969");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod19);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) 43629L);
        java.util.Date date26 = simpleTimePeriod19.getStart();
        java.util.Date date27 = simpleTimePeriod19.getStart();
        long long28 = simpleTimePeriod19.getEndMillis();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 13, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (byte) 10);
        boolean boolean16 = timePeriodValue14.equals((java.lang.Object) 1560495599999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues20.addPropertyChangeListener(propertyChangeListener21);
        timePeriodValues20.fireSeriesChanged();
        boolean boolean24 = timePeriodValue14.equals((java.lang.Object) timePeriodValues20);
        timePeriodValue14.setValue((java.lang.Number) 100.0f);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year14.next();
        java.util.Date date18 = year14.getEnd();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year14.getLastMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timePeriodValues17.getRangeDescription();
        timePeriodValues17.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.lang.String str24 = year23.toString();
        int int25 = year23.getYear();
        timePeriodValues17.setKey((java.lang.Comparable) year23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year23.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year23);
        int int29 = year9.compareTo((java.lang.Object) year23);
        long long30 = year9.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        int int5 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (-1.0f));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        long long13 = day12.getMiddleMillisecond();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        long long16 = year14.getMiddleMillisecond();
        long long17 = year14.getLastMillisecond();
        boolean boolean18 = day12.equals((java.lang.Object) long17);
        int int19 = day12.getYear();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-14400001L) + "'", long13 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1562097599999L + "'", long16 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("");
        int int9 = timePeriodValues3.getMinStartIndex();
        boolean boolean10 = timePeriodValues3.getNotify();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getLastMillisecond();
        int int3 = year0.getYear();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) -1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year9.next();
        long long33 = year9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, 10.0d);
        java.util.Date date25 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date11, date25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date25);
        java.util.Calendar calendar30 = null;
        try {
            long long31 = year29.getMiddleMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, 10.0d);
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 0L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 13);
        java.lang.String str39 = timePeriodValues3.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener40);
        int int42 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str39.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        java.util.Date date33 = simpleTimePeriod14.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues37.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 10.0d);
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date45, timeZone48);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date33, date45);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod50);
        int int52 = timePeriodValues51.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        try {
            org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues3.getTimePeriod(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        boolean boolean13 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues18.addPropertyChangeListener(propertyChangeListener19);
        timePeriodValues18.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timePeriodValues18.removeChangeListener(seriesChangeListener23);
        timePeriodValues18.setKey((java.lang.Comparable) 1.0f);
        int int27 = timePeriodValues18.getMinMiddleIndex();
        int int28 = timePeriodValues18.getMinMiddleIndex();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.lang.String str30 = year29.toString();
        boolean boolean31 = timePeriodValues18.equals((java.lang.Object) year29);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) (-1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(comparable14);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        try {
            timePeriodValues3.update((int) (byte) 1, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener4);
//        timePeriodValues3.setRangeDescription("13-June-2019");
//        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        java.lang.Object obj15 = null;
//        int int16 = day12.compareTo(obj15);
//        int int17 = day12.getMonth();
//        int int19 = day12.compareTo((java.lang.Object) (short) 1);
//        long long20 = day12.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener25 = null;
//        timePeriodValues24.addPropertyChangeListener(propertyChangeListener25);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues24.add((org.jfree.data.time.TimePeriod) simpleTimePeriod29, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
//        timePeriodValues24.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, (double) 0L);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timePeriodValues24.addPropertyChangeListener(propertyChangeListener45);
//        int int47 = day12.compareTo((java.lang.Object) propertyChangeListener45);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day12, (double) (short) -1);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560452399999L + "'", long20 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str13 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str13.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9);
        long long15 = year9.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues19.addChangeListener(seriesChangeListener20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, 10.0d);
        timePeriodValues19.setKey((java.lang.Comparable) simpleTimePeriod30);
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
        timePeriodValues37.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
        timePeriodValues37.removeChangeListener(seriesChangeListener42);
        timePeriodValues37.setKey((java.lang.Comparable) 1.0f);
        int int46 = timePeriodValues37.getMinMiddleIndex();
        int int47 = timePeriodValues37.getMinMiddleIndex();
        boolean boolean48 = simpleTimePeriod30.equals((java.lang.Object) timePeriodValues37);
        java.util.Date date49 = simpleTimePeriod30.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timePeriodValues53.addPropertyChangeListener(propertyChangeListener54);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues53.add((org.jfree.data.time.TimePeriod) simpleTimePeriod58, 10.0d);
        java.util.Date date61 = simpleTimePeriod58.getEnd();
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date61);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date61, timeZone64);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(date49, date61);
        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod66);
        int int68 = year9.compareTo((java.lang.Object) simpleTimePeriod66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = year9.next();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        boolean boolean13 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str12.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
        timePeriodValues3.add(timePeriodValue24);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        boolean boolean28 = timePeriodValue24.equals((java.lang.Object) timePeriodValues27);
        java.lang.Number number29 = timePeriodValue24.getValue();
        timePeriodValue24.setValue((java.lang.Number) 100.0f);
        timePeriodValue24.setValue((java.lang.Number) (byte) 10);
        java.lang.Object obj34 = timePeriodValue24.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timePeriodValues38.addPropertyChangeListener(propertyChangeListener39);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues38.add((org.jfree.data.time.TimePeriod) simpleTimePeriod43, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timePeriodValues49.addPropertyChangeListener(propertyChangeListener50);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues49.add((org.jfree.data.time.TimePeriod) simpleTimePeriod54, 10.0d);
        timePeriodValues38.add((org.jfree.data.time.TimePeriod) simpleTimePeriod54, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timePeriodValues38.addPropertyChangeListener(propertyChangeListener59);
        java.lang.String str61 = timePeriodValues38.getDomainDescription();
        int int62 = timePeriodValues38.getItemCount();
        boolean boolean63 = timePeriodValue24.equals((java.lang.Object) timePeriodValues38);
        timePeriodValues38.setDescription("31-December-1969");
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) 10 + "'", number29.equals((byte) 10));
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str61.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDomainDescription("TimePeriodValue[13-June-2019,null]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        try {
            org.jfree.data.time.TimePeriod timePeriod25 = timePeriodValues3.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        boolean boolean24 = timePeriodValues3.getNotify();
        try {
            timePeriodValues3.update(1969, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        int int9 = year1.compareTo((java.lang.Object) timePeriodFormatException3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year1.next();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        java.util.Date date18 = simpleTimePeriod14.getEnd();
        java.lang.Class class19 = null;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.String str21 = year20.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.previous();
        java.util.Date date23 = regularTimePeriod22.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, 10.0d);
        java.util.Date date35 = simpleTimePeriod32.getEnd();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date35);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date35, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date23, timeZone38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date18, timeZone38);
        java.util.Calendar calendar42 = null;
        try {
            long long43 = year41.getLastMillisecond(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod40);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        java.lang.String str27 = timePeriodValues3.getRangeDescription();
        java.lang.Comparable comparable28 = null;
        try {
            timePeriodValues3.setKey(comparable28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str26.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        java.lang.String str8 = timePeriodValues6.getDomainDescription();
        try {
            java.lang.Number number10 = timePeriodValues6.getValue((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues3.getTimePeriod(0);
        boolean boolean28 = timePeriodValues3.getNotify();
        timePeriodValues3.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener31);
        java.lang.Number number34 = timePeriodValues3.getValue(0);
        org.junit.Assert.assertNotNull(timePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 10.0d + "'", number34.equals(10.0d));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues3.getTimePeriod(0);
        boolean boolean28 = timePeriodValues3.getNotify();
        java.lang.String str29 = timePeriodValues3.getRangeDescription();
        boolean boolean30 = timePeriodValues3.getNotify();
        org.junit.Assert.assertNotNull(timePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        java.lang.String str17 = timePeriodValues3.getDescription();
        java.lang.String str18 = timePeriodValues3.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = timePeriodValues3.createCopy((int) (byte) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(timePeriodValues21);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        long long11 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, 10.0d);
        int int23 = simpleTimePeriod8.compareTo((java.lang.Object) simpleTimePeriod20);
        long long24 = simpleTimePeriod20.getEndMillis();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues3.getRangeDescription();
//        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        java.lang.String str10 = year9.toString();
//        int int11 = year9.getYear();
//        timePeriodValues3.setKey((java.lang.Comparable) year9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9);
//        long long15 = year9.getSerialIndex();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        long long18 = day16.getSerialIndex();
//        long long19 = day16.getLastMillisecond();
//        java.util.Date date20 = day16.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day16.next();
//        boolean boolean22 = year9.equals((java.lang.Object) day16);
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = year9.getLastMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
        timePeriodValues3.add(timePeriodValue24);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues29.addPropertyChangeListener(propertyChangeListener30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) simpleTimePeriod34, 10.0d);
        java.util.Date date37 = simpleTimePeriod34.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod34);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod34, (java.lang.Number) (byte) 10);
        java.lang.Number number41 = timePeriodValue40.getValue();
        java.lang.String str42 = timePeriodValue40.toString();
        java.lang.Number number43 = null;
        timePeriodValue40.setValue(number43);
        timePeriodValue40.setValue((java.lang.Number) 1562097599999L);
        timePeriodValues3.add(timePeriodValue40);
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + (byte) 10 + "'", number41.equals((byte) 10));
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Date date6 = regularTimePeriod5.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues10.addChangeListener(seriesChangeListener11);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
//        timePeriodValues10.setKey((java.lang.Comparable) simpleTimePeriod21);
//        java.util.Date date25 = simpleTimePeriod21.getEnd();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.lang.String str28 = year27.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
//        java.util.Date date30 = regularTimePeriod29.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date42, timeZone45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date30, timeZone45);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date25, timeZone45);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date6, timeZone45);
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
//        timePeriodValues53.addChangeListener(seriesChangeListener54);
//        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener60 = null;
//        timePeriodValues59.addPropertyChangeListener(propertyChangeListener60);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues59.add((org.jfree.data.time.TimePeriod) simpleTimePeriod64, 10.0d);
//        timePeriodValues53.setKey((java.lang.Comparable) simpleTimePeriod64);
//        java.util.Date date68 = simpleTimePeriod64.getEnd();
//        boolean boolean69 = year49.equals((java.lang.Object) simpleTimePeriod64);
//        long long70 = simpleTimePeriod64.getEndMillis();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 10L + "'", long70 == 10L);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9);
        long long15 = year9.getSerialIndex();
        java.lang.String str16 = year9.toString();
        long long17 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod26, "13-June-2019", "13-June-2019");
        timePeriodValues31.fireSeriesChanged();
        java.lang.Comparable comparable33 = timePeriodValues31.getKey();
        boolean boolean34 = year9.equals((java.lang.Object) timePeriodValues31);
        long long35 = year9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(comparable33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        java.util.Date date11 = simpleTimePeriod8.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date11, timeZone59);
//        java.util.Calendar calendar64 = null;
//        try {
//            long long65 = day63.getLastMillisecond(calendar64);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.lang.String str2 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8, "13-June-2019", "13-June-2019");
//        java.util.Date date14 = simpleTimePeriod8.getStart();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        long long17 = day15.getSerialIndex();
//        java.lang.Object obj18 = null;
//        int int19 = day15.compareTo(obj18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day15.next();
//        java.util.Date date21 = regularTimePeriod20.getEnd();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
//        boolean boolean23 = simpleTimePeriod8.equals((java.lang.Object) date21);
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues27.add((org.jfree.data.time.TimePeriod) simpleTimePeriod32, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod32, "13-June-2019", "13-June-2019");
//        java.util.Date date38 = simpleTimePeriod32.getStart();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.String str40 = day39.toString();
//        long long41 = day39.getSerialIndex();
//        java.lang.Object obj42 = null;
//        int int43 = day39.compareTo(obj42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day39.next();
//        java.util.Date date45 = regularTimePeriod44.getEnd();
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
//        boolean boolean47 = simpleTimePeriod32.equals((java.lang.Object) date45);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date45);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(date21, date45);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
//        java.lang.String str51 = year50.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        java.util.Date date53 = regularTimePeriod52.getEnd();
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date45, date53);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "13-June-2019" + "'", str40.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43629L + "'", long41 == 43629L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2019" + "'", str51.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(date53);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod17, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues23.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, 10.0d);
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener33);
        java.lang.String str35 = timePeriodValues12.getDomainDescription();
        timePeriodValues12.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        timePeriodValues12.setKey((java.lang.Comparable) 11);
        timePeriodValues12.fireSeriesChanged();
        boolean boolean41 = timePeriodValues3.equals((java.lang.Object) timePeriodValues12);
        int int42 = timePeriodValues12.getMinEndIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue44 = timePeriodValues12.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str35.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 2019);
        java.lang.String str4 = year0.toString();
        long long5 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        boolean boolean4 = simpleTimePeriod2.equals((java.lang.Object) 'a');
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        int int10 = timePeriodValues9.getItemCount();
        java.lang.String str11 = timePeriodValues9.getDescription();
        timePeriodValues9.delete(9, 3);
        try {
            int int15 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.Class<?> wildcardClass16 = seriesChangeEvent15.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        int int18 = day13.compareTo((java.lang.Object) wildcardClass16);
        int int19 = day13.getDayOfMonth();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 31 + "'", int19 == 31);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.lang.String str10 = timePeriodValues3.getDescription();
        int int11 = timePeriodValues3.getItemCount();
        boolean boolean13 = timePeriodValues3.equals((java.lang.Object) (short) 0);
        boolean boolean14 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
//        java.lang.Class<?> wildcardClass21 = simpleTimePeriod18.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timePeriodValues26.addPropertyChangeListener(propertyChangeListener27);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) simpleTimePeriod31, 10.0d);
//        java.util.Date date34 = simpleTimePeriod31.getEnd();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener41 = null;
//        timePeriodValues40.addPropertyChangeListener(propertyChangeListener41);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues40.add((org.jfree.data.time.TimePeriod) simpleTimePeriod45, 10.0d);
//        java.util.Date date48 = simpleTimePeriod45.getEnd();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date48);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date48, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date34, timeZone51);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date7, timeZone51);
//        java.lang.String str55 = year54.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        int int6 = timePeriodValues3.getMinEndIndex();
//        timePeriodValues3.setDescription("");
//        int int9 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        boolean boolean13 = timePeriodValues3.equals((java.lang.Object) day10);
//        int int14 = timePeriodValues3.getMinEndIndex();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (-1.0d) + "'", obj3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (-1.0d) + "'", obj4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (-1.0d) + "'", obj5.equals((-1.0d)));
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues12.createCopy((int) (short) -1, 11);
//        java.lang.Object obj16 = timePeriodValues15.clone();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues15.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timePeriodValues15.removeChangeListener(seriesChangeListener19);
//        java.lang.String str21 = timePeriodValues15.getRangeDescription();
//        timePeriodValues15.setDescription("31-December-1969");
//        int int24 = day7.compareTo((java.lang.Object) timePeriodValues15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = timePeriodValues26.createCopy(0, (int) '4');
//        int int30 = day7.compareTo((java.lang.Object) '4');
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(timePeriodValues15);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(timePeriodValues29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        int int7 = day0.getMonth();
//        long long8 = day0.getFirstMillisecond();
//        java.lang.String str9 = day0.toString();
//        long long10 = day0.getMiddleMillisecond();
//        long long11 = day0.getFirstMillisecond();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day0.getFirstMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560452399999L + "'", long10 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8, "13-June-2019", "13-June-2019");
//        java.util.Date date14 = simpleTimePeriod8.getStart();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        long long17 = day15.getSerialIndex();
//        java.lang.Object obj18 = null;
//        int int19 = day15.compareTo(obj18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day15.next();
//        java.util.Date date21 = regularTimePeriod20.getEnd();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
//        boolean boolean23 = simpleTimePeriod8.equals((java.lang.Object) date21);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date21);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues3.getTimePeriod(0);
        boolean boolean28 = timePeriodValues3.getNotify();
        int int29 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.update((int) (short) 1, (java.lang.Number) 3);
        timePeriodValues3.setDomainDescription("");
        org.junit.Assert.assertNotNull(timePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Class<?> wildcardClass13 = timePeriodValues3.getClass();
        int int14 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues6.addPropertyChangeListener(propertyChangeListener8);
//        int int10 = timePeriodValues6.getMinEndIndex();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getSerialIndex();
//        java.util.Date date13 = day11.getEnd();
//        long long14 = day11.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (short) -1);
//        java.lang.Number number17 = null;
//        timePeriodValue16.setValue(number17);
//        timePeriodValues6.add(timePeriodValue16);
//        java.lang.Number number20 = timePeriodValue16.getValue();
//        java.lang.Object obj21 = timePeriodValue16.clone();
//        org.jfree.data.time.TimePeriod timePeriod22 = timePeriodValue16.getPeriod();
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertNotNull(timePeriod22);
//    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
//        java.util.Date date11 = simpleTimePeriod8.getEnd();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date11, timeZone59);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.TimePeriodValues timePeriodValues68 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener69 = null;
//        timePeriodValues68.addPropertyChangeListener(propertyChangeListener69);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod73 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues68.add((org.jfree.data.time.TimePeriod) simpleTimePeriod73, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues78 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod73, "13-June-2019", "13-June-2019");
//        timePeriodValues78.fireSeriesChanged();
//        java.lang.Comparable comparable80 = timePeriodValues78.getKey();
//        boolean boolean81 = year64.equals((java.lang.Object) comparable80);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(comparable80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        timePeriodValues3.setRangeDescription("hi!");
        boolean boolean14 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + "hi!" + "'", comparable11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.fireSeriesChanged();
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        java.lang.String str4 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        timePeriodValues3.setKey((java.lang.Comparable) 1.0f);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.lang.String str15 = year14.toString();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) year14);
        int int17 = year14.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) 'a');
        java.lang.String str20 = timePeriodValue19.toString();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[2019,97.0]" + "'", str20.equals("TimePeriodValue[2019,97.0]"));
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = day4.getClass();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        long long9 = day7.getSerialIndex();
//        long long10 = day7.getLastMillisecond();
//        java.util.Date date11 = day7.getStart();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date11, timeZone59);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date3, timeZone59);
//        java.lang.Class<?> wildcardClass65 = day64.getClass();
//        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass65);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertNotNull(class66);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0f);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.lang.String str6 = timePeriodValues3.getRangeDescription();
//        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        java.lang.String str10 = year9.toString();
//        int int11 = year9.getYear();
//        timePeriodValues3.setKey((java.lang.Comparable) year9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9);
//        long long15 = year9.getSerialIndex();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        long long18 = day16.getSerialIndex();
//        long long19 = day16.getLastMillisecond();
//        java.util.Date date20 = day16.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day16.next();
//        boolean boolean22 = year9.equals((java.lang.Object) day16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timePeriodValues26.addPropertyChangeListener(propertyChangeListener27);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) simpleTimePeriod31, 10.0d);
//        java.lang.Class<?> wildcardClass34 = simpleTimePeriod31.getClass();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod31);
//        java.lang.Object obj36 = seriesChangeEvent35.getSource();
//        int int37 = day16.compareTo((java.lang.Object) seriesChangeEvent35);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        int int13 = day12.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
        int int15 = day12.getMonth();
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str7 = timePeriodFormatException6.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.lang.String str1 = year0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
//        java.util.Date date3 = regularTimePeriod2.getEnd();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getSerialIndex();
//        java.lang.Class<?> wildcardClass6 = day4.getClass();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        long long9 = day7.getSerialIndex();
//        long long10 = day7.getLastMillisecond();
//        java.util.Date date11 = day7.getStart();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        long long14 = day12.getSerialIndex();
//        long long15 = day12.getLastMillisecond();
//        java.util.Date date16 = day12.getStart();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues21.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, 10.0d);
//        java.lang.Class<?> wildcardClass29 = simpleTimePeriod26.getClass();
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues48.add((org.jfree.data.time.TimePeriod) simpleTimePeriod53, 10.0d);
//        java.util.Date date56 = simpleTimePeriod53.getEnd();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56);
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date42, timeZone59);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date16, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date11, timeZone59);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date3, timeZone59);
//        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day64, "", "");
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: 13-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        java.util.Date date2 = year1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
//        java.util.Date date17 = simpleTimePeriod14.getEnd();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timePeriodValues23.addPropertyChangeListener(propertyChangeListener24);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, 10.0d);
//        java.util.Date date31 = simpleTimePeriod28.getEnd();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(date17, date31);
//        int int34 = day0.compareTo((java.lang.Object) date17);
//        long long35 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560409200000L + "'", long35 == 1560409200000L);
//    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) (short) -1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues10.addPropertyChangeListener(propertyChangeListener11);
//        timePeriodValues10.fireSeriesChanged();
//        java.lang.Comparable comparable14 = timePeriodValues10.getKey();
//        timePeriodValues10.fireSeriesChanged();
//        boolean boolean16 = timePeriodValues10.isEmpty();
//        boolean boolean17 = day0.equals((java.lang.Object) boolean16);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + "hi!" + "'", comparable14.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMinStartIndex();
        java.lang.String str7 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        long long44 = simpleTimePeriod40.getStartMillis();
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod40.equals(obj45);
        boolean boolean47 = year9.equals((java.lang.Object) simpleTimePeriod40);
        java.util.Date date48 = simpleTimePeriod40.getStart();
        java.util.Date date49 = simpleTimePeriod40.getStart();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(date49);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (byte) 10);
        java.lang.Number number15 = timePeriodValue14.getValue();
        java.lang.String str16 = timePeriodValue14.toString();
        java.lang.Object obj17 = null;
        boolean boolean18 = timePeriodValue14.equals(obj17);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) 10 + "'", number15.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues6.addPropertyChangeListener(propertyChangeListener8);
//        int int10 = timePeriodValues6.getMinEndIndex();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getSerialIndex();
//        java.util.Date date13 = day11.getEnd();
//        long long14 = day11.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) (short) -1);
//        java.lang.Number number17 = null;
//        timePeriodValue16.setValue(number17);
//        timePeriodValues6.add(timePeriodValue16);
//        java.lang.String str20 = timePeriodValue16.toString();
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[13-June-2019,null]" + "'", str20.equals("TimePeriodValue[13-June-2019,null]"));
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getMonth();
//        int int4 = day0.getMonth();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        long long44 = simpleTimePeriod40.getStartMillis();
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod40.equals(obj45);
        boolean boolean47 = year9.equals((java.lang.Object) simpleTimePeriod40);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timePeriodValues51.addPropertyChangeListener(propertyChangeListener52);
        timePeriodValues51.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
        timePeriodValues51.removeChangeListener(seriesChangeListener56);
        timePeriodValues51.setKey((java.lang.Comparable) 1.0f);
        int int60 = timePeriodValues51.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timePeriodValues64.addPropertyChangeListener(propertyChangeListener65);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod69 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues64.add((org.jfree.data.time.TimePeriod) simpleTimePeriod69, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues75 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener76 = null;
        timePeriodValues75.addPropertyChangeListener(propertyChangeListener76);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod80 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues75.add((org.jfree.data.time.TimePeriod) simpleTimePeriod80, 10.0d);
        timePeriodValues64.add((org.jfree.data.time.TimePeriod) simpleTimePeriod80, (double) 0L);
        timePeriodValues51.add((org.jfree.data.time.TimePeriod) simpleTimePeriod80, (double) 13);
        java.lang.String str87 = timePeriodValues51.getDomainDescription();
        int int88 = year9.compareTo((java.lang.Object) str87);
        org.jfree.data.time.TimePeriodValues timePeriodValues89 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year9);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str87.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        java.lang.Class class0 = null;
//        java.util.Date date1 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues5.addPropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues5.add((org.jfree.data.time.TimePeriod) simpleTimePeriod10, 10.0d);
//        java.util.Date date13 = simpleTimePeriod10.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        long long16 = day14.getSerialIndex();
//        long long17 = day14.getLastMillisecond();
//        java.util.Date date18 = day14.getStart();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timePeriodValues23.addPropertyChangeListener(propertyChangeListener24);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, 10.0d);
//        java.lang.Class<?> wildcardClass31 = simpleTimePeriod28.getClass();
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timePeriodValues36.addPropertyChangeListener(propertyChangeListener37);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues36.add((org.jfree.data.time.TimePeriod) simpleTimePeriod41, 10.0d);
//        java.util.Date date44 = simpleTimePeriod41.getEnd();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date44);
//        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener51 = null;
//        timePeriodValues50.addPropertyChangeListener(propertyChangeListener51);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod55 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues50.add((org.jfree.data.time.TimePeriod) simpleTimePeriod55, 10.0d);
//        java.util.Date date58 = simpleTimePeriod55.getEnd();
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date58);
//        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date58, timeZone61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date44, timeZone61);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date18, timeZone61);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date13, timeZone61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone61);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43629L + "'", long16 == 43629L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone61);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNull(regularTimePeriod66);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("13-June-2019");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
        timePeriodValues3.add(timePeriodValue24);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
        boolean boolean28 = timePeriodValue24.equals((java.lang.Object) timePeriodValues27);
        java.lang.String str29 = timePeriodValue24.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues33.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues33.add((org.jfree.data.time.TimePeriod) simpleTimePeriod38, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timePeriodValues44.addPropertyChangeListener(propertyChangeListener45);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues44.add((org.jfree.data.time.TimePeriod) simpleTimePeriod49, 10.0d);
        timePeriodValues33.add((org.jfree.data.time.TimePeriod) simpleTimePeriod49, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timePeriodValues33.addPropertyChangeListener(propertyChangeListener54);
        java.lang.String str56 = timePeriodValues33.getDomainDescription();
        timePeriodValues33.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        boolean boolean59 = timePeriodValue24.equals((java.lang.Object) timePeriodValues33);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener60 = null;
        timePeriodValues33.removeChangeListener(seriesChangeListener60);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str56.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        java.util.Date date7 = day0.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
//        java.lang.Class<?> wildcardClass21 = simpleTimePeriod18.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timePeriodValues26.addPropertyChangeListener(propertyChangeListener27);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) simpleTimePeriod31, 10.0d);
//        java.util.Date date34 = simpleTimePeriod31.getEnd();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34);
//        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener41 = null;
//        timePeriodValues40.addPropertyChangeListener(propertyChangeListener41);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues40.add((org.jfree.data.time.TimePeriod) simpleTimePeriod45, 10.0d);
//        java.util.Date date48 = simpleTimePeriod45.getEnd();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date48);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date48, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date34, timeZone51);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date7, timeZone51);
//        int int55 = year54.getYear();
//        int int56 = year54.getYear();
//        long long57 = year54.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577865599999L + "'", long57 == 1577865599999L);
//    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        long long6 = day4.getSerialIndex();
//        long long7 = day4.getLastMillisecond();
//        boolean boolean9 = day4.equals((java.lang.Object) "hi!");
//        boolean boolean10 = day0.equals((java.lang.Object) boolean9);
//        boolean boolean12 = day0.equals((java.lang.Object) 13);
//        java.util.Date date13 = day0.getStart();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        long long15 = day14.getSerialIndex();
//        java.util.Calendar calendar16 = null;
//        try {
//            day14.peg(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        long long9 = day0.getSerialIndex();
//        java.lang.String str10 = day0.toString();
//        java.lang.String str11 = day0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        long long3 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues35.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues35.add((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 10.0d);
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        long long44 = simpleTimePeriod40.getStartMillis();
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod40.equals(obj45);
        boolean boolean47 = year9.equals((java.lang.Object) simpleTimePeriod40);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod40, "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesException: hi!");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue52 = timePeriodValues50.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, 13, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues6.getClass();
        java.lang.String str9 = timePeriodValues6.getDomainDescription();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str9.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8, "13-June-2019", "13-June-2019");
        timePeriodValues13.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue16 = timePeriodValues13.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        int int13 = timePeriodValues3.getItemCount();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = null;
        try {
            timePeriodValues3.add(timePeriodValue14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0L);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener29);
        int int31 = timePeriodValues3.getMaxEndIndex();
        java.lang.Object obj32 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
        timePeriodValues36.addChangeListener(seriesChangeListener37);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues42.addPropertyChangeListener(propertyChangeListener43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues42.add((org.jfree.data.time.TimePeriod) simpleTimePeriod47, 10.0d);
        timePeriodValues36.setKey((java.lang.Comparable) simpleTimePeriod47);
        java.util.Date date51 = simpleTimePeriod47.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues55.addPropertyChangeListener(propertyChangeListener56);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues55.add((org.jfree.data.time.TimePeriod) simpleTimePeriod60, 10.0d);
        java.util.Date date63 = simpleTimePeriod60.getEnd();
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date63);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod65 = new org.jfree.data.time.SimpleTimePeriod(date51, date63);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date63);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day66, (double) 100.0f);
        java.lang.String str69 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str26.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "hi!" + "'", str69.equals("hi!"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        int int2 = year0.getYear();
        java.lang.Number number3 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues22.add((org.jfree.data.time.TimePeriod) simpleTimePeriod27, 10.0d);
        timePeriodValues16.setKey((java.lang.Comparable) simpleTimePeriod27);
        boolean boolean31 = year9.equals((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year9.next();
        long long33 = year9.getFirstMillisecond();
        java.lang.String str34 = year9.toString();
        java.util.Date date35 = year9.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date35, "31-December-1969", "org.jfree.data.time.TimePeriodFormatException: 2019");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
        org.junit.Assert.assertNotNull(date35);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Date date2 = day0.getEnd();
//        int int3 = day0.getMonth();
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str7 = timePeriodFormatException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        long long7 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate8 = day0.getSerialDate();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate8);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        int int6 = day0.getDayOfMonth();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day0.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 5);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 13-June-2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 13-June-2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 13-June-2019" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: 13-June-2019"));
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener4);
//        timePeriodValues3.setRangeDescription("13-June-2019");
//        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) simpleTimePeriod18, 10.0d);
//        java.util.Date date21 = simpleTimePeriod18.getEnd();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod18);
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (java.lang.Number) (byte) 10);
//        timePeriodValues3.add(timePeriodValue24);
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1);
//        boolean boolean28 = timePeriodValue24.equals((java.lang.Object) timePeriodValues27);
//        java.lang.Number number29 = timePeriodValue24.getValue();
//        org.jfree.data.time.TimePeriod timePeriod30 = timePeriodValue24.getPeriod();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        long long33 = day31.getSerialIndex();
//        java.lang.Object obj34 = null;
//        int int35 = day31.compareTo(obj34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day31.next();
//        org.jfree.data.time.SerialDate serialDate37 = day31.getSerialDate();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.next();
//        long long40 = day38.getLastMillisecond();
//        boolean boolean41 = timePeriodValue24.equals((java.lang.Object) day38);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) 10 + "'", number29.equals((byte) 10));
//        org.junit.Assert.assertNotNull(timePeriod30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13-June-2019" + "'", str32.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43629L + "'", long33 == 43629L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560495599999L + "'", long40 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        int int5 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
//        java.lang.String str9 = day8.toString();
//        long long10 = day8.getLastMillisecond();
//        java.lang.Object obj11 = null;
//        boolean boolean12 = day8.equals(obj11);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodFormatException1);
        java.lang.Object obj4 = seriesChangeEvent3.getSource();
        java.lang.Object obj5 = seriesChangeEvent3.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 13-June-2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 13-June-2019"));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 2019);
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        java.lang.String str5 = year0.toString();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod8.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, 10.0d);
        java.lang.Class<?> wildcardClass23 = simpleTimePeriod20.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) simpleTimePeriod33, 10.0d);
        java.util.Date date36 = simpleTimePeriod33.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues42.addPropertyChangeListener(propertyChangeListener43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues42.add((org.jfree.data.time.TimePeriod) simpleTimePeriod47, 10.0d);
        java.util.Date date50 = simpleTimePeriod47.getEnd();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date50, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date36, timeZone53);
        java.lang.Class class56 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        boolean boolean57 = simpleTimePeriod8.equals((java.lang.Object) wildcardClass23);
        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener62 = null;
        timePeriodValues61.addPropertyChangeListener(propertyChangeListener62);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues61.add((org.jfree.data.time.TimePeriod) simpleTimePeriod66, 10.0d);
        int int69 = timePeriodValues61.getMaxMiddleIndex();
        boolean boolean70 = simpleTimePeriod8.equals((java.lang.Object) timePeriodValues61);
        long long71 = simpleTimePeriod8.getEndMillis();
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 10L + "'", long71 == 10L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("13-June-2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        java.lang.Object obj3 = null;
//        int int4 = day0.compareTo(obj3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        java.util.Date date6 = regularTimePeriod5.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues10.addChangeListener(seriesChangeListener11);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues16.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, 10.0d);
//        timePeriodValues10.setKey((java.lang.Comparable) simpleTimePeriod21);
//        java.util.Date date25 = simpleTimePeriod21.getEnd();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        java.lang.String str28 = year27.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
//        java.util.Date date30 = regularTimePeriod29.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timePeriodValues34.addPropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues34.add((org.jfree.data.time.TimePeriod) simpleTimePeriod39, 10.0d);
//        java.util.Date date42 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date42, timeZone45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date30, timeZone45);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date25, timeZone45);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date6, timeZone45);
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
//        timePeriodValues53.addChangeListener(seriesChangeListener54);
//        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener60 = null;
//        timePeriodValues59.addPropertyChangeListener(propertyChangeListener60);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues59.add((org.jfree.data.time.TimePeriod) simpleTimePeriod64, 10.0d);
//        timePeriodValues53.setKey((java.lang.Comparable) simpleTimePeriod64);
//        java.util.Date date68 = simpleTimePeriod64.getEnd();
//        boolean boolean69 = year49.equals((java.lang.Object) simpleTimePeriod64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = year49.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.lang.String str4 = day3.toString();
//        long long5 = day3.getSerialIndex();
//        long long6 = day3.getLastMillisecond();
//        java.util.Date date7 = day3.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        long long10 = day8.getSerialIndex();
//        long long11 = day8.getLastMillisecond();
//        java.util.Date date12 = day8.getStart();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, 10.0d);
//        java.lang.Class<?> wildcardClass25 = simpleTimePeriod22.getClass();
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timePeriodValues30.addPropertyChangeListener(propertyChangeListener31);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues30.add((org.jfree.data.time.TimePeriod) simpleTimePeriod35, 10.0d);
//        java.util.Date date38 = simpleTimePeriod35.getEnd();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timePeriodValues44.addPropertyChangeListener(propertyChangeListener45);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues44.add((org.jfree.data.time.TimePeriod) simpleTimePeriod49, 10.0d);
//        java.util.Date date52 = simpleTimePeriod49.getEnd();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date52);
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date52, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date38, timeZone55);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date12, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date7, timeZone55);
//        java.lang.Class class60 = null;
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
//        java.lang.String str62 = year61.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year61.previous();
//        java.util.Date date64 = regularTimePeriod63.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues68 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener69 = null;
//        timePeriodValues68.addPropertyChangeListener(propertyChangeListener69);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod73 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues68.add((org.jfree.data.time.TimePeriod) simpleTimePeriod73, 10.0d);
//        java.util.Date date76 = simpleTimePeriod73.getEnd();
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date76);
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date76);
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date76, timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date64, timeZone79);
//        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date7, timeZone79);
//        int int83 = day82.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2019" + "'", str62.equals("2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 2019 + "'", int83 == 2019);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) simpleTimePeriod15, 10.0d);
        timePeriodValues4.setKey((java.lang.Comparable) simpleTimePeriod15);
        java.util.Date date19 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues23.addPropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod28, 10.0d);
        java.util.Date date31 = simpleTimePeriod28.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(date19, date31);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date31);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date0, date31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1), "org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        int int4 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("");
        int int9 = timePeriodValues3.getMinStartIndex();
        int int10 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) simpleTimePeriod19, 10.0d);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod19);
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (java.lang.Number) (byte) 10);
        java.lang.Number number26 = timePeriodValue25.getValue();
        java.lang.String str27 = timePeriodValue25.toString();
        java.lang.Number number28 = null;
        timePeriodValue25.setValue(number28);
        timePeriodValues3.add(timePeriodValue25);
        java.lang.String str31 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (byte) 10 + "'", number26.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues6.addPropertyChangeListener(propertyChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getSerialIndex();
//        java.lang.Class<?> wildcardClass12 = day10.getClass();
//        timePeriodValues6.setKey((java.lang.Comparable) day10);
//        int int14 = timePeriodValues6.getMaxMiddleIndex();
//        java.lang.String str15 = timePeriodValues6.getRangeDescription();
//        int int16 = timePeriodValues6.getMinEndIndex();
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (31) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.lang.Object obj11 = null;
        try {
            int int12 = simpleTimePeriod8.compareTo(obj11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        try {
            timePeriodValues3.update(0, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
//        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
//        timePeriodValues21.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timePeriodValues21.removeChangeListener(seriesChangeListener26);
//        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
//        int int30 = timePeriodValues21.getMinMiddleIndex();
//        int int31 = timePeriodValues21.getMinMiddleIndex();
//        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
//        java.util.Date date33 = simpleTimePeriod14.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) simpleTimePeriod42, 10.0d);
//        java.util.Date date45 = simpleTimePeriod42.getEnd();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45);
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date45, timeZone48);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date33, date45);
//        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod50);
//        java.lang.Comparable comparable52 = timePeriodValues51.getKey();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        long long54 = day53.getSerialIndex();
//        java.util.Date date55 = day53.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day53.previous();
//        int int57 = day53.getMonth();
//        org.jfree.data.time.SerialDate serialDate58 = day53.getSerialDate();
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(serialDate58);
//        timePeriodValues51.add((org.jfree.data.time.TimePeriod) day59, (java.lang.Number) 2019L);
//        long long62 = day59.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNotNull(comparable52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 43629L + "'", long54 == 43629L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 43629L + "'", long62 == 43629L);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.previous();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        int int17 = year9.compareTo((java.lang.Object) timePeriodFormatException15);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getSerialIndex();
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.time.TimePeriodFormatException: hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Date date2 = year0.getStart();
        int int3 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, 10.0d);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        int int13 = day12.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day12.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 31 + "'", int13 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) -1, 11);
        int int7 = timePeriodValues6.getMaxStartIndex();
        java.lang.Class<?> wildcardClass8 = timePeriodValues6.getClass();
        int int9 = timePeriodValues6.getMinStartIndex();
        int int10 = timePeriodValues6.getMaxEndIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod14, 10.0d);
        timePeriodValues3.setKey((java.lang.Comparable) simpleTimePeriod14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        timePeriodValues21.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener26);
        timePeriodValues21.setKey((java.lang.Comparable) 1.0f);
        int int30 = timePeriodValues21.getMinMiddleIndex();
        int int31 = timePeriodValues21.getMinMiddleIndex();
        boolean boolean32 = simpleTimePeriod14.equals((java.lang.Object) timePeriodValues21);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "org.jfree.data.general.SeriesChangeEvent[source=-1.0]", "hi!");
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues36.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (byte) 10);
        timePeriodValues36.add((org.jfree.data.time.TimePeriod) simpleTimePeriod41, 10.0d);
        java.util.Date date44 = simpleTimePeriod41.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date44);
        java.util.Date date48 = day47.getStart();
        int int49 = simpleTimePeriod14.compareTo((java.lang.Object) day47);
        java.util.Date date50 = simpleTimePeriod14.getEnd();
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(date50);
    }
}

