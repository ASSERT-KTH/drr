import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        long long6 = year4.getLastMillisecond();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, "", "2019", class9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long13 = fixedMillisecond12.getSerialIndex();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries10.getNextTimePeriod();
        timeSeries10.setNotify(true);
        boolean boolean21 = month0.equals((java.lang.Object) timeSeries10);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        long long24 = year22.getLastMillisecond();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long24, "", "2019", class27);
        timeSeries28.setDomainDescription("hi!");
        java.util.Collection collection31 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        int int32 = timeSeries28.getMaximumItemCount();
        int int33 = timeSeries28.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries28.getDataItem(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2147483647 + "'", int32 == 2147483647);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2147483647 + "'", int33 == 2147483647);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        timeSeries6.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries6.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        long long19 = year17.getLastMillisecond();
        java.lang.String str20 = year17.toString();
        java.lang.Object obj21 = null;
        boolean boolean22 = year17.equals(obj21);
        long long23 = year17.getSerialIndex();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        long long27 = year25.getLastMillisecond();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long27, "", "2019", class30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getSerialIndex();
        long long34 = year32.getLastMillisecond();
        int int35 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        int int36 = timeSeries31.getItemCount();
        java.lang.String str37 = timeSeries31.getDomainDescription();
        timeSeries31.setRangeDescription("");
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries31.createCopy((int) (byte) 0, (int) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries6.addAndOrUpdate(timeSeries42);
        long long44 = timeSeries43.getMaximumItemAge();
        java.lang.Class class45 = timeSeries43.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9223372036854775807L + "'", long44 == 9223372036854775807L);
        org.junit.Assert.assertNull(class45);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries6.getTimePeriod(0);
        timeSeries6.setDescription("hi!");
        java.util.Collection collection19 = timeSeries6.getTimePeriods();
        boolean boolean20 = timeSeries6.isEmpty();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-459), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int2 = spreadsheetDate1.getMonth();
//        int int3 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long6 = fixedMillisecond5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.previous();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getMiddleMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
//        boolean boolean13 = spreadsheetDate1.isOn(serialDate12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long19 = fixedMillisecond18.getSerialIndex();
//        long long20 = fixedMillisecond18.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.next();
//        java.util.Date date22 = fixedMillisecond18.getStart();
//        long long23 = fixedMillisecond18.getMiddleMillisecond();
//        boolean boolean24 = fixedMillisecond14.equals((java.lang.Object) long23);
//        long long25 = fixedMillisecond14.getFirstMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond14.getLastMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond14.getEnd();
//        boolean boolean29 = spreadsheetDate1.equals((java.lang.Object) date28);
//        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate1.getFollowingDayOfWeek(1);
//        serialDate31.setDescription("");
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440807872L + "'", long25 == 1560440807872L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560440807872L + "'", long27 == 1560440807872L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(serialDate31);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        java.lang.String str9 = day8.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-1969" + "'", str9.equals("31-December-1969"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.List list11 = timeSeries6.getItems();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long15 = fixedMillisecond14.getSerialIndex();
        long long16 = fixedMillisecond14.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
        java.util.Date date18 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        java.util.List list23 = timeSeries6.getItems();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries6.getTimePeriod(0);
        timeSeries6.setDescription("hi!");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year20 = month19.getYear();
        int int21 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        int int22 = timeSeries6.getMaximumItemCount();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
        int int28 = day26.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 1555225199999L);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener31);
        try {
            timeSeries6.update((int) ' ', (java.lang.Number) 1560440807872L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        int int2 = day1.getMonth();
        int int3 = day1.getYear();
        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) '4', serialDate4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        timeSeries6.setNotify(true);
        long long17 = timeSeries6.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries6.addChangeListener(seriesChangeListener18);
        timeSeries6.clear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        long long6 = year4.getLastMillisecond();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, "", "2019", class9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long13 = fixedMillisecond12.getSerialIndex();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries10.getNextTimePeriod();
        timeSeries10.setNotify(true);
        boolean boolean21 = month0.equals((java.lang.Object) timeSeries10);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        long long24 = year22.getLastMillisecond();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long24, "", "2019", class27);
        timeSeries28.setDomainDescription("hi!");
        java.util.Collection collection31 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        boolean boolean33 = timeSeries10.equals((java.lang.Object) 1560440752715L);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener34);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        long long6 = year4.getLastMillisecond();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, "", "2019", class9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long13 = fixedMillisecond12.getSerialIndex();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries10.getNextTimePeriod();
        timeSeries10.setNotify(true);
        boolean boolean21 = month0.equals((java.lang.Object) timeSeries10);
        timeSeries10.removeAgedItems(false);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.next();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day24);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getSerialIndex();
        long long32 = year30.getLastMillisecond();
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long32, "", "2019", class35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long39 = fixedMillisecond38.getSerialIndex();
        long long40 = fixedMillisecond38.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond38.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeries36.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries36.getTimePeriod(0);
        timeSeries36.setDescription("hi!");
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year50 = month49.getYear();
        int int51 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) month49);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month49, (java.lang.Number) 10.0d);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getSerialIndex();
        long long56 = year54.getLastMillisecond();
        java.lang.Class class59 = null;
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long56, "", "2019", class59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long63 = fixedMillisecond62.getSerialIndex();
        long long64 = fixedMillisecond62.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = fixedMillisecond62.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (java.lang.Number) (-1.0d));
        int int68 = timeSeriesDataItem53.compareTo((java.lang.Object) fixedMillisecond62);
        timeSeriesDataItem53.setValue((java.lang.Number) 1560440759172L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = timeSeriesDataItem53.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = timeSeriesDataItem53.getPeriod();
        try {
            timeSeries10.add(timeSeriesDataItem53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1L + "'", long40 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(year50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2019L + "'", long55 == 2019L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1577865599999L + "'", long56 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1L + "'", long63 == 1L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1L + "'", long64 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("July");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        int int3 = year0.getYear();
        boolean boolean5 = year0.equals((java.lang.Object) (-1));
        java.util.Date date6 = year0.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        long long7 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(10, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(2);
        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate1.getNearestDayOfWeek(7);
        java.util.Date date13 = spreadsheetDate1.toDate();
        java.util.Date date14 = spreadsheetDate1.toDate();
        int int15 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        long long6 = year4.getLastMillisecond();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, "", "2019", class9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long13 = fixedMillisecond12.getSerialIndex();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries10.getNextTimePeriod();
        timeSeries10.setNotify(true);
        boolean boolean21 = month0.equals((java.lang.Object) timeSeries10);
        timeSeries10.removeAgedItems(false);
        java.lang.Object obj24 = timeSeries10.clone();
        timeSeries10.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("31-December-1969", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(31, 0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        int int15 = timeSeries6.getMaximumItemCount();
        timeSeries6.setKey((java.lang.Comparable) 10L);
        timeSeries6.setNotify(false);
        java.lang.Object obj20 = timeSeries6.clone();
        int int21 = timeSeries6.getItemCount();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.Year year14 = month12.getYear();
        long long15 = month12.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 2019L);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
        java.lang.String str20 = month18.toString();
        java.lang.String str21 = month18.toString();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        long long24 = year22.getLastMillisecond();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long24, "", "2019", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long31 = fixedMillisecond30.getSerialIndex();
        long long32 = fixedMillisecond30.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond30.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeries28.getNextTimePeriod();
        timeSeries28.setNotify(true);
        boolean boolean39 = month18.equals((java.lang.Object) timeSeries28);
        timeSeries28.removeAgedItems(false);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate43 = day42.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day42.next();
        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day42);
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day42.previous();
        int int48 = day42.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a', 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("January");
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-459), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -459");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries6.addChangeListener(seriesChangeListener14);
        java.lang.Class class16 = timeSeries6.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNull(class16);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        java.lang.Class<?> wildcardClass12 = timeSeries6.getClass();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        int int3 = spreadsheetDate2.getMonth();
        int int4 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        int int8 = spreadsheetDate7.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean11 = spreadsheetDate7.isOnOrAfter(serialDate10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        int int18 = day16.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths(0, serialDate19);
        boolean boolean21 = spreadsheetDate7.isOnOrBefore(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        int int24 = spreadsheetDate23.getDayOfMonth();
        boolean boolean25 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean26 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(10, serialDate29);
        boolean boolean31 = spreadsheetDate2.isOnOrAfter(serialDate30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 13 + "'", int18 == 13);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        timeSeries6.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries6.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        long long19 = year17.getLastMillisecond();
        java.lang.String str20 = year17.toString();
        java.lang.Object obj21 = null;
        boolean boolean22 = year17.equals(obj21);
        long long23 = year17.getSerialIndex();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        long long27 = year25.getLastMillisecond();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long27, "", "2019", class30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getSerialIndex();
        long long34 = year32.getLastMillisecond();
        int int35 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        int int36 = timeSeries31.getItemCount();
        java.lang.String str37 = timeSeries31.getDomainDescription();
        timeSeries31.setRangeDescription("");
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries31.createCopy((int) (byte) 0, (int) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries6.addAndOrUpdate(timeSeries42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        long long45 = year44.getSerialIndex();
        long long46 = year44.getLastMillisecond();
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long46, "", "2019", class49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long53 = fixedMillisecond52.getSerialIndex();
        long long54 = fixedMillisecond52.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond52.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries50.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = timeSeries50.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = timeSeries50.getTimePeriod(0);
        timeSeries50.setDescription("hi!");
        java.util.Collection collection63 = timeSeries50.getTimePeriods();
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = month64.next();
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        long long67 = year66.getSerialIndex();
        long long68 = year66.getLastMillisecond();
        int int69 = year66.getYear();
        boolean boolean71 = year66.equals((java.lang.Object) (-1));
        int int72 = month64.compareTo((java.lang.Object) boolean71);
        long long73 = month64.getFirstMillisecond();
        timeSeries50.update((org.jfree.data.time.RegularTimePeriod) month64, (java.lang.Number) 1);
        int int76 = month64.getYearValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond78 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long79 = fixedMillisecond78.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = fixedMillisecond78.previous();
        long long81 = fixedMillisecond78.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries82 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) month64, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond78);
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = day86.next();
        try {
            timeSeries82.add((org.jfree.data.time.RegularTimePeriod) day86, (java.lang.Number) 10.0f, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 2019L + "'", long45 == 2019L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1L + "'", long53 == 1L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1L + "'", long54 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(collection63);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 2019L + "'", long67 == 2019L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1577865599999L + "'", long68 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2019 + "'", int69 == 2019);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1559372400000L + "'", long73 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2019 + "'", int76 == 2019);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1L + "'", long79 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1L + "'", long81 == 1L);
        org.junit.Assert.assertNotNull(timeSeries82);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.List list11 = timeSeries6.getItems();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long21 = fixedMillisecond20.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
        java.util.Calendar calendar24 = null;
        fixedMillisecond20.peg(calendar24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        java.lang.String str27 = timeSeries26.getDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        int int11 = day8.compareTo((java.lang.Object) long10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        long long15 = year13.getLastMillisecond();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long15, "", "2019", class18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getSerialIndex();
        long long22 = year20.getLastMillisecond();
        int int23 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) year20);
        int int24 = timeSeries19.getItemCount();
        java.lang.Class<?> wildcardClass25 = timeSeries19.getClass();
        java.net.URL uRL26 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass25);
        boolean boolean27 = day8.equals((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day8.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day8.previous();
        int int30 = fixedMillisecond1.compareTo((java.lang.Object) day8);
        int int31 = day8.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNull(uRL26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-460));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        int int8 = fixedMillisecond1.compareTo((java.lang.Object) 100);
        java.util.Calendar calendar9 = null;
        fixedMillisecond1.peg(calendar9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(12, (int) (short) 1, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        int int15 = timeSeries6.getMaximumItemCount();
        timeSeries6.setKey((java.lang.Comparable) 10L);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year19 = month18.getYear();
        org.jfree.data.time.Year year20 = month18.getYear();
        try {
            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 1560440797735L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertNotNull(year20);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        long long5 = year3.getLastMillisecond();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long5, "", "2019", class8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        long long12 = year10.getLastMillisecond();
        int int13 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        int int14 = timeSeries9.getItemCount();
        java.lang.Class<?> wildcardClass15 = timeSeries9.getClass();
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass15);
        java.net.URL uRL17 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass15);
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("31-December-1969", (java.lang.Class) wildcardClass15);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(uRL16);
        org.junit.Assert.assertNull(uRL17);
        org.junit.Assert.assertNull(obj18);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long3 = fixedMillisecond2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond2.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond2.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long12 = fixedMillisecond11.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond11.previous();
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond11.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond11.getTime();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long21 = fixedMillisecond20.getSerialIndex();
        long long22 = fixedMillisecond20.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.next();
        java.util.Date date24 = fixedMillisecond20.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getSerialIndex();
        long long28 = year26.getLastMillisecond();
        java.util.Date date29 = year26.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long32 = fixedMillisecond31.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond31.previous();
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond31.getMiddleMillisecond(calendar34);
        java.util.Date date36 = fixedMillisecond31.getTime();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date36, timeZone37);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date29, timeZone37);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date24, timeZone37);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date16, timeZone37);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date7, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year42.previous();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(2, year42);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getSerialIndex();
        long long3 = year1.getLastMillisecond();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long3, "", "2019", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long10 = fixedMillisecond9.getSerialIndex();
        long long11 = fixedMillisecond9.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries7.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries7.getTimePeriod(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long20 = fixedMillisecond19.getSerialIndex();
        long long21 = fixedMillisecond19.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond19.getLastMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond19.getTime();
        int int26 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        int int27 = year0.compareTo((java.lang.Object) timeSeries7);
        timeSeries7.setDomainDescription("September");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        int int7 = timeSeries6.getMaximumItemCount();
        java.lang.Object obj8 = timeSeries6.clone();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year10 = month9.getYear();
        org.jfree.data.time.Year year11 = month9.getYear();
        int int12 = month9.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        long long16 = year14.getLastMillisecond();
        java.util.Date date17 = year14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long20 = fixedMillisecond19.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.previous();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond19.getMiddleMillisecond(calendar22);
        java.util.Date date24 = fixedMillisecond19.getTime();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24, timeZone25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date17, timeZone25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month27, (double) 2019);
        org.jfree.data.time.Year year30 = month27.getYear();
        java.util.Date date31 = year30.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertNotNull(date31);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int2 = spreadsheetDate1.getMonth();
//        int int3 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long6 = fixedMillisecond5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.previous();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getMiddleMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
//        boolean boolean13 = spreadsheetDate1.isOn(serialDate12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long19 = fixedMillisecond18.getSerialIndex();
//        long long20 = fixedMillisecond18.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.next();
//        java.util.Date date22 = fixedMillisecond18.getStart();
//        long long23 = fixedMillisecond18.getMiddleMillisecond();
//        boolean boolean24 = fixedMillisecond14.equals((java.lang.Object) long23);
//        long long25 = fixedMillisecond14.getFirstMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond14.getLastMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond14.getEnd();
//        boolean boolean29 = spreadsheetDate1.equals((java.lang.Object) date28);
//        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate1.getFollowingDayOfWeek(1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int34 = spreadsheetDate33.getMonth();
//        int int35 = spreadsheetDate33.getYYYY();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays(10, serialDate38);
//        org.jfree.data.time.SerialDate serialDate41 = serialDate38.getPreviousDayOfWeek(2);
//        boolean boolean42 = spreadsheetDate33.isOnOrAfter(serialDate41);
//        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate33.getNearestDayOfWeek(7);
//        int int45 = spreadsheetDate1.compare(serialDate44);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440812864L + "'", long25 == 1560440812864L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560440812864L + "'", long27 == 1560440812864L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1900 + "'", int35 == 1900);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-2) + "'", int45 == (-2));
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2958465);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 716968 + "'", int1 == 716968);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        long long2 = year0.getLastMillisecond();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long9 = fixedMillisecond8.getSerialIndex();
//        long long10 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries6.getTimePeriod(0);
//        timeSeries6.setDescription("hi!");
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year20 = month19.getYear();
//        int int21 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 10.0d);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
//        long long25 = year24.getSerialIndex();
//        long long26 = year24.getLastMillisecond();
//        java.lang.Class class29 = null;
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long26, "", "2019", class29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long33 = fixedMillisecond32.getSerialIndex();
//        long long34 = fixedMillisecond32.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (-1.0d));
//        int int38 = timeSeriesDataItem23.compareTo((java.lang.Object) fixedMillisecond32);
//        timeSeriesDataItem23.setValue((java.lang.Number) 1560440759172L);
//        java.lang.Object obj41 = null;
//        boolean boolean42 = timeSeriesDataItem23.equals(obj41);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
//        long long44 = year43.getSerialIndex();
//        long long45 = year43.getLastMillisecond();
//        java.lang.Class class48 = null;
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long45, "", "2019", class48);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long52 = fixedMillisecond51.getSerialIndex();
//        long long53 = fixedMillisecond51.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = fixedMillisecond51.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries49.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (java.lang.Number) (-1.0d));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = timeSeries49.getNextTimePeriod();
//        int int58 = timeSeries49.getMaximumItemCount();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent59 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries49);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean62 = fixedMillisecond60.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long65 = fixedMillisecond64.getSerialIndex();
//        long long66 = fixedMillisecond64.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = fixedMillisecond64.next();
//        java.util.Date date68 = fixedMillisecond64.getStart();
//        long long69 = fixedMillisecond64.getMiddleMillisecond();
//        boolean boolean70 = fixedMillisecond60.equals((java.lang.Object) long69);
//        long long71 = fixedMillisecond60.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = fixedMillisecond60.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries49.addOrUpdate(regularTimePeriod72, (double) 1560440779182L);
//        boolean boolean75 = timeSeriesDataItem23.equals((java.lang.Object) timeSeries49);
//        timeSeries49.clear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1L + "'", long33 == 1L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2019L + "'", long44 == 2019L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1L + "'", long52 == 1L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1L + "'", long53 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2147483647 + "'", int58 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1L + "'", long65 == 1L);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1L + "'", long66 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1L + "'", long69 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560440813220L + "'", long71 == 1560440813220L);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays(10, serialDate3);
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getPreviousDayOfWeek((int) (short) 1);
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(10, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(2);
        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(100);
        int int13 = spreadsheetDate12.getMonth();
        int int14 = spreadsheetDate12.getYYYY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long17 = fixedMillisecond16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond16.previous();
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond16.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond16.getTime();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date21);
        boolean boolean24 = spreadsheetDate12.isOn(serialDate23);
        int int25 = spreadsheetDate12.toSerial();
        int int26 = spreadsheetDate12.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        int int30 = spreadsheetDate29.getMonth();
        int int31 = spreadsheetDate29.getYYYY();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addDays(10, serialDate34);
        org.jfree.data.time.SerialDate serialDate37 = serialDate34.getPreviousDayOfWeek(2);
        boolean boolean38 = spreadsheetDate29.isOnOrAfter(serialDate37);
        org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate29.getNearestDayOfWeek(7);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(10, serialDate44);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addYears(7, serialDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(100);
        int int49 = spreadsheetDate48.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean52 = spreadsheetDate48.isOnOrAfter(serialDate51);
        boolean boolean53 = spreadsheetDate29.isInRange(serialDate46, (org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(100);
        int int57 = spreadsheetDate56.getMonth();
        int int58 = spreadsheetDate56.getYYYY();
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(100);
        int int62 = spreadsheetDate61.getMonth();
        int int63 = spreadsheetDate61.getYYYY();
        java.util.Date date64 = spreadsheetDate61.toDate();
        boolean boolean66 = spreadsheetDate29.isInRange(serialDate59, (org.jfree.data.time.SerialDate) spreadsheetDate61, 0);
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addMonths(3, serialDate59);
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.addDays(0, serialDate70);
        boolean boolean73 = spreadsheetDate12.isInRange(serialDate59, serialDate71, 2);
        org.jfree.data.time.SerialDate serialDate74 = serialDate9.getEndOfCurrentMonth(serialDate59);
        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
        long long76 = year75.getSerialIndex();
        long long77 = year75.getLastMillisecond();
        java.lang.Class class80 = null;
        org.jfree.data.time.TimeSeries timeSeries81 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long77, "", "2019", class80);
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year();
        long long83 = year82.getSerialIndex();
        long long84 = year82.getLastMillisecond();
        int int85 = timeSeries81.getIndex((org.jfree.data.time.RegularTimePeriod) year82);
        timeSeries81.setMaximumItemCount((int) (byte) 100);
        java.lang.Object obj88 = timeSeries81.clone();
        boolean boolean89 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) serialDate59, (java.lang.Object) timeSeries81);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 9 + "'", int49 == 9);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1900 + "'", int58 == 1900);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1900 + "'", int63 == 1900);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 2019L + "'", long76 == 2019L);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1577865599999L + "'", long77 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 2019L + "'", long83 == 2019L);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1577865599999L + "'", long84 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
        org.junit.Assert.assertNotNull(obj88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries6.getTimePeriod(0);
        timeSeries6.setDescription("hi!");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year20 = month19.getYear();
        int int21 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 10.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        long long29 = year27.getLastMillisecond();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long29, "", "2019", class32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getSerialIndex();
        long long36 = year34.getLastMillisecond();
        int int37 = timeSeries33.getIndex((org.jfree.data.time.RegularTimePeriod) year34);
        int int38 = timeSeries33.getItemCount();
        java.lang.Class<?> wildcardClass39 = timeSeries33.getClass();
        java.net.URL uRL40 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass39);
        java.io.InputStream inputStream41 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ClassContext", (java.lang.Class) wildcardClass39);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem23, (java.lang.Class) wildcardClass39);
        timeSeries42.setMaximumItemCount(9999);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNull(uRL40);
        org.junit.Assert.assertNull(inputStream41);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int3 = spreadsheetDate2.getMonth();
//        int int4 = spreadsheetDate2.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long7 = fixedMillisecond6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond6.previous();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getMiddleMillisecond(calendar9);
//        java.util.Date date11 = fixedMillisecond6.getTime();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date11);
//        boolean boolean14 = spreadsheetDate2.isOn(serialDate13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean17 = fixedMillisecond15.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long20 = fixedMillisecond19.getSerialIndex();
//        long long21 = fixedMillisecond19.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
//        java.util.Date date23 = fixedMillisecond19.getStart();
//        long long24 = fixedMillisecond19.getMiddleMillisecond();
//        boolean boolean25 = fixedMillisecond15.equals((java.lang.Object) long24);
//        long long26 = fixedMillisecond15.getFirstMillisecond();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond15.getLastMillisecond(calendar27);
//        java.util.Date date29 = fixedMillisecond15.getEnd();
//        boolean boolean30 = spreadsheetDate2.equals((java.lang.Object) date29);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
//        long long32 = year31.getSerialIndex();
//        long long33 = year31.getLastMillisecond();
//        java.util.Date date34 = year31.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long37 = fixedMillisecond36.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond36.previous();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond36.getMiddleMillisecond(calendar39);
//        java.util.Date date41 = fixedMillisecond36.getTime();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date41, timeZone42);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date34, timeZone42);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date29, timeZone42);
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date29);
//        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date29);
//        try {
//            org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) -1, serialDate47);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440814870L + "'", long26 == 1560440814870L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560440814870L + "'", long28 == 1560440814870L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1L + "'", long37 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1L + "'", long40 == 1L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNotNull(serialDate47);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        int int8 = fixedMillisecond1.compareTo((java.lang.Object) 100);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond1);
        java.lang.Object obj12 = seriesChangeEvent11.getSource();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        timeSeries6.fireSeriesChanged();
        java.lang.String str12 = timeSeries6.getDescription();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year14 = month13.getYear();
        org.jfree.data.time.Year year15 = month13.getYear();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) year15);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(year15);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays(10, serialDate2);
        java.lang.String str4 = serialDate2.getDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getSerialIndex();
        long long7 = year5.getLastMillisecond();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, "", "2019", class10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        long long14 = year12.getLastMillisecond();
        int int15 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        java.util.List list16 = timeSeries11.getItems();
        timeSeries11.fireSeriesChanged();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day21.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long26 = fixedMillisecond25.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.previous();
        java.util.Calendar calendar29 = null;
        fixedMillisecond25.peg(calendar29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day21.next();
        boolean boolean33 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) str4, (java.lang.Object) day21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day21.next();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getSerialIndex();
        long long7 = year5.getLastMillisecond();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, "", "2019", class10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        long long14 = year12.getLastMillisecond();
        int int15 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        int int16 = timeSeries11.getItemCount();
        java.lang.Class<?> wildcardClass17 = timeSeries11.getClass();
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getSerialIndex();
        long long22 = year20.getLastMillisecond();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long22, "", "2019", class25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        long long29 = year27.getLastMillisecond();
        int int30 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        int int31 = timeSeries26.getItemCount();
        java.lang.Class<?> wildcardClass32 = timeSeries26.getClass();
        java.net.URL uRL33 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass32);
        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass17, (java.lang.Class) wildcardClass32);
        java.lang.Class class35 = null;
        java.lang.Object obj36 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass32, class35);
        java.net.URL uRL37 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", (java.lang.Class) wildcardClass32);
        java.io.InputStream inputStream38 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("31-December-1969", (java.lang.Class) wildcardClass32);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(uRL18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNull(uRL33);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertNull(uRL37);
        org.junit.Assert.assertNull(inputStream38);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        java.lang.String str12 = timeSeries6.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener13);
        int int15 = timeSeries6.getMaximumItemCount();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getSerialIndex();
        long long18 = year16.getLastMillisecond();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long18, "", "2019", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long25 = fixedMillisecond24.getSerialIndex();
        long long26 = fixedMillisecond24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeries22.getNextTimePeriod();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getSerialIndex();
        long long33 = year31.getLastMillisecond();
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long33, "", "2019", class36);
        timeSeries37.setDomainDescription("hi!");
        java.util.Collection collection40 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries37);
        boolean boolean41 = timeSeries6.equals((java.lang.Object) collection40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        long long43 = year42.getSerialIndex();
        long long44 = year42.getLastMillisecond();
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long44, "", "2019", class47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        long long50 = year49.getSerialIndex();
        long long51 = year49.getLastMillisecond();
        int int52 = timeSeries48.getIndex((org.jfree.data.time.RegularTimePeriod) year49);
        int int53 = timeSeries48.getItemCount();
        long long54 = timeSeries48.getMaximumItemAge();
        long long55 = timeSeries48.getMaximumItemAge();
        java.util.Collection collection56 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries48);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long59 = fixedMillisecond58.getSerialIndex();
        long long60 = fixedMillisecond58.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = fixedMillisecond58.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries48.getDataItem(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
        org.junit.Assert.assertNotNull(collection40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 2019L + "'", long50 == 2019L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 9223372036854775807L + "'", long54 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 9223372036854775807L + "'", long55 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1L + "'", long59 == 1L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1L + "'", long60 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNull(timeSeriesDataItem62);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        int int2 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        long long4 = day0.getSerialIndex();
//        long long5 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.removeChangeListener(seriesChangeListener7);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) 3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long19 = fixedMillisecond18.getSerialIndex();
        long long20 = fixedMillisecond18.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.next();
        java.util.Date date22 = fixedMillisecond18.getStart();
        long long23 = fixedMillisecond18.getMiddleMillisecond();
        boolean boolean24 = fixedMillisecond14.equals((java.lang.Object) long23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long27 = fixedMillisecond26.getSerialIndex();
        long long28 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.next();
        java.util.Date date30 = fixedMillisecond26.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond26.next();
        boolean boolean32 = fixedMillisecond14.equals((java.lang.Object) fixedMillisecond26);
        boolean boolean33 = timeSeries6.equals((java.lang.Object) fixedMillisecond26);
        java.lang.String str34 = timeSeries6.getRangeDescription();
        timeSeries6.setMaximumItemCount(2019);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getSerialIndex();
        long long3 = year1.getLastMillisecond();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long3, "", "2019", class6);
        int int8 = timeSeries7.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long11 = fixedMillisecond10.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond10.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.previous();
        int int14 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.String str20 = timePeriodFormatException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        boolean boolean27 = fixedMillisecond10.equals((java.lang.Object) timePeriodFormatException18);
        boolean boolean28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "hi!", (java.lang.Object) boolean27);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long6 = fixedMillisecond5.getSerialIndex();
//        long long7 = fixedMillisecond5.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Date date9 = fixedMillisecond5.getStart();
//        long long10 = fixedMillisecond5.getMiddleMillisecond();
//        boolean boolean11 = fixedMillisecond1.equals((java.lang.Object) long10);
//        long long12 = fixedMillisecond1.getFirstMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond1.getLastMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond1.getEnd();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int18 = spreadsheetDate17.getMonth();
//        int int19 = spreadsheetDate17.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long22 = fixedMillisecond21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond21.previous();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond21.getMiddleMillisecond(calendar24);
//        java.util.Date date26 = fixedMillisecond21.getTime();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date26);
//        boolean boolean29 = spreadsheetDate17.isOn(serialDate28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean32 = fixedMillisecond30.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long35 = fixedMillisecond34.getSerialIndex();
//        long long36 = fixedMillisecond34.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond34.next();
//        java.util.Date date38 = fixedMillisecond34.getStart();
//        long long39 = fixedMillisecond34.getMiddleMillisecond();
//        boolean boolean40 = fixedMillisecond30.equals((java.lang.Object) long39);
//        long long41 = fixedMillisecond30.getFirstMillisecond();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond30.getLastMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond30.getEnd();
//        boolean boolean45 = spreadsheetDate17.equals((java.lang.Object) date44);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        long long47 = year46.getSerialIndex();
//        long long48 = year46.getLastMillisecond();
//        java.util.Date date49 = year46.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long52 = fixedMillisecond51.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond51.previous();
//        java.util.Calendar calendar54 = null;
//        long long55 = fixedMillisecond51.getMiddleMillisecond(calendar54);
//        java.util.Date date56 = fixedMillisecond51.getTime();
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date56, timeZone57);
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month(date49, timeZone57);
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date44, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date15, timeZone57);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
//        long long63 = year62.getSerialIndex();
//        long long64 = year62.getLastMillisecond();
//        java.util.Date date65 = year62.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long68 = fixedMillisecond67.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = fixedMillisecond67.previous();
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond67.getMiddleMillisecond(calendar70);
//        java.util.Date date72 = fixedMillisecond67.getTime();
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month(date72, timeZone73);
//        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month(date65, timeZone73);
//        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date15, timeZone73);
//        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.createInstance(date15);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440815965L + "'", long12 == 1560440815965L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440815965L + "'", long14 == 1560440815965L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1900 + "'", int19 == 1900);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440815969L + "'", long41 == 1560440815969L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560440815969L + "'", long43 == 1560440815969L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577865599999L + "'", long48 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1L + "'", long52 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 2019L + "'", long63 == 2019L);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1577865599999L + "'", long64 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1L + "'", long68 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1L + "'", long71 == 1L);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNotNull(serialDate77);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getSerialIndex();
        long long7 = year5.getLastMillisecond();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, "", "2019", class10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        long long14 = year12.getLastMillisecond();
        int int15 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        int int16 = timeSeries11.getItemCount();
        java.lang.Class<?> wildcardClass17 = timeSeries11.getClass();
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass17);
        java.io.InputStream inputStream19 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ClassContext", (java.lang.Class) wildcardClass17);
        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.time.TimePeriodFormatException: hi!", (java.lang.Class) wildcardClass17);
        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesChangeEvent[source=-1]", (java.lang.Class) wildcardClass17);
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("April", (java.lang.Class) wildcardClass17);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(uRL18);
        org.junit.Assert.assertNull(inputStream19);
        org.junit.Assert.assertNull(uRL20);
        org.junit.Assert.assertNull(uRL21);
        org.junit.Assert.assertNull(uRL22);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(10, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(2);
        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate1.getNearestDayOfWeek(7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(100);
        int int15 = spreadsheetDate14.getMonth();
        int int16 = spreadsheetDate14.getYYYY();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays(10, serialDate19);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getPreviousDayOfWeek(2);
        boolean boolean23 = spreadsheetDate14.isOnOrAfter(serialDate22);
        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate14.getNearestDayOfWeek(7);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(10, serialDate29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears(7, serialDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(100);
        int int34 = spreadsheetDate33.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean37 = spreadsheetDate33.isOnOrAfter(serialDate36);
        boolean boolean38 = spreadsheetDate14.isInRange(serialDate31, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean39 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        timeSeries6.setMaximumItemCount((int) (byte) 100);
        timeSeries6.setDescription("June 2019");
        timeSeries6.setDomainDescription("6-April-1900");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "February" + "'", str2.equals("February"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(6, (int) (short) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ThreadContext");
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        java.lang.String str12 = timeSeries6.getDomainDescription();
        java.lang.Class class13 = timeSeries6.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        long long19 = year17.getLastMillisecond();
        int int20 = year17.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1L));
        java.lang.String str23 = seriesChangeEvent22.toString();
        int int24 = year17.compareTo((java.lang.Object) str23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(10, year17);
        java.util.Date date26 = year17.getEnd();
        java.lang.Number number27 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) year17);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str23.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNull(number27);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries6.getTimePeriod(0);
        timeSeries6.setDescription("hi!");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year20 = month19.getYear();
        int int21 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        java.util.Date date22 = month19.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date22);
        java.util.TimeZone timeZone24 = null;
        try {
            org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22, timeZone24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(date22);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        boolean boolean5 = spreadsheetDate1.isOnOrAfter(serialDate4);
//        java.util.Date date6 = spreadsheetDate1.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long9 = fixedMillisecond8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond8.getMiddleMillisecond(calendar11);
//        java.util.Date date13 = fixedMillisecond8.getTime();
//        java.util.Date date14 = fixedMillisecond8.getTime();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int17 = spreadsheetDate16.getMonth();
//        int int18 = spreadsheetDate16.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long21 = fixedMillisecond20.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond20.getMiddleMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond20.getTime();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date25);
//        boolean boolean28 = spreadsheetDate16.isOn(serialDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean31 = fixedMillisecond29.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long34 = fixedMillisecond33.getSerialIndex();
//        long long35 = fixedMillisecond33.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond33.next();
//        java.util.Date date37 = fixedMillisecond33.getStart();
//        long long38 = fixedMillisecond33.getMiddleMillisecond();
//        boolean boolean39 = fixedMillisecond29.equals((java.lang.Object) long38);
//        long long40 = fixedMillisecond29.getFirstMillisecond();
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond29.getLastMillisecond(calendar41);
//        java.util.Date date43 = fixedMillisecond29.getEnd();
//        boolean boolean44 = spreadsheetDate16.equals((java.lang.Object) date43);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        long long46 = year45.getSerialIndex();
//        long long47 = year45.getLastMillisecond();
//        java.util.Date date48 = year45.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long51 = fixedMillisecond50.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = fixedMillisecond50.previous();
//        java.util.Calendar calendar53 = null;
//        long long54 = fixedMillisecond50.getMiddleMillisecond(calendar53);
//        java.util.Date date55 = fixedMillisecond50.getTime();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date55, timeZone56);
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date48, timeZone56);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date43, timeZone56);
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(date14, timeZone56);
//        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date6, timeZone56);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560440817481L + "'", long40 == 1560440817481L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560440817481L + "'", long42 == 1560440817481L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1577865599999L + "'", long47 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1L + "'", long51 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1L + "'", long54 == 1L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone56);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int2 = spreadsheetDate1.getMonth();
//        int int3 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(10, serialDate6);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(2);
//        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(0, serialDate13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int17 = spreadsheetDate16.getMonth();
//        int int18 = spreadsheetDate16.getYYYY();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(10, serialDate21);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate21.getPreviousDayOfWeek(2);
//        boolean boolean25 = spreadsheetDate16.isOnOrAfter(serialDate24);
//        boolean boolean27 = spreadsheetDate1.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16, 0);
//        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate16.getNearestDayOfWeek(4);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int32 = spreadsheetDate31.getMonth();
//        int int33 = spreadsheetDate31.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long36 = fixedMillisecond35.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond35.previous();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond35.getMiddleMillisecond(calendar38);
//        java.util.Date date40 = fixedMillisecond35.getTime();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date40);
//        boolean boolean43 = spreadsheetDate31.isOn(serialDate42);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean46 = fixedMillisecond44.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long49 = fixedMillisecond48.getSerialIndex();
//        long long50 = fixedMillisecond48.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond48.next();
//        java.util.Date date52 = fixedMillisecond48.getStart();
//        long long53 = fixedMillisecond48.getMiddleMillisecond();
//        boolean boolean54 = fixedMillisecond44.equals((java.lang.Object) long53);
//        long long55 = fixedMillisecond44.getFirstMillisecond();
//        java.util.Calendar calendar56 = null;
//        long long57 = fixedMillisecond44.getLastMillisecond(calendar56);
//        java.util.Date date58 = fixedMillisecond44.getEnd();
//        boolean boolean59 = spreadsheetDate31.equals((java.lang.Object) date58);
//        org.jfree.data.time.SerialDate serialDate61 = spreadsheetDate31.getFollowingDayOfWeek(1);
//        boolean boolean62 = spreadsheetDate16.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1L + "'", long49 == 1L);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1L + "'", long50 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1L + "'", long53 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560440818332L + "'", long55 == 1560440818332L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560440818332L + "'", long57 == 1560440818332L);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("July");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2147483647);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries6.getTimePeriod(0);
        timeSeries6.setDescription("hi!");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year20 = month19.getYear();
        int int21 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        long long22 = month19.getFirstMillisecond();
        int int23 = month19.getYearValue();
        int int24 = month19.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1559372400000L + "'", long22 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.List list11 = timeSeries6.getItems();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long21 = fixedMillisecond20.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
        java.util.Calendar calendar24 = null;
        fixedMillisecond20.peg(calendar24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        java.lang.Object obj27 = timeSeries6.clone();
        timeSeries6.setRangeDescription("9-April-1900");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        java.lang.String str12 = timeSeries6.getDomainDescription();
        timeSeries6.setRangeDescription("");
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries6.createCopy((int) (byte) 0, (int) (short) 100);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.lang.String str19 = year18.toString();
        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getSerialIndex();
        long long23 = year21.getLastMillisecond();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long23, "", "2019", class26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getSerialIndex();
        long long30 = year28.getLastMillisecond();
        int int31 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) year28);
        int int32 = timeSeries27.getItemCount();
        java.lang.String str33 = timeSeries27.getDomainDescription();
        timeSeries27.setRangeDescription("");
        int int36 = year18.compareTo((java.lang.Object) timeSeries27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long39 = fixedMillisecond38.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond38.previous();
        java.lang.Class<?> wildcardClass41 = regularTimePeriod40.getClass();
        try {
            timeSeries27.add(regularTimePeriod40, (java.lang.Number) 1560440746952L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.List list11 = timeSeries6.getItems();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long21 = fixedMillisecond20.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
        java.util.Calendar calendar24 = null;
        fixedMillisecond20.peg(calendar24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        timeSeries6.removeAgedItems(false);
        java.lang.String str29 = timeSeries6.getDescription();
        long long30 = timeSeries6.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        int int15 = timeSeries6.getMaximumItemCount();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        int int21 = day19.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        timeSeries6.setMaximumItemCount(10);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getSerialIndex();
        long long28 = year26.getLastMillisecond();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long28, "", "2019", class31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long35 = fixedMillisecond34.getSerialIndex();
        long long36 = fixedMillisecond34.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond34.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeries32.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeries32.getTimePeriod(0);
        timeSeries32.setDescription("hi!");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year46 = month45.getYear();
        int int47 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (java.lang.Number) 10.0d);
        try {
            timeSeries6.add(timeSeriesDataItem49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(year46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.List list11 = timeSeries6.getItems();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        long long14 = year12.getLastMillisecond();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long14, "", "2019", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long21 = fixedMillisecond20.getSerialIndex();
        long long22 = fixedMillisecond20.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries18.getNextTimePeriod();
        int int27 = timeSeries18.getMaximumItemCount();
        timeSeries18.setKey((java.lang.Comparable) 10L);
        java.util.Collection collection30 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        boolean boolean31 = timeSeries6.isEmpty();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries6.getTimePeriod(0);
        timeSeries6.setDescription("hi!");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year20 = month19.getYear();
        int int21 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 10.0d);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        long long26 = year24.getLastMillisecond();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long26, "", "2019", class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long33 = fixedMillisecond32.getSerialIndex();
        long long34 = fixedMillisecond32.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (-1.0d));
        int int38 = timeSeriesDataItem23.compareTo((java.lang.Object) fixedMillisecond32);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond32.getMiddleMillisecond(calendar39);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1L + "'", long33 == 1L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1L + "'", long40 == 1L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        int int15 = timeSeries6.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(6, year1);
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.next();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        int int3 = spreadsheetDate2.getMonth();
        int int4 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(10, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getPreviousDayOfWeek(2);
        boolean boolean11 = spreadsheetDate2.isOnOrAfter(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate2.getNearestDayOfWeek(7);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        java.util.Collection collection12 = timeSeries6.getTimePeriods();
        timeSeries6.setMaximumItemCount((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        long long6 = year4.getLastMillisecond();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, "", "2019", class9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long13 = fixedMillisecond12.getSerialIndex();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries10.getNextTimePeriod();
        timeSeries10.setNotify(true);
        boolean boolean21 = month0.equals((java.lang.Object) timeSeries10);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        long long24 = year22.getLastMillisecond();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long24, "", "2019", class27);
        timeSeries28.setDomainDescription("hi!");
        java.util.Collection collection31 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        int int32 = timeSeries28.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long35 = fixedMillisecond34.getSerialIndex();
        long long36 = fixedMillisecond34.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond34.next();
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond34.getLastMillisecond(calendar38);
        int int41 = fixedMillisecond34.compareTo((java.lang.Object) 100);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        long long48 = year47.getSerialIndex();
        long long49 = year47.getLastMillisecond();
        java.lang.Class class52 = null;
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long49, "", "2019", class52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getSerialIndex();
        long long56 = year54.getLastMillisecond();
        int int57 = timeSeries53.getIndex((org.jfree.data.time.RegularTimePeriod) year54);
        int int58 = timeSeries53.getItemCount();
        java.lang.Class<?> wildcardClass59 = timeSeries53.getClass();
        java.net.URL uRL60 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass59);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        long long63 = year62.getSerialIndex();
        long long64 = year62.getLastMillisecond();
        java.lang.Class class67 = null;
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long64, "", "2019", class67);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        long long70 = year69.getSerialIndex();
        long long71 = year69.getLastMillisecond();
        int int72 = timeSeries68.getIndex((org.jfree.data.time.RegularTimePeriod) year69);
        int int73 = timeSeries68.getItemCount();
        java.lang.Class<?> wildcardClass74 = timeSeries68.getClass();
        java.net.URL uRL75 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass74);
        java.lang.Object obj76 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass59, (java.lang.Class) wildcardClass74);
        java.lang.Object obj77 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass74);
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond34, "2019", "", (java.lang.Class) wildcardClass74);
        java.util.Collection collection79 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries78);
        timeSeries28.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2147483647 + "'", int32 == 2147483647);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2019L + "'", long55 == 2019L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1577865599999L + "'", long56 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNull(uRL60);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 2019L + "'", long63 == 2019L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1577865599999L + "'", long64 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 2019L + "'", long70 == 2019L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1577865599999L + "'", long71 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNull(uRL75);
        org.junit.Assert.assertNull(obj76);
        org.junit.Assert.assertNull(obj77);
        org.junit.Assert.assertNotNull(collection79);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        long long2 = year0.getLastMillisecond();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        long long9 = year7.getLastMillisecond();
//        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
//        timeSeries6.setMaximumItemCount((int) (byte) 100);
//        java.lang.Object obj13 = timeSeries6.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long19 = fixedMillisecond18.getSerialIndex();
//        long long20 = fixedMillisecond18.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.next();
//        java.util.Date date22 = fixedMillisecond18.getStart();
//        long long23 = fixedMillisecond18.getMiddleMillisecond();
//        boolean boolean24 = fixedMillisecond14.equals((java.lang.Object) long23);
//        long long25 = fixedMillisecond14.getFirstMillisecond();
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 1560440803143L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440819886L + "'", long25 == 1560440819886L);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        java.lang.Class<?> wildcardClass12 = timeSeries6.getClass();
        java.util.Collection collection13 = timeSeries6.getTimePeriods();
        java.util.List list14 = timeSeries6.getItems();
        try {
            java.util.Collection collection15 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list14);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.List list11 = timeSeries6.getItems();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long15 = fixedMillisecond14.getSerialIndex();
        long long16 = fixedMillisecond14.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
        java.util.Date date18 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        timeSeries6.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) '#');
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        java.lang.Comparable comparable28 = timeSeries6.getKey();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 1577865599999L + "'", comparable28.equals(1577865599999L));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(100);
        int int6 = spreadsheetDate5.getMonth();
        int int7 = spreadsheetDate5.getYYYY();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(10, serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getPreviousDayOfWeek(2);
        boolean boolean14 = spreadsheetDate5.isOnOrAfter(serialDate13);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(0, serialDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(100);
        int int21 = spreadsheetDate20.getMonth();
        int int22 = spreadsheetDate20.getYYYY();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addDays(10, serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getPreviousDayOfWeek(2);
        boolean boolean29 = spreadsheetDate20.isOnOrAfter(serialDate28);
        boolean boolean31 = spreadsheetDate5.isInRange(serialDate18, (org.jfree.data.time.SerialDate) spreadsheetDate20, 0);
        org.jfree.data.time.SerialDate serialDate32 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate33 = null;
        try {
            int int34 = spreadsheetDate20.compare(serialDate33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(serialDate32);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        int int3 = spreadsheetDate2.getMonth();
        int int4 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        int int8 = spreadsheetDate7.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean11 = spreadsheetDate7.isOnOrAfter(serialDate10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        int int18 = day16.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths(0, serialDate19);
        boolean boolean21 = spreadsheetDate7.isOnOrBefore(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        int int24 = spreadsheetDate23.getDayOfMonth();
        boolean boolean25 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean26 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int27 = spreadsheetDate2.getDayOfMonth();
        java.util.Date date28 = spreadsheetDate2.toDate();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 13 + "'", int18 == 13);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 9 + "'", int27 == 9);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        java.lang.Class<?> wildcardClass12 = timeSeries6.getClass();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries6.addChangeListener(seriesChangeListener15);
        timeSeries6.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(10, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(2);
        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate1.getNearestDayOfWeek(7);
        java.util.Date date13 = spreadsheetDate1.toDate();
        java.util.Date date14 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        long long17 = year15.getLastMillisecond();
        int int18 = year15.getYear();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year15);
        boolean boolean20 = spreadsheetDate1.equals((java.lang.Object) year15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        int int5 = day3.getMonth();
        long long6 = day3.getLastMillisecond();
        long long7 = day3.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1555225199999L + "'", long6 == 1555225199999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1555225199999L + "'", long7 == 1555225199999L);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        java.lang.Class class1 = null;
//        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("September", class1);
//        org.junit.Assert.assertNull(uRL2);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        int int3 = spreadsheetDate2.getMonth();
        int int4 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(100);
        int int8 = spreadsheetDate7.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean11 = spreadsheetDate7.isOnOrAfter(serialDate10);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        int int18 = day16.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths(0, serialDate19);
        boolean boolean21 = spreadsheetDate7.isOnOrBefore(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        int int24 = spreadsheetDate23.getDayOfMonth();
        boolean boolean25 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean26 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int27 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 13 + "'", int18 == 13);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 9 + "'", int27 == 9);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        long long8 = year6.getLastMillisecond();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long8, "", "2019", class11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        long long15 = year13.getLastMillisecond();
        int int16 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        int int17 = timeSeries12.getItemCount();
        java.lang.Class<?> wildcardClass18 = timeSeries12.getClass();
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getSerialIndex();
        long long23 = year21.getLastMillisecond();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long23, "", "2019", class26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getSerialIndex();
        long long30 = year28.getLastMillisecond();
        int int31 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) year28);
        int int32 = timeSeries27.getItemCount();
        java.lang.Class<?> wildcardClass33 = timeSeries27.getClass();
        java.net.URL uRL34 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass33);
        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass18, (java.lang.Class) wildcardClass33);
        java.lang.Class class36 = null;
        java.lang.Object obj37 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass33, class36);
        java.net.URL uRL38 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", (java.lang.Class) wildcardClass33);
        java.io.InputStream inputStream39 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("January", (java.lang.Class) wildcardClass33);
        java.io.InputStream inputStream40 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ERROR : Relative To String", (java.lang.Class) wildcardClass33);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(uRL19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 2019L + "'", long22 == 2019L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNull(uRL34);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertNull(obj37);
        org.junit.Assert.assertNull(uRL38);
        org.junit.Assert.assertNull(inputStream39);
        org.junit.Assert.assertNull(inputStream40);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        int int7 = timeSeries6.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long10 = fixedMillisecond9.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond9.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.previous();
        int int13 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond9.next();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        long long17 = year15.getLastMillisecond();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17, "", "2019", class20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        long long24 = year22.getLastMillisecond();
        int int25 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) year22);
        timeSeries21.setMaximumItemCount((int) (byte) 100);
        timeSeries21.setDescription("June 2019");
        boolean boolean30 = fixedMillisecond9.equals((java.lang.Object) "June 2019");
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond9.getLastMillisecond(calendar31);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.List list11 = timeSeries6.getItems();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long21 = fixedMillisecond20.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
        java.util.Calendar calendar24 = null;
        fixedMillisecond20.peg(calendar24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = null;
        java.lang.Number number28 = null;
        try {
            timeSeries6.update(regularTimePeriod27, number28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(6, year1);
        long long4 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int2 = spreadsheetDate1.getMonth();
//        int int3 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(10, serialDate6);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(2);
//        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
//        int int11 = spreadsheetDate1.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int14 = spreadsheetDate13.getMonth();
//        int int15 = spreadsheetDate13.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long18 = fixedMillisecond17.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond17.previous();
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond17.getMiddleMillisecond(calendar20);
//        java.util.Date date22 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date22);
//        boolean boolean25 = spreadsheetDate13.isOn(serialDate24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean28 = fixedMillisecond26.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long31 = fixedMillisecond30.getSerialIndex();
//        long long32 = fixedMillisecond30.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond30.next();
//        java.util.Date date34 = fixedMillisecond30.getStart();
//        long long35 = fixedMillisecond30.getMiddleMillisecond();
//        boolean boolean36 = fixedMillisecond26.equals((java.lang.Object) long35);
//        long long37 = fixedMillisecond26.getFirstMillisecond();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond26.getLastMillisecond(calendar38);
//        java.util.Date date40 = fixedMillisecond26.getEnd();
//        boolean boolean41 = spreadsheetDate13.equals((java.lang.Object) date40);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int44 = spreadsheetDate43.getMonth();
//        int int45 = spreadsheetDate43.getYYYY();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays(10, serialDate48);
//        org.jfree.data.time.SerialDate serialDate51 = serialDate48.getPreviousDayOfWeek(2);
//        boolean boolean52 = spreadsheetDate43.isOnOrAfter(serialDate51);
//        int int53 = spreadsheetDate43.getDayOfWeek();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate43);
//        int int55 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate43);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int59 = spreadsheetDate58.getMonth();
//        int int60 = spreadsheetDate58.getYYYY();
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate58);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int64 = spreadsheetDate63.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        boolean boolean67 = spreadsheetDate63.isOnOrAfter(serialDate66);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(13, 4, 2019);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = day72.previous();
//        int int74 = day72.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate75 = day72.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.addMonths(0, serialDate75);
//        boolean boolean77 = spreadsheetDate63.isOnOrBefore(serialDate76);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate79 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int80 = spreadsheetDate79.getDayOfMonth();
//        boolean boolean81 = spreadsheetDate63.isOn((org.jfree.data.time.SerialDate) spreadsheetDate79);
//        boolean boolean82 = spreadsheetDate58.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate63);
//        int int83 = spreadsheetDate58.getDayOfMonth();
//        boolean boolean84 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate43, (org.jfree.data.time.SerialDate) spreadsheetDate58);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560440820598L + "'", long37 == 1560440820598L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560440820598L + "'", long39 == 1560440820598L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 4 + "'", int44 == 4);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1900 + "'", int45 == 1900);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2 + "'", int53 == 2);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 4 + "'", int59 == 4);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1900 + "'", int60 == 1900);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 9 + "'", int64 == 9);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 13 + "'", int74 == 13);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 9 + "'", int80 == 9);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 9 + "'", int83 == 9);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(3, year1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        int int5 = day3.getDayOfMonth();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        long long8 = year6.getLastMillisecond();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long8, "", "2019", class11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long15 = fixedMillisecond14.getSerialIndex();
        long long16 = fixedMillisecond14.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries12.getNextTimePeriod();
        timeSeries12.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener23);
        boolean boolean25 = day3.equals((java.lang.Object) propertyChangeListener23);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = day3.getFirstMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(10, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(2);
        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
        int int11 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.List list11 = timeSeries6.getItems();
        timeSeries6.fireSeriesChanged();
        java.lang.String str13 = timeSeries6.getDomainDescription();
        java.util.Collection collection14 = timeSeries6.getTimePeriods();
        try {
            timeSeries6.delete(0, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 31);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.Class<?> wildcardClass12 = timePeriodFormatException9.getClass();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException9.getSuppressed();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        long long4 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries6.addChangeListener(seriesChangeListener14);
        timeSeries6.update(0, (java.lang.Number) 1577865599999L);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        long long21 = year19.getLastMillisecond();
        int int22 = year19.getYear();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year19);
        boolean boolean25 = year19.equals((java.lang.Object) 'a');
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) year19);
        java.util.List list27 = timeSeries6.getItems();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        timeSeries6.setNotify(true);
        long long17 = timeSeries6.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries6.addChangeListener(seriesChangeListener18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            timeSeries6.delete(regularTimePeriod20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        int int3 = year0.getYear();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getSerialIndex();
        long long7 = year5.getLastMillisecond();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, "", "2019", class10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long14 = fixedMillisecond13.getSerialIndex();
        long long15 = fixedMillisecond13.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries11.getNextTimePeriod();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getSerialIndex();
        long long22 = year20.getLastMillisecond();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long22, "", "2019", class25);
        timeSeries26.setDomainDescription("hi!");
        java.util.Collection collection29 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
        int int35 = day33.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) day33);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getSerialIndex();
        long long41 = year39.getLastMillisecond();
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long41, "", "2019", class44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        long long47 = year46.getSerialIndex();
        long long48 = year46.getLastMillisecond();
        int int49 = timeSeries45.getIndex((org.jfree.data.time.RegularTimePeriod) year46);
        int int50 = timeSeries45.getItemCount();
        java.lang.Class<?> wildcardClass51 = timeSeries45.getClass();
        java.net.URL uRL52 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass51);
        java.io.InputStream inputStream53 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ClassContext", (java.lang.Class) wildcardClass51);
        int int54 = timeSeriesDataItem36.compareTo((java.lang.Object) "ClassContext");
        try {
            timeSeries4.add(timeSeriesDataItem36);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 13 + "'", int35 == 13);
        org.junit.Assert.assertNotNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577865599999L + "'", long48 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNull(uRL52);
        org.junit.Assert.assertNull(inputStream53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        long long2 = year0.getLastMillisecond();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long9 = fixedMillisecond8.getSerialIndex();
//        long long10 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries6.getTimePeriod(0);
//        timeSeries6.setDescription("hi!");
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Year year20 = month19.getYear();
//        int int21 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 10.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        long long28 = year27.getSerialIndex();
//        long long29 = year27.getLastMillisecond();
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long29, "", "2019", class32);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        long long35 = year34.getSerialIndex();
//        long long36 = year34.getLastMillisecond();
//        int int37 = timeSeries33.getIndex((org.jfree.data.time.RegularTimePeriod) year34);
//        int int38 = timeSeries33.getItemCount();
//        java.lang.Class<?> wildcardClass39 = timeSeries33.getClass();
//        java.net.URL uRL40 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass39);
//        java.io.InputStream inputStream41 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ClassContext", (java.lang.Class) wildcardClass39);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem23, (java.lang.Class) wildcardClass39);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(13, 4, 2019);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day46.previous();
//        java.lang.String str49 = day46.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean52 = fixedMillisecond50.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long55 = fixedMillisecond54.getSerialIndex();
//        long long56 = fixedMillisecond54.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond54.next();
//        java.util.Date date58 = fixedMillisecond54.getStart();
//        long long59 = fixedMillisecond54.getMiddleMillisecond();
//        boolean boolean60 = fixedMillisecond50.equals((java.lang.Object) long59);
//        long long61 = fixedMillisecond50.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = fixedMillisecond50.next();
//        int int63 = day46.compareTo((java.lang.Object) fixedMillisecond50);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, 1.0d);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean68 = fixedMillisecond66.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long71 = fixedMillisecond70.getSerialIndex();
//        long long72 = fixedMillisecond70.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = fixedMillisecond70.next();
//        java.util.Date date74 = fixedMillisecond70.getStart();
//        long long75 = fixedMillisecond70.getMiddleMillisecond();
//        boolean boolean76 = fixedMillisecond66.equals((java.lang.Object) long75);
//        long long77 = fixedMillisecond66.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = fixedMillisecond66.next();
//        java.lang.Number number79 = timeSeries42.getValue(regularTimePeriod78);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener80 = null;
//        timeSeries42.addChangeListener(seriesChangeListener80);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNull(uRL40);
//        org.junit.Assert.assertNull(inputStream41);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-April-2019" + "'", str49.equals("13-April-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1L + "'", long56 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1L + "'", long59 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560440822615L + "'", long61 == 1560440822615L);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem65);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1L + "'", long71 == 1L);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1L + "'", long72 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1L + "'", long75 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1560440822620L + "'", long77 == 1560440822620L);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 1.0d + "'", number79.equals(1.0d));
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long6 = fixedMillisecond5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.previous();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond5.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond5.getTime();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date10, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date3, timeZone11);
        long long14 = month13.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(10, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(2);
        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
        int int11 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day12.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        timeSeries6.setDomainDescription("hi!");
        java.lang.String str9 = timeSeries6.getRangeDescription();
        int int10 = timeSeries6.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        int int6 = fixedMillisecond1.compareTo((java.lang.Object) 'a');
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long9, "", "2019", class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long16 = fixedMillisecond15.getSerialIndex();
        long long17 = fixedMillisecond15.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond15.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries13.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries13.getTimePeriod(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long26 = fixedMillisecond25.getSerialIndex();
        long long27 = fixedMillisecond25.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.next();
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getLastMillisecond(calendar29);
        java.util.Date date31 = fixedMillisecond25.getTime();
        int int32 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        java.lang.Class class33 = timeSeries13.getTimePeriodClass();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getSerialIndex();
        timeSeries13.update((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) (byte) -1);
        boolean boolean38 = fixedMillisecond1.equals((java.lang.Object) year34);
        java.util.Date date39 = fixedMillisecond1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
        long long41 = fixedMillisecond40.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNull(class33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1L + "'", long41 == 1L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        java.lang.Class<?> wildcardClass12 = timeSeries6.getClass();
        boolean boolean13 = timeSeries6.isEmpty();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int15 = month14.getYearValue();
        org.jfree.data.time.Year year16 = month14.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) year16);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries6.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        long long17 = year15.getLastMillisecond();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17, "", "2019", class20);
        timeSeries21.setDomainDescription("hi!");
        java.util.Collection collection24 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        timeSeries21.setRangeDescription("ThreadContext");
        try {
            timeSeries21.update(7, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(collection24);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        int int6 = day3.compareTo((java.lang.Object) long5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.previous();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries6.getTimePeriod(0);
        timeSeries6.setDescription("hi!");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year20 = month19.getYear();
        int int21 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        java.util.Date date22 = month19.getStart();
        long long23 = month19.getSerialIndex();
        int int25 = month19.compareTo((java.lang.Object) 100L);
        java.lang.String str26 = month19.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 24234L + "'", long23 == 24234L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "June 2019" + "'", str26.equals("June 2019"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(4, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        java.lang.Class<?> wildcardClass12 = timeSeries6.getClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries6.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
        java.util.Date date20 = day18.getStart();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
        java.lang.String str23 = month21.toString();
        java.lang.String str24 = month21.toString();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day18, (org.jfree.data.time.RegularTimePeriod) month21);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "June 2019" + "'", str23.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertNotNull(timeSeries25);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        long long2 = year0.getLastMillisecond();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        long long9 = year7.getLastMillisecond();
//        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
//        int int11 = timeSeries6.getItemCount();
//        java.util.List list12 = timeSeries6.getItems();
//        timeSeries6.setMaximumItemAge(2019L);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int17 = spreadsheetDate16.getMonth();
//        int int18 = spreadsheetDate16.getYYYY();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(10, serialDate21);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate21.getPreviousDayOfWeek(2);
//        boolean boolean25 = spreadsheetDate16.isOnOrAfter(serialDate24);
//        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate16.getNearestDayOfWeek(7);
//        timeSeries6.setKey((java.lang.Comparable) spreadsheetDate16);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
//        long long31 = day29.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 1560440822615L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560495599999L + "'", long31 == 1560495599999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        timeSeries6.setDomainDescription("hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        long long11 = year9.getLastMillisecond();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long11, "", "2019", class14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getSerialIndex();
        long long18 = year16.getLastMillisecond();
        int int19 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) year16);
        java.util.List list20 = timeSeries15.getItems();
        timeSeries15.fireSeriesChanged();
        java.lang.String str22 = timeSeries15.getRangeDescription();
        java.lang.Comparable comparable23 = timeSeries15.getKey();
        boolean boolean24 = timeSeries6.equals((java.lang.Object) comparable23);
        timeSeries6.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries6.createCopy((int) (short) 0, 6);
        long long30 = timeSeries6.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 1577865599999L + "'", comparable23.equals(1577865599999L));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long11 = fixedMillisecond10.getSerialIndex();
        long long12 = fixedMillisecond10.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
        java.util.Date date14 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getSerialIndex();
        long long18 = year16.getLastMillisecond();
        java.util.Date date19 = year16.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long22 = fixedMillisecond21.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond21.previous();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond21.getMiddleMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond21.getTime();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date26, timeZone27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date19, timeZone27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date14, timeZone27);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date6, timeZone27);
        java.util.Calendar calendar32 = null;
        try {
            day31.peg(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        long long6 = year4.getLastMillisecond();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, "", "2019", class9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long13 = fixedMillisecond12.getSerialIndex();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries10.getNextTimePeriod();
        timeSeries10.setNotify(true);
        boolean boolean21 = month0.equals((java.lang.Object) timeSeries10);
        timeSeries10.removeAgedItems(false);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day24.next();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day24);
        java.util.Calendar calendar28 = null;
        try {
            long long29 = day24.getFirstMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        java.util.List list12 = timeSeries6.getItems();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.previous();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries6.getDataItem(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        long long6 = year4.getLastMillisecond();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, "", "2019", class9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long13 = fixedMillisecond12.getSerialIndex();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries10.getNextTimePeriod();
        timeSeries10.setNotify(true);
        boolean boolean21 = month0.equals((java.lang.Object) timeSeries10);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        long long24 = year22.getLastMillisecond();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long24, "", "2019", class27);
        timeSeries28.setDomainDescription("hi!");
        java.util.Collection collection31 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        int int32 = timeSeries28.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long35 = fixedMillisecond34.getSerialIndex();
        long long36 = fixedMillisecond34.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond34.next();
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond34.getLastMillisecond(calendar38);
        java.util.Date date40 = fixedMillisecond34.getTime();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        org.jfree.data.time.Year year42 = month41.getYear();
        int int43 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year42.previous();
        int int45 = year42.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2147483647 + "'", int32 == 2147483647);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(year42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1969 + "'", int45 == 1969);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        int int7 = timeSeries6.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long10 = fixedMillisecond9.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond9.previous();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond9.getMiddleMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond9.getTime();
        java.util.Date date15 = fixedMillisecond9.getTime();
        int int16 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        int int3 = spreadsheetDate2.getMonth();
        int int4 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        long long8 = year6.getLastMillisecond();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long8, "", "2019", class11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        long long15 = year13.getLastMillisecond();
        int int16 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries12.setMaximumItemCount((int) (byte) 100);
        timeSeries12.setDescription("June 2019");
        boolean boolean21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 0, (java.lang.Object) timeSeries12);
        java.lang.String str22 = timeSeries12.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getSerialIndex();
        long long7 = year5.getLastMillisecond();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, "", "2019", class10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        long long14 = year12.getLastMillisecond();
        int int15 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        int int16 = timeSeries11.getItemCount();
        java.lang.Class<?> wildcardClass17 = timeSeries11.getClass();
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getSerialIndex();
        long long22 = year20.getLastMillisecond();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long22, "", "2019", class25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        long long29 = year27.getLastMillisecond();
        int int30 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year27);
        int int31 = timeSeries26.getItemCount();
        java.lang.Class<?> wildcardClass32 = timeSeries26.getClass();
        java.net.URL uRL33 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass32);
        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass17, (java.lang.Class) wildcardClass32);
        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass32);
        java.net.URL uRL36 = org.jfree.chart.util.ObjectUtilities.getResource("June 2019", (java.lang.Class) wildcardClass32);
        java.net.URL uRL37 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass32);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(uRL18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNull(uRL33);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertNull(uRL36);
        org.junit.Assert.assertNull(uRL37);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        long long6 = year4.getLastMillisecond();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, "", "2019", class9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getSerialIndex();
        long long13 = year11.getLastMillisecond();
        int int14 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        int int15 = timeSeries10.getItemCount();
        java.lang.Class<?> wildcardClass16 = timeSeries10.getClass();
        java.net.URL uRL17 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        long long21 = year19.getLastMillisecond();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long21, "", "2019", class24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getSerialIndex();
        long long28 = year26.getLastMillisecond();
        int int29 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) year26);
        int int30 = timeSeries25.getItemCount();
        java.lang.Class<?> wildcardClass31 = timeSeries25.getClass();
        java.net.URL uRL32 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass31);
        java.lang.Object obj33 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass16, (java.lang.Class) wildcardClass31);
        java.lang.Class class34 = null;
        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass31, class34);
        try {
            java.net.URL uRL36 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("9-April-1900", class34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNull(uRL17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNull(uRL32);
        org.junit.Assert.assertNull(obj33);
        org.junit.Assert.assertNull(obj35);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(10, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(2);
        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(0, serialDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        int int17 = spreadsheetDate16.getMonth();
        int int18 = spreadsheetDate16.getYYYY();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(10, serialDate21);
        org.jfree.data.time.SerialDate serialDate24 = serialDate21.getPreviousDayOfWeek(2);
        boolean boolean25 = spreadsheetDate16.isOnOrAfter(serialDate24);
        boolean boolean27 = spreadsheetDate1.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16, 0);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addDays(10, serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = serialDate31.getPreviousDayOfWeek((int) (short) 1);
        boolean boolean34 = spreadsheetDate1.isBefore(serialDate33);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(10, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(2);
        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
        int int11 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean15 = spreadsheetDate1.isOnOrAfter(serialDate14);
        java.util.Date date16 = spreadsheetDate1.toDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date16);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        long long2 = year0.getLastMillisecond();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        long long9 = year7.getLastMillisecond();
//        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
//        int int11 = timeSeries6.getItemCount();
//        java.util.List list12 = timeSeries6.getItems();
//        timeSeries6.setMaximumItemAge(2019L);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int17 = spreadsheetDate16.getMonth();
//        int int18 = spreadsheetDate16.getYYYY();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(10, serialDate21);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate21.getPreviousDayOfWeek(2);
//        boolean boolean25 = spreadsheetDate16.isOnOrAfter(serialDate24);
//        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate16.getNearestDayOfWeek(7);
//        timeSeries6.setKey((java.lang.Comparable) spreadsheetDate16);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(10, serialDate31);
//        java.lang.String str33 = serialDate31.getDescription();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        long long35 = year34.getSerialIndex();
//        long long36 = year34.getLastMillisecond();
//        java.lang.Class class39 = null;
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long36, "", "2019", class39);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
//        long long42 = year41.getSerialIndex();
//        long long43 = year41.getLastMillisecond();
//        int int44 = timeSeries40.getIndex((org.jfree.data.time.RegularTimePeriod) year41);
//        java.util.List list45 = timeSeries40.getItems();
//        timeSeries40.fireSeriesChanged();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(13, 4, 2019);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day50.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long55 = fixedMillisecond54.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond54.previous();
//        java.util.Calendar calendar58 = null;
//        fixedMillisecond54.peg(calendar58);
//        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries40.createCopy((org.jfree.data.time.RegularTimePeriod) day50, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day50.next();
//        boolean boolean62 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) str33, (java.lang.Object) day50);
//        boolean boolean63 = timeSeries6.equals((java.lang.Object) day50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean66 = fixedMillisecond64.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long69 = fixedMillisecond68.getSerialIndex();
//        long long70 = fixedMillisecond68.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = fixedMillisecond68.next();
//        java.util.Date date72 = fixedMillisecond68.getStart();
//        long long73 = fixedMillisecond68.getMiddleMillisecond();
//        boolean boolean74 = fixedMillisecond64.equals((java.lang.Object) long73);
//        long long75 = fixedMillisecond64.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = fixedMillisecond64.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = fixedMillisecond64.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = fixedMillisecond64.next();
//        long long79 = fixedMillisecond64.getLastMillisecond();
//        java.util.Calendar calendar80 = null;
//        long long81 = fixedMillisecond64.getLastMillisecond(calendar80);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem83 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, 0.0d);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNull(str33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(list45);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(timeSeries60);
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1L + "'", long69 == 1L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1L + "'", long70 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1L + "'", long73 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1560440824228L + "'", long75 == 1560440824228L);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1560440824228L + "'", long79 == 1560440824228L);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1560440824228L + "'", long81 == 1560440824228L);
//        org.junit.Assert.assertNull(timeSeriesDataItem83);
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long5 = fixedMillisecond4.getSerialIndex();
//        long long6 = fixedMillisecond4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond4.next();
//        java.util.Date date8 = fixedMillisecond4.getStart();
//        long long9 = fixedMillisecond4.getMiddleMillisecond();
//        boolean boolean10 = fixedMillisecond0.equals((java.lang.Object) long9);
//        long long11 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond0.next();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond0.getMiddleMillisecond(calendar13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        java.lang.Object obj17 = timeSeriesDataItem16.clone();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440824937L + "'", long11 == 1560440824937L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440824937L + "'", long14 == 1560440824937L);
//        org.junit.Assert.assertNotNull(obj17);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        long long8 = day7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 25568L + "'", long8 == 25568L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        java.lang.String str12 = timeSeries6.getDomainDescription();
        timeSeries6.setRangeDescription("");
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries6.createCopy((int) (byte) 0, (int) (short) 100);
        timeSeries17.setNotify(false);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(timeSeries17);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        long long2 = year0.getLastMillisecond();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        long long9 = year7.getLastMillisecond();
//        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
//        java.util.List list11 = timeSeries6.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean14 = fixedMillisecond12.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long17 = fixedMillisecond16.getSerialIndex();
//        long long18 = fixedMillisecond16.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.next();
//        java.util.Date date20 = fixedMillisecond16.getStart();
//        long long21 = fixedMillisecond16.getMiddleMillisecond();
//        boolean boolean22 = fixedMillisecond12.equals((java.lang.Object) long21);
//        java.lang.String str23 = fixedMillisecond12.toString();
//        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(list11);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Thu Jun 13 08:47:05 PDT 2019" + "'", str23.equals("Thu Jun 13 08:47:05 PDT 2019"));
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Date date5 = fixedMillisecond1.getStart();
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
        int int10 = spreadsheetDate9.getMonth();
        int int11 = spreadsheetDate9.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(100);
        int int14 = spreadsheetDate13.getMonth();
        int int15 = spreadsheetDate13.getYYYY();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays(10, serialDate18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getPreviousDayOfWeek(2);
        boolean boolean22 = spreadsheetDate13.isOnOrAfter(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addDays(0, serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(100);
        int int29 = spreadsheetDate28.getMonth();
        int int30 = spreadsheetDate28.getYYYY();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays(10, serialDate33);
        org.jfree.data.time.SerialDate serialDate36 = serialDate33.getPreviousDayOfWeek(2);
        boolean boolean37 = spreadsheetDate28.isOnOrAfter(serialDate36);
        boolean boolean39 = spreadsheetDate13.isInRange(serialDate26, (org.jfree.data.time.SerialDate) spreadsheetDate28, 0);
        org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        long long42 = year41.getSerialIndex();
        long long43 = year41.getLastMillisecond();
        int int44 = year41.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(100);
        int int47 = spreadsheetDate46.getMonth();
        int int48 = spreadsheetDate46.getYYYY();
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addDays(10, serialDate51);
        org.jfree.data.time.SerialDate serialDate54 = serialDate51.getPreviousDayOfWeek(2);
        boolean boolean55 = spreadsheetDate46.isOnOrAfter(serialDate54);
        org.jfree.data.time.SerialDate serialDate57 = spreadsheetDate46.getNearestDayOfWeek(7);
        int int58 = year41.compareTo((java.lang.Object) serialDate57);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addDays(10, serialDate61);
        org.jfree.data.time.SerialDate serialDate64 = serialDate61.getPreviousDayOfWeek(2);
        boolean boolean65 = spreadsheetDate28.isInRange(serialDate57, serialDate61);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean67 = fixedMillisecond1.equals((java.lang.Object) serialDate66);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1900 + "'", int48 == 1900);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        int int15 = timeSeries6.getMaximumItemCount();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries6);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long21 = fixedMillisecond20.getSerialIndex();
        long long22 = fixedMillisecond20.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.next();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond20.getMiddleMillisecond(calendar24);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, number26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getSerialIndex();
        long long30 = year28.getLastMillisecond();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long30, "", "2019", class33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long37 = fixedMillisecond36.getSerialIndex();
        long long38 = fixedMillisecond36.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond36.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeries34.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeries34.getTimePeriod(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long47 = fixedMillisecond46.getSerialIndex();
        long long48 = fixedMillisecond46.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond46.next();
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond46.getLastMillisecond(calendar50);
        java.util.Date date52 = fixedMillisecond46.getTime();
        int int53 = timeSeries34.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
        timeSeries34.removeChangeListener(seriesChangeListener54);
        timeSeries34.clear();
        java.util.Collection collection57 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1L + "'", long37 == 1L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1L + "'", long48 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1L + "'", long51 == 1L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(collection57);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.lang.String str2 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long4 = fixedMillisecond3.getSerialIndex();
        long long5 = fixedMillisecond3.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond3.next();
        int int8 = fixedMillisecond3.compareTo((java.lang.Object) 'a');
        boolean boolean9 = month0.equals((java.lang.Object) 'a');
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str12 = timePeriodFormatException11.toString();
        boolean boolean13 = month0.equals((java.lang.Object) timePeriodFormatException11);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long6 = fixedMillisecond5.getSerialIndex();
//        long long7 = fixedMillisecond5.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
//        java.util.Date date9 = fixedMillisecond5.getStart();
//        long long10 = fixedMillisecond5.getMiddleMillisecond();
//        boolean boolean11 = fixedMillisecond1.equals((java.lang.Object) long10);
//        long long12 = fixedMillisecond1.getFirstMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond1.getLastMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond1.getEnd();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int18 = spreadsheetDate17.getMonth();
//        int int19 = spreadsheetDate17.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long22 = fixedMillisecond21.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond21.previous();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond21.getMiddleMillisecond(calendar24);
//        java.util.Date date26 = fixedMillisecond21.getTime();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date26);
//        boolean boolean29 = spreadsheetDate17.isOn(serialDate28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean32 = fixedMillisecond30.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long35 = fixedMillisecond34.getSerialIndex();
//        long long36 = fixedMillisecond34.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond34.next();
//        java.util.Date date38 = fixedMillisecond34.getStart();
//        long long39 = fixedMillisecond34.getMiddleMillisecond();
//        boolean boolean40 = fixedMillisecond30.equals((java.lang.Object) long39);
//        long long41 = fixedMillisecond30.getFirstMillisecond();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond30.getLastMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond30.getEnd();
//        boolean boolean45 = spreadsheetDate17.equals((java.lang.Object) date44);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
//        long long47 = year46.getSerialIndex();
//        long long48 = year46.getLastMillisecond();
//        java.util.Date date49 = year46.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long52 = fixedMillisecond51.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond51.previous();
//        java.util.Calendar calendar54 = null;
//        long long55 = fixedMillisecond51.getMiddleMillisecond(calendar54);
//        java.util.Date date56 = fixedMillisecond51.getTime();
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date56, timeZone57);
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month(date49, timeZone57);
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date44, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date15, timeZone57);
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
//        long long63 = year62.getSerialIndex();
//        long long64 = year62.getLastMillisecond();
//        java.util.Date date65 = year62.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long68 = fixedMillisecond67.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = fixedMillisecond67.previous();
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond67.getMiddleMillisecond(calendar70);
//        java.util.Date date72 = fixedMillisecond67.getTime();
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month(date72, timeZone73);
//        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month(date65, timeZone73);
//        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date15, timeZone73);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(13, 4, 2019);
//        int int81 = day80.getDayOfMonth();
//        long long82 = day80.getFirstMillisecond();
//        java.util.Date date83 = day80.getEnd();
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date83, timeZone84);
//        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month(date15, timeZone84);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560440826269L + "'", long12 == 1560440826269L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560440826269L + "'", long14 == 1560440826269L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1900 + "'", int19 == 1900);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560440826277L + "'", long41 == 1560440826277L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560440826277L + "'", long43 == 1560440826277L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 2019L + "'", long47 == 2019L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577865599999L + "'", long48 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1L + "'", long52 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 2019L + "'", long63 == 2019L);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1577865599999L + "'", long64 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1L + "'", long68 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1L + "'", long71 == 1L);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 13 + "'", int81 == 13);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1555138800000L + "'", long82 == 1555138800000L);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(timeZone84);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(10, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(2);
        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(0, serialDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        int int17 = spreadsheetDate16.getMonth();
        int int18 = spreadsheetDate16.getYYYY();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(10, serialDate21);
        org.jfree.data.time.SerialDate serialDate24 = serialDate21.getPreviousDayOfWeek(2);
        boolean boolean25 = spreadsheetDate16.isOnOrAfter(serialDate24);
        boolean boolean27 = spreadsheetDate1.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16, 0);
        int int28 = spreadsheetDate1.getDayOfMonth();
        int int29 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 9 + "'", int28 == 9);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1900 + "'", int29 == 1900);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.List list11 = timeSeries6.getItems();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        long long14 = year12.getLastMillisecond();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long14, "", "2019", class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long21 = fixedMillisecond20.getSerialIndex();
        long long22 = fixedMillisecond20.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries18.getNextTimePeriod();
        int int27 = timeSeries18.getMaximumItemCount();
        timeSeries18.setKey((java.lang.Comparable) 10L);
        java.util.Collection collection30 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        timeSeries6.setDescription("hi!");
        timeSeries6.setRangeDescription("April");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
        org.junit.Assert.assertNotNull(collection30);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        java.lang.String str6 = day3.toString();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        int int12 = day10.getDayOfMonth();
        int int13 = day3.compareTo((java.lang.Object) day10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day10.next();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-April-2019" + "'", str6.equals("13-April-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        long long6 = year4.getLastMillisecond();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long6, "", "2019", class9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long13 = fixedMillisecond12.getSerialIndex();
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries10.getNextTimePeriod();
        timeSeries10.setNotify(true);
        boolean boolean21 = month0.equals((java.lang.Object) timeSeries10);
        java.lang.String str22 = month0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "June 2019" + "'", str22.equals("June 2019"));
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int3 = spreadsheetDate2.getMonth();
//        int int4 = spreadsheetDate2.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long7 = fixedMillisecond6.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond6.previous();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getMiddleMillisecond(calendar9);
//        java.util.Date date11 = fixedMillisecond6.getTime();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date11);
//        boolean boolean14 = spreadsheetDate2.isOn(serialDate13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean17 = fixedMillisecond15.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long20 = fixedMillisecond19.getSerialIndex();
//        long long21 = fixedMillisecond19.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
//        java.util.Date date23 = fixedMillisecond19.getStart();
//        long long24 = fixedMillisecond19.getMiddleMillisecond();
//        boolean boolean25 = fixedMillisecond15.equals((java.lang.Object) long24);
//        long long26 = fixedMillisecond15.getFirstMillisecond();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond15.getLastMillisecond(calendar27);
//        java.util.Date date29 = fixedMillisecond15.getEnd();
//        boolean boolean30 = spreadsheetDate2.equals((java.lang.Object) date29);
//        try {
//            org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-460), (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560440828109L + "'", long26 == 1560440828109L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560440828109L + "'", long28 == 1560440828109L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long6 = fixedMillisecond5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.previous();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond5.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond5.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
        boolean boolean13 = spreadsheetDate1.isOn(serialDate12);
        int int14 = spreadsheetDate1.toSerial();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        int int20 = day18.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate21 = day18.getSerialDate();
        boolean boolean22 = spreadsheetDate1.isOn(serialDate21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.String str11 = timePeriodFormatException9.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Class<?> wildcardClass18 = timePeriodFormatException15.getClass();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        timeSeries6.setMaximumItemCount((int) (byte) 100);
        timeSeries6.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        try {
            timeSeries6.removeAgedItems(1560440777823L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long3 = fixedMillisecond2.getSerialIndex();
        long long4 = fixedMillisecond2.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond2.next();
        java.util.Date date6 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        boolean boolean25 = year7.equals((java.lang.Object) timePeriodFormatException16);
        try {
            org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((-435), year7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        int int3 = spreadsheetDate2.getMonth();
        int int4 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(10, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getPreviousDayOfWeek(2);
        boolean boolean11 = spreadsheetDate2.isOnOrAfter(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate2.getNearestDayOfWeek(7);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(10, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(7, serialDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        int int22 = spreadsheetDate21.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean25 = spreadsheetDate21.isOnOrAfter(serialDate24);
        boolean boolean26 = spreadsheetDate2.isInRange(serialDate19, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        int int30 = spreadsheetDate29.getMonth();
        int int31 = spreadsheetDate29.getYYYY();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        int int35 = spreadsheetDate34.getMonth();
        int int36 = spreadsheetDate34.getYYYY();
        java.util.Date date37 = spreadsheetDate34.toDate();
        boolean boolean39 = spreadsheetDate2.isInRange(serialDate32, (org.jfree.data.time.SerialDate) spreadsheetDate34, 0);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths(3, serialDate32);
        java.lang.String str41 = serialDate40.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 9 + "'", int22 == 9);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "9-July-1900" + "'", str41.equals("9-July-1900"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        int int3 = year0.getYear();
        long long4 = year0.getLastMillisecond();
        long long5 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        timeSeries6.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries6.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getSerialIndex();
        long long19 = year17.getLastMillisecond();
        java.lang.String str20 = year17.toString();
        java.lang.Object obj21 = null;
        boolean boolean22 = year17.equals(obj21);
        long long23 = year17.getSerialIndex();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        long long27 = year25.getLastMillisecond();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long27, "", "2019", class30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getSerialIndex();
        long long34 = year32.getLastMillisecond();
        int int35 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) year32);
        int int36 = timeSeries31.getItemCount();
        java.lang.String str37 = timeSeries31.getDomainDescription();
        timeSeries31.setRangeDescription("");
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries31.createCopy((int) (byte) 0, (int) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries6.addAndOrUpdate(timeSeries42);
        java.util.List list44 = timeSeries43.getItems();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = null;
        try {
            timeSeries43.add(regularTimePeriod45, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(list44);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        int int7 = timeSeries6.getMaximumItemCount();
        java.lang.Object obj8 = timeSeries6.clone();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year10 = month9.getYear();
        org.jfree.data.time.Year year11 = month9.getYear();
        int int12 = month9.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        long long16 = year14.getLastMillisecond();
        java.util.Date date17 = year14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long20 = fixedMillisecond19.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.previous();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond19.getMiddleMillisecond(calendar22);
        java.util.Date date24 = fixedMillisecond19.getTime();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24, timeZone25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date17, timeZone25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month27, (double) 2019);
        org.jfree.data.time.Year year30 = month27.getYear();
        boolean boolean32 = month27.equals((java.lang.Object) 1560440807872L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries6.getTimePeriod(0);
        timeSeries6.setDescription("hi!");
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year20 = month19.getYear();
        int int21 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) month19);
        long long22 = month19.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month19.next();
        int int24 = month19.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1559372400000L + "'", long22 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long5 = fixedMillisecond4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond4.previous();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond4.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond4.getTime();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date9);
        boolean boolean12 = spreadsheetDate1.isOnOrBefore(serialDate11);
        java.util.Date date13 = spreadsheetDate1.toDate();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(10, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(7, serialDate17);
        boolean boolean20 = spreadsheetDate1.isAfter(serialDate17);
        int int21 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(100);
        int int24 = spreadsheetDate23.getMonth();
        int int25 = spreadsheetDate23.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(100);
        int int28 = spreadsheetDate27.getMonth();
        int int29 = spreadsheetDate27.getYYYY();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addDays(10, serialDate32);
        org.jfree.data.time.SerialDate serialDate35 = serialDate32.getPreviousDayOfWeek(2);
        boolean boolean36 = spreadsheetDate27.isOnOrAfter(serialDate35);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addDays(0, serialDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(100);
        int int43 = spreadsheetDate42.getMonth();
        int int44 = spreadsheetDate42.getYYYY();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addDays(10, serialDate47);
        org.jfree.data.time.SerialDate serialDate50 = serialDate47.getPreviousDayOfWeek(2);
        boolean boolean51 = spreadsheetDate42.isOnOrAfter(serialDate50);
        boolean boolean53 = spreadsheetDate27.isInRange(serialDate40, (org.jfree.data.time.SerialDate) spreadsheetDate42, 0);
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate23.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.previous();
        int int60 = day58.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate61 = day58.getSerialDate();
        boolean boolean62 = spreadsheetDate42.isBefore(serialDate61);
        int int63 = spreadsheetDate42.getDayOfWeek();
        boolean boolean64 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1900 + "'", int29 == 1900);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1900 + "'", int44 == 1900);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 13 + "'", int60 == 13);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        java.util.Date date10 = year7.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long13 = fixedMillisecond12.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond12.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond12.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date10, timeZone18);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date5, timeZone18);
        java.lang.String str22 = day21.toString();
        long long23 = day21.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "31-December-1969" + "'", str22.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 25568L + "'", long23 == 25568L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(10, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(2);
        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
        int int11 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int13 = spreadsheetDate1.getDayOfWeek();
        try {
            org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate1.getFollowingDayOfWeek(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        java.lang.Class class1 = null;
//        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("Monday", class1);
//        org.junit.Assert.assertNull(uRL2);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.Date date9 = fixedMillisecond8.getTime();
        java.util.Date date10 = fixedMillisecond8.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long13 = fixedMillisecond12.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond12.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond12.getTime();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long22 = fixedMillisecond21.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond21.previous();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond21.getMiddleMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond21.getTime();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long31 = fixedMillisecond30.getSerialIndex();
        long long32 = fixedMillisecond30.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond30.next();
        java.util.Date date34 = fixedMillisecond30.getStart();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getSerialIndex();
        long long38 = year36.getLastMillisecond();
        java.util.Date date39 = year36.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long42 = fixedMillisecond41.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond41.previous();
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond41.getMiddleMillisecond(calendar44);
        java.util.Date date46 = fixedMillisecond41.getTime();
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date46, timeZone47);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date39, timeZone47);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date34, timeZone47);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date26, timeZone47);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date17, timeZone47);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date10, timeZone47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(date10);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1L + "'", long42 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1L + "'", long45 == 1L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(serialDate55);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long6 = fixedMillisecond5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.previous();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond5.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond5.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
        boolean boolean13 = spreadsheetDate1.isOn(serialDate12);
        int int14 = spreadsheetDate1.getYYYY();
        int int15 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        int int21 = day19.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        boolean boolean23 = spreadsheetDate1.isBefore(serialDate22);
        java.lang.String str24 = spreadsheetDate1.toString();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(10, serialDate27);
        org.jfree.data.time.SerialDate serialDate30 = serialDate27.getPreviousDayOfWeek(2);
        boolean boolean31 = spreadsheetDate1.isBefore(serialDate30);
        java.lang.Object obj32 = null;
        try {
            int int33 = spreadsheetDate1.compareTo(obj32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(100);
        int int3 = spreadsheetDate2.getMonth();
        int int4 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(10, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getPreviousDayOfWeek(2);
        boolean boolean11 = spreadsheetDate2.isOnOrAfter(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate2.getNearestDayOfWeek(7);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(10, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(7, serialDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(100);
        int int22 = spreadsheetDate21.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean25 = spreadsheetDate21.isOnOrAfter(serialDate24);
        boolean boolean26 = spreadsheetDate2.isInRange(serialDate19, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(100);
        int int30 = spreadsheetDate29.getMonth();
        int int31 = spreadsheetDate29.getYYYY();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(100);
        int int35 = spreadsheetDate34.getMonth();
        int int36 = spreadsheetDate34.getYYYY();
        java.util.Date date37 = spreadsheetDate34.toDate();
        boolean boolean39 = spreadsheetDate2.isInRange(serialDate32, (org.jfree.data.time.SerialDate) spreadsheetDate34, 0);
        try {
            org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 9 + "'", int22 == 9);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getSerialIndex();
        long long3 = year1.getLastMillisecond();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long3, "", "2019", class6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        long long10 = year8.getLastMillisecond();
        int int11 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) year8);
        int int12 = timeSeries7.getItemCount();
        java.lang.Class<?> wildcardClass13 = timeSeries7.getClass();
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.time.TimePeriodFormatException: hi!", (java.lang.Class) wildcardClass13);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(inputStream14);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        int int15 = timeSeries6.getMaximumItemCount();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        int int21 = day19.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        timeSeriesDataItem23.setValue((java.lang.Number) 1560440793699L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getSerialIndex();
        long long5 = year3.getLastMillisecond();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long5, "", "2019", class8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getSerialIndex();
        long long12 = year10.getLastMillisecond();
        int int13 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        int int14 = timeSeries9.getItemCount();
        java.lang.Class<?> wildcardClass15 = timeSeries9.getClass();
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass15);
        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ClassContext", (java.lang.Class) wildcardClass15);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        java.lang.String str21 = month19.toString();
        java.lang.String str22 = month19.toString();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getSerialIndex();
        long long25 = year23.getLastMillisecond();
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long25, "", "2019", class28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long32 = fixedMillisecond31.getSerialIndex();
        long long33 = fixedMillisecond31.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond31.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeries29.getNextTimePeriod();
        timeSeries29.setNotify(true);
        boolean boolean40 = month19.equals((java.lang.Object) timeSeries29);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        long long42 = year41.getSerialIndex();
        long long43 = year41.getLastMillisecond();
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long43, "", "2019", class46);
        timeSeries47.setDomainDescription("hi!");
        java.util.Collection collection50 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries47);
        int int51 = timeSeries47.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long54 = fixedMillisecond53.getSerialIndex();
        long long55 = fixedMillisecond53.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond53.next();
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond53.getLastMillisecond(calendar57);
        java.util.Date date59 = fixedMillisecond53.getTime();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(date59);
        org.jfree.data.time.Year year61 = month60.getYear();
        int int62 = timeSeries47.getIndex((org.jfree.data.time.RegularTimePeriod) year61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year61.previous();
        java.lang.Class<?> wildcardClass64 = year61.getClass();
        java.io.InputStream inputStream65 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Preceding", (java.lang.Class) wildcardClass64);
        java.lang.Object obj66 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", (java.lang.Class) wildcardClass15, (java.lang.Class) wildcardClass64);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(uRL16);
        org.junit.Assert.assertNull(inputStream17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "June 2019" + "'", str22.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1L + "'", long33 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2147483647 + "'", int51 == 2147483647);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1L + "'", long54 == 1L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1L + "'", long55 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1L + "'", long58 == 1L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(year61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNull(inputStream65);
        org.junit.Assert.assertNull(obj66);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getSerialIndex();
        long long7 = year5.getLastMillisecond();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long7, "", "2019", class10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getSerialIndex();
        long long14 = year12.getLastMillisecond();
        int int15 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year12);
        int int16 = timeSeries11.getItemCount();
        java.lang.Class<?> wildcardClass17 = timeSeries11.getClass();
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass17);
        java.io.InputStream inputStream19 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ClassContext", (java.lang.Class) wildcardClass17);
        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.time.TimePeriodFormatException: hi!", (java.lang.Class) wildcardClass17);
        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.time.TimePeriodFormatException: hi!", (java.lang.Class) wildcardClass17);
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Thu Jun 13 08:47:05 PDT 2019", (java.lang.Class) wildcardClass17);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(uRL18);
        org.junit.Assert.assertNull(inputStream19);
        org.junit.Assert.assertNull(uRL20);
        org.junit.Assert.assertNull(uRL21);
        org.junit.Assert.assertNull(uRL22);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long14 = fixedMillisecond13.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.previous();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond13.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond13.getTime();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date18);
        int int21 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        timeSeries6.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getSerialIndex();
        long long8 = year6.getLastMillisecond();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long8, "", "2019", class11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        long long15 = year13.getLastMillisecond();
        int int16 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) year13);
        int int17 = timeSeries12.getItemCount();
        java.lang.Class<?> wildcardClass18 = timeSeries12.getClass();
        java.net.URL uRL19 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass18);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ClassContext", (java.lang.Class) wildcardClass18);
        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.time.TimePeriodFormatException: hi!", (java.lang.Class) wildcardClass18);
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesChangeEvent[source=-1]", (java.lang.Class) wildcardClass18);
        java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.time.TimePeriodFormatException: hi!", (java.lang.Class) wildcardClass18);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getSerialIndex();
        long long30 = year28.getLastMillisecond();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long30, "", "2019", class33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getSerialIndex();
        long long37 = year35.getLastMillisecond();
        int int38 = timeSeries34.getIndex((org.jfree.data.time.RegularTimePeriod) year35);
        int int39 = timeSeries34.getItemCount();
        java.lang.Class<?> wildcardClass40 = timeSeries34.getClass();
        java.net.URL uRL41 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass40);
        java.io.InputStream inputStream42 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ClassContext", (java.lang.Class) wildcardClass40);
        java.net.URL uRL43 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.time.TimePeriodFormatException: hi!", (java.lang.Class) wildcardClass40);
        java.net.URL uRL44 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.time.TimePeriodFormatException: hi!", (java.lang.Class) wildcardClass40);
        java.lang.Object obj45 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January", (java.lang.Class) wildcardClass18, (java.lang.Class) wildcardClass40);
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(uRL19);
        org.junit.Assert.assertNull(inputStream20);
        org.junit.Assert.assertNull(uRL21);
        org.junit.Assert.assertNull(uRL22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 2019L + "'", long29 == 2019L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNull(uRL41);
        org.junit.Assert.assertNull(inputStream42);
        org.junit.Assert.assertNull(uRL43);
        org.junit.Assert.assertNull(uRL44);
        org.junit.Assert.assertNull(obj45);
        org.junit.Assert.assertNotNull(class46);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day5.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getSerialIndex();
        long long3 = year1.getLastMillisecond();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long3, "", "2019", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long10 = fixedMillisecond9.getSerialIndex();
        long long11 = fixedMillisecond9.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries7.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries7.getTimePeriod(0);
        timeSeries7.setDescription("hi!");
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = month20.getYear();
        int int22 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) month20);
        java.util.Date date23 = month20.getStart();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        try {
            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) -1, serialDate24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries6.getTimePeriod(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long19 = fixedMillisecond18.getSerialIndex();
        long long20 = fixedMillisecond18.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.next();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond18.getLastMillisecond(calendar22);
        java.util.Date date24 = fixedMillisecond18.getTime();
        int int25 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.lang.Class class26 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getSerialIndex();
        timeSeries6.update((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) (byte) -1);
        java.lang.String str31 = timeSeries6.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener32);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNull(class26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2019L + "'", long28 == 2019L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries6.addChangeListener(seriesChangeListener14);
        timeSeries6.update(0, (java.lang.Number) 1577865599999L);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getSerialIndex();
        long long21 = year19.getLastMillisecond();
        int int22 = year19.getYear();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year19);
        boolean boolean25 = year19.equals((java.lang.Object) 'a');
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) year19);
        long long27 = year19.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 2019L + "'", long20 == 2019L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        long long2 = year0.getLastMillisecond();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long9 = fixedMillisecond8.getSerialIndex();
//        long long10 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
//        int int15 = timeSeries6.getMaximumItemCount();
//        timeSeries6.setKey((java.lang.Comparable) 10L);
//        java.lang.String str18 = timeSeries6.getRangeDescription();
//        timeSeries6.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean23 = fixedMillisecond21.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long26 = fixedMillisecond25.getSerialIndex();
//        long long27 = fixedMillisecond25.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.next();
//        java.util.Date date29 = fixedMillisecond25.getStart();
//        long long30 = fixedMillisecond25.getMiddleMillisecond();
//        boolean boolean31 = fixedMillisecond21.equals((java.lang.Object) long30);
//        long long32 = fixedMillisecond21.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond21.next();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond21.getMiddleMillisecond(calendar34);
//        long long36 = fixedMillisecond21.getLastMillisecond();
//        long long37 = fixedMillisecond21.getMiddleMillisecond();
//        try {
//            timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1560440796043L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560440831066L + "'", long32 == 1560440831066L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440831066L + "'", long35 == 1560440831066L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560440831066L + "'", long36 == 1560440831066L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560440831066L + "'", long37 == 1560440831066L);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.List list11 = timeSeries6.getItems();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long21 = fixedMillisecond20.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
        java.util.Calendar calendar24 = null;
        fixedMillisecond20.peg(calendar24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        java.lang.Object obj27 = timeSeries6.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries6.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(obj27);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int2 = spreadsheetDate1.getMonth();
//        int int3 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long6 = fixedMillisecond5.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.previous();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond5.getMiddleMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getTime();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
//        boolean boolean13 = spreadsheetDate1.isOn(serialDate12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean16 = fixedMillisecond14.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long19 = fixedMillisecond18.getSerialIndex();
//        long long20 = fixedMillisecond18.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.next();
//        java.util.Date date22 = fixedMillisecond18.getStart();
//        long long23 = fixedMillisecond18.getMiddleMillisecond();
//        boolean boolean24 = fixedMillisecond14.equals((java.lang.Object) long23);
//        long long25 = fixedMillisecond14.getFirstMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond14.getLastMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond14.getEnd();
//        boolean boolean29 = spreadsheetDate1.equals((java.lang.Object) date28);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(9);
//        boolean boolean32 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560440831126L + "'", long25 == 1560440831126L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560440831126L + "'", long27 == 1560440831126L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        java.util.Date date10 = year7.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long13 = fixedMillisecond12.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond12.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond12.getTime();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17, timeZone18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date10, timeZone18);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date5, timeZone18);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getSerialIndex();
        long long26 = year24.getLastMillisecond();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long26, "", "2019", class29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getSerialIndex();
        long long33 = year31.getLastMillisecond();
        int int34 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) year31);
        int int35 = timeSeries30.getItemCount();
        java.lang.Class<?> wildcardClass36 = timeSeries30.getClass();
        java.net.URL uRL37 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass36);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate22, (java.lang.Class) wildcardClass36);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 2019L + "'", long32 == 2019L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(uRL37);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(10, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(2);
        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(0, serialDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(100);
        int int17 = spreadsheetDate16.getMonth();
        int int18 = spreadsheetDate16.getYYYY();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(10, serialDate21);
        org.jfree.data.time.SerialDate serialDate24 = serialDate21.getPreviousDayOfWeek(2);
        boolean boolean25 = spreadsheetDate16.isOnOrAfter(serialDate24);
        boolean boolean27 = spreadsheetDate1.isInRange(serialDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16, 0);
        spreadsheetDate16.setDescription("9-April-1900");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        java.lang.String str9 = month8.toString();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month8.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "December 1969" + "'", str9.equals("December 1969"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.List list11 = timeSeries6.getItems();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long21 = fixedMillisecond20.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
        java.util.Calendar calendar24 = null;
        fixedMillisecond20.peg(calendar24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        java.lang.Object obj27 = timeSeries6.clone();
        java.util.Collection collection28 = timeSeries6.getTimePeriods();
        try {
            java.lang.Number number30 = timeSeries6.getValue(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(collection28);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean2 = fixedMillisecond0.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long5 = fixedMillisecond4.getSerialIndex();
//        long long6 = fixedMillisecond4.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond4.next();
//        java.util.Date date8 = fixedMillisecond4.getStart();
//        long long9 = fixedMillisecond4.getMiddleMillisecond();
//        boolean boolean10 = fixedMillisecond0.equals((java.lang.Object) long9);
//        long long11 = fixedMillisecond0.getFirstMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond0.getMiddleMillisecond(calendar12);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560440832187L + "'", long11 == 1560440832187L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560440832187L + "'", long13 == 1560440832187L);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        long long2 = year0.getLastMillisecond();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        long long8 = year7.getSerialIndex();
//        long long9 = year7.getLastMillisecond();
//        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
//        int int11 = timeSeries6.getItemCount();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
//        org.jfree.data.time.Year year14 = month12.getYear();
//        long long15 = month12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 2019L);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
//        java.lang.String str20 = month18.toString();
//        java.lang.String str21 = month18.toString();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getSerialIndex();
//        long long24 = year22.getLastMillisecond();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long24, "", "2019", class27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long31 = fixedMillisecond30.getSerialIndex();
//        long long32 = fixedMillisecond30.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond30.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) (-1.0d));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeries28.getNextTimePeriod();
//        timeSeries28.setNotify(true);
//        boolean boolean39 = month18.equals((java.lang.Object) timeSeries28);
//        timeSeries28.removeAgedItems(false);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate43 = day42.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day42.next();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day42.previous();
//        long long48 = day42.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560409200000L + "'", long48 == 1560409200000L);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long11 = fixedMillisecond10.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond10.previous();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond10.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond10.getTime();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long20 = fixedMillisecond19.getSerialIndex();
        long long21 = fixedMillisecond19.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        java.util.Date date23 = fixedMillisecond19.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getSerialIndex();
        long long27 = year25.getLastMillisecond();
        java.util.Date date28 = year25.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long31 = fixedMillisecond30.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond30.previous();
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond30.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond30.getTime();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date35, timeZone36);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date28, timeZone36);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date23, timeZone36);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date15, timeZone36);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date6, timeZone36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        int int6 = day4.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (short) -1, serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getSerialIndex();
        long long3 = year1.getSerialIndex();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2019, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long17 = fixedMillisecond16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond16.previous();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod18.getClass();
        boolean boolean20 = timeSeries6.equals((java.lang.Object) regularTimePeriod18);
        java.util.List list21 = timeSeries6.getItems();
        int int22 = timeSeries6.getItemCount();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getLastMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        java.lang.Class<?> wildcardClass12 = timeSeries6.getClass();
        java.util.Collection collection13 = timeSeries6.getTimePeriods();
        timeSeries6.setRangeDescription("ClassContext");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(collection13);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        timeSeries6.setNotify(true);
        long long17 = timeSeries6.getMaximumItemAge();
        java.lang.Comparable comparable18 = timeSeries6.getKey();
        try {
            timeSeries6.removeAgedItems(1560440796044L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 1577865599999L + "'", comparable18.equals(1577865599999L));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long6 = fixedMillisecond5.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.previous();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond5.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond5.getTime();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
        boolean boolean13 = spreadsheetDate1.isOn(serialDate12);
        int int14 = spreadsheetDate1.getYYYY();
        int int15 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        int int19 = spreadsheetDate18.getMonth();
        int int20 = spreadsheetDate18.getYYYY();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean22 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        java.lang.String str12 = timeSeries6.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener13);
        int int15 = timeSeries6.getMaximumItemCount();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getSerialIndex();
        long long18 = year16.getLastMillisecond();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long18, "", "2019", class21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long25 = fixedMillisecond24.getSerialIndex();
        long long26 = fixedMillisecond24.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) (-1.0d));
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getSerialIndex();
        long long32 = year30.getLastMillisecond();
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long32, "", "2019", class35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getSerialIndex();
        long long39 = year37.getLastMillisecond();
        int int40 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) year37);
        java.util.List list41 = timeSeries36.getItems();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        long long43 = year42.getSerialIndex();
        long long44 = year42.getLastMillisecond();
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long44, "", "2019", class47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long51 = fixedMillisecond50.getSerialIndex();
        long long52 = fixedMillisecond50.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond50.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries48.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = timeSeries48.getNextTimePeriod();
        int int57 = timeSeries48.getMaximumItemCount();
        timeSeries48.setKey((java.lang.Comparable) 10L);
        java.util.Collection collection60 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries48);
        boolean boolean61 = fixedMillisecond24.equals((java.lang.Object) collection60);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (double) (byte) 1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener64 = null;
        timeSeries6.removeChangeListener(seriesChangeListener64);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 2019L + "'", long31 == 2019L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 2019L + "'", long38 == 2019L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1L + "'", long51 == 1L);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1L + "'", long52 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2147483647 + "'", int57 == 2147483647);
        org.junit.Assert.assertNotNull(collection60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(100);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(10, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getPreviousDayOfWeek(2);
        boolean boolean10 = spreadsheetDate1.isOnOrAfter(serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate1.getNearestDayOfWeek(7);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getSerialIndex();
        long long15 = year13.getLastMillisecond();
        int int16 = year13.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(100);
        int int19 = spreadsheetDate18.getMonth();
        int int20 = spreadsheetDate18.getYYYY();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays(10, serialDate23);
        org.jfree.data.time.SerialDate serialDate26 = serialDate23.getPreviousDayOfWeek(2);
        boolean boolean27 = spreadsheetDate18.isOnOrAfter(serialDate26);
        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate18.getNearestDayOfWeek(7);
        int int30 = year13.compareTo((java.lang.Object) serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays(10, serialDate33);
        java.lang.String str35 = serialDate33.getDescription();
        boolean boolean37 = spreadsheetDate1.isInRange(serialDate29, serialDate33, 1969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        int int15 = timeSeries6.getMaximumItemCount();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries6);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries6.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long21 = fixedMillisecond20.getSerialIndex();
        long long22 = fixedMillisecond20.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.next();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond20.getMiddleMillisecond(calendar24);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, number26);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getSerialIndex();
        long long34 = year32.getLastMillisecond();
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long34, "", "2019", class37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getSerialIndex();
        long long41 = year39.getLastMillisecond();
        int int42 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) year39);
        int int43 = timeSeries38.getItemCount();
        java.lang.Class<?> wildcardClass44 = timeSeries38.getClass();
        java.net.URL uRL45 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", (java.lang.Class) wildcardClass44);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        long long48 = year47.getSerialIndex();
        long long49 = year47.getLastMillisecond();
        java.lang.Class class52 = null;
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long49, "", "2019", class52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getSerialIndex();
        long long56 = year54.getLastMillisecond();
        int int57 = timeSeries53.getIndex((org.jfree.data.time.RegularTimePeriod) year54);
        int int58 = timeSeries53.getItemCount();
        java.lang.Class<?> wildcardClass59 = timeSeries53.getClass();
        java.net.URL uRL60 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass59);
        java.lang.Object obj61 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass44, (java.lang.Class) wildcardClass59);
        java.lang.Class class62 = null;
        java.lang.Object obj63 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2019", (java.lang.Class) wildcardClass59, class62);
        java.net.URL uRL64 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", (java.lang.Class) wildcardClass59);
        int int65 = timeSeriesDataItem27.compareTo((java.lang.Object) "ClassContext");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 2019L + "'", long40 == 2019L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNull(uRL45);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2019L + "'", long55 == 2019L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1577865599999L + "'", long56 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNull(uRL60);
        org.junit.Assert.assertNull(obj61);
        org.junit.Assert.assertNull(obj63);
        org.junit.Assert.assertNull(uRL64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        int int7 = timeSeries6.getMaximumItemCount();
        java.lang.Object obj8 = timeSeries6.clone();
        timeSeries6.setDescription("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1L));
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        java.lang.Object obj6 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (-1L) + "'", obj3.equals((-1L)));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (-1L) + "'", obj5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + (-1L) + "'", obj6.equals((-1L)));
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long2 = fixedMillisecond1.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
//        java.util.Date date6 = fixedMillisecond1.getTime();
//        java.util.Date date7 = fixedMillisecond1.getTime();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(100);
//        int int10 = spreadsheetDate9.getMonth();
//        int int11 = spreadsheetDate9.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long14 = fixedMillisecond13.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.previous();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond13.getMiddleMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond13.getTime();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date18);
//        boolean boolean21 = spreadsheetDate9.isOn(serialDate20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        boolean boolean24 = fixedMillisecond22.equals((java.lang.Object) 3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long27 = fixedMillisecond26.getSerialIndex();
//        long long28 = fixedMillisecond26.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.next();
//        java.util.Date date30 = fixedMillisecond26.getStart();
//        long long31 = fixedMillisecond26.getMiddleMillisecond();
//        boolean boolean32 = fixedMillisecond22.equals((java.lang.Object) long31);
//        long long33 = fixedMillisecond22.getFirstMillisecond();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond22.getLastMillisecond(calendar34);
//        java.util.Date date36 = fixedMillisecond22.getEnd();
//        boolean boolean37 = spreadsheetDate9.equals((java.lang.Object) date36);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        long long39 = year38.getSerialIndex();
//        long long40 = year38.getLastMillisecond();
//        java.util.Date date41 = year38.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
//        long long44 = fixedMillisecond43.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond43.previous();
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond43.getMiddleMillisecond(calendar46);
//        java.util.Date date48 = fixedMillisecond43.getTime();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date48, timeZone49);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date41, timeZone49);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date36, timeZone49);
//        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date7, timeZone49);
//        org.jfree.data.time.Year year54 = month53.getYear();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560440833787L + "'", long33 == 1560440833787L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560440833787L + "'", long35 == 1560440833787L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1L + "'", long44 == 1L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(year54);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        int int11 = timeSeries6.getItemCount();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.Year year14 = month12.getYear();
        long long15 = month12.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 2019L);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
        java.lang.String str20 = month18.toString();
        java.lang.String str21 = month18.toString();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getSerialIndex();
        long long24 = year22.getLastMillisecond();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long24, "", "2019", class27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long31 = fixedMillisecond30.getSerialIndex();
        long long32 = fixedMillisecond30.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond30.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeries28.getNextTimePeriod();
        timeSeries28.setNotify(true);
        boolean boolean39 = month18.equals((java.lang.Object) timeSeries28);
        timeSeries28.removeAgedItems(false);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate43 = day42.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day42.next();
        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) day42);
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day42);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        long long48 = year47.getSerialIndex();
        long long49 = year47.getLastMillisecond();
        java.lang.Class class52 = null;
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long49, "", "2019", class52);
        timeSeries53.setDomainDescription("hi!");
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        long long61 = year60.getSerialIndex();
        int int62 = day59.compareTo((java.lang.Object) long61);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        long long65 = year64.getSerialIndex();
        long long66 = year64.getLastMillisecond();
        java.lang.Class class69 = null;
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long66, "", "2019", class69);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year();
        long long72 = year71.getSerialIndex();
        long long73 = year71.getLastMillisecond();
        int int74 = timeSeries70.getIndex((org.jfree.data.time.RegularTimePeriod) year71);
        int int75 = timeSeries70.getItemCount();
        java.lang.Class<?> wildcardClass76 = timeSeries70.getClass();
        java.net.URL uRL77 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass76);
        boolean boolean78 = day59.equals((java.lang.Object) "SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries53.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day59, (java.lang.Number) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = day59.previous();
        boolean boolean82 = timeSeries6.equals((java.lang.Object) regularTimePeriod81);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 2019L + "'", long48 == 2019L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 2019L + "'", long61 == 2019L);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 2019L + "'", long65 == 2019L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1577865599999L + "'", long66 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 2019L + "'", long72 == 2019L);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1577865599999L + "'", long73 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertNull(uRL77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem80);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long9 = fixedMillisecond8.getSerialIndex();
        long long10 = fixedMillisecond8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getNextTimePeriod();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getSerialIndex();
        long long17 = year15.getLastMillisecond();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17, "", "2019", class20);
        timeSeries21.setDomainDescription("hi!");
        java.util.Collection collection24 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(13, 4, 2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
        int int30 = day28.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeriesDataItem31.getPeriod();
        java.lang.Object obj33 = timeSeriesDataItem31.clone();
        java.lang.Number number34 = timeSeriesDataItem31.getValue();
        java.lang.Number number35 = null;
        timeSeriesDataItem31.setValue(number35);
        java.lang.Object obj37 = timeSeriesDataItem31.clone();
        java.lang.Object obj38 = timeSeriesDataItem31.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 13 + "'", int30 == 13);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-1.0d) + "'", number34.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1900, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1900");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "", "2019", class5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        long long9 = year7.getLastMillisecond();
        int int10 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.List list11 = timeSeries6.getItems();
        timeSeries6.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long15 = fixedMillisecond14.getSerialIndex();
        long long16 = fixedMillisecond14.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
        java.util.Date date18 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) year19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
        boolean boolean23 = timeSeries6.getNotify();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(9999);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getSerialIndex();
        long long3 = year1.getLastMillisecond();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long3, "", "2019", class6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long10 = fixedMillisecond9.getSerialIndex();
        long long11 = fixedMillisecond9.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond9.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries7.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries7.getTimePeriod(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long20 = fixedMillisecond19.getSerialIndex();
        long long21 = fixedMillisecond19.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond19.next();
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond19.getLastMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond19.getTime();
        int int26 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        int int27 = year0.compareTo((java.lang.Object) timeSeries7);
        java.lang.Number number29 = null;
        try {
            timeSeries7.update(1969, number29);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2019L + "'", long2 == 2019L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        java.util.Date date8 = year7.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getSerialIndex();
        long long11 = year9.getLastMillisecond();
        java.util.Date date12 = year9.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (byte) 1);
        long long15 = fixedMillisecond14.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.previous();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond14.getMiddleMillisecond(calendar17);
        java.util.Date date19 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date19, timeZone20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date12, timeZone20);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date8, timeZone20);
        org.jfree.data.time.Year year24 = month23.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(year24);
    }
}

