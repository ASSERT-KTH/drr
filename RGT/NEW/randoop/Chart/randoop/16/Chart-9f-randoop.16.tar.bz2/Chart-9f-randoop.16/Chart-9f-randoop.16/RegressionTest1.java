import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        java.lang.String str4 = timeSeries1.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.addChangeListener(seriesChangeListener5);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        long long6 = fixedMillisecond1.getSerialIndex();
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getFirstMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) '#');
        java.lang.String[] strArray15 = org.jfree.data.time.SerialDate.getMonths();
        int int16 = timeSeriesDataItem14.compareTo((java.lang.Object) strArray15);
        timeSeries1.add(timeSeriesDataItem14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries1.addChangeListener(seriesChangeListener18);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries21.fireSeriesChanged();
        timeSeries21.removeAgedItems((long) 2, false);
        java.lang.String str26 = timeSeries21.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        java.util.Date date31 = fixedMillisecond28.getTime();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
        int int34 = day32.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) 0L);
        int int37 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day32);
        java.lang.String str38 = day32.toString();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable41 = timeSeries40.getKey();
        java.lang.String str42 = timeSeries40.getDescription();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
        java.util.Date date49 = fixedMillisecond46.getTime();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (double) '#');
        int int53 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) day50);
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries40.addAndOrUpdate(timeSeries44);
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timeSeries40.addPropertyChangeListener(propertyChangeListener55);
        boolean boolean57 = day32.equals((java.lang.Object) propertyChangeListener55);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 12 + "'", int34 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "31-December-1969" + "'", str38.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + 0.0f + "'", comparable41.equals(0.0f));
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-1L) + "'", long48 == (-1L));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        int int4 = year0.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean6 = year0.equals((java.lang.Object) day5);
        long long7 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year0.previous();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection6 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.removeChangeListener(seriesChangeListener7);
        boolean boolean9 = timeSeries5.getNotify();
        timeSeries5.setNotify(false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries5.getDataItem(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond1.equals(obj6);
        java.lang.String str8 = fixedMillisecond1.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        int int14 = fixedMillisecond10.compareTo((java.lang.Object) true);
        java.util.Date date15 = fixedMillisecond10.getEnd();
        int int16 = fixedMillisecond1.compareTo((java.lang.Object) date15);
        long long17 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str8.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.util.Date date6 = day5.getEnd();
        int int7 = day5.getYear();
        java.util.Date date8 = day5.getStart();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable11 = timeSeries10.getKey();
        java.lang.String str12 = timeSeries10.getDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection15 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        boolean boolean16 = day5.equals((java.lang.Object) collection15);
        long long17 = day5.getLastMillisecond();
        long long18 = day5.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate24);
        org.jfree.data.time.SerialDate serialDate26 = serialDate21.getEndOfCurrentMonth(serialDate24);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(13, serialDate26);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable33 = timeSeries32.getKey();
        java.lang.String str34 = timeSeries32.getDescription();
        int int35 = timeSeries32.getItemCount();
        timeSeries32.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day43, (double) '#');
        java.lang.String[] strArray46 = org.jfree.data.time.SerialDate.getMonths();
        int int47 = timeSeriesDataItem45.compareTo((java.lang.Object) strArray46);
        timeSeries32.add(timeSeriesDataItem45);
        java.lang.Object obj49 = timeSeriesDataItem45.clone();
        java.lang.Class<?> wildcardClass50 = timeSeriesDataItem45.getClass();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate26, "Value", "", (java.lang.Class) wildcardClass50);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable54 = timeSeries53.getKey();
        java.lang.String str55 = timeSeries53.getDescription();
        int int56 = timeSeries53.getItemCount();
        timeSeries53.setDescription("hi!");
        java.lang.Class class59 = timeSeries53.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar62 = null;
        long long63 = fixedMillisecond61.getMiddleMillisecond(calendar62);
        java.util.Date date64 = fixedMillisecond61.getTime();
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date64, timeZone65);
        java.lang.Class class67 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar70 = null;
        long long71 = fixedMillisecond69.getMiddleMillisecond(calendar70);
        java.util.Date date72 = fixedMillisecond69.getTime();
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date72);
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar76 = null;
        long long77 = fixedMillisecond75.getMiddleMillisecond(calendar76);
        java.util.Date date78 = fixedMillisecond75.getTime();
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date78, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date72, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date64, timeZone79);
        java.util.TimeZone timeZone83 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date64, timeZone83);
        org.jfree.data.time.TimeSeries timeSeries85 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long18, (java.lang.Class) wildcardClass50);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 0.0f + "'", comparable11.equals(0.0f));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28799999L + "'", long17 == 28799999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 0.0f + "'", comparable33.equals(0.0f));
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + comparable54 + "' != '" + 0.0f + "'", comparable54.equals(0.0f));
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(class59);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-1L) + "'", long63 == (-1L));
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-1L) + "'", long71 == (-1L));
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-1L) + "'", long77 == (-1L));
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertNull(regularTimePeriod84);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable12 = timeSeries11.getKey();
        java.lang.String str13 = timeSeries11.getDescription();
        int int14 = timeSeries11.getItemCount();
        timeSeries11.setDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.addAndOrUpdate(timeSeries11);
        timeSeries19.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 0.0f + "'", comparable12.equals(0.0f));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries19);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate3.setDescription("");
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, serialDate3);
        java.lang.String str7 = serialDate6.toString();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (byte) 0, serialDate6);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-March-1900" + "'", str7.equals("9-March-1900"));
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        int int6 = year4.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, year4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month7);
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        try {
            timeSeries1.delete((int) (byte) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        timeSeries1.fireSeriesChanged();
        timeSeries1.setRangeDescription("9-March-1900");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = serialDate1.getEndOfCurrentMonth(serialDate4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day7.next();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.String str10 = timeSeries8.getDescription();
        int int11 = timeSeries8.getItemCount();
        timeSeries8.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (double) '#');
        java.lang.String[] strArray22 = org.jfree.data.time.SerialDate.getMonths();
        int int23 = timeSeriesDataItem21.compareTo((java.lang.Object) strArray22);
        timeSeries8.add(timeSeriesDataItem21);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries8.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries28.fireSeriesChanged();
        timeSeries28.removeAgedItems((long) 2, false);
        java.lang.String str33 = timeSeries28.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
        int int41 = day39.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) 0L);
        int int44 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day39);
        java.lang.Number number45 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getMiddleMillisecond(calendar48);
        java.util.Date date50 = fixedMillisecond47.getTime();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (double) '#');
        timeSeries1.add(timeSeriesDataItem53, true);
        java.lang.Number number56 = timeSeriesDataItem53.getValue();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0f + "'", comparable9.equals(0.0f));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-1L) + "'", long49 == (-1L));
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 35.0d + "'", number56.equals(35.0d));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timeSeries1.getMaximumItemCount();
        java.lang.String str10 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException4.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: June 2019" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: June 2019"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        int int14 = day12.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 0L);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        java.util.List list9 = timeSeries1.getItems();
        timeSeries1.setKey((java.lang.Comparable) 9);
        timeSeries1.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        int int21 = day19.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        int int29 = fixedMillisecond25.compareTo((java.lang.Object) true);
        java.util.Date date30 = fixedMillisecond25.getEnd();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        long long32 = fixedMillisecond25.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1L) + "'", long32 == (-1L));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        java.lang.String str6 = timeSeries4.getDescription();
        int int7 = timeSeries4.getItemCount();
        java.util.List list8 = timeSeries4.getItems();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        java.lang.String str10 = month9.toString();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        long long13 = year11.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month9, (org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year11.previous();
        java.lang.Number number16 = timeSeries1.getValue(regularTimePeriod15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) 1572591599999L);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0f + "'", comparable5.equals(0.0f));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "June 2019" + "'", str10.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.lang.Object obj8 = null;
        boolean boolean9 = fixedMillisecond1.equals(obj8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) '#');
        java.lang.String[] strArray15 = org.jfree.data.time.SerialDate.getMonths();
        int int16 = timeSeriesDataItem14.compareTo((java.lang.Object) strArray15);
        timeSeries1.add(timeSeriesDataItem14);
        java.lang.Object obj18 = timeSeriesDataItem14.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem14.getPeriod();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries5.fireSeriesChanged();
        timeSeries5.removeAgedItems((long) 2, false);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        timeSeries5.setNotify(false);
        timeSeries5.removeAgedItems((long) 5, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        int int21 = fixedMillisecond17.compareTo((java.lang.Object) true);
        java.util.Date date22 = fixedMillisecond17.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable26 = timeSeries25.getKey();
        java.lang.String str27 = timeSeries25.getDescription();
        int int28 = timeSeries25.getItemCount();
        timeSeries25.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond32.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day36, (double) '#');
        java.lang.String[] strArray39 = org.jfree.data.time.SerialDate.getMonths();
        int int40 = timeSeriesDataItem38.compareTo((java.lang.Object) strArray39);
        timeSeries25.add(timeSeriesDataItem38);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries25.addChangeListener(seriesChangeListener42);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries45.fireSeriesChanged();
        timeSeries45.removeAgedItems((long) 2, false);
        java.lang.String str50 = timeSeries45.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond52.getMiddleMillisecond(calendar53);
        java.util.Date date55 = fixedMillisecond52.getTime();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day56.previous();
        int int58 = day56.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day56, (java.lang.Number) 0L);
        int int61 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) day56);
        java.lang.Number number62 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day56);
        java.util.Collection collection63 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + 0.0f + "'", comparable26.equals(0.0f));
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Value" + "'", str50.equals("Value"));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-1L) + "'", long54 == (-1L));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 12 + "'", int58 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNull(number62);
        org.junit.Assert.assertNotNull(collection63);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        java.util.List list9 = timeSeries1.getItems();
        timeSeries1.setKey((java.lang.Comparable) 9);
        timeSeries1.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        int int21 = day19.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        int int29 = fixedMillisecond25.compareTo((java.lang.Object) true);
        java.lang.Object obj30 = null;
        boolean boolean31 = fixedMillisecond25.equals(obj30);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (short) 1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, 0.0d);
        try {
            timeSeries1.add(timeSeriesDataItem36, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond7);
        java.lang.String str9 = seriesChangeEvent8.toString();
        java.lang.String str10 = seriesChangeEvent8.toString();
        java.lang.Object obj11 = seriesChangeEvent8.getSource();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Thu Oct 31 23:59:59 PDT 2019]" + "'", str9.equals("org.jfree.data.general.SeriesChangeEvent[source=Thu Oct 31 23:59:59 PDT 2019]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Thu Oct 31 23:59:59 PDT 2019]" + "'", str10.equals("org.jfree.data.general.SeriesChangeEvent[source=Thu Oct 31 23:59:59 PDT 2019]"));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable6 = timeSeries5.getKey();
        java.lang.String str7 = timeSeries5.getDescription();
        int int8 = timeSeries5.getItemCount();
        timeSeries5.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        java.lang.String str14 = timeSeries12.getDescription();
        int int15 = timeSeries12.getItemCount();
        timeSeries12.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) '#');
        java.lang.String[] strArray26 = org.jfree.data.time.SerialDate.getMonths();
        int int27 = timeSeriesDataItem25.compareTo((java.lang.Object) strArray26);
        timeSeries12.add(timeSeriesDataItem25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries12.addChangeListener(seriesChangeListener29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries32.fireSeriesChanged();
        timeSeries32.removeAgedItems((long) 2, false);
        java.lang.String str37 = timeSeries32.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.previous();
        int int45 = day43.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 0L);
        int int48 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) day43);
        java.lang.Number number49 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day43);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries3.addAndOrUpdate(timeSeries5);
        boolean boolean51 = spreadsheetDate1.equals((java.lang.Object) timeSeries5);
        java.lang.String str52 = spreadsheetDate1.toString();
        int int53 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate56.setDescription("");
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, serialDate56);
        boolean boolean60 = spreadsheetDate1.isBefore(serialDate56);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0f + "'", comparable6.equals(0.0f));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0f + "'", comparable13.equals(0.0f));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Value" + "'", str37.equals("Value"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "11-July-1905" + "'", str52.equals("11-July-1905"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 7 + "'", int53 == 7);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("9-April-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int3 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(13, serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int16 = spreadsheetDate15.getMonth();
        boolean boolean18 = spreadsheetDate2.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15, 12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = serialDate22.getEndOfCurrentMonth(serialDate25);
        java.lang.String str28 = serialDate22.getDescription();
        int int29 = spreadsheetDate20.compare(serialDate22);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable32 = timeSeries31.getKey();
        java.lang.String str33 = timeSeries31.getDescription();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
        java.util.Date date40 = fixedMillisecond37.getTime();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day41, (double) '#');
        int int44 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries31.addAndOrUpdate(timeSeries35);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate48);
        timeSeries35.setKey((java.lang.Comparable) serialDate48);
        boolean boolean51 = spreadsheetDate20.isBefore(serialDate48);
        int int52 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        try {
            org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1905 + "'", int3 == 1905);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 7 + "'", int16 == 7);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1919 + "'", int29 == 1919);
        org.junit.Assert.assertTrue("'" + comparable32 + "' != '" + 0.0f + "'", comparable32.equals(0.0f));
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-1L) + "'", long39 == (-1L));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond3.getTime();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) '#');
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries1.addChangeListener(seriesChangeListener11);
        int int13 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable16 = timeSeries15.getKey();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection20 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        timeSeries15.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond23.getTime();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day27, (double) '#');
        java.lang.String[] strArray30 = org.jfree.data.time.SerialDate.getMonths();
        int int31 = timeSeriesDataItem29.compareTo((java.lang.Object) strArray30);
        timeSeries15.add(timeSeriesDataItem29);
        timeSeries1.setKey((java.lang.Comparable) timeSeriesDataItem29);
        java.lang.Object obj34 = null;
        int int35 = timeSeriesDataItem29.compareTo(obj34);
        java.lang.Object obj36 = timeSeriesDataItem29.clone();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 0.0f + "'", comparable16.equals(0.0f));
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate6);
        boolean boolean9 = spreadsheetDate1.isOnOrAfter(serialDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = serialDate13.getEndOfCurrentMonth(serialDate16);
        java.lang.String str19 = serialDate13.getDescription();
        int int20 = spreadsheetDate11.compare(serialDate13);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable23 = timeSeries22.getKey();
        java.lang.String str24 = timeSeries22.getDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        java.util.Date date31 = fixedMillisecond28.getTime();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (double) '#');
        int int35 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) day32);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries22.addAndOrUpdate(timeSeries26);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate39);
        timeSeries26.setKey((java.lang.Comparable) serialDate39);
        boolean boolean42 = spreadsheetDate11.isBefore(serialDate39);
        int int43 = spreadsheetDate11.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int46 = spreadsheetDate45.getYYYY();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate52);
        org.jfree.data.time.SerialDate serialDate54 = serialDate49.getEndOfCurrentMonth(serialDate52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addDays(13, serialDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int59 = spreadsheetDate58.getMonth();
        boolean boolean61 = spreadsheetDate45.isInRange(serialDate54, (org.jfree.data.time.SerialDate) spreadsheetDate58, 12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate68);
        org.jfree.data.time.SerialDate serialDate70 = serialDate65.getEndOfCurrentMonth(serialDate68);
        java.lang.String str71 = serialDate65.getDescription();
        int int72 = spreadsheetDate63.compare(serialDate65);
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable75 = timeSeries74.getKey();
        java.lang.String str76 = timeSeries74.getDescription();
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar81 = null;
        long long82 = fixedMillisecond80.getMiddleMillisecond(calendar81);
        java.util.Date date83 = fixedMillisecond80.getTime();
        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date83);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day84, (double) '#');
        int int87 = timeSeries78.getIndex((org.jfree.data.time.RegularTimePeriod) day84);
        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries74.addAndOrUpdate(timeSeries78);
        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate92 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate91);
        timeSeries78.setKey((java.lang.Comparable) serialDate91);
        boolean boolean94 = spreadsheetDate63.isBefore(serialDate91);
        int int95 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate63);
        org.jfree.data.time.SerialDate serialDate96 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean97 = spreadsheetDate1.isOn(serialDate96);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1919 + "'", int20 == 1919);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 0.0f + "'", comparable23.equals(0.0f));
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 11 + "'", int43 == 11);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1905 + "'", int46 == 1905);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 7 + "'", int59 == 7);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1919 + "'", int72 == 1919);
        org.junit.Assert.assertTrue("'" + comparable75 + "' != '" + 0.0f + "'", comparable75.equals(0.0f));
        org.junit.Assert.assertNull(str76);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-1L) + "'", long82 == (-1L));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
        org.junit.Assert.assertNotNull(timeSeries88);
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
        org.junit.Assert.assertNotNull(serialDate96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.Year year6 = month4.getYear();
        long long7 = year6.getFirstMillisecond();
        long long8 = year6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries18.fireSeriesChanged();
        timeSeries18.removeAgedItems((long) 2, false);
        java.lang.String str23 = timeSeries18.getRangeDescription();
        timeSeries18.setNotify(false);
        java.util.List list26 = timeSeries18.getItems();
        timeSeries18.setKey((java.lang.Comparable) 9);
        timeSeries18.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond32.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
        int int38 = day36.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 8);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (short) 10, year42);
        int int47 = month45.compareTo((java.lang.Object) 13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) 1969);
        timeSeries1.add(timeSeriesDataItem49, false);
        timeSeries1.removeAgedItems((long) 100, false);
        timeSeries1.clear();
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = serialDate1.getEndOfCurrentMonth(serialDate4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day7);
        long long10 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getTime();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        long long17 = day16.getFirstMillisecond();
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) day16);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-57600000L) + "'", long17 == (-57600000L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries5.fireSeriesChanged();
        timeSeries5.removeAgedItems((long) 2, false);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getTime();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        int int18 = day16.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 0L);
        org.jfree.data.time.SerialDate serialDate21 = day16.getSerialDate();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate26);
        org.jfree.data.time.SerialDate serialDate28 = serialDate23.getEndOfCurrentMonth(serialDate26);
        java.lang.String str29 = serialDate23.toString();
        boolean boolean31 = spreadsheetDate1.isInRange(serialDate21, serialDate23, 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-April-1900" + "'", str29.equals("9-April-1900"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        int int7 = day6.getMonth();
        int int8 = day6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.previous();
        int int10 = day6.getMonth();
        java.lang.String str11 = day6.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-1969" + "'", str11.equals("31-December-1969"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int3 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(13, serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int16 = spreadsheetDate15.getMonth();
        boolean boolean18 = spreadsheetDate2.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15, 12);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate27);
        org.jfree.data.time.SerialDate serialDate29 = serialDate24.getEndOfCurrentMonth(serialDate27);
        java.lang.String str30 = serialDate24.getDescription();
        int int31 = spreadsheetDate22.compare(serialDate24);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate34.setDescription("");
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, serialDate34);
        java.lang.String str38 = serialDate37.toString();
        boolean boolean39 = spreadsheetDate22.isOnOrBefore(serialDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int42 = spreadsheetDate41.getMonth();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate47);
        org.jfree.data.time.SerialDate serialDate49 = serialDate44.getEndOfCurrentMonth(serialDate47);
        java.lang.String str50 = serialDate44.getDescription();
        int int51 = spreadsheetDate41.compare(serialDate44);
        int int52 = spreadsheetDate41.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate53 = serialDate37.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate41);
        int int54 = spreadsheetDate41.getDayOfMonth();
        boolean boolean55 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1905 + "'", int3 == 1905);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 7 + "'", int16 == 7);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1919 + "'", int31 == 1919);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-March-1900" + "'", str38.equals("9-March-1900"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 7 + "'", int42 == 7);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1919 + "'", int51 == 1919);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 11 + "'", int52 == 11);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 11 + "'", int54 == 11);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond1.equals(obj6);
        java.lang.String str8 = fixedMillisecond1.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        int int14 = fixedMillisecond10.compareTo((java.lang.Object) true);
        java.util.Date date15 = fixedMillisecond10.getEnd();
        int int16 = fixedMillisecond1.compareTo((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year17.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str8.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date5);
        long long16 = fixedMillisecond15.getSerialIndex();
        long long17 = fixedMillisecond15.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) '#');
        java.lang.String[] strArray15 = org.jfree.data.time.SerialDate.getMonths();
        int int16 = timeSeriesDataItem14.compareTo((java.lang.Object) strArray15);
        timeSeries1.add(timeSeriesDataItem14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries1.addChangeListener(seriesChangeListener18);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries21.fireSeriesChanged();
        timeSeries21.removeAgedItems((long) 2, false);
        java.lang.String str26 = timeSeries21.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        java.util.Date date31 = fixedMillisecond28.getTime();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
        int int34 = day32.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) 0L);
        int int37 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day32);
        java.lang.String str38 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 12 + "'", int34 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection6 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.removeChangeListener(seriesChangeListener7);
        timeSeries5.setDomainDescription("");
        long long11 = timeSeries5.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date5);
        try {
            org.jfree.data.time.SerialDate serialDate18 = serialDate16.getNearestDayOfWeek((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = serialDate2.getEndOfCurrentMonth(serialDate5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(13, serialDate7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable14 = timeSeries13.getKey();
        java.lang.String str15 = timeSeries13.getDescription();
        int int16 = timeSeries13.getItemCount();
        timeSeries13.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) '#');
        java.lang.String[] strArray27 = org.jfree.data.time.SerialDate.getMonths();
        int int28 = timeSeriesDataItem26.compareTo((java.lang.Object) strArray27);
        timeSeries13.add(timeSeriesDataItem26);
        java.lang.Object obj30 = timeSeriesDataItem26.clone();
        java.lang.Class<?> wildcardClass31 = timeSeriesDataItem26.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, "Value", "", (java.lang.Class) wildcardClass31);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        int int36 = year34.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 10, year34);
        java.util.Date date38 = month37.getEnd();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond42.getMiddleMillisecond(calendar43);
        java.util.Date date45 = fixedMillisecond42.getTime();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day46, (double) '#');
        int int49 = timeSeries40.getIndex((org.jfree.data.time.RegularTimePeriod) day46);
        boolean boolean50 = month37.equals((java.lang.Object) int49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month37.next();
        int int52 = timeSeries32.getIndex((org.jfree.data.time.RegularTimePeriod) month37);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 0.0f + "'", comparable14.equals(0.0f));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("September");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable7 = timeSeries6.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int11 = year9.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 10, year9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month12, (double) (byte) 100);
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        java.lang.String str19 = month18.toString();
        long long20 = month18.getLastMillisecond();
        long long21 = month18.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 1.0f);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 1560191578339L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 0.0f + "'", comparable7.equals(0.0f));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "June 2019" + "'", str19.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561964399999L + "'", long20 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 24234L + "'", long21 == 24234L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable12 = timeSeries11.getKey();
        java.lang.String str13 = timeSeries11.getDescription();
        int int14 = timeSeries11.getItemCount();
        timeSeries11.setDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.addAndOrUpdate(timeSeries11);
        int int20 = timeSeries11.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 0.0f + "'", comparable12.equals(0.0f));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        long long7 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getFirstMillisecond(calendar8);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond1.getMiddleMillisecond(calendar10);
        long long12 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = serialDate2.getEndOfCurrentMonth(serialDate5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(13, serialDate7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable14 = timeSeries13.getKey();
        java.lang.String str15 = timeSeries13.getDescription();
        int int16 = timeSeries13.getItemCount();
        timeSeries13.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) '#');
        java.lang.String[] strArray27 = org.jfree.data.time.SerialDate.getMonths();
        int int28 = timeSeriesDataItem26.compareTo((java.lang.Object) strArray27);
        timeSeries13.add(timeSeriesDataItem26);
        java.lang.Object obj30 = timeSeriesDataItem26.clone();
        java.lang.Class<?> wildcardClass31 = timeSeriesDataItem26.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, "Value", "", (java.lang.Class) wildcardClass31);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable35 = timeSeries34.getKey();
        java.lang.String str36 = timeSeries34.getDescription();
        int int37 = timeSeries34.getItemCount();
        timeSeries34.setDescription("hi!");
        java.lang.Class class40 = timeSeries34.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond42.getMiddleMillisecond(calendar43);
        java.util.Date date45 = fixedMillisecond42.getTime();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45, timeZone46);
        java.lang.Class class48 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getMiddleMillisecond(calendar51);
        java.util.Date date53 = fixedMillisecond50.getTime();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date53);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond56.getMiddleMillisecond(calendar57);
        java.util.Date date59 = fixedMillisecond56.getTime();
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date59, timeZone60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date53, timeZone60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date45, timeZone60);
        java.util.TimeZone timeZone64 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date45, timeZone64);
        java.lang.Class class66 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar69 = null;
        long long70 = fixedMillisecond68.getMiddleMillisecond(calendar69);
        java.util.Date date71 = fixedMillisecond68.getTime();
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date71);
        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar75 = null;
        long long76 = fixedMillisecond74.getMiddleMillisecond(calendar75);
        java.util.Date date77 = fixedMillisecond74.getTime();
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date77, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date71, timeZone78);
        org.jfree.data.time.Month month81 = new org.jfree.data.time.Month(date45, timeZone78);
        long long82 = month81.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 0.0f + "'", comparable14.equals(0.0f));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + 0.0f + "'", comparable35.equals(0.0f));
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-1L) + "'", long52 == (-1L));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-1L) + "'", long58 == (-1L));
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-1L) + "'", long70 == (-1L));
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-1L) + "'", long76 == (-1L));
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-2649600000L) + "'", long82 == (-2649600000L));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        timeSeries1.setNotify(true);
        timeSeries1.clear();
        java.util.List list20 = timeSeries1.getItems();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int24 = year22.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, year22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
        java.lang.Number number27 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month25);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(number27);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 1919, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.lang.Number number12 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.Class class13 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int16 = year14.compareTo((java.lang.Object) 3);
        long long17 = year14.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass18 = year14.getClass();
        long long19 = year14.getFirstMillisecond();
        int int20 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year14);
        try {
            timeSeries1.delete((int) ' ', 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) (-1L));
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.String str10 = timeSeries8.getDescription();
        int int11 = timeSeries8.getItemCount();
        timeSeries8.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (double) '#');
        java.lang.String[] strArray22 = org.jfree.data.time.SerialDate.getMonths();
        int int23 = timeSeriesDataItem21.compareTo((java.lang.Object) strArray22);
        timeSeries8.add(timeSeriesDataItem21);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries8.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries28.fireSeriesChanged();
        timeSeries28.removeAgedItems((long) 2, false);
        java.lang.String str33 = timeSeries28.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
        int int41 = day39.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) 0L);
        int int44 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day39);
        java.lang.Number number45 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getMiddleMillisecond(calendar48);
        java.util.Date date50 = fixedMillisecond47.getTime();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (double) '#');
        timeSeries1.add(timeSeriesDataItem53, true);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        int int58 = year56.compareTo((java.lang.Object) 3);
        int int60 = year56.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
        boolean boolean62 = year56.equals((java.lang.Object) day61);
        java.lang.Number number63 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year56);
        java.util.Calendar calendar64 = null;
        try {
            long long65 = year56.getFirstMillisecond(calendar64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0f + "'", comparable9.equals(0.0f));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-1L) + "'", long49 == (-1L));
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + 35.0d + "'", number63.equals(35.0d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.Year year6 = month4.getYear();
        org.jfree.data.time.Year year7 = month4.getYear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(year7);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, (int) (byte) 1, 2019);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191641707L + "'", long2 == 1560191641707L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        java.lang.String str5 = timeSeries3.getDescription();
        int int6 = timeSeries3.getItemCount();
        timeSeries3.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable11 = timeSeries10.getKey();
        java.lang.String str12 = timeSeries10.getDescription();
        int int13 = timeSeries10.getItemCount();
        timeSeries10.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) '#');
        java.lang.String[] strArray24 = org.jfree.data.time.SerialDate.getMonths();
        int int25 = timeSeriesDataItem23.compareTo((java.lang.Object) strArray24);
        timeSeries10.add(timeSeriesDataItem23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries10.addChangeListener(seriesChangeListener27);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries30.fireSeriesChanged();
        timeSeries30.removeAgedItems((long) 2, false);
        java.lang.String str35 = timeSeries30.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
        java.util.Date date40 = fixedMillisecond37.getTime();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
        int int43 = day41.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day41, (java.lang.Number) 0L);
        int int46 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day41);
        java.lang.Number number47 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries1.addAndOrUpdate(timeSeries3);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 0.0f + "'", comparable4.equals(0.0f));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 0.0f + "'", comparable11.equals(0.0f));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Value" + "'", str35.equals("Value"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-1L) + "'", long39 == (-1L));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertNotNull(timeSeries48);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(13, serialDate11);
        boolean boolean14 = spreadsheetDate1.isOnOrAfter(serialDate13);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays(5, serialDate19);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, serialDate23);
        boolean boolean25 = spreadsheetDate1.isInRange(serialDate19, serialDate24);
        java.util.Date date26 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems((long) 5, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond13.getTime();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1L));
        long long20 = day17.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 25568L + "'", long20 == 25568L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection6 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.removeChangeListener(seriesChangeListener7);
        timeSeries5.setDomainDescription("October 2019");
        java.util.Collection collection11 = timeSeries5.getTimePeriods();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(collection11);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10, 1969, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(13, serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int15 = spreadsheetDate14.getMonth();
        boolean boolean17 = spreadsheetDate1.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14, 12);
        int int18 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate21);
        int int23 = spreadsheetDate1.compare(serialDate21);
        int int24 = spreadsheetDate1.toSerial();
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        boolean boolean29 = spreadsheetDate1.equals((java.lang.Object) regularTimePeriod28);
        java.lang.String str30 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1905 + "'", int18 == 1905);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1919 + "'", int23 == 1919);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(13, serialDate9);
        boolean boolean12 = month0.equals((java.lang.Object) serialDate11);
        long long13 = month0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate4.getDescription();
        int int11 = spreadsheetDate1.compare(serialDate4);
        spreadsheetDate1.setDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) '#');
        int int24 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
        boolean boolean26 = day21.equals((java.lang.Object) 7);
        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
        boolean boolean28 = spreadsheetDate1.isAfter(serialDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int31 = spreadsheetDate30.getYYYY();
        boolean boolean32 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable35 = timeSeries34.getKey();
        java.lang.String str36 = timeSeries34.getDescription();
        timeSeries34.setRangeDescription("June 2019");
        boolean boolean39 = spreadsheetDate30.equals((java.lang.Object) "June 2019");
        int int40 = spreadsheetDate30.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1919 + "'", int11 == 1919);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1905 + "'", int31 == 1905);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + 0.0f + "'", comparable35.equals(0.0f));
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 11 + "'", int40 == 11);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        long long4 = year1.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass5 = year1.getClass();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = serialDate7.getEndOfCurrentMonth(serialDate10);
        boolean boolean13 = year1.equals((java.lang.Object) serialDate10);
        long long14 = year1.getFirstMillisecond();
        int int15 = year1.getYear();
        try {
            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        try {
            org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate1.getFollowingDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        int int5 = month4.getMonth();
        org.jfree.data.time.Year year6 = month4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date5);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year17.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 0);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month2);
        long long4 = month2.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5L + "'", long4 == 5L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable6 = timeSeries5.getKey();
        java.lang.String str7 = timeSeries5.getDescription();
        int int8 = timeSeries5.getItemCount();
        timeSeries5.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        java.lang.String str14 = timeSeries12.getDescription();
        int int15 = timeSeries12.getItemCount();
        timeSeries12.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) '#');
        java.lang.String[] strArray26 = org.jfree.data.time.SerialDate.getMonths();
        int int27 = timeSeriesDataItem25.compareTo((java.lang.Object) strArray26);
        timeSeries12.add(timeSeriesDataItem25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries12.addChangeListener(seriesChangeListener29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries32.fireSeriesChanged();
        timeSeries32.removeAgedItems((long) 2, false);
        java.lang.String str37 = timeSeries32.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.previous();
        int int45 = day43.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 0L);
        int int48 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) day43);
        java.lang.Number number49 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day43);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries3.addAndOrUpdate(timeSeries5);
        boolean boolean51 = spreadsheetDate1.equals((java.lang.Object) timeSeries5);
        int int52 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate59);
        org.jfree.data.time.SerialDate serialDate61 = serialDate56.getEndOfCurrentMonth(serialDate59);
        java.lang.String str62 = serialDate56.getDescription();
        int int63 = spreadsheetDate54.compare(serialDate56);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable66 = timeSeries65.getKey();
        java.lang.String str67 = timeSeries65.getDescription();
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar72 = null;
        long long73 = fixedMillisecond71.getMiddleMillisecond(calendar72);
        java.util.Date date74 = fixedMillisecond71.getTime();
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date74);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day75, (double) '#');
        int int78 = timeSeries69.getIndex((org.jfree.data.time.RegularTimePeriod) day75);
        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries65.addAndOrUpdate(timeSeries69);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate82);
        timeSeries69.setKey((java.lang.Comparable) serialDate82);
        boolean boolean85 = spreadsheetDate54.isBefore(serialDate82);
        int int86 = spreadsheetDate54.getDayOfMonth();
        boolean boolean87 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0f + "'", comparable6.equals(0.0f));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0f + "'", comparable13.equals(0.0f));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Value" + "'", str37.equals("Value"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 11 + "'", int52 == 11);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1919 + "'", int63 == 1919);
        org.junit.Assert.assertTrue("'" + comparable66 + "' != '" + 0.0f + "'", comparable66.equals(0.0f));
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-1L) + "'", long73 == (-1L));
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertNotNull(timeSeries79);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 11 + "'", int86 == 11);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1905, (int) '#', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        java.util.List list9 = timeSeries1.getItems();
        timeSeries1.setKey((java.lang.Comparable) 9);
        timeSeries1.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        int int21 = day19.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 8);
        java.lang.String str24 = day19.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "31-December-1969" + "'", str24.equals("31-December-1969"));
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191643567L + "'", long2 == 1560191643567L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560191643567L + "'", long4 == 1560191643567L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560191643567L + "'", long5 == 1560191643567L);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        java.util.List list5 = timeSeries1.getItems();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.String str7 = month6.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.String str12 = timeSeries11.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries11.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, serialDate4);
        java.lang.String str6 = serialDate5.getDescription();
        serialDate5.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(2, serialDate5);
        try {
            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(8, serialDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        java.util.Date date6 = fixedMillisecond1.getEnd();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getFirstMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) '#');
        timeSeriesDataItem7.setValue((java.lang.Number) 1577865599999L);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        java.util.List list5 = timeSeries1.getItems();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int9 = year7.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (short) 10, year7);
        java.util.Date date11 = month10.getEnd();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (double) '#');
        int int22 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) day19);
        boolean boolean23 = month10.equals((java.lang.Object) int22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month10.next();
        long long25 = month10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod26, (double) (byte) 10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod26, (double) 1561964399999L);
        try {
            timeSeries1.add(timeSeriesDataItem30, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1572591599999L + "'", long25 == 1572591599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = serialDate2.getEndOfCurrentMonth(serialDate5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(13, serialDate7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable14 = timeSeries13.getKey();
        java.lang.String str15 = timeSeries13.getDescription();
        int int16 = timeSeries13.getItemCount();
        timeSeries13.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) '#');
        java.lang.String[] strArray27 = org.jfree.data.time.SerialDate.getMonths();
        int int28 = timeSeriesDataItem26.compareTo((java.lang.Object) strArray27);
        timeSeries13.add(timeSeriesDataItem26);
        java.lang.Object obj30 = timeSeriesDataItem26.clone();
        java.lang.Class<?> wildcardClass31 = timeSeriesDataItem26.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, "Value", "", (java.lang.Class) wildcardClass31);
        java.util.List list33 = timeSeries32.getItems();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        java.lang.String str35 = month34.toString();
        long long36 = month34.getLastMillisecond();
        long long37 = month34.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) 1.0f);
        try {
            timeSeries32.add(timeSeriesDataItem39);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 0.0f + "'", comparable14.equals(0.0f));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "June 2019" + "'", str35.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1561964399999L + "'", long36 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 24234L + "'", long37 == 24234L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(31, 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        long long3 = year0.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long8 = fixedMillisecond7.getSerialIndex();
        int int9 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable12 = timeSeries11.getKey();
        java.lang.String str13 = timeSeries11.getDescription();
        int int14 = timeSeries11.getItemCount();
        timeSeries11.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) '#');
        java.lang.String[] strArray25 = org.jfree.data.time.SerialDate.getMonths();
        int int26 = timeSeriesDataItem24.compareTo((java.lang.Object) strArray25);
        timeSeries11.add(timeSeriesDataItem24);
        java.lang.Object obj28 = timeSeriesDataItem24.clone();
        java.lang.Class<?> wildcardClass29 = timeSeriesDataItem24.getClass();
        timeSeries5.add(timeSeriesDataItem24, false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 0.0f + "'", comparable12.equals(0.0f));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.String str10 = timeSeries8.getDescription();
        int int11 = timeSeries8.getItemCount();
        timeSeries8.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (double) '#');
        java.lang.String[] strArray22 = org.jfree.data.time.SerialDate.getMonths();
        int int23 = timeSeriesDataItem21.compareTo((java.lang.Object) strArray22);
        timeSeries8.add(timeSeriesDataItem21);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries8.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries28.fireSeriesChanged();
        timeSeries28.removeAgedItems((long) 2, false);
        java.lang.String str33 = timeSeries28.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
        int int41 = day39.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) 0L);
        int int44 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day39);
        java.lang.Number number45 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day39);
        timeSeries1.removeAgedItems(0L, false);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0f + "'", comparable9.equals(0.0f));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(number45);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        java.lang.String str7 = seriesException6.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) seriesException6);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str7.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        int int6 = month4.compareTo((java.lang.Object) 13);
        java.lang.String str7 = month4.toString();
        java.lang.String str8 = month4.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "October 2019" + "'", str7.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 2019" + "'", str8.equals("October 2019"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = serialDate1.getEndOfCurrentMonth(serialDate4);
        java.lang.String str7 = serialDate1.getDescription();
        serialDate1.setDescription("9-April-1900");
        serialDate1.setDescription("Wed Dec 31 15:59:59 PST 1969");
        org.jfree.data.time.SerialDate serialDate13 = serialDate1.getPreviousDayOfWeek(6);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        int int7 = day6.getMonth();
        int int8 = day6.getMonth();
        int int9 = day6.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        long long3 = year0.getFirstMillisecond();
        java.lang.String str4 = year0.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate4.getDescription();
        int int11 = spreadsheetDate1.compare(serialDate4);
        spreadsheetDate1.setDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) '#');
        int int24 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
        boolean boolean26 = day21.equals((java.lang.Object) 7);
        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
        boolean boolean28 = spreadsheetDate1.isAfter(serialDate27);
        int int29 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        int int33 = year31.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (short) 10, year31);
        java.util.Date date35 = month34.getEnd();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day43, (double) '#');
        int int46 = timeSeries37.getIndex((org.jfree.data.time.RegularTimePeriod) day43);
        boolean boolean47 = month34.equals((java.lang.Object) int46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month34.next();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable51 = timeSeries50.getKey();
        java.lang.String str52 = timeSeries50.getDescription();
        int int53 = timeSeries50.getItemCount();
        timeSeries50.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar58 = null;
        long long59 = fixedMillisecond57.getMiddleMillisecond(calendar58);
        java.util.Date date60 = fixedMillisecond57.getTime();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day61, (double) '#');
        long long64 = day61.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries50.getDataItem((org.jfree.data.time.RegularTimePeriod) day61);
        boolean boolean66 = month34.equals((java.lang.Object) day61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day61.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = day61.next();
        try {
            int int69 = spreadsheetDate1.compareTo((java.lang.Object) day61);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Day cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1919 + "'", int11 == 1919);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 11 + "'", int29 == 11);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + comparable51 + "' != '" + 0.0f + "'", comparable51.equals(0.0f));
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-1L) + "'", long59 == (-1L));
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 25568L + "'", long64 == 25568L);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        long long3 = year0.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate9);
        boolean boolean12 = year0.equals((java.lang.Object) serialDate9);
        long long13 = year0.getFirstMillisecond();
        int int14 = year0.getYear();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year0.getMiddleMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(13, serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int15 = spreadsheetDate14.getMonth();
        boolean boolean17 = spreadsheetDate1.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14, 12);
        int int18 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate21);
        int int23 = spreadsheetDate1.compare(serialDate21);
        int int24 = spreadsheetDate1.toSerial();
        java.lang.String str25 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1905 + "'", int18 == 1905);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1919 + "'", int23 == 1919);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int4 = year2.compareTo((java.lang.Object) 3);
        long long5 = year2.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass6 = year2.getClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year2);
        int int8 = month0.compareTo((java.lang.Object) year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month0.previous();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(13, serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int15 = spreadsheetDate14.getMonth();
        boolean boolean17 = spreadsheetDate1.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14, 12);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate25);
        org.jfree.data.time.SerialDate serialDate27 = serialDate22.getEndOfCurrentMonth(serialDate25);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(13, serialDate27);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable34 = timeSeries33.getKey();
        java.lang.String str35 = timeSeries33.getDescription();
        int int36 = timeSeries33.getItemCount();
        timeSeries33.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
        java.util.Date date43 = fixedMillisecond40.getTime();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day44, (double) '#');
        java.lang.String[] strArray47 = org.jfree.data.time.SerialDate.getMonths();
        int int48 = timeSeriesDataItem46.compareTo((java.lang.Object) strArray47);
        timeSeries33.add(timeSeriesDataItem46);
        java.lang.Object obj50 = timeSeriesDataItem46.clone();
        java.lang.Class<?> wildcardClass51 = timeSeriesDataItem46.getClass();
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate27, "Value", "", (java.lang.Class) wildcardClass51);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable55 = timeSeries54.getKey();
        java.lang.String str56 = timeSeries54.getDescription();
        int int57 = timeSeries54.getItemCount();
        timeSeries54.setDescription("hi!");
        java.lang.Class class60 = timeSeries54.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar63 = null;
        long long64 = fixedMillisecond62.getMiddleMillisecond(calendar63);
        java.util.Date date65 = fixedMillisecond62.getTime();
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date65, timeZone66);
        java.lang.Class class68 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar71 = null;
        long long72 = fixedMillisecond70.getMiddleMillisecond(calendar71);
        java.util.Date date73 = fixedMillisecond70.getTime();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date73);
        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar77 = null;
        long long78 = fixedMillisecond76.getMiddleMillisecond(calendar77);
        java.util.Date date79 = fixedMillisecond76.getTime();
        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date79, timeZone80);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class68, date73, timeZone80);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date65, timeZone80);
        java.util.TimeZone timeZone84 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date65, timeZone84);
        org.jfree.data.time.TimeSeries timeSeries86 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 12, "October", "hi!", (java.lang.Class) wildcardClass51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + comparable34 + "' != '" + 0.0f + "'", comparable34.equals(0.0f));
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + comparable55 + "' != '" + 0.0f + "'", comparable55.equals(0.0f));
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(class60);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-1L) + "'", long64 == (-1L));
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-1L) + "'", long72 == (-1L));
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-1L) + "'", long78 == (-1L));
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(timeZone80);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(regularTimePeriod83);
        org.junit.Assert.assertNull(regularTimePeriod85);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries18.fireSeriesChanged();
        timeSeries18.removeAgedItems((long) 2, false);
        java.lang.String str23 = timeSeries18.getRangeDescription();
        timeSeries18.setNotify(false);
        java.util.List list26 = timeSeries18.getItems();
        timeSeries18.setKey((java.lang.Comparable) 9);
        timeSeries18.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond32.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
        int int38 = day36.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 8);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (short) 10, year42);
        int int47 = month45.compareTo((java.lang.Object) 13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) 1969);
        timeSeries1.add(timeSeriesDataItem49, false);
        timeSeries1.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries1.createCopy(0, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar60 = null;
        long long61 = fixedMillisecond59.getMiddleMillisecond(calendar60);
        int int63 = fixedMillisecond59.compareTo((java.lang.Object) true);
        java.lang.Object obj64 = null;
        boolean boolean65 = fixedMillisecond59.equals(obj64);
        java.lang.String str66 = fixedMillisecond59.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = fixedMillisecond59.next();
        timeSeries57.setKey((java.lang.Comparable) fixedMillisecond59);
        java.util.Collection collection69 = timeSeries57.getTimePeriods();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-1L) + "'", long61 == (-1L));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str66.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(collection69);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-435), (int) 'a', (-23668));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2147483647);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2147483647L + "'", long2 == 2147483647L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        java.lang.String str9 = timeSeries7.getDescription();
        int int10 = timeSeries7.getItemCount();
        timeSeries7.setDescription("hi!");
        java.lang.Class class13 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        java.util.Date date20 = day19.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond23.getTime();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date20, timeZone28);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date4, timeZone28);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 0.0f + "'", comparable8.equals(0.0f));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.String str10 = timeSeries8.getDescription();
        int int11 = timeSeries8.getItemCount();
        timeSeries8.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (double) '#');
        java.lang.String[] strArray22 = org.jfree.data.time.SerialDate.getMonths();
        int int23 = timeSeriesDataItem21.compareTo((java.lang.Object) strArray22);
        timeSeries8.add(timeSeriesDataItem21);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries8.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries28.fireSeriesChanged();
        timeSeries28.removeAgedItems((long) 2, false);
        java.lang.String str33 = timeSeries28.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
        int int41 = day39.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) 0L);
        int int44 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day39);
        java.lang.Number number45 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getMiddleMillisecond(calendar48);
        java.util.Date date50 = fixedMillisecond47.getTime();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (double) '#');
        timeSeries1.add(timeSeriesDataItem53, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar58 = null;
        long long59 = fixedMillisecond57.getMiddleMillisecond(calendar58);
        java.util.Date date60 = fixedMillisecond57.getTime();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day61.previous();
        long long63 = day61.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day61, (java.lang.Number) (-435));
        long long66 = day61.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day61.next();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0f + "'", comparable9.equals(0.0f));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-1L) + "'", long49 == (-1L));
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-1L) + "'", long59 == (-1L));
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 25568L + "'", long63 == 25568L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 25568L + "'", long66 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) '#');
        java.lang.String[] strArray15 = org.jfree.data.time.SerialDate.getMonths();
        int int16 = timeSeriesDataItem14.compareTo((java.lang.Object) strArray15);
        timeSeries1.add(timeSeriesDataItem14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries1.addChangeListener(seriesChangeListener18);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries21.fireSeriesChanged();
        timeSeries21.removeAgedItems((long) 2, false);
        java.lang.String str26 = timeSeries21.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        java.util.Date date31 = fixedMillisecond28.getTime();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
        int int34 = day32.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) 0L);
        int int37 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day32);
        java.lang.Class<?> wildcardClass38 = day32.getClass();
        java.util.Calendar calendar39 = null;
        try {
            long long40 = day32.getLastMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 12 + "'", int34 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(wildcardClass38);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries18.fireSeriesChanged();
        timeSeries18.removeAgedItems((long) 2, false);
        java.lang.String str23 = timeSeries18.getRangeDescription();
        timeSeries18.setNotify(false);
        java.util.List list26 = timeSeries18.getItems();
        timeSeries18.setKey((java.lang.Comparable) 9);
        timeSeries18.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond32.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
        int int38 = day36.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 8);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (short) 10, year42);
        int int47 = month45.compareTo((java.lang.Object) 13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) 1969);
        timeSeries1.add(timeSeriesDataItem49, false);
        timeSeries1.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries1.createCopy(0, 0);
        long long58 = timeSeries57.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 9223372036854775807L + "'", long58 == 9223372036854775807L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable6 = timeSeries5.getKey();
        java.lang.String str7 = timeSeries5.getDescription();
        int int8 = timeSeries5.getItemCount();
        timeSeries5.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        java.lang.String str14 = timeSeries12.getDescription();
        int int15 = timeSeries12.getItemCount();
        timeSeries12.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) '#');
        java.lang.String[] strArray26 = org.jfree.data.time.SerialDate.getMonths();
        int int27 = timeSeriesDataItem25.compareTo((java.lang.Object) strArray26);
        timeSeries12.add(timeSeriesDataItem25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries12.addChangeListener(seriesChangeListener29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries32.fireSeriesChanged();
        timeSeries32.removeAgedItems((long) 2, false);
        java.lang.String str37 = timeSeries32.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.previous();
        int int45 = day43.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 0L);
        int int48 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) day43);
        java.lang.Number number49 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day43);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries3.addAndOrUpdate(timeSeries5);
        boolean boolean51 = spreadsheetDate1.equals((java.lang.Object) timeSeries5);
        java.lang.String str52 = spreadsheetDate1.toString();
        int int53 = spreadsheetDate1.getMonth();
        int int54 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0f + "'", comparable6.equals(0.0f));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0f + "'", comparable13.equals(0.0f));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Value" + "'", str37.equals("Value"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "11-July-1905" + "'", str52.equals("11-July-1905"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 7 + "'", int53 == 7);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 7 + "'", int54 == 7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        timeSeries5.setDescription("Value");
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond10.getTime();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) '#');
        int int17 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day14);
        org.jfree.data.time.SerialDate serialDate18 = day14.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate(regularTimePeriod19, (double) 9999);
        timeSeries1.setMaximumItemAge((long) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) (-1L));
        java.util.Date date4 = fixedMillisecond1.getTime();
        long long5 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate6);
        java.lang.String str9 = serialDate3.getDescription();
        int int10 = spreadsheetDate1.compare(serialDate3);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = serialDate3.getEndOfCurrentMonth(serialDate14);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1919 + "'", int10 == 1919);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        java.util.Date date6 = fixedMillisecond1.getEnd();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.String str10 = timeSeries8.getDescription();
        int int11 = timeSeries8.getItemCount();
        timeSeries8.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable16 = timeSeries15.getKey();
        java.lang.String str17 = timeSeries15.getDescription();
        int int18 = timeSeries15.getItemCount();
        timeSeries15.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (double) '#');
        java.lang.String[] strArray29 = org.jfree.data.time.SerialDate.getMonths();
        int int30 = timeSeriesDataItem28.compareTo((java.lang.Object) strArray29);
        timeSeries15.add(timeSeriesDataItem28);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries15.addChangeListener(seriesChangeListener32);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries35.fireSeriesChanged();
        timeSeries35.removeAgedItems((long) 2, false);
        java.lang.String str40 = timeSeries35.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond42.getMiddleMillisecond(calendar43);
        java.util.Date date45 = fixedMillisecond42.getTime();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
        int int48 = day46.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) 0L);
        int int51 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) day46);
        java.lang.Number number52 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond54.getMiddleMillisecond(calendar55);
        java.util.Date date57 = fixedMillisecond54.getTime();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day58, (double) '#');
        timeSeries8.add(timeSeriesDataItem60, true);
        boolean boolean63 = fixedMillisecond1.equals((java.lang.Object) true);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        int int67 = year65.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month((int) (short) 10, year65);
        java.util.Date date69 = month68.getEnd();
        org.jfree.data.time.Year year70 = month68.getYear();
        long long71 = year70.getLastMillisecond();
        boolean boolean72 = fixedMillisecond1.equals((java.lang.Object) year70);
        long long73 = year70.getSerialIndex();
        long long74 = year70.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0f + "'", comparable9.equals(0.0f));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 0.0f + "'", comparable16.equals(0.0f));
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 12 + "'", int48 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-1L) + "'", long56 == (-1L));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(year70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1577865599999L + "'", long71 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 2019L + "'", long73 == 2019L);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1577865599999L + "'", long74 == 1577865599999L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) 'a', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-452) + "'", int1 == (-452));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        long long6 = fixedMillisecond1.getSerialIndex();
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date8 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean17 = month4.equals((java.lang.Object) int16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month4.next();
        long long19 = month4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month4.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int24 = year22.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, year22);
        java.util.Date date26 = month25.getEnd();
        boolean boolean27 = month4.equals((java.lang.Object) date26);
        java.lang.String str28 = month4.toString();
        java.lang.String str29 = month4.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1572591599999L + "'", long19 == 1572591599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "October 2019" + "'", str28.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "October 2019" + "'", str29.equals("October 2019"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        int int7 = day6.getMonth();
        java.lang.Object obj8 = null;
        boolean boolean9 = day6.equals(obj8);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day6.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate4.getDescription();
        int int11 = spreadsheetDate1.compare(serialDate4);
        int int12 = spreadsheetDate1.getDayOfMonth();
        int int13 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1919 + "'", int11 == 1919);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 11 + "'", int12 == 11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        java.lang.String str6 = timeSeries4.getDescription();
        int int7 = timeSeries4.getItemCount();
        timeSeries4.setDescription("hi!");
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getTime();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        java.util.Date date17 = day16.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date17, timeZone25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-2649600000L), "9-March-1900", "Last", class10);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0f + "'", comparable5.equals(0.0f));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        java.util.List list5 = timeSeries1.getItems();
        timeSeries1.removeAgedItems(false);
        java.lang.Class class8 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 2147483647);
        java.util.Date date11 = fixedMillisecond10.getTime();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date11, timeZone12);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate18);
        timeSeries5.setKey((java.lang.Comparable) serialDate18);
        java.util.Collection collection21 = timeSeries5.getTimePeriods();
        try {
            java.lang.Number number23 = timeSeries5.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(collection21);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean17 = month4.equals((java.lang.Object) int16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month4.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries18.fireSeriesChanged();
        timeSeries18.removeAgedItems((long) 2, false);
        java.lang.String str23 = timeSeries18.getRangeDescription();
        timeSeries18.setNotify(false);
        java.util.List list26 = timeSeries18.getItems();
        timeSeries18.setKey((java.lang.Comparable) 9);
        timeSeries18.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond32.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
        int int38 = day36.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 8);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (short) 10, year42);
        int int47 = month45.compareTo((java.lang.Object) 13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) 1969);
        timeSeries1.add(timeSeriesDataItem49, false);
        timeSeries1.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries1.createCopy(0, 0);
        java.util.Collection collection58 = timeSeries57.getTimePeriods();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertNotNull(collection58);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        java.lang.String str6 = timeSeries4.getDescription();
        int int7 = timeSeries4.getItemCount();
        timeSeries4.setDescription("hi!");
        java.lang.Class class10 = timeSeries4.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getTime();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        java.lang.Class class18 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        java.util.Date date29 = fixedMillisecond26.getTime();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date29, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date23, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone30);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month0, class10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (double) 1);
        java.lang.Object obj37 = timeSeriesDataItem36.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0f + "'", comparable5.equals(0.0f));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1L) + "'", long28 == (-1L));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        long long3 = year0.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long8 = fixedMillisecond7.getSerialIndex();
        int int9 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        long long3 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries5.fireSeriesChanged();
        timeSeries5.removeAgedItems((long) 2, false);
        java.lang.String str10 = timeSeries5.getRangeDescription();
        timeSeries5.setNotify(false);
        java.util.List list13 = timeSeries5.getItems();
        int int14 = year0.compareTo((java.lang.Object) timeSeries5);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        java.lang.String str16 = month15.toString();
        try {
            timeSeries5.add((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) 1562097599999L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "June 2019" + "'", str16.equals("June 2019"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        java.lang.String str2 = month1.toString();
        org.jfree.data.time.Year year3 = month1.getYear();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(100, year3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2147483647);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: June 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean17 = month4.equals((java.lang.Object) int16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month4.next();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable21 = timeSeries20.getKey();
        java.lang.String str22 = timeSeries20.getDescription();
        int int23 = timeSeries20.getItemCount();
        timeSeries20.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (double) '#');
        long long34 = day31.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) day31);
        boolean boolean36 = month4.equals((java.lang.Object) day31);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, serialDate41);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate43);
        int int45 = day31.compareTo((java.lang.Object) (byte) 1);
        org.jfree.data.time.SerialDate serialDate46 = day31.getSerialDate();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0.0f + "'", comparable21.equals(0.0f));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 25568L + "'", long34 == 25568L);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(serialDate46);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.util.Date date6 = day5.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) 1562097599999L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        boolean boolean13 = timeSeriesDataItem8.equals((java.lang.Object) fixedMillisecond10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.toSerial();
        java.lang.Object obj5 = null;
        try {
            int int6 = spreadsheetDate1.compareTo(obj5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        java.util.List list5 = timeSeries1.getItems();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.String str7 = month6.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month6.next();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        java.util.Date date6 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        long long8 = day7.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-14400001L) + "'", long8 == (-14400001L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean17 = month4.equals((java.lang.Object) int16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month4.next();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable21 = timeSeries20.getKey();
        java.lang.String str22 = timeSeries20.getDescription();
        int int23 = timeSeries20.getItemCount();
        timeSeries20.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (double) '#');
        long long34 = day31.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) day31);
        boolean boolean36 = month4.equals((java.lang.Object) day31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day31.next();
        int int38 = day31.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0.0f + "'", comparable21.equals(0.0f));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 25568L + "'", long34 == 25568L);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 2958465);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        java.util.List list9 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable12 = timeSeries11.getKey();
        java.lang.String str13 = timeSeries11.getDescription();
        int int14 = timeSeries11.getItemCount();
        timeSeries11.setDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries1.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int22 = year20.compareTo((java.lang.Object) 3);
        int int24 = year20.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = year20.equals((java.lang.Object) day25);
        timeSeries11.setKey((java.lang.Comparable) boolean26);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries11.removeChangeListener(seriesChangeListener28);
        try {
            java.lang.Number number31 = timeSeries11.getValue(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 0.0f + "'", comparable12.equals(0.0f));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate18);
        timeSeries5.setKey((java.lang.Comparable) serialDate18);
        timeSeries5.removeAgedItems(false);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.lang.String str24 = month23.toString();
        long long25 = month23.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable28 = timeSeries27.getKey();
        java.lang.String str29 = timeSeries27.getDescription();
        int int30 = timeSeries27.getItemCount();
        timeSeries27.setDescription("hi!");
        java.lang.Class class33 = timeSeries27.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38, timeZone39);
        java.lang.Class class41 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond43.getMiddleMillisecond(calendar44);
        java.util.Date date46 = fixedMillisecond43.getTime();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond49.getMiddleMillisecond(calendar50);
        java.util.Date date52 = fixedMillisecond49.getTime();
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date52, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date46, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date38, timeZone53);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23, class33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, (double) 1);
        boolean boolean60 = timeSeries5.equals((java.lang.Object) month23);
        long long61 = timeSeries5.getMaximumItemAge();
        try {
            timeSeries5.delete((-435), 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -435");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1561964399999L + "'", long25 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 0.0f + "'", comparable28.equals(0.0f));
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-1L) + "'", long45 == (-1L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 9223372036854775807L + "'", long61 == 9223372036854775807L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        int int12 = fixedMillisecond8.compareTo((java.lang.Object) true);
        long long13 = fixedMillisecond8.getSerialIndex();
        long long14 = fixedMillisecond8.getMiddleMillisecond();
        java.util.Date date15 = fixedMillisecond8.getTime();
        boolean boolean16 = day5.equals((java.lang.Object) date15);
        int int17 = day5.getDayOfMonth();
        int int18 = day5.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 31 + "'", int18 == 31);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean17 = month4.equals((java.lang.Object) int16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month4.next();
        long long19 = month4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month4.next();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = month4.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1572591599999L + "'", long19 == 1572591599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable6 = timeSeries5.getKey();
        java.lang.String str7 = timeSeries5.getDescription();
        int int8 = timeSeries5.getItemCount();
        timeSeries5.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        java.lang.String str14 = timeSeries12.getDescription();
        int int15 = timeSeries12.getItemCount();
        timeSeries12.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) '#');
        java.lang.String[] strArray26 = org.jfree.data.time.SerialDate.getMonths();
        int int27 = timeSeriesDataItem25.compareTo((java.lang.Object) strArray26);
        timeSeries12.add(timeSeriesDataItem25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries12.addChangeListener(seriesChangeListener29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries32.fireSeriesChanged();
        timeSeries32.removeAgedItems((long) 2, false);
        java.lang.String str37 = timeSeries32.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.previous();
        int int45 = day43.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 0L);
        int int48 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) day43);
        java.lang.Number number49 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day43);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries3.addAndOrUpdate(timeSeries5);
        boolean boolean51 = spreadsheetDate1.equals((java.lang.Object) timeSeries5);
        java.lang.String str52 = spreadsheetDate1.toString();
        java.lang.String str53 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate54 = null;
        try {
            int int55 = spreadsheetDate1.compare(serialDate54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0f + "'", comparable6.equals(0.0f));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0f + "'", comparable13.equals(0.0f));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Value" + "'", str37.equals("Value"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "11-July-1905" + "'", str52.equals("11-July-1905"));
        org.junit.Assert.assertNull(str53);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond3.getTime();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) '#');
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day7);
        timeSeries1.setDescription("");
        java.lang.Object obj13 = timeSeries1.clone();
        boolean boolean14 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
        java.util.Date date19 = fixedMillisecond16.getTime();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        java.util.Date date21 = day20.getEnd();
        int int22 = day20.getYear();
        java.util.Date date23 = day20.getStart();
        int int24 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        java.util.Date date29 = fixedMillisecond26.getTime();
        int int30 = day20.compareTo((java.lang.Object) fixedMillisecond26);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1L) + "'", long28 == (-1L));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(1900);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(8, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(13, serialDate11);
        boolean boolean14 = spreadsheetDate1.isOnOrAfter(serialDate13);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays(5, serialDate19);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, serialDate23);
        boolean boolean25 = spreadsheetDate1.isInRange(serialDate19, serialDate24);
        java.util.Date date26 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(1900);
        boolean boolean29 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate28);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate35);
        org.jfree.data.time.SerialDate serialDate37 = serialDate32.getEndOfCurrentMonth(serialDate35);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2, serialDate35);
        int int39 = spreadsheetDate1.compare(serialDate35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1919 + "'", int39 == 1919);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(5, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "May" + "'", str2.equals("May"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        java.util.List list5 = timeSeries1.getItems();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.String str7 = month6.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Object obj12 = timeSeries11.clone();
        try {
            timeSeries11.update((int) (byte) 1, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(obj12);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int3 = year1.compareTo((java.lang.Object) 3);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
//        int int5 = month4.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond6.getTime();
//        int int10 = month4.compareTo((java.lang.Object) fixedMillisecond6);
//        int int11 = month4.getYearValue();
//        org.jfree.data.time.Year year12 = month4.getYear();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560191649634L + "'", long8 == 1560191649634L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(year12);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) '#');
        long long15 = day12.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day12);
        java.lang.String str17 = day12.toString();
        int int18 = day12.getMonth();
        long long19 = day12.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 25568L + "'", long15 == 25568L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-December-1969" + "'", str17.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.String str10 = timeSeries8.getDescription();
        int int11 = timeSeries8.getItemCount();
        timeSeries8.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (double) '#');
        java.lang.String[] strArray22 = org.jfree.data.time.SerialDate.getMonths();
        int int23 = timeSeriesDataItem21.compareTo((java.lang.Object) strArray22);
        timeSeries8.add(timeSeriesDataItem21);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries8.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries28.fireSeriesChanged();
        timeSeries28.removeAgedItems((long) 2, false);
        java.lang.String str33 = timeSeries28.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
        int int41 = day39.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) 0L);
        int int44 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day39);
        java.lang.Number number45 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getMiddleMillisecond(calendar48);
        java.util.Date date50 = fixedMillisecond47.getTime();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (double) '#');
        timeSeries1.add(timeSeriesDataItem53, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar58 = null;
        long long59 = fixedMillisecond57.getMiddleMillisecond(calendar58);
        java.util.Date date60 = fixedMillisecond57.getTime();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day61.previous();
        long long63 = day61.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day61, (java.lang.Number) (-435));
        java.lang.Comparable comparable66 = timeSeries1.getKey();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries1.getDataItem(regularTimePeriod67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0f + "'", comparable9.equals(0.0f));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-1L) + "'", long49 == (-1L));
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-1L) + "'", long59 == (-1L));
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 25568L + "'", long63 == 25568L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + comparable66 + "' != '" + 0.0f + "'", comparable66.equals(0.0f));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        java.util.List list5 = timeSeries1.getItems();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.String str7 = month6.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year8);
        timeSeries1.clear();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate15.setDescription("");
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, serialDate15);
        java.lang.String str19 = serialDate18.toString();
        timeSeries1.setKey((java.lang.Comparable) serialDate18);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "9-March-1900" + "'", str19.equals("9-March-1900"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.String str10 = timeSeries8.getDescription();
        int int11 = timeSeries8.getItemCount();
        timeSeries8.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (double) '#');
        java.lang.String[] strArray22 = org.jfree.data.time.SerialDate.getMonths();
        int int23 = timeSeriesDataItem21.compareTo((java.lang.Object) strArray22);
        timeSeries8.add(timeSeriesDataItem21);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries8.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries28.fireSeriesChanged();
        timeSeries28.removeAgedItems((long) 2, false);
        java.lang.String str33 = timeSeries28.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
        int int41 = day39.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) 0L);
        int int44 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day39);
        java.lang.Number number45 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day39);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate51);
        org.jfree.data.time.SerialDate serialDate53 = serialDate48.getEndOfCurrentMonth(serialDate51);
        java.lang.String str54 = serialDate48.getDescription();
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addMonths(0, serialDate48);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(serialDate55);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day56, (-1.0d));
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0f + "'", comparable9.equals(0.0f));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNull(timeSeriesDataItem58);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        java.util.List list5 = timeSeries1.getItems();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.String str7 = month6.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Object obj12 = timeSeries11.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 2147483647);
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1560191578339L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = null;
        try {
            timeSeries11.delete(regularTimePeriod18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-435), 0, (-23668));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        int int7 = fixedMillisecond1.compareTo((java.lang.Object) 7);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        java.lang.String str11 = timeSeries9.getDescription();
        int int12 = timeSeries9.getItemCount();
        timeSeries9.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
        java.util.Date date19 = fixedMillisecond16.getTime();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, (double) '#');
        java.lang.String[] strArray23 = org.jfree.data.time.SerialDate.getMonths();
        int int24 = timeSeriesDataItem22.compareTo((java.lang.Object) strArray23);
        timeSeries9.add(timeSeriesDataItem22);
        java.lang.Object obj26 = timeSeriesDataItem22.clone();
        java.lang.Class<?> wildcardClass27 = timeSeriesDataItem22.getClass();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, (java.lang.Class) wildcardClass27);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        int int32 = year30.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (short) 10, year30);
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        try {
            timeSeries28.add((org.jfree.data.time.RegularTimePeriod) month35, (double) 100.0f, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0.0f + "'", comparable10.equals(0.0f));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(1900);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(7, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = serialDate1.getEndOfCurrentMonth(serialDate4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.next();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day7);
        long long10 = timeSeries9.getMaximumItemAge();
        timeSeries9.setRangeDescription("9-March-1900");
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("9-March-1900");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate6);
        java.lang.String str9 = serialDate3.getDescription();
        int int10 = spreadsheetDate1.compare(serialDate3);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        java.lang.String str14 = timeSeries12.getDescription();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) '#');
        int int25 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) day22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate29);
        timeSeries16.setKey((java.lang.Comparable) serialDate29);
        boolean boolean32 = spreadsheetDate1.isBefore(serialDate29);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable35 = timeSeries34.getKey();
        java.lang.String str36 = timeSeries34.getDescription();
        int int37 = timeSeries34.getItemCount();
        timeSeries34.setDescription("hi!");
        timeSeries34.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener41);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
        timeSeries34.removeChangeListener(seriesChangeListener43);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        java.lang.String str46 = month45.toString();
        long long47 = month45.getLastMillisecond();
        timeSeries34.delete((org.jfree.data.time.RegularTimePeriod) month45);
        boolean boolean49 = spreadsheetDate1.equals((java.lang.Object) timeSeries34);
        java.lang.String str50 = spreadsheetDate1.toString();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1919 + "'", int10 == 1919);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0f + "'", comparable13.equals(0.0f));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + 0.0f + "'", comparable35.equals(0.0f));
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "June 2019" + "'", str46.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1561964399999L + "'", long47 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "11-July-1905" + "'", str50.equals("11-July-1905"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        int int5 = month4.getMonth();
        org.jfree.data.time.Year year6 = month4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month4.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        timeSeries1.fireSeriesChanged();
        timeSeries1.setRangeDescription("9-March-1900");
        java.lang.String str10 = timeSeries1.getRangeDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int14 = year12.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (short) 10, year12);
        int int16 = year12.getYear();
        java.lang.Number number17 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year12);
        long long18 = year12.getSerialIndex();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-March-1900" + "'", str10.equals("9-March-1900"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection6 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.String str10 = timeSeries8.getDescription();
        int int11 = timeSeries8.getItemCount();
        timeSeries8.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (double) '#');
        java.lang.String[] strArray22 = org.jfree.data.time.SerialDate.getMonths();
        int int23 = timeSeriesDataItem21.compareTo((java.lang.Object) strArray22);
        timeSeries8.add(timeSeriesDataItem21);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries8.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries28.fireSeriesChanged();
        timeSeries28.removeAgedItems((long) 2, false);
        java.lang.String str33 = timeSeries28.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
        int int41 = day39.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) 0L);
        int int44 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day39);
        java.lang.Number number45 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day39);
        java.lang.Comparable comparable46 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0f + "'", comparable9.equals(0.0f));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 0.0f + "'", comparable46.equals(0.0f));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("September");
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate3.setDescription("");
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(9, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getNearestDayOfWeek(6);
        try {
            org.jfree.data.time.SerialDate serialDate11 = serialDate9.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.util.Date date6 = day5.getEnd();
        int int7 = day5.getYear();
        java.util.Date date8 = day5.getStart();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable11 = timeSeries10.getKey();
        java.lang.String str12 = timeSeries10.getDescription();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection15 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        boolean boolean16 = day5.equals((java.lang.Object) collection15);
        int int17 = day5.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 0.0f + "'", comparable11.equals(0.0f));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1572591599999L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeriesDataItem2.getPeriod();
        java.lang.Object obj4 = timeSeriesDataItem2.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (-435), false);
        java.lang.String str26 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) '#');
        timeSeries1.add(timeSeriesDataItem23, true);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener26);
        timeSeries1.setRangeDescription("Last");
        java.lang.String str30 = timeSeries1.getDescription();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getSerialIndex();
        int int4 = month0.getMonth();
        java.util.Date date5 = month0.getStart();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        java.lang.String str6 = timeSeries4.getDescription();
        int int7 = timeSeries4.getItemCount();
        timeSeries4.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond11.getTime();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (double) '#');
        long long18 = day15.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day15);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) 1560191619921L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0f + "'", comparable5.equals(0.0f));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 25568L + "'", long18 == 25568L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (-435), false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.previous();
        int int33 = day31.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day31.previous();
        int int35 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day31);
        long long36 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2147483647);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2147483647L + "'", long2 == 2147483647L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2147483647L + "'", long3 == 2147483647L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        long long3 = year0.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        long long5 = year0.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int3 = year1.compareTo((java.lang.Object) 3);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
//        int int5 = month4.getMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond6.getTime();
//        int int10 = month4.compareTo((java.lang.Object) fixedMillisecond6);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (double) 1);
//        java.lang.Object obj13 = null;
//        int int14 = timeSeriesDataItem12.compareTo(obj13);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560191651305L + "'", long8 == 1560191651305L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.lang.Number number12 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day11);
        java.lang.String str13 = day11.toString();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date5);
        int int17 = month16.getYearValue();
        org.jfree.data.time.Year year18 = month16.getYear();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(year18);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate4.getDescription();
        int int11 = spreadsheetDate1.compare(serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate13 = serialDate4.getPreviousDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1919 + "'", int11 == 1919);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        long long8 = year5.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = serialDate7.getEndOfCurrentMonth(serialDate10);
        java.lang.String str13 = serialDate7.getDescription();
        int int14 = spreadsheetDate5.compare(serialDate7);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable17 = timeSeries16.getKey();
        java.lang.String str18 = timeSeries16.getDescription();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (double) '#');
        int int29 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries16.addAndOrUpdate(timeSeries20);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate33);
        timeSeries20.setKey((java.lang.Comparable) serialDate33);
        boolean boolean36 = spreadsheetDate5.isBefore(serialDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int39 = spreadsheetDate38.getYYYY();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate45);
        org.jfree.data.time.SerialDate serialDate47 = serialDate42.getEndOfCurrentMonth(serialDate45);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(serialDate47);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addDays(13, serialDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int52 = spreadsheetDate51.getMonth();
        boolean boolean54 = spreadsheetDate38.isInRange(serialDate47, (org.jfree.data.time.SerialDate) spreadsheetDate51, 12);
        boolean boolean55 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean57 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1919 + "'", int14 == 1919);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 0.0f + "'", comparable17.equals(0.0f));
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1905 + "'", int39 == 1905);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 7 + "'", int52 == 7);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.String str10 = timeSeries8.getDescription();
        int int11 = timeSeries8.getItemCount();
        timeSeries8.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (double) '#');
        java.lang.String[] strArray22 = org.jfree.data.time.SerialDate.getMonths();
        int int23 = timeSeriesDataItem21.compareTo((java.lang.Object) strArray22);
        timeSeries8.add(timeSeriesDataItem21);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries8.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries28.fireSeriesChanged();
        timeSeries28.removeAgedItems((long) 2, false);
        java.lang.String str33 = timeSeries28.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
        int int41 = day39.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) 0L);
        int int44 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day39);
        java.lang.Number number45 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getMiddleMillisecond(calendar48);
        java.util.Date date50 = fixedMillisecond47.getTime();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (double) '#');
        timeSeries1.add(timeSeriesDataItem53, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar58 = null;
        long long59 = fixedMillisecond57.getMiddleMillisecond(calendar58);
        java.util.Date date60 = fixedMillisecond57.getTime();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day61.previous();
        long long63 = day61.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day61, (java.lang.Number) (-435));
        java.lang.Comparable comparable66 = timeSeries1.getKey();
        timeSeries1.removeAgedItems(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries1.getNextTimePeriod();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0f + "'", comparable9.equals(0.0f));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-1L) + "'", long49 == (-1L));
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-1L) + "'", long59 == (-1L));
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 25568L + "'", long63 == 25568L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + comparable66 + "' != '" + 0.0f + "'", comparable66.equals(0.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod69);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) '#');
        java.lang.Number number8 = timeSeriesDataItem7.getValue();
        java.lang.Object obj9 = null;
        boolean boolean10 = timeSeriesDataItem7.equals(obj9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 35.0d + "'", number8.equals(35.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1, 1905, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        long long3 = year0.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        long long5 = year0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        java.lang.String str9 = timeSeries7.getDescription();
        int int10 = timeSeries7.getItemCount();
        timeSeries7.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (double) '#');
        java.lang.String[] strArray21 = org.jfree.data.time.SerialDate.getMonths();
        int int22 = timeSeriesDataItem20.compareTo((java.lang.Object) strArray21);
        timeSeries7.add(timeSeriesDataItem20);
        java.lang.Object obj24 = timeSeriesDataItem20.clone();
        boolean boolean25 = year0.equals((java.lang.Object) timeSeriesDataItem20);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = year0.getFirstMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 0.0f + "'", comparable8.equals(0.0f));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection6 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.removeChangeListener(seriesChangeListener7);
        timeSeries5.setDomainDescription("October 2019");
        timeSeries5.setRangeDescription("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        long long3 = year0.getMiddleMillisecond();
        long long4 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        java.util.Date date6 = fixedMillisecond1.getEnd();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.toSerial();
        int int5 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(0, serialDate12);
        boolean boolean14 = spreadsheetDate1.equals((java.lang.Object) serialDate12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean17 = month4.equals((java.lang.Object) int16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month4.next();
        long long19 = month4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month4.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int24 = year22.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, year22);
        java.util.Date date26 = month25.getEnd();
        boolean boolean27 = month4.equals((java.lang.Object) date26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date26);
        java.util.Date date29 = fixedMillisecond28.getEnd();
        java.util.Calendar calendar30 = null;
        fixedMillisecond28.peg(calendar30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1572591599999L + "'", long19 == 1572591599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        int int5 = year1.getYear();
        long long6 = year1.getLastMillisecond();
        java.lang.String str7 = year1.toString();
        long long8 = year1.getMiddleMillisecond();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(4);
        boolean boolean11 = year1.equals((java.lang.Object) serialDate10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean17 = month4.equals((java.lang.Object) int16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month4.next();
        long long19 = month4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month4.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod20, (double) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod20);
        try {
            timeSeries23.update(4, (java.lang.Number) 1560191609804L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1572591599999L + "'", long19 == 1572591599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond3.getTime();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) '#');
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries1.addChangeListener(seriesChangeListener11);
        int int13 = timeSeries1.getItemCount();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int16 = year14.compareTo((java.lang.Object) 3);
        int int18 = year14.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        boolean boolean20 = year14.equals((java.lang.Object) day19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year14, (double) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year14.previous();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries18.fireSeriesChanged();
        timeSeries18.removeAgedItems((long) 2, false);
        java.lang.String str23 = timeSeries18.getRangeDescription();
        timeSeries18.setNotify(false);
        java.util.List list26 = timeSeries18.getItems();
        timeSeries18.setKey((java.lang.Comparable) 9);
        timeSeries18.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond32.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
        int int38 = day36.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 8);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (short) 10, year42);
        int int47 = month45.compareTo((java.lang.Object) 13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) 1969);
        timeSeries1.add(timeSeriesDataItem49, false);
        timeSeries1.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries1.createCopy(0, 0);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener58 = null;
        timeSeries1.removeChangeListener(seriesChangeListener58);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(timeSeries57);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean17 = month4.equals((java.lang.Object) int16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month4.next();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable21 = timeSeries20.getKey();
        java.lang.String str22 = timeSeries20.getDescription();
        int int23 = timeSeries20.getItemCount();
        timeSeries20.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (double) '#');
        long long34 = day31.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) day31);
        boolean boolean36 = month4.equals((java.lang.Object) day31);
        java.lang.Class class37 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond45.getMiddleMillisecond(calendar46);
        java.util.Date date48 = fixedMillisecond45.getTime();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date48, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date42, timeZone49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date42);
        int int53 = month4.compareTo((java.lang.Object) date42);
        java.util.Calendar calendar54 = null;
        try {
            long long55 = month4.getLastMillisecond(calendar54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0.0f + "'", comparable21.equals(0.0f));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 25568L + "'", long34 == 25568L);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-1L) + "'", long47 == (-1L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.util.Date date6 = day5.getEnd();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.String str10 = timeSeries8.getDescription();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection13 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        int int14 = day5.compareTo((java.lang.Object) collection13);
        org.jfree.data.time.SerialDate serialDate15 = day5.getSerialDate();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0f + "'", comparable9.equals(0.0f));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries18.fireSeriesChanged();
        timeSeries18.removeAgedItems((long) 2, false);
        java.lang.String str23 = timeSeries18.getRangeDescription();
        timeSeries18.setNotify(false);
        java.util.List list26 = timeSeries18.getItems();
        timeSeries18.setKey((java.lang.Comparable) 9);
        timeSeries18.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond32.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
        int int38 = day36.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 8);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (short) 10, year42);
        int int47 = month45.compareTo((java.lang.Object) 13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) 1969);
        timeSeries1.add(timeSeriesDataItem49, false);
        timeSeries1.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries1.createCopy(0, 0);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        int int61 = year59.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month((int) (short) 10, year59);
        int int63 = year59.getYear();
        int int64 = year59.getYear();
        java.lang.Number number65 = timeSeries57.getValue((org.jfree.data.time.RegularTimePeriod) year59);
        long long66 = year59.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2019 + "'", int63 == 2019);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2019 + "'", int64 == 2019);
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 8 + "'", number65.equals(8));
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1577865599999L + "'", long66 == 1577865599999L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection6 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate6);
        java.lang.String str9 = serialDate3.getDescription();
        int int10 = spreadsheetDate1.compare(serialDate3);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        java.lang.String str14 = timeSeries12.getDescription();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) '#');
        int int25 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) day22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate29);
        timeSeries16.setKey((java.lang.Comparable) serialDate29);
        boolean boolean32 = spreadsheetDate1.isBefore(serialDate29);
        int int33 = spreadsheetDate1.getDayOfMonth();
        java.util.Date date34 = spreadsheetDate1.toDate();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable37 = timeSeries36.getKey();
        java.lang.String str38 = timeSeries36.getDescription();
        int int39 = timeSeries36.getItemCount();
        timeSeries36.setDescription("hi!");
        java.lang.Class class42 = timeSeries36.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond44.getMiddleMillisecond(calendar45);
        java.util.Date date47 = fixedMillisecond44.getTime();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        java.util.Date date49 = day48.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(date49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond52.getMiddleMillisecond(calendar53);
        java.util.Date date55 = fixedMillisecond52.getTime();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date55);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date55, timeZone57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date49, timeZone57);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date34, timeZone57);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1919 + "'", int10 == 1919);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0f + "'", comparable13.equals(0.0f));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 0.0f + "'", comparable37.equals(0.0f));
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-1L) + "'", long46 == (-1L));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-1L) + "'", long54 == (-1L));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        java.util.List list9 = timeSeries1.getItems();
        timeSeries1.setKey((java.lang.Comparable) 9);
        timeSeries1.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        int int21 = day19.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        int int29 = fixedMillisecond25.compareTo((java.lang.Object) true);
        java.lang.Object obj30 = null;
        boolean boolean31 = fixedMillisecond25.equals(obj30);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (short) 1);
        java.lang.Object obj34 = timeSeries1.clone();
        timeSeries1.removeAgedItems((long) (short) 0, true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
        int int7 = fixedMillisecond3.compareTo((java.lang.Object) true);
        java.util.Date date8 = fixedMillisecond3.getEnd();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond3.getLastMillisecond(calendar9);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond3.getFirstMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond3.getTime();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date13);
        int int16 = spreadsheetDate1.compare(serialDate15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate15);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-23668) + "'", int16 == (-23668));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        timeSeries1.setNotify(true);
        timeSeries1.clear();
        java.util.List list20 = timeSeries1.getItems();
        int int21 = timeSeries1.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long24 = fixedMillisecond23.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        java.util.Date date31 = fixedMillisecond28.getTime();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (double) '#');
        int int35 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) day32);
        int int36 = fixedMillisecond23.compareTo((java.lang.Object) timeSeries26);
        java.util.Collection collection37 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(collection37);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        int int4 = year0.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean6 = year0.equals((java.lang.Object) day5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = serialDate10.getEndOfCurrentMonth(serialDate13);
        java.lang.String str16 = serialDate10.getDescription();
        int int17 = spreadsheetDate8.compare(serialDate10);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable20 = timeSeries19.getKey();
        java.lang.String str21 = timeSeries19.getDescription();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond25.getTime();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (double) '#');
        int int32 = timeSeries23.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries19.addAndOrUpdate(timeSeries23);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate36);
        timeSeries23.setKey((java.lang.Comparable) serialDate36);
        boolean boolean39 = spreadsheetDate8.isBefore(serialDate36);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable42 = timeSeries41.getKey();
        java.lang.String str43 = timeSeries41.getDescription();
        int int44 = timeSeries41.getItemCount();
        timeSeries41.setDescription("hi!");
        timeSeries41.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timeSeries41.addPropertyChangeListener(propertyChangeListener48);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener50 = null;
        timeSeries41.removeChangeListener(seriesChangeListener50);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        java.lang.String str53 = month52.toString();
        long long54 = month52.getLastMillisecond();
        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) month52);
        boolean boolean56 = spreadsheetDate8.equals((java.lang.Object) timeSeries41);
        boolean boolean57 = day5.equals((java.lang.Object) spreadsheetDate8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1919 + "'", int17 == 1919);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 0.0f + "'", comparable20.equals(0.0f));
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + comparable42 + "' != '" + 0.0f + "'", comparable42.equals(0.0f));
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "June 2019" + "'", str53.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1561964399999L + "'", long54 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection6 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.removeChangeListener(seriesChangeListener7);
        timeSeries5.setDomainDescription("October 2019");
        long long11 = timeSeries5.getMaximumItemAge();
        timeSeries5.setDomainDescription("11-July-1905");
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int16 = year14.compareTo((java.lang.Object) 3);
        int int18 = year14.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        boolean boolean20 = year14.equals((java.lang.Object) day19);
        try {
            timeSeries5.update((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 3);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        timeSeries1.setNotify(true);
        timeSeries1.clear();
        long long20 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(5, 2147483647, (-435));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        long long3 = year0.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long8 = fixedMillisecond7.getSerialIndex();
        int int9 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        java.lang.Class class10 = timeSeries5.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries5.addChangeListener(seriesChangeListener16);
        java.util.List list18 = timeSeries5.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 2147483647);
        java.util.Date date21 = fixedMillisecond20.getEnd();
        try {
            timeSeries5.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems(false);
        timeSeries1.setMaximumItemAge((long) 1919);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable20 = timeSeries19.getKey();
        java.lang.String str21 = timeSeries19.getDescription();
        int int22 = timeSeries19.getItemCount();
        timeSeries19.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        java.util.Date date29 = fixedMillisecond26.getTime();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) '#');
        java.lang.String[] strArray33 = org.jfree.data.time.SerialDate.getMonths();
        int int34 = timeSeriesDataItem32.compareTo((java.lang.Object) strArray33);
        timeSeries19.add(timeSeriesDataItem32);
        java.lang.Object obj36 = timeSeriesDataItem32.clone();
        java.lang.Class<?> wildcardClass37 = timeSeriesDataItem32.getClass();
        java.lang.Number number38 = timeSeriesDataItem32.getValue();
        timeSeries1.add(timeSeriesDataItem32);
        boolean boolean41 = timeSeries1.equals((java.lang.Object) "Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 0.0f + "'", comparable20.equals(0.0f));
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1L) + "'", long28 == (-1L));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 35.0d + "'", number38.equals(35.0d));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        int int5 = year1.getYear();
        long long6 = year1.getLastMillisecond();
        java.lang.String str7 = year1.toString();
        java.lang.String str8 = year1.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.Year year6 = month4.getYear();
        long long7 = month4.getLastMillisecond();
        java.lang.String str8 = month4.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1572591599999L + "'", long7 == 1572591599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 2019" + "'", str8.equals("October 2019"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond1.equals(obj6);
        java.lang.String str8 = fixedMillisecond1.toString();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        java.lang.String str14 = timeSeries12.getDescription();
        int int15 = timeSeries12.getItemCount();
        timeSeries12.setDescription("hi!");
        timeSeries12.fireSeriesChanged();
        timeSeries12.setRangeDescription("9-March-1900");
        java.lang.Class class21 = timeSeries12.getTimePeriodClass();
        timeSeries12.setDomainDescription("");
        int int24 = fixedMillisecond1.compareTo((java.lang.Object) timeSeries12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str8.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0f + "'", comparable13.equals(0.0f));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable7 = timeSeries6.getKey();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int11 = year9.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 10, year9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month12, (double) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (double) '#');
        timeSeriesDataItem17.setValue((java.lang.Number) 2147483647L);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 0.0f + "'", comparable7.equals(0.0f));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        java.util.List list5 = timeSeries1.getItems();
        timeSeries1.removeAgedItems(false);
        java.lang.Class class8 = timeSeries1.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) class8);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        java.util.List list5 = timeSeries1.getItems();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.String str7 = month6.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year8.previous();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        int int17 = year15.compareTo((java.lang.Object) 3);
        long long18 = year15.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass19 = year15.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year15);
        int int21 = month13.compareTo((java.lang.Object) year15);
        org.jfree.data.time.Year year22 = month13.getYear();
        int int23 = year8.compareTo((java.lang.Object) year22);
        java.lang.String str24 = year8.toString();
        java.lang.String str25 = year8.toString();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1562097599999L + "'", long18 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.util.Date date6 = day5.getEnd();
        long long7 = day5.getSerialIndex();
        java.lang.String str8 = day5.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-1969" + "'", str8.equals("31-December-1969"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate4.getDescription();
        int int11 = spreadsheetDate1.compare(serialDate4);
        spreadsheetDate1.setDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) '#');
        int int24 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
        boolean boolean26 = day21.equals((java.lang.Object) 7);
        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
        boolean boolean28 = spreadsheetDate1.isAfter(serialDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int31 = spreadsheetDate30.getYYYY();
        boolean boolean32 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int35 = spreadsheetDate34.getMonth();
        int int36 = spreadsheetDate34.getDayOfWeek();
        java.lang.String str37 = spreadsheetDate34.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42, timeZone43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date42);
        boolean boolean46 = spreadsheetDate34.isBefore(serialDate45);
        boolean boolean47 = spreadsheetDate30.isAfter(serialDate45);
        try {
            org.jfree.data.time.SerialDate serialDate49 = spreadsheetDate30.getFollowingDayOfWeek(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1919 + "'", int11 == 1919);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1905 + "'", int31 == 1905);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 7 + "'", int35 == 7);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "11-July-1905" + "'", str37.equals("11-July-1905"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date5);
        long long18 = year17.getFirstMillisecond();
        long long19 = year17.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31507200000L) + "'", long18 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("May");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems((long) 5, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        int int17 = fixedMillisecond13.compareTo((java.lang.Object) true);
        java.util.Date date18 = fixedMillisecond13.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long22 = fixedMillisecond21.getSerialIndex();
        boolean boolean23 = fixedMillisecond13.equals((java.lang.Object) fixedMillisecond21);
        long long24 = fixedMillisecond21.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        java.lang.String str5 = timeSeries3.getDescription();
        int int6 = timeSeries3.getItemCount();
        timeSeries3.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable11 = timeSeries10.getKey();
        java.lang.String str12 = timeSeries10.getDescription();
        int int13 = timeSeries10.getItemCount();
        timeSeries10.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) '#');
        java.lang.String[] strArray24 = org.jfree.data.time.SerialDate.getMonths();
        int int25 = timeSeriesDataItem23.compareTo((java.lang.Object) strArray24);
        timeSeries10.add(timeSeriesDataItem23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries10.addChangeListener(seriesChangeListener27);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries30.fireSeriesChanged();
        timeSeries30.removeAgedItems((long) 2, false);
        java.lang.String str35 = timeSeries30.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
        java.util.Date date40 = fixedMillisecond37.getTime();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
        int int43 = day41.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day41, (java.lang.Number) 0L);
        int int46 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day41);
        java.lang.Number number47 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries1.addAndOrUpdate(timeSeries3);
        java.lang.Comparable comparable49 = timeSeries1.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener50 = null;
        timeSeries1.addChangeListener(seriesChangeListener50);
        try {
            java.lang.Number number53 = timeSeries1.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 0.0f + "'", comparable4.equals(0.0f));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 0.0f + "'", comparable11.equals(0.0f));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Value" + "'", str35.equals("Value"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-1L) + "'", long39 == (-1L));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + comparable49 + "' != '" + 0.0f + "'", comparable49.equals(0.0f));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, (-435), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        timeSeries1.fireSeriesChanged();
        timeSeries1.setRangeDescription("9-March-1900");
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries1.createCopy(5, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        long long8 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("11-July-1905");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(13, serialDate11);
        boolean boolean14 = spreadsheetDate1.isOnOrAfter(serialDate13);
        java.lang.String str15 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate16 = null;
        try {
            boolean boolean17 = spreadsheetDate1.isAfter(serialDate16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        java.util.Date date6 = fixedMillisecond1.getEnd();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate18);
        timeSeries5.setKey((java.lang.Comparable) serialDate18);
        org.jfree.data.time.SerialDate serialDate22 = serialDate18.getPreviousDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable25 = timeSeries24.getKey();
        java.lang.String str26 = timeSeries24.getDescription();
        int int27 = timeSeries24.getItemCount();
        timeSeries24.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getMiddleMillisecond(calendar32);
        java.util.Date date34 = fixedMillisecond31.getTime();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (double) '#');
        java.lang.String[] strArray38 = org.jfree.data.time.SerialDate.getMonths();
        int int39 = timeSeriesDataItem37.compareTo((java.lang.Object) strArray38);
        timeSeries24.add(timeSeriesDataItem37);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries24.addChangeListener(seriesChangeListener41);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries44.fireSeriesChanged();
        timeSeries44.removeAgedItems((long) 2, false);
        java.lang.String str49 = timeSeries44.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond51.getMiddleMillisecond(calendar52);
        java.util.Date date54 = fixedMillisecond51.getTime();
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.previous();
        int int57 = day55.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) 0L);
        int int60 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) day55);
        java.lang.Class<?> wildcardClass61 = day55.getClass();
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate18, (java.lang.Class) wildcardClass61);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 0.0f + "'", comparable25.equals(0.0f));
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Value" + "'", str49.equals("Value"));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-1L) + "'", long53 == (-1L));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 12 + "'", int57 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(wildcardClass61);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        java.util.List list5 = timeSeries1.getItems();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.String str7 = month6.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Object obj12 = timeSeries11.clone();
        java.lang.Class class13 = timeSeries11.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 9, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, serialDate5);
        boolean boolean8 = spreadsheetDate1.isBefore(serialDate5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond3.getTime();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) '#');
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day7);
        boolean boolean12 = day7.equals((java.lang.Object) 7);
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        java.util.Date date4 = spreadsheetDate1.toDate();
        java.lang.String str5 = spreadsheetDate1.getDescription();
        int int6 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int5 = spreadsheetDate4.getYYYY();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = serialDate8.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(13, serialDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean20 = spreadsheetDate4.isInRange(serialDate13, (org.jfree.data.time.SerialDate) spreadsheetDate17, 12);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate4);
        int int23 = spreadsheetDate4.getYYYY();
        int int24 = spreadsheetDate4.getYYYY();
        boolean boolean25 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1905 + "'", int5 == 1905);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1905 + "'", int23 == 1905);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1905 + "'", int24 == 1905);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        int int7 = day6.getMonth();
        int int8 = day6.getMonth();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection6 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
        java.lang.String[] strArray16 = org.jfree.data.time.SerialDate.getMonths();
        int int17 = timeSeriesDataItem15.compareTo((java.lang.Object) strArray16);
        timeSeries1.add(timeSeriesDataItem15);
        java.lang.Object obj19 = timeSeriesDataItem15.clone();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day5.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(9999);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-460), 100, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) '#');
        timeSeries1.add(timeSeriesDataItem23, true);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener26);
        timeSeries1.setRangeDescription("Last");
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getMiddleMillisecond(calendar32);
        java.util.Date date34 = fixedMillisecond31.getTime();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34, timeZone35);
        int int37 = day36.getMonth();
        int int38 = day36.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day36.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, 0.0d);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 12 + "'", int37 == 12);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond4.getTime();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (double) '#');
        long long11 = day8.getSerialIndex();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries1.addChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 25568L + "'", long11 == 25568L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond7);
        java.lang.String str9 = seriesChangeEvent8.toString();
        java.lang.Object obj10 = seriesChangeEvent8.getSource();
        java.lang.String str11 = seriesChangeEvent8.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Thu Oct 31 23:59:59 PDT 2019]" + "'", str9.equals("org.jfree.data.general.SeriesChangeEvent[source=Thu Oct 31 23:59:59 PDT 2019]"));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Thu Oct 31 23:59:59 PDT 2019]" + "'", str11.equals("org.jfree.data.general.SeriesChangeEvent[source=Thu Oct 31 23:59:59 PDT 2019]"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(10, (int) (byte) 0, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, (int) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(13, serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int15 = spreadsheetDate14.getMonth();
        boolean boolean17 = spreadsheetDate1.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14, 12);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (double) '#');
        int int29 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) day26);
        boolean boolean31 = day26.equals((java.lang.Object) 7);
        int int32 = day26.getYear();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate38);
        org.jfree.data.time.SerialDate serialDate40 = serialDate35.getEndOfCurrentMonth(serialDate38);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addDays(13, serialDate40);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable47 = timeSeries46.getKey();
        java.lang.String str48 = timeSeries46.getDescription();
        int int49 = timeSeries46.getItemCount();
        timeSeries46.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar54 = null;
        long long55 = fixedMillisecond53.getMiddleMillisecond(calendar54);
        java.util.Date date56 = fixedMillisecond53.getTime();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day57, (double) '#');
        java.lang.String[] strArray60 = org.jfree.data.time.SerialDate.getMonths();
        int int61 = timeSeriesDataItem59.compareTo((java.lang.Object) strArray60);
        timeSeries46.add(timeSeriesDataItem59);
        java.lang.Object obj63 = timeSeriesDataItem59.clone();
        java.lang.Class<?> wildcardClass64 = timeSeriesDataItem59.getClass();
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate40, "Value", "", (java.lang.Class) wildcardClass64);
        boolean boolean66 = day26.equals((java.lang.Object) wildcardClass64);
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day18, (java.lang.Class) wildcardClass64);
        org.jfree.data.time.TimeSeries timeSeries68 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries69 = timeSeries67.addAndOrUpdate(timeSeries68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1969 + "'", int32 == 1969);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + comparable47 + "' != '" + 0.0f + "'", comparable47.equals(0.0f));
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-1L) + "'", long55 == (-1L));
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(strArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(obj63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate4.getDescription();
        int int11 = spreadsheetDate1.compare(serialDate4);
        spreadsheetDate1.setDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) '#');
        int int24 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
        boolean boolean26 = day21.equals((java.lang.Object) 7);
        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
        boolean boolean28 = spreadsheetDate1.isAfter(serialDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int31 = spreadsheetDate30.getYYYY();
        boolean boolean32 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int35 = spreadsheetDate34.getMonth();
        int int36 = spreadsheetDate34.getDayOfWeek();
        java.lang.String str37 = spreadsheetDate34.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42, timeZone43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date42);
        boolean boolean46 = spreadsheetDate34.isBefore(serialDate45);
        boolean boolean47 = spreadsheetDate30.isAfter(serialDate45);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate30);
        java.util.Date date49 = day48.getStart();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable52 = timeSeries51.getKey();
        java.lang.String str53 = timeSeries51.getDescription();
        int int54 = timeSeries51.getItemCount();
        timeSeries51.setDescription("hi!");
        java.lang.Class class57 = timeSeries51.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar60 = null;
        long long61 = fixedMillisecond59.getMiddleMillisecond(calendar60);
        java.util.Date date62 = fixedMillisecond59.getTime();
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date62, timeZone63);
        java.lang.Class class65 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar68 = null;
        long long69 = fixedMillisecond67.getMiddleMillisecond(calendar68);
        java.util.Date date70 = fixedMillisecond67.getTime();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar74 = null;
        long long75 = fixedMillisecond73.getMiddleMillisecond(calendar74);
        java.util.Date date76 = fixedMillisecond73.getTime();
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date76, timeZone77);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date70, timeZone77);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date62, timeZone77);
        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year(date49, timeZone77);
        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond(date49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1919 + "'", int11 == 1919);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1905 + "'", int31 == 1905);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 7 + "'", int35 == 7);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "11-July-1905" + "'", str37.equals("11-July-1905"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + 0.0f + "'", comparable52.equals(0.0f));
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(class57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-1L) + "'", long61 == (-1L));
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-1L) + "'", long69 == (-1L));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-1L) + "'", long75 == (-1L));
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
        java.lang.Object obj3 = timeSeriesDataItem2.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        int int9 = fixedMillisecond5.compareTo((java.lang.Object) true);
        int int11 = fixedMillisecond5.compareTo((java.lang.Object) 7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable14 = timeSeries13.getKey();
        java.lang.String str15 = timeSeries13.getDescription();
        int int16 = timeSeries13.getItemCount();
        timeSeries13.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) '#');
        java.lang.String[] strArray27 = org.jfree.data.time.SerialDate.getMonths();
        int int28 = timeSeriesDataItem26.compareTo((java.lang.Object) strArray27);
        timeSeries13.add(timeSeriesDataItem26);
        java.lang.Object obj30 = timeSeriesDataItem26.clone();
        java.lang.Class<?> wildcardClass31 = timeSeriesDataItem26.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, (java.lang.Class) wildcardClass31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, (java.lang.Class) wildcardClass31);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 0.0f + "'", comparable14.equals(0.0f));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
//        int int3 = year1.compareTo((java.lang.Object) 3);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
//        java.util.Date date5 = month4.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
//        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
//        boolean boolean17 = month4.equals((java.lang.Object) int16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month4.next();
//        long long19 = month4.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month4.next();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        int int24 = year22.compareTo((java.lang.Object) 3);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, year22);
//        java.util.Date date26 = month25.getEnd();
//        boolean boolean27 = month4.equals((java.lang.Object) date26);
//        java.util.Date date28 = month4.getEnd();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond31.getMiddleMillisecond(calendar32);
//        java.util.Date date34 = fixedMillisecond31.getTime();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34, timeZone35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date34);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
//        java.lang.Comparable comparable40 = timeSeries39.getKey();
//        java.lang.String str41 = timeSeries39.getDescription();
//        int int42 = timeSeries39.getItemCount();
//        timeSeries39.setDescription("hi!");
//        java.lang.Class class45 = timeSeries39.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond47.getMiddleMillisecond(calendar48);
//        java.util.Date date50 = fixedMillisecond47.getTime();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50, timeZone51);
//        java.lang.Class class53 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar56 = null;
//        long long57 = fixedMillisecond55.getMiddleMillisecond(calendar56);
//        java.util.Date date58 = fixedMillisecond55.getTime();
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date58);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((-1L));
//        java.util.Calendar calendar62 = null;
//        long long63 = fixedMillisecond61.getMiddleMillisecond(calendar62);
//        java.util.Date date64 = fixedMillisecond61.getTime();
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date64, timeZone65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date58, timeZone65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date50, timeZone65);
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date34, timeZone65);
//        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date28, timeZone65);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar72 = null;
//        long long73 = fixedMillisecond71.getMiddleMillisecond(calendar72);
//        java.util.Date date74 = fixedMillisecond71.getTime();
//        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year();
//        int int77 = year75.compareTo((java.lang.Object) 3);
//        long long78 = year75.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass79 = year75.getClass();
//        java.util.Date date80 = null;
//        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass79, date80, timeZone81);
//        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date74, timeZone81);
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date28, timeZone81);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1572591599999L + "'", long19 == 1572591599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + comparable40 + "' != '" + 0.0f + "'", comparable40.equals(0.0f));
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-1L) + "'", long49 == (-1L));
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-1L) + "'", long57 == (-1L));
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-1L) + "'", long63 == (-1L));
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560191660314L + "'", long73 == 1560191660314L);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1562097599999L + "'", long78 == 1562097599999L);
//        org.junit.Assert.assertNotNull(wildcardClass79);
//        org.junit.Assert.assertNotNull(timeZone81);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        java.util.List list5 = timeSeries1.getItems();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.String str7 = month6.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Object obj12 = timeSeries11.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 2147483647);
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1560191578339L);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries11.removePropertyChangeListener(propertyChangeListener18);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date5);
        long long16 = fixedMillisecond15.getSerialIndex();
        java.util.Calendar calendar17 = null;
        fixedMillisecond15.peg(calendar17);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond15.getMiddleMillisecond(calendar19);
        java.util.Calendar calendar21 = null;
        fixedMillisecond15.peg(calendar21);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.Year year6 = month4.getYear();
        int int7 = month4.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month4.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond3.getTime();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) '#');
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day7);
        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.previous();
        int int13 = day7.getYear();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day7.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        int int7 = day6.getMonth();
        long long8 = day6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) (-1L));
        long long4 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate4.getDescription();
        int int11 = spreadsheetDate1.compare(serialDate4);
        spreadsheetDate1.setDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) '#');
        int int24 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
        boolean boolean26 = day21.equals((java.lang.Object) 7);
        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
        boolean boolean28 = spreadsheetDate1.isAfter(serialDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate35);
        org.jfree.data.time.SerialDate serialDate37 = serialDate32.getEndOfCurrentMonth(serialDate35);
        boolean boolean38 = spreadsheetDate30.isOnOrAfter(serialDate32);
        boolean boolean39 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
        int int45 = fixedMillisecond41.compareTo((java.lang.Object) true);
        long long46 = fixedMillisecond41.getSerialIndex();
        long long47 = fixedMillisecond41.getMiddleMillisecond();
        java.util.Date date48 = fixedMillisecond41.getTime();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond52.getMiddleMillisecond(calendar53);
        java.util.Date date55 = fixedMillisecond52.getTime();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day56, (double) '#');
        int int59 = timeSeries50.getIndex((org.jfree.data.time.RegularTimePeriod) day56);
        org.jfree.data.time.SerialDate serialDate60 = day56.getSerialDate();
        boolean boolean61 = fixedMillisecond41.equals((java.lang.Object) serialDate60);
        boolean boolean62 = spreadsheetDate1.isOnOrAfter(serialDate60);
        int int63 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        int int66 = year64.compareTo((java.lang.Object) 3);
        long long67 = year64.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass68 = year64.getClass();
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate73);
        org.jfree.data.time.SerialDate serialDate75 = serialDate70.getEndOfCurrentMonth(serialDate73);
        boolean boolean76 = year64.equals((java.lang.Object) serialDate73);
        boolean boolean77 = spreadsheetDate1.isOn(serialDate73);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1919 + "'", int11 == 1919);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1L) + "'", long43 == (-1L));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-1L) + "'", long46 == (-1L));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-1L) + "'", long47 == (-1L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-1L) + "'", long54 == (-1L));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 3 + "'", int63 == 3);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1562097599999L + "'", long67 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2147483647);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2147483647L + "'", long2 == 2147483647L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable6 = timeSeries5.getKey();
        java.lang.String str7 = timeSeries5.getDescription();
        int int8 = timeSeries5.getItemCount();
        timeSeries5.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        java.lang.String str14 = timeSeries12.getDescription();
        int int15 = timeSeries12.getItemCount();
        timeSeries12.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) '#');
        java.lang.String[] strArray26 = org.jfree.data.time.SerialDate.getMonths();
        int int27 = timeSeriesDataItem25.compareTo((java.lang.Object) strArray26);
        timeSeries12.add(timeSeriesDataItem25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries12.addChangeListener(seriesChangeListener29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries32.fireSeriesChanged();
        timeSeries32.removeAgedItems((long) 2, false);
        java.lang.String str37 = timeSeries32.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.previous();
        int int45 = day43.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 0L);
        int int48 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) day43);
        java.lang.Number number49 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day43);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries3.addAndOrUpdate(timeSeries5);
        boolean boolean51 = spreadsheetDate1.equals((java.lang.Object) timeSeries5);
        int int52 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int55 = spreadsheetDate54.getMonth();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate60);
        org.jfree.data.time.SerialDate serialDate62 = serialDate57.getEndOfCurrentMonth(serialDate60);
        java.lang.String str63 = serialDate57.getDescription();
        int int64 = spreadsheetDate54.compare(serialDate57);
        spreadsheetDate54.setDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar71 = null;
        long long72 = fixedMillisecond70.getMiddleMillisecond(calendar71);
        java.util.Date date73 = fixedMillisecond70.getTime();
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date73);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day74, (double) '#');
        int int77 = timeSeries68.getIndex((org.jfree.data.time.RegularTimePeriod) day74);
        boolean boolean79 = day74.equals((java.lang.Object) 7);
        org.jfree.data.time.SerialDate serialDate80 = day74.getSerialDate();
        boolean boolean81 = spreadsheetDate54.isAfter(serialDate80);
        boolean boolean82 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0f + "'", comparable6.equals(0.0f));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0f + "'", comparable13.equals(0.0f));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Value" + "'", str37.equals("Value"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 11 + "'", int52 == 11);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 7 + "'", int55 == 7);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1919 + "'", int64 == 1919);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-1L) + "'", long72 == (-1L));
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean17 = month4.equals((java.lang.Object) int16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month4.next();
        long long19 = month4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month4.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int24 = year22.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, year22);
        java.util.Date date26 = month25.getEnd();
        boolean boolean27 = month4.equals((java.lang.Object) date26);
        java.lang.String str28 = month4.toString();
        java.util.Calendar calendar29 = null;
        try {
            month4.peg(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1572591599999L + "'", long19 == 1572591599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "October 2019" + "'", str28.equals("October 2019"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        java.util.List list9 = timeSeries1.getItems();
        timeSeries1.setKey((java.lang.Comparable) 9);
        timeSeries1.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        int int21 = day19.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 8);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        int int27 = year25.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 10, year25);
        int int30 = month28.compareTo((java.lang.Object) 13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, (double) 1969);
        boolean boolean33 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38, timeZone39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date38);
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year41, (java.lang.Number) (short) 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable6 = timeSeries5.getKey();
        java.lang.String str7 = timeSeries5.getDescription();
        int int8 = timeSeries5.getItemCount();
        timeSeries5.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        java.lang.String str14 = timeSeries12.getDescription();
        int int15 = timeSeries12.getItemCount();
        timeSeries12.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) '#');
        java.lang.String[] strArray26 = org.jfree.data.time.SerialDate.getMonths();
        int int27 = timeSeriesDataItem25.compareTo((java.lang.Object) strArray26);
        timeSeries12.add(timeSeriesDataItem25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries12.addChangeListener(seriesChangeListener29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries32.fireSeriesChanged();
        timeSeries32.removeAgedItems((long) 2, false);
        java.lang.String str37 = timeSeries32.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.previous();
        int int45 = day43.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 0L);
        int int48 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) day43);
        java.lang.Number number49 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day43);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries3.addAndOrUpdate(timeSeries5);
        boolean boolean51 = spreadsheetDate1.equals((java.lang.Object) timeSeries5);
        timeSeries5.setNotify(false);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0f + "'", comparable6.equals(0.0f));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0f + "'", comparable13.equals(0.0f));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Value" + "'", str37.equals("Value"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate4.getDescription();
        int int11 = spreadsheetDate1.compare(serialDate4);
        spreadsheetDate1.setDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) '#');
        int int24 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) day21);
        boolean boolean26 = day21.equals((java.lang.Object) 7);
        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
        boolean boolean28 = spreadsheetDate1.isAfter(serialDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int31 = spreadsheetDate30.getYYYY();
        boolean boolean32 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int35 = spreadsheetDate34.getMonth();
        int int36 = spreadsheetDate34.getDayOfWeek();
        java.lang.String str37 = spreadsheetDate34.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date42, timeZone43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date42);
        boolean boolean46 = spreadsheetDate34.isBefore(serialDate45);
        boolean boolean47 = spreadsheetDate30.isAfter(serialDate45);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(serialDate45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1919 + "'", int11 == 1919);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1905 + "'", int31 == 1905);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 7 + "'", int35 == 7);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "11-July-1905" + "'", str37.equals("11-July-1905"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate6);
        java.lang.String str9 = serialDate3.getDescription();
        int int10 = spreadsheetDate1.compare(serialDate3);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        java.lang.String str14 = timeSeries12.getDescription();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) '#');
        int int25 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) day22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate29);
        timeSeries16.setKey((java.lang.Comparable) serialDate29);
        boolean boolean32 = spreadsheetDate1.isBefore(serialDate29);
        int int33 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int36 = spreadsheetDate35.getYYYY();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = serialDate39.getEndOfCurrentMonth(serialDate42);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addDays(13, serialDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int49 = spreadsheetDate48.getMonth();
        boolean boolean51 = spreadsheetDate35.isInRange(serialDate44, (org.jfree.data.time.SerialDate) spreadsheetDate48, 12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate58);
        org.jfree.data.time.SerialDate serialDate60 = serialDate55.getEndOfCurrentMonth(serialDate58);
        java.lang.String str61 = serialDate55.getDescription();
        int int62 = spreadsheetDate53.compare(serialDate55);
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable65 = timeSeries64.getKey();
        java.lang.String str66 = timeSeries64.getDescription();
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar71 = null;
        long long72 = fixedMillisecond70.getMiddleMillisecond(calendar71);
        java.util.Date date73 = fixedMillisecond70.getTime();
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date73);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day74, (double) '#');
        int int77 = timeSeries68.getIndex((org.jfree.data.time.RegularTimePeriod) day74);
        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries64.addAndOrUpdate(timeSeries68);
        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate81);
        timeSeries68.setKey((java.lang.Comparable) serialDate81);
        boolean boolean84 = spreadsheetDate53.isBefore(serialDate81);
        int int85 = spreadsheetDate35.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
        org.jfree.data.time.SerialDate serialDate86 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate35);
        spreadsheetDate1.setDescription("9-March-1900");
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1919 + "'", int10 == 1919);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0f + "'", comparable13.equals(0.0f));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1905 + "'", int36 == 1905);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 7 + "'", int49 == 7);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1919 + "'", int62 == 1919);
        org.junit.Assert.assertTrue("'" + comparable65 + "' != '" + 0.0f + "'", comparable65.equals(0.0f));
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-1L) + "'", long72 == (-1L));
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertNotNull(timeSeries78);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertNotNull(serialDate86);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Preceding");
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        java.lang.String str3 = spreadsheetDate1.toString();
        int int4 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "11-July-1905" + "'", str3.equals("11-July-1905"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = serialDate2.getEndOfCurrentMonth(serialDate5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(13, serialDate7);
        java.lang.String str10 = serialDate7.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate12 = serialDate7.getFollowingDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
        java.lang.String str8 = regularTimePeriod7.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1-January-1970" + "'", str8.equals("1-January-1970"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        java.util.List list5 = timeSeries1.getItems();
        timeSeries1.removeAgedItems(false);
        boolean boolean8 = timeSeries1.getNotify();
        timeSeries1.setMaximumItemAge(0L);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.next();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int11 = year9.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (short) 10, year9);
        java.util.Date date13 = month12.getEnd();
        org.jfree.data.time.Year year14 = month12.getYear();
        long long15 = year14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year14.previous();
        int int18 = day5.compareTo((java.lang.Object) regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 0);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable5 = timeSeries4.getKey();
        java.lang.String str6 = timeSeries4.getDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection9 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        timeSeries4.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getTime();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) '#');
        java.lang.String[] strArray19 = org.jfree.data.time.SerialDate.getMonths();
        int int20 = timeSeriesDataItem18.compareTo((java.lang.Object) strArray19);
        timeSeries4.add(timeSeriesDataItem18);
        boolean boolean22 = month2.equals((java.lang.Object) timeSeries4);
        java.lang.Comparable comparable23 = timeSeries4.getKey();
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 0.0f + "'", comparable5.equals(0.0f));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 0.0f + "'", comparable23.equals(0.0f));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond3.getTime();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) '#');
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day7);
        boolean boolean12 = day7.equals((java.lang.Object) 7);
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getPreviousDayOfWeek(1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Value");
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean17 = month4.equals((java.lang.Object) int16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month4.next();
        long long19 = month4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month4.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int24 = year22.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, year22);
        java.util.Date date26 = month25.getEnd();
        boolean boolean27 = month4.equals((java.lang.Object) date26);
        java.lang.Class class28 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
        java.util.Date date33 = fixedMillisecond30.getTime();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
        java.util.Date date39 = fixedMillisecond36.getTime();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date39, timeZone40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date33, timeZone40);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date26, timeZone40);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1572591599999L + "'", long19 == 1572591599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1L) + "'", long32 == (-1L));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-1L) + "'", long38 == (-1L));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod42);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        java.util.List list5 = timeSeries1.getItems();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.String str7 = month6.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year8.previous();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        java.lang.String str14 = month13.toString();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        int int17 = year15.compareTo((java.lang.Object) 3);
        long long18 = year15.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass19 = year15.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year15);
        int int21 = month13.compareTo((java.lang.Object) year15);
        org.jfree.data.time.Year year22 = month13.getYear();
        int int23 = year8.compareTo((java.lang.Object) year22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) 13);
        long long26 = year8.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1562097599999L + "'", long18 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-435), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection6 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.removeChangeListener(seriesChangeListener7);
        timeSeries5.setDomainDescription("October 2019");
        timeSeries5.setRangeDescription("11-July-1905");
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection6 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
        java.lang.String[] strArray16 = org.jfree.data.time.SerialDate.getMonths();
        int int17 = timeSeriesDataItem15.compareTo((java.lang.Object) strArray16);
        timeSeries1.add(timeSeriesDataItem15);
        java.lang.Object obj19 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 1900, (-452));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) '#');
        java.lang.String[] strArray15 = org.jfree.data.time.SerialDate.getMonths();
        int int16 = timeSeriesDataItem14.compareTo((java.lang.Object) strArray15);
        timeSeries1.add(timeSeriesDataItem14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries1.addChangeListener(seriesChangeListener18);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries21.fireSeriesChanged();
        timeSeries21.removeAgedItems((long) 2, false);
        java.lang.String str26 = timeSeries21.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
        java.util.Date date31 = fixedMillisecond28.getTime();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
        int int34 = day32.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) 0L);
        int int37 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day32);
        java.lang.String str38 = day32.toString();
        int int39 = day32.getYear();
        long long40 = day32.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day32.previous();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 12 + "'", int34 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "31-December-1969" + "'", str38.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1969 + "'", int39 == 1969);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 28799999L + "'", long40 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        java.util.Date date6 = fixedMillisecond1.getEnd();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.String str10 = timeSeries8.getDescription();
        int int11 = timeSeries8.getItemCount();
        timeSeries8.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable16 = timeSeries15.getKey();
        java.lang.String str17 = timeSeries15.getDescription();
        int int18 = timeSeries15.getItemCount();
        timeSeries15.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (double) '#');
        java.lang.String[] strArray29 = org.jfree.data.time.SerialDate.getMonths();
        int int30 = timeSeriesDataItem28.compareTo((java.lang.Object) strArray29);
        timeSeries15.add(timeSeriesDataItem28);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries15.addChangeListener(seriesChangeListener32);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries35.fireSeriesChanged();
        timeSeries35.removeAgedItems((long) 2, false);
        java.lang.String str40 = timeSeries35.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond42.getMiddleMillisecond(calendar43);
        java.util.Date date45 = fixedMillisecond42.getTime();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
        int int48 = day46.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) 0L);
        int int51 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) day46);
        java.lang.Number number52 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond54.getMiddleMillisecond(calendar55);
        java.util.Date date57 = fixedMillisecond54.getTime();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day58, (double) '#');
        timeSeries8.add(timeSeriesDataItem60, true);
        boolean boolean63 = fixedMillisecond1.equals((java.lang.Object) true);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        int int67 = year65.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month((int) (short) 10, year65);
        java.util.Date date69 = month68.getEnd();
        org.jfree.data.time.Year year70 = month68.getYear();
        long long71 = year70.getLastMillisecond();
        boolean boolean72 = fixedMillisecond1.equals((java.lang.Object) year70);
        java.util.Date date73 = year70.getStart();
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date73);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0f + "'", comparable9.equals(0.0f));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 0.0f + "'", comparable16.equals(0.0f));
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 12 + "'", int48 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-1L) + "'", long56 == (-1L));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(year70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1577865599999L + "'", long71 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(date73);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate6);
        java.lang.String str9 = serialDate3.getDescription();
        int int10 = spreadsheetDate1.compare(serialDate3);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        java.lang.String str14 = timeSeries12.getDescription();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) '#');
        int int25 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) day22);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries12.addAndOrUpdate(timeSeries16);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate29);
        timeSeries16.setKey((java.lang.Comparable) serialDate29);
        boolean boolean32 = spreadsheetDate1.isBefore(serialDate29);
        int int33 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate39);
        org.jfree.data.time.SerialDate serialDate41 = serialDate36.getEndOfCurrentMonth(serialDate39);
        java.lang.String str42 = serialDate36.getDescription();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(0, serialDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int46 = spreadsheetDate45.getYYYY();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate52);
        org.jfree.data.time.SerialDate serialDate54 = serialDate49.getEndOfCurrentMonth(serialDate52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addDays(13, serialDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int59 = spreadsheetDate58.getMonth();
        boolean boolean61 = spreadsheetDate45.isInRange(serialDate54, (org.jfree.data.time.SerialDate) spreadsheetDate58, 12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate68);
        org.jfree.data.time.SerialDate serialDate70 = serialDate65.getEndOfCurrentMonth(serialDate68);
        java.lang.String str71 = serialDate65.getDescription();
        int int72 = spreadsheetDate63.compare(serialDate65);
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable75 = timeSeries74.getKey();
        java.lang.String str76 = timeSeries74.getDescription();
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar81 = null;
        long long82 = fixedMillisecond80.getMiddleMillisecond(calendar81);
        java.util.Date date83 = fixedMillisecond80.getTime();
        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date83);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day84, (double) '#');
        int int87 = timeSeries78.getIndex((org.jfree.data.time.RegularTimePeriod) day84);
        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries74.addAndOrUpdate(timeSeries78);
        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate92 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate91);
        timeSeries78.setKey((java.lang.Comparable) serialDate91);
        boolean boolean94 = spreadsheetDate63.isBefore(serialDate91);
        int int95 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate63);
        org.jfree.data.time.SerialDate serialDate96 = serialDate36.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate63);
        int int97 = spreadsheetDate63.toSerial();
        int int98 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate63);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1919 + "'", int10 == 1919);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0f + "'", comparable13.equals(0.0f));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 11 + "'", int33 == 11);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1905 + "'", int46 == 1905);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 7 + "'", int59 == 7);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1919 + "'", int72 == 1919);
        org.junit.Assert.assertTrue("'" + comparable75 + "' != '" + 0.0f + "'", comparable75.equals(0.0f));
        org.junit.Assert.assertNull(str76);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-1L) + "'", long82 == (-1L));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
        org.junit.Assert.assertNotNull(timeSeries88);
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
        org.junit.Assert.assertNotNull(serialDate96);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 2019 + "'", int97 == 2019);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection6 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.removeChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries5.getDescription();
        try {
            timeSeries5.update(0, (java.lang.Number) 5L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable6 = timeSeries5.getKey();
        java.lang.String str7 = timeSeries5.getDescription();
        int int8 = timeSeries5.getItemCount();
        timeSeries5.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        java.lang.String str14 = timeSeries12.getDescription();
        int int15 = timeSeries12.getItemCount();
        timeSeries12.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) '#');
        java.lang.String[] strArray26 = org.jfree.data.time.SerialDate.getMonths();
        int int27 = timeSeriesDataItem25.compareTo((java.lang.Object) strArray26);
        timeSeries12.add(timeSeriesDataItem25);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries12.addChangeListener(seriesChangeListener29);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries32.fireSeriesChanged();
        timeSeries32.removeAgedItems((long) 2, false);
        java.lang.String str37 = timeSeries32.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
        java.util.Date date42 = fixedMillisecond39.getTime();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day43.previous();
        int int45 = day43.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 0L);
        int int48 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) day43);
        java.lang.Number number49 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day43);
        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries3.addAndOrUpdate(timeSeries5);
        boolean boolean51 = spreadsheetDate1.equals((java.lang.Object) timeSeries5);
        timeSeries5.clear();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0f + "'", comparable6.equals(0.0f));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0f + "'", comparable13.equals(0.0f));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Value" + "'", str37.equals("Value"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNotNull(timeSeries50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond1.equals(obj6);
        java.lang.String str8 = fixedMillisecond1.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
        int int14 = fixedMillisecond10.compareTo((java.lang.Object) true);
        java.util.Date date15 = fixedMillisecond10.getEnd();
        int int16 = fixedMillisecond1.compareTo((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.next();
        long long19 = year17.getLastMillisecond();
        long long20 = year17.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str8.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28799999L + "'", long20 == 28799999L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 0);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month2);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable6 = timeSeries5.getKey();
        java.lang.String str7 = timeSeries5.getDescription();
        int int8 = timeSeries5.getItemCount();
        timeSeries5.setDescription("hi!");
        timeSeries5.fireSeriesChanged();
        timeSeries5.setRangeDescription("9-March-1900");
        boolean boolean14 = timeSeries5.isEmpty();
        int int15 = month2.compareTo((java.lang.Object) boolean14);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0f + "'", comparable6.equals(0.0f));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
        int int7 = fixedMillisecond3.compareTo((java.lang.Object) true);
        java.util.Date date8 = fixedMillisecond3.getEnd();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond3.getLastMillisecond(calendar9);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond3.getFirstMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond3.getTime();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date13);
        int int16 = spreadsheetDate1.compare(serialDate15);
        int int17 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate20);
        boolean boolean22 = spreadsheetDate1.isAfter(serialDate20);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-23668) + "'", int16 == (-23668));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond4.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
        int int10 = day9.getMonth();
        boolean boolean11 = month0.equals((java.lang.Object) day9);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month0.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        int int6 = year4.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 10, year4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month7);
        int int9 = month7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        serialDate13.setDescription("");
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, serialDate13);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(5, serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = serialDate13.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears(4, serialDate23);
        int int25 = month7.compareTo((java.lang.Object) serialDate23);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        java.util.Date date6 = fixedMillisecond1.getEnd();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.String str10 = timeSeries8.getDescription();
        int int11 = timeSeries8.getItemCount();
        timeSeries8.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable16 = timeSeries15.getKey();
        java.lang.String str17 = timeSeries15.getDescription();
        int int18 = timeSeries15.getItemCount();
        timeSeries15.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond22.getTime();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (double) '#');
        java.lang.String[] strArray29 = org.jfree.data.time.SerialDate.getMonths();
        int int30 = timeSeriesDataItem28.compareTo((java.lang.Object) strArray29);
        timeSeries15.add(timeSeriesDataItem28);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries15.addChangeListener(seriesChangeListener32);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries35.fireSeriesChanged();
        timeSeries35.removeAgedItems((long) 2, false);
        java.lang.String str40 = timeSeries35.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond42.getMiddleMillisecond(calendar43);
        java.util.Date date45 = fixedMillisecond42.getTime();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
        int int48 = day46.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries35.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) 0L);
        int int51 = timeSeries15.getIndex((org.jfree.data.time.RegularTimePeriod) day46);
        java.lang.Number number52 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond54.getMiddleMillisecond(calendar55);
        java.util.Date date57 = fixedMillisecond54.getTime();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day58, (double) '#');
        timeSeries8.add(timeSeriesDataItem60, true);
        boolean boolean63 = fixedMillisecond1.equals((java.lang.Object) true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond((-1L));
        int int67 = fixedMillisecond65.compareTo((java.lang.Object) (-1L));
        long long68 = fixedMillisecond65.getSerialIndex();
        java.util.Calendar calendar69 = null;
        fixedMillisecond65.peg(calendar69);
        boolean boolean71 = fixedMillisecond1.equals((java.lang.Object) fixedMillisecond65);
        long long72 = fixedMillisecond65.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0f + "'", comparable9.equals(0.0f));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 0.0f + "'", comparable16.equals(0.0f));
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 12 + "'", int48 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNull(number52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-1L) + "'", long56 == (-1L));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-1L) + "'", long68 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-1L) + "'", long72 == (-1L));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems((long) 5, false);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        int int15 = year13.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (short) 10, year13);
        java.util.Date date17 = month16.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
        java.lang.Number number20 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int24 = year22.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, year22);
        java.util.Date date26 = month25.getEnd();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
        java.util.Date date33 = fixedMillisecond30.getTime();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day34, (double) '#');
        int int37 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) day34);
        boolean boolean38 = month25.equals((java.lang.Object) int37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month25.next();
        int int40 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable43 = timeSeries42.getKey();
        java.lang.String str44 = timeSeries42.getDescription();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond48.getMiddleMillisecond(calendar49);
        java.util.Date date51 = fixedMillisecond48.getTime();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day52, (double) '#');
        int int55 = timeSeries46.getIndex((org.jfree.data.time.RegularTimePeriod) day52);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries42.addAndOrUpdate(timeSeries46);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries1.addAndOrUpdate(timeSeries46);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNull(number20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1L) + "'", long32 == (-1L));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 0.0f + "'", comparable43.equals(0.0f));
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-1L) + "'", long50 == (-1L));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(timeSeries57);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        timeSeries1.removeAgedItems((long) 5, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
        int int17 = fixedMillisecond13.compareTo((java.lang.Object) true);
        java.util.Date date18 = fixedMillisecond13.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray22 = seriesException21.getSuppressed();
        boolean boolean23 = fixedMillisecond13.equals((java.lang.Object) seriesException21);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) '#', false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable9 = timeSeries8.getKey();
        java.lang.String str10 = timeSeries8.getDescription();
        int int11 = timeSeries8.getItemCount();
        timeSeries8.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (double) '#');
        java.lang.String[] strArray22 = org.jfree.data.time.SerialDate.getMonths();
        int int23 = timeSeriesDataItem21.compareTo((java.lang.Object) strArray22);
        timeSeries8.add(timeSeriesDataItem21);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries8.addChangeListener(seriesChangeListener25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries28.fireSeriesChanged();
        timeSeries28.removeAgedItems((long) 2, false);
        java.lang.String str33 = timeSeries28.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
        int int41 = day39.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) 0L);
        int int44 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) day39);
        java.lang.Number number45 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond47.getMiddleMillisecond(calendar48);
        java.util.Date date50 = fixedMillisecond47.getTime();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (double) '#');
        timeSeries1.add(timeSeriesDataItem53, true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar58 = null;
        long long59 = fixedMillisecond57.getMiddleMillisecond(calendar58);
        java.util.Date date60 = fixedMillisecond57.getTime();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day61.previous();
        long long63 = day61.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day61, (java.lang.Number) (-435));
        long long66 = day61.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day61, (java.lang.Number) (short) 1);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0f + "'", comparable9.equals(0.0f));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-1L) + "'", long49 == (-1L));
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-1L) + "'", long59 == (-1L));
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 25568L + "'", long63 == 25568L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 25568L + "'", long66 == 25568L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection6 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.removeChangeListener(seriesChangeListener7);
        timeSeries5.setDomainDescription("October 2019");
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        int int16 = fixedMillisecond12.compareTo((java.lang.Object) true);
        long long17 = fixedMillisecond12.getSerialIndex();
        java.util.Calendar calendar18 = null;
        fixedMillisecond12.peg(calendar18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond12.getLastMillisecond(calendar21);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        java.util.List list9 = timeSeries1.getItems();
        timeSeries1.setKey((java.lang.Comparable) 9);
        timeSeries1.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond15.getTime();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        int int21 = day19.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 8);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        int int27 = year25.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 10, year25);
        int int30 = month28.compareTo((java.lang.Object) 13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, (double) 1969);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getMiddleMillisecond(calendar35);
        java.util.Date date37 = fixedMillisecond34.getTime();
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond34.getLastMillisecond(calendar38);
        int int40 = timeSeriesDataItem32.compareTo((java.lang.Object) fixedMillisecond34);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond34.getMiddleMillisecond(calendar41);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-1L) + "'", long39 == (-1L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(6, (int) (byte) 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection6 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries5.removeChangeListener(seriesChangeListener7);
        timeSeries5.setDomainDescription("October 2019");
        try {
            timeSeries5.delete(2019, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 2147483647);
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2147483647L + "'", long2 == 2147483647L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond4.getTime();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (double) '#');
        int int11 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries2.addChangeListener(seriesChangeListener12);
        int int14 = timeSeries2.getItemCount();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        int int17 = year15.compareTo((java.lang.Object) 3);
        int int19 = year15.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        boolean boolean21 = year15.equals((java.lang.Object) day20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year15, (double) 10.0f);
        java.lang.Class class24 = timeSeries2.getTimePeriodClass();
        java.lang.Class class25 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
        java.util.Date date36 = fixedMillisecond33.getTime();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date30, timeZone37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date30);
        long long41 = fixedMillisecond40.getSerialIndex();
        java.util.Calendar calendar42 = null;
        fixedMillisecond40.peg(calendar42);
        java.util.Date date44 = fixedMillisecond40.getTime();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable47 = timeSeries46.getKey();
        java.lang.String str48 = timeSeries46.getDescription();
        int int49 = timeSeries46.getItemCount();
        timeSeries46.setDescription("hi!");
        java.lang.Class class52 = timeSeries46.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond54.getMiddleMillisecond(calendar55);
        java.util.Date date57 = fixedMillisecond54.getTime();
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date57, timeZone58);
        java.lang.Class class60 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar63 = null;
        long long64 = fixedMillisecond62.getMiddleMillisecond(calendar63);
        java.util.Date date65 = fixedMillisecond62.getTime();
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar69 = null;
        long long70 = fixedMillisecond68.getMiddleMillisecond(calendar69);
        java.util.Date date71 = fixedMillisecond68.getTime();
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date71, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date65, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date57, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date44, timeZone72);
        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, class24);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-1L) + "'", long35 == (-1L));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1L) + "'", long41 == (-1L));
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + comparable47 + "' != '" + 0.0f + "'", comparable47.equals(0.0f));
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(class52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-1L) + "'", long56 == (-1L));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-1L) + "'", long64 == (-1L));
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-1L) + "'", long70 == (-1L));
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int3 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(13, serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int16 = spreadsheetDate15.getMonth();
        boolean boolean18 = spreadsheetDate2.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15, 12);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate2);
        int int21 = spreadsheetDate2.getYYYY();
        int int22 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int25 = spreadsheetDate24.getMonth();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate30);
        org.jfree.data.time.SerialDate serialDate32 = serialDate27.getEndOfCurrentMonth(serialDate30);
        java.lang.String str33 = serialDate27.getDescription();
        int int34 = spreadsheetDate24.compare(serialDate27);
        spreadsheetDate24.setDescription("June 2019");
        int int37 = spreadsheetDate24.getYYYY();
        int int38 = spreadsheetDate24.getMonth();
        boolean boolean39 = spreadsheetDate2.equals((java.lang.Object) int38);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1905 + "'", int3 == 1905);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 7 + "'", int16 == 7);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1905 + "'", int21 == 1905);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1905 + "'", int22 == 1905);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 7 + "'", int25 == 7);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1919 + "'", int34 == 1919);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1905 + "'", int37 == 1905);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 7 + "'", int38 == 7);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond3.getTime();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) '#');
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getTime();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (double) 1571252399999L);
        timeSeries1.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.lang.Number number12 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day11);
        int int13 = day11.getMonth();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(6, (int) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        boolean boolean18 = day11.equals((java.lang.Object) regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        java.util.Date date6 = fixedMillisecond1.getEnd();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = serialDate17.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays(13, serialDate22);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable29 = timeSeries28.getKey();
        java.lang.String str30 = timeSeries28.getDescription();
        int int31 = timeSeries28.getItemCount();
        timeSeries28.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (double) '#');
        java.lang.String[] strArray42 = org.jfree.data.time.SerialDate.getMonths();
        int int43 = timeSeriesDataItem41.compareTo((java.lang.Object) strArray42);
        timeSeries28.add(timeSeriesDataItem41);
        java.lang.Object obj45 = timeSeriesDataItem41.clone();
        java.lang.Class<?> wildcardClass46 = timeSeriesDataItem41.getClass();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate22, "Value", "", (java.lang.Class) wildcardClass46);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable50 = timeSeries49.getKey();
        java.lang.String str51 = timeSeries49.getDescription();
        int int52 = timeSeries49.getItemCount();
        timeSeries49.setDescription("hi!");
        java.lang.Class class55 = timeSeries49.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar58 = null;
        long long59 = fixedMillisecond57.getMiddleMillisecond(calendar58);
        java.util.Date date60 = fixedMillisecond57.getTime();
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date60, timeZone61);
        java.lang.Class class63 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar66 = null;
        long long67 = fixedMillisecond65.getMiddleMillisecond(calendar66);
        java.util.Date date68 = fixedMillisecond65.getTime();
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date68);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar72 = null;
        long long73 = fixedMillisecond71.getMiddleMillisecond(calendar72);
        java.util.Date date74 = fixedMillisecond71.getTime();
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date74, timeZone75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date68, timeZone75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date60, timeZone75);
        java.util.TimeZone timeZone79 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date60, timeZone79);
        java.lang.Class class81 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar84 = null;
        long long85 = fixedMillisecond83.getMiddleMillisecond(calendar84);
        java.util.Date date86 = fixedMillisecond83.getTime();
        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(date86);
        org.jfree.data.time.FixedMillisecond fixedMillisecond89 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar90 = null;
        long long91 = fixedMillisecond89.getMiddleMillisecond(calendar90);
        java.util.Date date92 = fixedMillisecond89.getTime();
        java.util.TimeZone timeZone93 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day94 = new org.jfree.data.time.Day(date92, timeZone93);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance(class81, date86, timeZone93);
        org.jfree.data.time.Month month96 = new org.jfree.data.time.Month(date60, timeZone93);
        org.jfree.data.time.Year year97 = new org.jfree.data.time.Year(date11, timeZone93);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + 0.0f + "'", comparable29.equals(0.0f));
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + comparable50 + "' != '" + 0.0f + "'", comparable50.equals(0.0f));
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-1L) + "'", long59 == (-1L));
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-1L) + "'", long67 == (-1L));
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-1L) + "'", long73 == (-1L));
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-1L) + "'", long85 == (-1L));
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + (-1L) + "'", long91 == (-1L));
        org.junit.Assert.assertNotNull(date92);
        org.junit.Assert.assertNotNull(timeZone93);
        org.junit.Assert.assertNull(regularTimePeriod95);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        long long2 = month0.getLastMillisecond();
        long long3 = month0.getSerialIndex();
        int int4 = month0.getMonth();
        int int5 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int18 = year16.compareTo((java.lang.Object) 3);
        long long19 = year16.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass20 = year16.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 9999);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1562097599999L + "'", long19 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        timeSeries1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.String str13 = month12.toString();
        long long14 = month12.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month12);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable18 = timeSeries17.getKey();
        java.lang.String str19 = timeSeries17.getDescription();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.util.Collection collection22 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        timeSeries17.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond25.getTime();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (double) '#');
        java.lang.String[] strArray32 = org.jfree.data.time.SerialDate.getMonths();
        int int33 = timeSeriesDataItem31.compareTo((java.lang.Object) strArray32);
        timeSeries17.add(timeSeriesDataItem31);
        timeSeriesDataItem31.setValue((java.lang.Number) 2);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable39 = timeSeries38.getKey();
        java.lang.String str40 = timeSeries38.getDescription();
        int int41 = timeSeries38.getItemCount();
        timeSeries38.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable46 = timeSeries45.getKey();
        java.lang.String str47 = timeSeries45.getDescription();
        int int48 = timeSeries45.getItemCount();
        timeSeries45.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond52.getMiddleMillisecond(calendar53);
        java.util.Date date55 = fixedMillisecond52.getTime();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day56, (double) '#');
        java.lang.String[] strArray59 = org.jfree.data.time.SerialDate.getMonths();
        int int60 = timeSeriesDataItem58.compareTo((java.lang.Object) strArray59);
        timeSeries45.add(timeSeriesDataItem58);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener62 = null;
        timeSeries45.addChangeListener(seriesChangeListener62);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries65.fireSeriesChanged();
        timeSeries65.removeAgedItems((long) 2, false);
        java.lang.String str70 = timeSeries65.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar73 = null;
        long long74 = fixedMillisecond72.getMiddleMillisecond(calendar73);
        java.util.Date date75 = fixedMillisecond72.getTime();
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = day76.previous();
        int int78 = day76.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries65.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day76, (java.lang.Number) 0L);
        int int81 = timeSeries45.getIndex((org.jfree.data.time.RegularTimePeriod) day76);
        java.lang.Number number82 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) day76);
        boolean boolean83 = timeSeriesDataItem31.equals((java.lang.Object) number82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = timeSeriesDataItem31.getPeriod();
        timeSeries1.delete(regularTimePeriod84);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "June 2019" + "'", str13.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1561964399999L + "'", long14 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 0.0f + "'", comparable18.equals(0.0f));
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + 0.0f + "'", comparable39.equals(0.0f));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + 0.0f + "'", comparable46.equals(0.0f));
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-1L) + "'", long54 == (-1L));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Value" + "'", str70.equals("Value"));
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-1L) + "'", long74 == (-1L));
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 12 + "'", int78 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNull(number82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date5);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate6);
        java.lang.String str9 = serialDate3.getDescription();
        int int10 = spreadsheetDate1.compare(serialDate3);
        java.lang.String str11 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1919 + "'", int10 == 1919);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int4 = spreadsheetDate3.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate9);
        java.lang.String str12 = serialDate6.getDescription();
        int int13 = spreadsheetDate3.compare(serialDate6);
        spreadsheetDate3.setDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getTime();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) '#');
        int int26 = timeSeries17.getIndex((org.jfree.data.time.RegularTimePeriod) day23);
        boolean boolean28 = day23.equals((java.lang.Object) 7);
        org.jfree.data.time.SerialDate serialDate29 = day23.getSerialDate();
        boolean boolean30 = spreadsheetDate3.isAfter(serialDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable37 = timeSeries36.getKey();
        java.lang.String str38 = timeSeries36.getDescription();
        int int39 = timeSeries36.getItemCount();
        timeSeries36.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable44 = timeSeries43.getKey();
        java.lang.String str45 = timeSeries43.getDescription();
        int int46 = timeSeries43.getItemCount();
        timeSeries43.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getMiddleMillisecond(calendar51);
        java.util.Date date53 = fixedMillisecond50.getTime();
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day54, (double) '#');
        java.lang.String[] strArray57 = org.jfree.data.time.SerialDate.getMonths();
        int int58 = timeSeriesDataItem56.compareTo((java.lang.Object) strArray57);
        timeSeries43.add(timeSeriesDataItem56);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries43.addChangeListener(seriesChangeListener60);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries63.fireSeriesChanged();
        timeSeries63.removeAgedItems((long) 2, false);
        java.lang.String str68 = timeSeries63.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar71 = null;
        long long72 = fixedMillisecond70.getMiddleMillisecond(calendar71);
        java.util.Date date73 = fixedMillisecond70.getTime();
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = day74.previous();
        int int76 = day74.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries63.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day74, (java.lang.Number) 0L);
        int int79 = timeSeries43.getIndex((org.jfree.data.time.RegularTimePeriod) day74);
        java.lang.Number number80 = timeSeries36.getValue((org.jfree.data.time.RegularTimePeriod) day74);
        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries34.addAndOrUpdate(timeSeries36);
        boolean boolean82 = spreadsheetDate32.equals((java.lang.Object) timeSeries36);
        boolean boolean83 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int84 = spreadsheetDate3.toSerial();
        int int85 = spreadsheetDate3.getYYYY();
        int int86 = spreadsheetDate3.getMonth();
        int int87 = month0.compareTo((java.lang.Object) spreadsheetDate3);
        int int88 = spreadsheetDate3.getYYYY();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1919 + "'", int13 == 1919);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + 0.0f + "'", comparable37.equals(0.0f));
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + 0.0f + "'", comparable44.equals(0.0f));
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-1L) + "'", long52 == (-1L));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Value" + "'", str68.equals("Value"));
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-1L) + "'", long72 == (-1L));
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 12 + "'", int76 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNull(number80);
        org.junit.Assert.assertNotNull(timeSeries81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 2019 + "'", int84 == 2019);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1905 + "'", int85 == 1905);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 7 + "'", int86 == 7);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1905 + "'", int88 == 1905);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean17 = month4.equals((java.lang.Object) int16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month4.next();
        long long19 = month4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month4.next();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int24 = year22.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (short) 10, year22);
        java.util.Date date26 = month25.getEnd();
        boolean boolean27 = month4.equals((java.lang.Object) date26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date26);
        java.util.Date date29 = fixedMillisecond28.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getMiddleMillisecond(calendar32);
        java.util.Date date34 = fixedMillisecond31.getTime();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34, timeZone35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date34);
        boolean boolean39 = fixedMillisecond28.equals((java.lang.Object) date34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1572591599999L + "'", long19 == 1572591599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) '#');
        int int16 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
        boolean boolean17 = month4.equals((java.lang.Object) int16);
        java.lang.String str18 = month4.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "October 2019" + "'", str18.equals("October 2019"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        int int7 = day6.getMonth();
        boolean boolean9 = day6.equals((java.lang.Object) "9-March-1900");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries1.removeChangeListener(seriesChangeListener9);
        int int11 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        timeSeries1.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable21 = timeSeries20.getKey();
        java.lang.String str22 = timeSeries20.getDescription();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
        java.util.Date date29 = fixedMillisecond26.getTime();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) '#');
        int int33 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) day30);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries20.addAndOrUpdate(timeSeries24);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable39 = timeSeries38.getKey();
        java.lang.String str40 = timeSeries38.getDescription();
        int int41 = timeSeries38.getItemCount();
        timeSeries38.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond45.getMiddleMillisecond(calendar46);
        java.util.Date date48 = fixedMillisecond45.getTime();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day49, (double) '#');
        java.lang.String[] strArray52 = org.jfree.data.time.SerialDate.getMonths();
        int int53 = timeSeriesDataItem51.compareTo((java.lang.Object) strArray52);
        timeSeries38.add(timeSeriesDataItem51);
        java.lang.Object obj55 = timeSeriesDataItem51.clone();
        java.lang.Class<?> wildcardClass56 = timeSeriesDataItem51.getClass();
        java.lang.Number number57 = timeSeriesDataItem51.getValue();
        timeSeries20.add(timeSeriesDataItem51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = timeSeriesDataItem51.getPeriod();
        timeSeries1.add(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + 0.0f + "'", comparable21.equals(0.0f));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1L) + "'", long28 == (-1L));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + 0.0f + "'", comparable39.equals(0.0f));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-1L) + "'", long47 == (-1L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(strArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 35.0d + "'", number57.equals(35.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod59);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getFirstMillisecond();
        long long5 = year0.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries7.fireSeriesChanged();
        timeSeries7.removeAgedItems((long) 2, false);
        java.lang.String str12 = timeSeries7.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        int int20 = day18.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable25 = timeSeries24.getKey();
        java.lang.String str26 = timeSeries24.getDescription();
        int int27 = timeSeries24.getItemCount();
        java.util.List list28 = timeSeries24.getItems();
        timeSeries24.removeAgedItems(false);
        java.util.Collection collection31 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        int int32 = year0.compareTo((java.lang.Object) collection31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year0.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 0.0f + "'", comparable25.equals(0.0f));
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(13, serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int15 = spreadsheetDate14.getMonth();
        boolean boolean17 = spreadsheetDate1.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14, 12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate24);
        org.jfree.data.time.SerialDate serialDate26 = serialDate21.getEndOfCurrentMonth(serialDate24);
        java.lang.String str27 = serialDate21.getDescription();
        int int28 = spreadsheetDate19.compare(serialDate21);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable31 = timeSeries30.getKey();
        java.lang.String str32 = timeSeries30.getDescription();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
        java.util.Date date39 = fixedMillisecond36.getTime();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day40, (double) '#');
        int int43 = timeSeries34.getIndex((org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries30.addAndOrUpdate(timeSeries34);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate47);
        timeSeries34.setKey((java.lang.Comparable) serialDate47);
        boolean boolean50 = spreadsheetDate19.isBefore(serialDate47);
        int int51 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int52 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate53 = null;
        try {
            boolean boolean54 = spreadsheetDate1.isAfter(serialDate53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1919 + "'", int28 == 1919);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + 0.0f + "'", comparable31.equals(0.0f));
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-1L) + "'", long38 == (-1L));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 7 + "'", int52 == 7);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        java.lang.String str4 = timeSeries1.getDescription();
        int int5 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable8 = timeSeries7.getKey();
        java.lang.String str9 = timeSeries7.getDescription();
        int int10 = timeSeries7.getItemCount();
        timeSeries7.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getTime();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (double) '#');
        java.lang.String[] strArray21 = org.jfree.data.time.SerialDate.getMonths();
        int int22 = timeSeriesDataItem20.compareTo((java.lang.Object) strArray21);
        timeSeries7.add(timeSeriesDataItem20);
        java.lang.Object obj24 = timeSeriesDataItem20.clone();
        java.lang.Class<?> wildcardClass25 = timeSeriesDataItem20.getClass();
        timeSeries1.add(timeSeriesDataItem20);
        java.lang.Comparable comparable27 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 0.0f + "'", comparable8.equals(0.0f));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + 0.0f + "'", comparable27.equals(0.0f));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        timeSeries1.setNotify(false);
        java.util.List list9 = timeSeries1.getItems();
        java.util.List list10 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getLastMillisecond(calendar13);
        long long15 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
        boolean boolean23 = fixedMillisecond12.equals((java.lang.Object) day21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("May");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        java.util.Date date4 = spreadsheetDate1.toDate();
        java.lang.String str5 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = serialDate9.getEndOfCurrentMonth(serialDate12);
        boolean boolean15 = spreadsheetDate7.isOnOrAfter(serialDate9);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, serialDate19);
        java.lang.String str22 = serialDate19.getDescription();
        boolean boolean24 = spreadsheetDate1.isInRange(serialDate9, serialDate19, 9999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.lang.Number number4 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day3);
        java.lang.Object obj5 = timeSeries1.clone();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries18.fireSeriesChanged();
        timeSeries18.removeAgedItems((long) 2, false);
        java.lang.String str23 = timeSeries18.getRangeDescription();
        timeSeries18.setNotify(false);
        java.util.List list26 = timeSeries18.getItems();
        timeSeries18.setKey((java.lang.Comparable) 9);
        timeSeries18.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond32.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
        int int38 = day36.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 8);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (short) 10, year42);
        int int47 = month45.compareTo((java.lang.Object) 13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) 1969);
        timeSeries1.add(timeSeriesDataItem49, false);
        java.lang.Comparable comparable52 = timeSeries1.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timeSeries1.removeChangeListener(seriesChangeListener53);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + 0.0f + "'", comparable52.equals(0.0f));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        int int5 = fixedMillisecond1.compareTo((java.lang.Object) true);
        java.util.Date date6 = fixedMillisecond1.getEnd();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.next();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year14.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond3.getTime();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) '#');
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond12.getTime();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (double) 1571252399999L);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries21.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable25 = timeSeries24.getKey();
        java.lang.String str26 = timeSeries24.getDescription();
        int int27 = timeSeries24.getItemCount();
        java.util.List list28 = timeSeries24.getItems();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        java.lang.String str30 = month29.toString();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getFirstMillisecond();
        long long33 = year31.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month29, (org.jfree.data.time.RegularTimePeriod) year31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year31.previous();
        java.lang.Number number36 = timeSeries21.getValue(regularTimePeriod35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries1.addOrUpdate(regularTimePeriod35, (double) 1577865599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 0.0f + "'", comparable25.equals(0.0f));
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "June 2019" + "'", str30.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month4);
        java.lang.String str7 = timeSeries6.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int3 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(13, serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int16 = spreadsheetDate15.getMonth();
        boolean boolean18 = spreadsheetDate2.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate15, 12);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate2);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries22.fireSeriesChanged();
        timeSeries22.removeAgedItems((long) 2, false);
        java.lang.String str27 = timeSeries22.getRangeDescription();
        timeSeries22.setNotify(false);
        java.util.List list30 = timeSeries22.getItems();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable33 = timeSeries32.getKey();
        java.lang.String str34 = timeSeries32.getDescription();
        int int35 = timeSeries32.getItemCount();
        timeSeries32.setDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries32.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries22.addAndOrUpdate(timeSeries32);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        int int43 = year41.compareTo((java.lang.Object) 3);
        int int45 = year41.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        boolean boolean47 = year41.equals((java.lang.Object) day46);
        timeSeries32.setKey((java.lang.Comparable) boolean47);
        java.util.Collection collection49 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries32.addOrUpdate(regularTimePeriod50, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1905 + "'", int3 == 1905);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 7 + "'", int16 == 7);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + 0.0f + "'", comparable33.equals(0.0f));
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(collection49);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int9 = year7.compareTo((java.lang.Object) 3);
        long long10 = year7.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass11 = year7.getClass();
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date4, timeZone13);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate4.getDescription();
        int int11 = spreadsheetDate1.compare(serialDate4);
        int int12 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        int int18 = fixedMillisecond14.compareTo((java.lang.Object) true);
        java.lang.Object obj19 = null;
        boolean boolean20 = fixedMillisecond14.equals(obj19);
        java.lang.String str21 = fixedMillisecond14.toString();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        int int25 = year23.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (short) 10, year23);
        java.util.Date date27 = month26.getEnd();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getMiddleMillisecond(calendar32);
        java.util.Date date34 = fixedMillisecond31.getTime();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (double) '#');
        int int38 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) day35);
        boolean boolean39 = month26.equals((java.lang.Object) int38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month26.next();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable43 = timeSeries42.getKey();
        java.lang.String str44 = timeSeries42.getDescription();
        int int45 = timeSeries42.getItemCount();
        timeSeries42.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond49.getMiddleMillisecond(calendar50);
        java.util.Date date52 = fixedMillisecond49.getTime();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day53, (double) '#');
        long long56 = day53.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) day53);
        boolean boolean58 = month26.equals((java.lang.Object) day53);
        java.lang.String str59 = month26.toString();
        int int60 = fixedMillisecond14.compareTo((java.lang.Object) month26);
        try {
            int int61 = spreadsheetDate1.compareTo((java.lang.Object) month26);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Month cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1919 + "'", int11 == 1919);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str21.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 0.0f + "'", comparable43.equals(0.0f));
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 25568L + "'", long56 == 25568L);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "October 2019" + "'", str59.equals("October 2019"));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.util.Date date14 = day13.getEnd();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = serialDate17.getEndOfCurrentMonth(serialDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays(13, serialDate22);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable29 = timeSeries28.getKey();
        java.lang.String str30 = timeSeries28.getDescription();
        int int31 = timeSeries28.getItemCount();
        timeSeries28.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (double) '#');
        java.lang.String[] strArray42 = org.jfree.data.time.SerialDate.getMonths();
        int int43 = timeSeriesDataItem41.compareTo((java.lang.Object) strArray42);
        timeSeries28.add(timeSeriesDataItem41);
        java.lang.Object obj45 = timeSeriesDataItem41.clone();
        java.lang.Class<?> wildcardClass46 = timeSeriesDataItem41.getClass();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate22, "Value", "", (java.lang.Class) wildcardClass46);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date14, (java.lang.Class) wildcardClass46);
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize(class49);
        int int51 = year5.compareTo((java.lang.Object) class50);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + 0.0f + "'", comparable29.equals(0.0f));
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertNotNull(class50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Feb" + "'", str2.equals("Feb"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond3.getTime();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) '#');
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day7);
        timeSeries1.setDescription("");
        java.lang.Object obj13 = timeSeries1.clone();
        boolean boolean14 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
        java.util.Date date19 = fixedMillisecond16.getTime();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        java.util.Date date21 = day20.getEnd();
        int int22 = day20.getYear();
        java.util.Date date23 = day20.getStart();
        int int24 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day20);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        int int28 = year26.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (short) 10, year26);
        java.util.Date date30 = month29.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getMiddleMillisecond(calendar35);
        java.util.Date date37 = fixedMillisecond34.getTime();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date37, timeZone38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date30, timeZone38);
        int int41 = day20.compareTo((java.lang.Object) timeZone38);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int19 = year17.compareTo((java.lang.Object) 3);
        int int21 = year17.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        boolean boolean23 = year17.equals((java.lang.Object) day22);
        long long24 = year17.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year17.previous();
        long long26 = year17.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (-1L));
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (-14400001L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        long long3 = year0.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long8 = fixedMillisecond7.getSerialIndex();
        int int9 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        long long10 = fixedMillisecond7.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        java.util.List list5 = timeSeries1.getItems();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        java.lang.String str7 = month6.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month6, (org.jfree.data.time.RegularTimePeriod) year8);
        long long12 = timeSeries11.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable15 = timeSeries14.getKey();
        java.lang.String str16 = timeSeries14.getDescription();
        int int17 = timeSeries14.getItemCount();
        timeSeries14.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
        java.util.Date date24 = fixedMillisecond21.getTime();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (double) '#');
        java.lang.String[] strArray28 = org.jfree.data.time.SerialDate.getMonths();
        int int29 = timeSeriesDataItem27.compareTo((java.lang.Object) strArray28);
        timeSeries14.add(timeSeriesDataItem27);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries14.addChangeListener(seriesChangeListener31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond34.getMiddleMillisecond(calendar35);
        java.util.Date date37 = fixedMillisecond34.getTime();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date37, timeZone38);
        boolean boolean40 = timeSeries14.equals((java.lang.Object) date37);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries11.addAndOrUpdate(timeSeries14);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 0.0f + "'", comparable15.equals(0.0f));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(timeSeries41);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        java.util.Date date4 = spreadsheetDate1.toDate();
        int int5 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate18);
        timeSeries5.setKey((java.lang.Comparable) serialDate18);
        timeSeries5.removeAgedItems(false);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        java.lang.String str24 = month23.toString();
        long long25 = month23.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable28 = timeSeries27.getKey();
        java.lang.String str29 = timeSeries27.getDescription();
        int int30 = timeSeries27.getItemCount();
        timeSeries27.setDescription("hi!");
        java.lang.Class class33 = timeSeries27.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond35.getTime();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38, timeZone39);
        java.lang.Class class41 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond43.getMiddleMillisecond(calendar44);
        java.util.Date date46 = fixedMillisecond43.getTime();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond49.getMiddleMillisecond(calendar50);
        java.util.Date date52 = fixedMillisecond49.getTime();
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date52, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date46, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date38, timeZone53);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month23, class33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, (double) 1);
        boolean boolean60 = timeSeries5.equals((java.lang.Object) month23);
        java.util.Calendar calendar61 = null;
        try {
            month23.peg(calendar61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "June 2019" + "'", str24.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1561964399999L + "'", long25 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + 0.0f + "'", comparable28.equals(0.0f));
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-1L) + "'", long37 == (-1L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-1L) + "'", long45 == (-1L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) '#');
        java.lang.String[] strArray15 = org.jfree.data.time.SerialDate.getMonths();
        int int16 = timeSeriesDataItem14.compareTo((java.lang.Object) strArray15);
        timeSeries1.add(timeSeriesDataItem14);
        java.lang.Object obj18 = timeSeriesDataItem14.clone();
        java.lang.Class<?> wildcardClass19 = timeSeriesDataItem14.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries18.fireSeriesChanged();
        timeSeries18.removeAgedItems((long) 2, false);
        java.lang.String str23 = timeSeries18.getRangeDescription();
        timeSeries18.setNotify(false);
        java.util.List list26 = timeSeries18.getItems();
        timeSeries18.setKey((java.lang.Comparable) 9);
        timeSeries18.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond32.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
        int int38 = day36.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 8);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (short) 10, year42);
        int int47 = month45.compareTo((java.lang.Object) 13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) 1969);
        timeSeries1.add(timeSeriesDataItem49, false);
        timeSeries1.removeAgedItems((long) 100, false);
        timeSeries1.clear();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        int int58 = year56.compareTo((java.lang.Object) 3);
        long long59 = year56.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass60 = year56.getClass();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long64 = fixedMillisecond63.getSerialIndex();
        int int65 = timeSeries61.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, (java.lang.Number) 1560191643567L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1562097599999L + "'", long59 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-1L) + "'", long64 == (-1L));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate6);
        boolean boolean9 = spreadsheetDate1.isOnOrAfter(serialDate3);
        int int10 = spreadsheetDate1.toSerial();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable13 = timeSeries12.getKey();
        java.lang.String str14 = timeSeries12.getDescription();
        int int15 = timeSeries12.getItemCount();
        timeSeries12.setDescription("hi!");
        java.lang.Class class18 = timeSeries12.getTimePeriodClass();
        timeSeries12.clear();
        boolean boolean20 = spreadsheetDate1.equals((java.lang.Object) timeSeries12);
        java.lang.String str21 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int24 = spreadsheetDate23.getYYYY();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate30);
        org.jfree.data.time.SerialDate serialDate32 = serialDate27.getEndOfCurrentMonth(serialDate30);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays(13, serialDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int37 = spreadsheetDate36.getMonth();
        boolean boolean39 = spreadsheetDate23.isInRange(serialDate32, (org.jfree.data.time.SerialDate) spreadsheetDate36, 12);
        int int40 = spreadsheetDate23.getYYYY();
        org.jfree.data.time.SerialDate serialDate41 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 0.0f + "'", comparable13.equals(0.0f));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1905 + "'", int24 == 1905);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 7 + "'", int37 == 7);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1905 + "'", int40 == 1905);
        org.junit.Assert.assertNotNull(serialDate41);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(13, serialDate11);
        boolean boolean14 = spreadsheetDate1.isOnOrAfter(serialDate13);
        int int15 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        java.lang.String str6 = fixedMillisecond1.toString();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        int int10 = fixedMillisecond1.compareTo((java.lang.Object) (-457));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str6.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        int int4 = year0.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean6 = year0.equals((java.lang.Object) day5);
        long long7 = year0.getSerialIndex();
        long long8 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(8, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        int int14 = day12.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 0L);
        org.jfree.data.time.SerialDate serialDate17 = day12.getSerialDate();
        long long18 = day12.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (-452), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) '#');
        timeSeriesDataItem7.setValue((java.lang.Number) 1577865599999L);
        timeSeriesDataItem7.setValue((java.lang.Number) 1572591599999L);
        timeSeriesDataItem7.setValue((java.lang.Number) 10.0f);
        java.lang.Number number14 = null;
        timeSeriesDataItem7.setValue(number14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int3 = year1.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 10, year1);
        int int5 = month4.getMonth();
        org.jfree.data.time.Year year6 = month4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12);
        int int15 = year6.compareTo((java.lang.Object) date12);
        int int16 = year6.getYear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(13, serialDate11);
        boolean boolean14 = spreadsheetDate1.isOnOrAfter(serialDate13);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays(5, serialDate19);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, serialDate23);
        boolean boolean25 = spreadsheetDate1.isInRange(serialDate19, serialDate24);
        int int26 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate31);
        org.jfree.data.time.SerialDate serialDate33 = serialDate28.getEndOfCurrentMonth(serialDate31);
        boolean boolean34 = spreadsheetDate1.isAfter(serialDate28);
        int int35 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1905 + "'", int26 == 1905);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 7 + "'", int35 == 7);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries18.fireSeriesChanged();
        timeSeries18.removeAgedItems((long) 2, false);
        java.lang.String str23 = timeSeries18.getRangeDescription();
        timeSeries18.setNotify(false);
        java.util.List list26 = timeSeries18.getItems();
        timeSeries18.setKey((java.lang.Comparable) 9);
        timeSeries18.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond32.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
        int int38 = day36.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 8);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (short) 10, year42);
        int int47 = month45.compareTo((java.lang.Object) 13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) 1969);
        timeSeries1.add(timeSeriesDataItem49, false);
        timeSeries1.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries1.createCopy(0, 0);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener60 = null;
        timeSeries1.addChangeListener(seriesChangeListener60);
        java.util.List list62 = timeSeries1.getItems();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertNotNull(list62);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date5);
        long long16 = fixedMillisecond15.getSerialIndex();
        java.util.Calendar calendar17 = null;
        fixedMillisecond15.peg(calendar17);
        java.util.Date date19 = fixedMillisecond15.getTime();
        java.util.Date date20 = fixedMillisecond15.getStart();
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond15.getLastMillisecond(calendar21);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond15.getMiddleMillisecond(calendar23);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) '#');
        long long15 = day12.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day12);
        long long17 = day12.getMiddleMillisecond();
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray20 = seriesException19.getSuppressed();
        int int21 = day12.compareTo((java.lang.Object) seriesException19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day12.next();
        java.util.Calendar calendar23 = null;
        try {
            day12.peg(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 25568L + "'", long15 == 25568L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-14400001L) + "'", long17 == (-14400001L));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.lang.Number number12 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day11);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = serialDate2.getEndOfCurrentMonth(serialDate5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(13, serialDate7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable14 = timeSeries13.getKey();
        java.lang.String str15 = timeSeries13.getDescription();
        int int16 = timeSeries13.getItemCount();
        timeSeries13.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getTime();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) '#');
        java.lang.String[] strArray27 = org.jfree.data.time.SerialDate.getMonths();
        int int28 = timeSeriesDataItem26.compareTo((java.lang.Object) strArray27);
        timeSeries13.add(timeSeriesDataItem26);
        java.lang.Object obj30 = timeSeriesDataItem26.clone();
        java.lang.Class<?> wildcardClass31 = timeSeriesDataItem26.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7, "Value", "", (java.lang.Class) wildcardClass31);
        java.util.List list33 = timeSeries32.getItems();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        int int36 = year34.compareTo((java.lang.Object) 3);
        int int38 = year34.compareTo((java.lang.Object) (-1.0d));
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        boolean boolean40 = year34.equals((java.lang.Object) day39);
        timeSeries32.delete((org.jfree.data.time.RegularTimePeriod) day39);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day39);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 0.0f + "'", comparable14.equals(0.0f));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) "Value");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries1.fireSeriesChanged();
        timeSeries1.removeAgedItems((long) 2, false);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        int int14 = day12.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 0L);
        java.lang.Object obj17 = timeSeries1.clone();
        java.lang.Comparable comparable18 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + 0.0f + "'", comparable18.equals(0.0f));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries18.fireSeriesChanged();
        timeSeries18.removeAgedItems((long) 2, false);
        java.lang.String str23 = timeSeries18.getRangeDescription();
        timeSeries18.setNotify(false);
        java.util.List list26 = timeSeries18.getItems();
        timeSeries18.setKey((java.lang.Comparable) 9);
        timeSeries18.setDescription("Preceding");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond32.getTime();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
        int int38 = day36.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 8);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int44 = year42.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (short) 10, year42);
        int int47 = month45.compareTo((java.lang.Object) 13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) 1969);
        timeSeries1.add(timeSeriesDataItem49, false);
        timeSeries1.removeAgedItems((long) 100, false);
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries1.createCopy(0, 0);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        int int61 = year59.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month((int) (short) 10, year59);
        int int63 = year59.getYear();
        int int64 = year59.getYear();
        java.lang.Number number65 = timeSeries57.getValue((org.jfree.data.time.RegularTimePeriod) year59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year59.previous();
        java.lang.String str67 = year59.toString();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2019 + "'", int63 == 2019);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2019 + "'", int64 == 2019);
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 8 + "'", number65.equals(8));
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "2019" + "'", str67.equals("2019"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(13, serialDate11);
        boolean boolean14 = spreadsheetDate1.isOnOrAfter(serialDate13);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays(5, serialDate19);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, serialDate23);
        boolean boolean25 = spreadsheetDate1.isInRange(serialDate19, serialDate24);
        int int26 = spreadsheetDate1.getYYYY();
        int int27 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1905 + "'", int26 == 1905);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1905 + "'", int27 == 1905);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date12, timeZone13);
        java.lang.Class class15 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond17.getTime();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond23.getTime();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date12, timeZone27);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date12);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(13, (int) (byte) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) 3);
        long long3 = year0.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond9.getTime();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.util.Date date14 = day13.getEnd();
        int int15 = day13.getYear();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day13, (double) 2147483647, true);
        int int19 = timeSeries5.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        java.lang.Class class16 = timeSeries5.getTimePeriodClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        int int21 = year19.compareTo((java.lang.Object) 3);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (short) 10, year19);
        java.util.Date date23 = month22.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getTime();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30, timeZone31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date23, timeZone31);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable36 = timeSeries35.getKey();
        java.lang.String str37 = timeSeries35.getDescription();
        int int38 = timeSeries35.getItemCount();
        timeSeries35.setDescription("hi!");
        java.lang.Class class41 = timeSeries35.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond43.getMiddleMillisecond(calendar44);
        java.util.Date date46 = fixedMillisecond43.getTime();
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date46, timeZone47);
        java.lang.Class class49 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond51.getMiddleMillisecond(calendar52);
        java.util.Date date54 = fixedMillisecond51.getTime();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date54);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar58 = null;
        long long59 = fixedMillisecond57.getMiddleMillisecond(calendar58);
        java.util.Date date60 = fixedMillisecond57.getTime();
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date60, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date54, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date46, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date23, timeZone61);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 0.0f + "'", comparable36.equals(0.0f));
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-1L) + "'", long45 == (-1L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-1L) + "'", long53 == (-1L));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-1L) + "'", long59 == (-1L));
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) '#');
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.addAndOrUpdate(timeSeries5);
        boolean boolean16 = timeSeries1.isEmpty();
        timeSeries1.setNotify(true);
        timeSeries1.clear();
        java.util.List list20 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) list20);
        java.lang.String str22 = seriesChangeEvent21.toString();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=[]]" + "'", str22.equals("org.jfree.data.general.SeriesChangeEvent[source=[]]"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable2 = timeSeries1.getKey();
        java.lang.String str3 = timeSeries1.getDescription();
        int int4 = timeSeries1.getItemCount();
        timeSeries1.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getTime();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) '#');
        java.lang.String[] strArray15 = org.jfree.data.time.SerialDate.getMonths();
        int int16 = timeSeriesDataItem14.compareTo((java.lang.Object) strArray15);
        timeSeries1.add(timeSeriesDataItem14);
        java.lang.Object obj18 = timeSeriesDataItem14.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        java.util.Calendar calendar23 = null;
        fixedMillisecond20.peg(calendar23);
        java.lang.String str25 = fixedMillisecond20.toString();
        boolean boolean26 = timeSeriesDataItem14.equals((java.lang.Object) str25);
        java.lang.Object obj27 = timeSeriesDataItem14.clone();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 0.0f + "'", comparable2.equals(0.0f));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str25.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(13, serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int15 = spreadsheetDate14.getMonth();
        boolean boolean17 = spreadsheetDate1.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14, 12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate24);
        org.jfree.data.time.SerialDate serialDate26 = serialDate21.getEndOfCurrentMonth(serialDate24);
        java.lang.String str27 = serialDate21.getDescription();
        int int28 = spreadsheetDate19.compare(serialDate21);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable31 = timeSeries30.getKey();
        java.lang.String str32 = timeSeries30.getDescription();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
        java.util.Date date39 = fixedMillisecond36.getTime();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day40, (double) '#');
        int int43 = timeSeries34.getIndex((org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries30.addAndOrUpdate(timeSeries34);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(7, serialDate47);
        timeSeries34.setKey((java.lang.Comparable) serialDate47);
        boolean boolean50 = spreadsheetDate19.isBefore(serialDate47);
        int int51 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int52 = spreadsheetDate1.getMonth();
        int int53 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905 + "'", int2 == 1905);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1919 + "'", int28 == 1919);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + 0.0f + "'", comparable31.equals(0.0f));
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-1L) + "'", long38 == (-1L));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 7 + "'", int52 == 7);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 3 + "'", int53 == 3);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate7);
        java.lang.String str10 = serialDate4.getDescription();
        int int11 = spreadsheetDate1.compare(serialDate4);
        int int12 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2019);
        int int15 = spreadsheetDate14.getMonth();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(4, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = serialDate17.getEndOfCurrentMonth(serialDate20);
        java.lang.String str23 = serialDate17.getDescription();
        int int24 = spreadsheetDate14.compare(serialDate17);
        spreadsheetDate14.setDescription("June 2019");
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
        java.util.Date date33 = fixedMillisecond30.getTime();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day34, (double) '#');
        int int37 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) day34);
        boolean boolean39 = day34.equals((java.lang.Object) 7);
        org.jfree.data.time.SerialDate serialDate40 = day34.getSerialDate();
        boolean boolean41 = spreadsheetDate14.isAfter(serialDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable48 = timeSeries47.getKey();
        java.lang.String str49 = timeSeries47.getDescription();
        int int50 = timeSeries47.getItemCount();
        timeSeries47.setDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        java.lang.Comparable comparable55 = timeSeries54.getKey();
        java.lang.String str56 = timeSeries54.getDescription();
        int int57 = timeSeries54.getItemCount();
        timeSeries54.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar62 = null;
        long long63 = fixedMillisecond61.getMiddleMillisecond(calendar62);
        java.util.Date date64 = fixedMillisecond61.getTime();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day65, (double) '#');
        java.lang.String[] strArray68 = org.jfree.data.time.SerialDate.getMonths();
        int int69 = timeSeriesDataItem67.compareTo((java.lang.Object) strArray68);
        timeSeries54.add(timeSeriesDataItem67);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener71 = null;
        timeSeries54.addChangeListener(seriesChangeListener71);
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f);
        timeSeries74.fireSeriesChanged();
        timeSeries74.removeAgedItems((long) 2, false);
        java.lang.String str79 = timeSeries74.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond((-1L));
        java.util.Calendar calendar82 = null;
        long long83 = fixedMillisecond81.getMiddleMillisecond(calendar82);
        java.util.Date date84 = fixedMillisecond81.getTime();
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date84);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = day85.previous();
        int int87 = day85.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries74.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day85, (java.lang.Number) 0L);
        int int90 = timeSeries54.getIndex((org.jfree.data.time.RegularTimePeriod) day85);
        java.lang.Number number91 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) day85);
        org.jfree.data.time.TimeSeries timeSeries92 = timeSeries45.addAndOrUpdate(timeSeries47);
        boolean boolean93 = spreadsheetDate43.equals((java.lang.Object) timeSeries47);
        boolean boolean94 = spreadsheetDate14.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean95 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1919 + "'", int11 == 1919);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 11 + "'", int12 == 11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1919 + "'", int24 == 1919);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1L) + "'", long32 == (-1L));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + comparable48 + "' != '" + 0.0f + "'", comparable48.equals(0.0f));
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + comparable55 + "' != '" + 0.0f + "'", comparable55.equals(0.0f));
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-1L) + "'", long63 == (-1L));
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(strArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "Value" + "'", str79.equals("Value"));
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + (-1L) + "'", long83 == (-1L));
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 12 + "'", int87 == 12);
        org.junit.Assert.assertNull(timeSeriesDataItem89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertNull(number91);
        org.junit.Assert.assertNotNull(timeSeries92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }
}

