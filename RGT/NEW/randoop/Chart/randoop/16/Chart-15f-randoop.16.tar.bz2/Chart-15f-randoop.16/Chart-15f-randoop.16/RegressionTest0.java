import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, 100.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, plot2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.Arrangement arrangement1 = null;
        org.jfree.chart.block.Arrangement arrangement2 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, arrangement1, arrangement2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) (short) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            rectangleInsets10.trim(rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color2, (float) (byte) 10, 0, textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        double double7 = rectangleInsets5.extendWidth((double) 0.0f);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            multiplePiePlot1.drawOutline(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textFragment1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 1L);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        double double5 = rectangleInsets0.calculateLeftInset((double) 'a');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.0d) + "'", double2 == (-5.0d));
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(false);
        org.jfree.data.Range range4 = null;
        try {
            numberAxis1.setRange(range4, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 10L, (-5.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, 64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        multiplePiePlot1.setDataset(categoryDataset2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.plot.PlotState plotState7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            multiplePiePlot1.draw(graphics2D4, rectangle2D5, point2D6, plotState7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=128,b=255]" + "'", str1.equals("java.awt.Color[r=128,g=128,b=255]"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "hi!" + "'", str0.equals("hi!"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Color color1 = java.awt.Color.getColor("1.2.0-pre");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        float[] floatArray9 = null;
        float[] floatArray10 = color6.getComponents(floatArray9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("", font1);
        float float3 = textFragment2.getBaselineOffset();
        float float4 = textFragment2.getBaselineOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = null;
        try {
            dateAxis0.setMinimumDate(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'date' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        try {
            piePlot0.setInteriorGap(10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (10.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot0.getLegendLabelURLGenerator();
        java.awt.Paint paint5 = piePlot0.getBaseSectionOutlinePaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(pieURLGenerator6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D5 = textTitle4.getBounds();
        org.jfree.chart.util.UnitType unitType6 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(unitType6, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType6, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D18 = textTitle17.getBounds();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets16.createOutsetRectangle(rectangle2D18, true, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            org.jfree.chart.axis.AxisState axisState24 = numberAxis3D1.draw(graphics2D2, (double) 100, rectangle2D5, rectangle2D18, rectangleEdge22, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        try {
            dateAxis0.zoomRange((double) 1.0f, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 0, jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=0]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=0]"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 10L, (double) 1, 0, (java.lang.Comparable) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        numberAxis1.setUpArrow(shape2);
        org.jfree.data.Range range5 = null;
        try {
            numberAxis1.setRange(range5, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
//        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
//        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
//        numberAxis1.setUpArrow(shape2);
//        org.jfree.data.general.PieDataset pieDataset5 = null;
//        java.lang.Comparable comparable8 = null;
//        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset5, 10, 0, comparable8, "", "");
//        try {
//            java.lang.Object obj12 = pieSectionEntity11.clone();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(shape2);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 1L, (double) (-1), 0.0d, 0.0d);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine();
        boolean boolean18 = color16.equals((java.lang.Object) textLine17);
        boolean boolean19 = unitType0.equals((java.lang.Object) textLine17);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        multiplePiePlot1.setDataset(categoryDataset2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        multiplePiePlot1.handleClick((int) '#', 10, plotRenderingInfo6);
        org.jfree.chart.util.TableOrder tableOrder8 = null;
        try {
            multiplePiePlot1.setDataExtractOrder(tableOrder8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = null;
        try {
            dateAxis0.setRange(range1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperBound();
        boolean boolean3 = numberAxis1.isTickMarksVisible();
        java.awt.Shape shape4 = null;
        try {
            numberAxis1.setUpArrow(shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.plot.Marker marker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            boolean boolean5 = xYPlot0.removeDomainMarker((int) (short) 10, marker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.clearRangeAxes();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle11.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double14 = categoryAxis8.getCategoryStart(255, (int) (short) -1, rectangle2D12, rectangleEdge13);
        java.awt.geom.Point2D point2D15 = null;
        org.jfree.chart.plot.PlotState plotState16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        xYPlot5.draw(graphics2D7, rectangle2D12, point2D15, plotState16, plotRenderingInfo17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double20 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 0.08d, (java.lang.Comparable) 64, categoryDataset3, 8.0d, rectangle2D12, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        java.awt.Paint paint2 = null;
        try {
            xYPlot0.setRangeCrosshairPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, false, false);
        numberAxis3.setUpperMargin(0.025d);
        try {
            xYPlot0.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis) numberAxis3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setExpandToFitSpace(false);
        java.lang.String str3 = textTitle0.getURLText();
        double double4 = textTitle0.getWidth();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setExpandToFitSpace(false);
        textTitle0.setText("1.2.0-pre");
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset(10.0d);
        double double4 = rectangleInsets0.calculateRightInset((-48.743718592964825d));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setAutoRangeIncludesZero(false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine();
        boolean boolean3 = color1.equals((java.lang.Object) textLine2);
        boolean boolean4 = rectangleAnchor0.equals((java.lang.Object) color1);
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) 8.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeAxes();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double11 = categoryAxis5.getCategoryStart(255, (int) (short) -1, rectangle2D9, rectangleEdge10);
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot2.draw(graphics2D4, rectangle2D9, point2D12, plotState13, plotRenderingInfo14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge16);
        double double18 = dateAxis0.valueToJava2D((double) 10, rectangle2D9, rectangleEdge17);
        java.util.Date date19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle21.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str24 = rectangleEdge23.toString();
        textTitle21.setPosition(rectangleEdge23);
        try {
            double double26 = dateAxis0.dateToJava2D(date19, rectangle2D20, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleEdge.TOP" + "'", str24.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int1 = color0.getRed();
        java.awt.color.ColorSpace colorSpace2 = color0.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        float[] floatArray6 = new float[] { '4' };
        try {
            float[] floatArray7 = color0.getColorComponents(colorSpace4, floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setExpandToFitSpace(false);
        double double3 = textTitle0.getWidth();
        java.awt.Graphics2D graphics2D4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textTitle0.arrange(graphics2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("{0}", graphics2D1, (float) (byte) 100, 0.0f, textAnchor4, (double) 10, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        numberAxis1.setAutoTickUnitSelection(true, false);
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        numberAxis1.centerRange(10.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(false);
        try {
            numberAxis1.setAutoRangeMinimumSize((double) 0.0f, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = multiplePiePlot1.getDatasetGroup();
        float float5 = multiplePiePlot1.getBackgroundAlpha();
        double double6 = multiplePiePlot1.getLimit();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=128,g=128,b=255]", graphics2D1, (-1.0f), 0.0f, textAnchor4, 0.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleEdge.TOP");
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker3.getLabelOffset();
        org.jfree.chart.util.Layer layer5 = null;
        try {
            xYPlot0.addDomainMarker(100, (org.jfree.chart.plot.Marker) valueMarker3, layer5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("java.awt.Color[r=128,g=128,b=255]", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeAxes();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double11 = categoryAxis5.getCategoryStart(255, (int) (short) -1, rectangle2D9, rectangleEdge10);
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot2.draw(graphics2D4, rectangle2D9, point2D12, plotState13, plotRenderingInfo14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge16);
        double double18 = dateAxis0.valueToJava2D((double) 10, rectangle2D9, rectangleEdge17);
        java.util.TimeZone timeZone19 = null;
        try {
            dateAxis0.setTimeZone(timeZone19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets8.createInsetRectangle(rectangle2D9, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeAxes();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double11 = categoryAxis5.getCategoryStart(255, (int) (short) -1, rectangle2D9, rectangleEdge10);
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot2.draw(graphics2D4, rectangle2D9, point2D12, plotState13, plotRenderingInfo14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge16);
        double double18 = dateAxis0.valueToJava2D((double) 10, rectangle2D9, rectangleEdge17);
        java.lang.Object obj19 = dateAxis0.clone();
        try {
            dateAxis0.zoomRange((double) (short) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = waferMapPlot1.getDataset();
        org.junit.Assert.assertNull(waferMapDataset2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 1L);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        java.lang.String str4 = unitType3.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.0d) + "'", double2 == (-5.0d));
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UnitType.ABSOLUTE" + "'", str4.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        java.lang.String str4 = numberAxis1.getLabelToolTip();
        numberAxis1.setLowerBound(0.0d);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int2 = objectList0.indexOf((java.lang.Object) 1);
        objectList0.set(0, (java.lang.Object) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent2.getType();
        java.lang.Object obj4 = chartChangeEvent2.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent2.getType();
        org.jfree.chart.JFreeChart jFreeChart6 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (short) 0 + "'", obj4.equals((short) 0));
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent2.getType();
        java.lang.Object obj4 = chartChangeEvent2.getSource();
        java.lang.String str5 = chartChangeEvent2.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (short) 0 + "'", obj4.equals((short) 0));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=0]" + "'", str5.equals("org.jfree.chart.event.ChartChangeEvent[source=0]"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("UnitType.ABSOLUTE", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeAxes();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double11 = categoryAxis5.getCategoryStart(255, (int) (short) -1, rectangle2D9, rectangleEdge10);
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot2.draw(graphics2D4, rectangle2D9, point2D12, plotState13, plotRenderingInfo14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge16);
        double double18 = dateAxis0.valueToJava2D((double) 10, rectangle2D9, rectangleEdge17);
        try {
            dateAxis0.zoomRange((double) (short) 1, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        textTitle0.setFrame((org.jfree.chart.block.BlockFrame) lineBorder2);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range2 = null;
        try {
            numberAxis1.setRangeWithMargins(range2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart3.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = jFreeChart3.getPadding();
        org.jfree.chart.event.ChartChangeListener chartChangeListener6 = null;
        try {
            jFreeChart3.addChangeListener(chartChangeListener6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        boolean boolean2 = color0.equals((java.lang.Object) textLine1);
        boolean boolean4 = textLine1.equals((java.lang.Object) (short) 1);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font6);
        textLine1.addFragment(textFragment7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            float float11 = textFragment7.calculateBaselineOffset(graphics2D9, textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.set((int) ' ', (java.lang.Object) 1.0d);
        java.lang.Object obj5 = objectList0.get(10);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 10L, 0.0d, 0.0d, (double) (-1L));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        double double2 = piePlot0.getStartAngle();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        piePlot0.markerChanged(markerChangeEvent3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot0.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        org.jfree.data.general.DatasetGroup datasetGroup4 = multiplePiePlot1.getDatasetGroup();
        multiplePiePlot1.zoom((-5.0d));
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        multiplePiePlot1.notifyListeners(plotChangeEvent7);
        boolean boolean10 = multiplePiePlot1.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        org.jfree.data.Range range4 = null;
        try {
            numberAxis1.setRange(range4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        numberAxis1.setUpArrow(shape2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean6 = numberAxis1.equals((java.lang.Object) color5);
        org.jfree.data.RangeType rangeType7 = numberAxis1.getRangeType();
        numberAxis1.resizeRange((double) '#');
        numberAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rangeType7);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.UnitType unitType4 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType16 = rectangleInsets15.getUnitType();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D18 = textTitle17.getBounds();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets15.createInsetRectangle(rectangle2D18);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets14.createOutsetRectangle(rectangle2D18, true, false);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D25 = textTitle24.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str27 = rectangleEdge26.toString();
        textTitle24.setPosition(rectangleEdge26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            org.jfree.chart.axis.AxisState axisState30 = numberAxis1.draw(graphics2D2, (-48.743718592964825d), rectangle2D22, rectangle2D23, rectangleEdge26, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(unitType16);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleEdge.TOP" + "'", str27.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("org.jfree.chart.event.ChartChangeEvent[source=0]");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.clearRangeAxes();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle10.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double13 = categoryAxis7.getCategoryStart(255, (int) (short) -1, rectangle2D11, rectangleEdge12);
        java.awt.geom.Point2D point2D14 = null;
        org.jfree.chart.plot.PlotState plotState15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        xYPlot4.draw(graphics2D6, rectangle2D11, point2D14, plotState15, plotRenderingInfo16);
        org.jfree.chart.util.UnitType unitType18 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets(unitType18, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets(unitType18, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType30 = rectangleInsets29.getUnitType();
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle31.getBounds();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets29.createInsetRectangle(rectangle2D32);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets28.createOutsetRectangle(rectangle2D32, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        try {
            org.jfree.chart.axis.AxisState axisState39 = categoryAxis3D1.draw(graphics2D2, 0.2d, rectangle2D11, rectangle2D36, rectangleEdge37, plotRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(unitType30);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperBound();
        boolean boolean4 = numberAxis2.isTickMarksVisible();
        boolean boolean5 = numberAxis2.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot6 = numberAxis2.getPlot();
        org.jfree.data.Range range7 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double12 = numberAxis11.getUpperBound();
        boolean boolean13 = numberAxis11.isTickMarksVisible();
        boolean boolean14 = numberAxis11.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot15 = numberAxis11.getPlot();
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, range7, lengthConstraintType8, (double) 3, range16, lengthConstraintType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = null;
        try {
            valueMarker1.setLabelOffsetType(lengthAdjustmentType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("org.jfree.chart.event.ChartChangeEvent[source=0]");
        categoryAxis3D1.setCategoryMargin(90.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 100, axisLocation3, true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperBound();
        boolean boolean3 = numberAxis1.isTickMarksVisible();
        boolean boolean4 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot5 = numberAxis1.getPlot();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType11 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType11, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType11, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType23 = rectangleInsets22.getUnitType();
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D25 = textTitle24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets22.createInsetRectangle(rectangle2D25);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets21.createOutsetRectangle(rectangle2D25, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double31 = categoryAxis8.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D29, rectangleEdge30);
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D29, "{0}", "org.jfree.chart.event.ChartChangeEvent[source=0]");
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge35);
        try {
            java.util.List list37 = numberAxis1.refreshTicks(graphics2D6, axisState7, rectangle2D29, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(unitType23);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D2 = textTitle1.getBounds();
        boolean boolean4 = textTitle1.equals((java.lang.Object) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = piePlot5.getLabelDistributor();
        java.awt.Paint paint7 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot5.setLabelBackgroundPaint(paint7);
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        piePlot5.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color10);
        double double12 = piePlot5.getLabelGap();
        columnArrangement0.add((org.jfree.chart.block.Block) textTitle1, (java.lang.Object) double12);
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.025d + "'", double12 == 0.025d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType2, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType2, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle13.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets12.createOutsetRectangle(rectangle2D14, true, true);
        try {
            xYPlot0.drawBackground(graphics2D1, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition2 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.extendHeight((double) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0d + "'", double2 == 7.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", graphics2D1, (float) 'a', (float) 3, textAnchor4, 7.0d, 10.0f, (float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = piePlot0.getBaseSectionOutlinePaint();
        piePlot0.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot0.getLabelPadding();
        double double14 = rectangleInsets13.getBottom();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("org.jfree.chart.event.ChartChangeEvent[source=0]");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        org.jfree.chart.util.UnitType unitType5 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType5, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType5, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle16.getBounds();
        java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets15.createOutsetRectangle(rectangle2D17, true, true);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle21.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str24 = rectangleEdge23.toString();
        textTitle21.setPosition(rectangleEdge23);
        try {
            double double26 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor2, 0, 1, rectangle2D20, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleEdge.TOP" + "'", str24.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomRangeAxes((double) 0L, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer10 = null;
        try {
            boolean boolean11 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        try {
            java.awt.image.BufferedImage bufferedImage8 = jFreeChart3.createBufferedImage((int) (short) 10, (int) (short) 0, (int) (short) 0, chartRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("UnitType.ABSOLUTE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key UnitType.ABSOLUTE");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, false, false);
        numberAxis3.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3.getLabelInsets();
        boolean boolean11 = xYPlot0.equals((java.lang.Object) rectangleInsets10);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            boolean boolean16 = xYPlot0.removeDomainMarker(64, marker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Paint paint2 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        xYPlot0.setDomainCrosshairValue((double) (-1L), false);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("1.2.0-pre");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key 1.2.0-pre");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setUpperMargin(1.0d);
        numberAxis2.setAutoTickUnitSelection(true, false);
        java.awt.Stroke stroke8 = numberAxis2.getTickMarkStroke();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        textTitle9.setExpandToFitSpace(false);
        java.lang.String str12 = textTitle9.getURLText();
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle9.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle9.getMargin();
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke8, rectangleInsets14);
        java.awt.Paint paint16 = lineBorder15.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.lang.Object obj1 = piePlot0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator2 = null;
        piePlot0.setToolTipGenerator(pieToolTipGenerator2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        piePlot0.setSimpleLabelOffset(rectangleInsets4);
        java.awt.Paint paint7 = piePlot0.getSectionOutlinePaint((java.lang.Comparable) (-16744448));
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        java.awt.Paint paint4 = multiplePiePlot1.getNoDataMessagePaint();
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        multiplePiePlot1.setAggregatedItemsPaint(paint5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType11 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType11, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType11, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType23 = rectangleInsets22.getUnitType();
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D25 = textTitle24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets22.createInsetRectangle(rectangle2D25);
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets21.createOutsetRectangle(rectangle2D25, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double31 = categoryAxis8.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D29, rectangleEdge30);
        java.awt.geom.Point2D point2D32 = null;
        org.jfree.chart.plot.PlotState plotState33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        try {
            multiplePiePlot1.draw(graphics2D7, rectangle2D29, point2D32, plotState33, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(unitType23);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart3.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = jFreeChart3.getPadding();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot6 = jFreeChart3.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.WaferMapPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(false);
        java.lang.Object obj4 = numberAxis1.clone();
        numberAxis1.setLowerBound(7.0d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        java.lang.String str4 = numberAxis1.getLabelToolTip();
        double double5 = numberAxis1.getUpperBound();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.clearRangeAxes();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle16.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double19 = categoryAxis13.getCategoryStart(255, (int) (short) -1, rectangle2D17, rectangleEdge18);
        java.awt.geom.Point2D point2D20 = null;
        org.jfree.chart.plot.PlotState plotState21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot10.draw(graphics2D12, rectangle2D17, point2D20, plotState21, plotRenderingInfo22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge24);
        double double26 = dateAxis8.valueToJava2D((double) 10, rectangle2D17, rectangleEdge25);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        xYPlot29.clearRangeAxes();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D36 = textTitle35.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double38 = categoryAxis32.getCategoryStart(255, (int) (short) -1, rectangle2D36, rectangleEdge37);
        java.awt.geom.Point2D point2D39 = null;
        org.jfree.chart.plot.PlotState plotState40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        xYPlot29.draw(graphics2D31, rectangle2D36, point2D39, plotState40, plotRenderingInfo41);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge43);
        double double45 = dateAxis27.valueToJava2D((double) 10, rectangle2D36, rectangleEdge44);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D47 = textTitle46.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str49 = rectangleEdge48.toString();
        textTitle46.setPosition(rectangleEdge48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        try {
            org.jfree.chart.axis.AxisState axisState52 = numberAxis1.draw(graphics2D6, (double) 10, rectangle2D17, rectangle2D36, rectangleEdge48, plotRenderingInfo51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "RectangleEdge.TOP" + "'", str49.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        xYPlot0.clearDomainMarkers((int) (short) -1);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis13.setTickUnit(numberTickUnit14, false, false);
        numberAxis13.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        textTitle20.setExpandToFitSpace(false);
        java.lang.String str23 = textTitle20.getURLText();
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle20.getBounds();
        numberAxis13.setDownArrow((java.awt.Shape) rectangle2D24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge26);
        double double28 = categoryAxis3.getCategoryEnd(0, (int) (short) 100, rectangle2D24, rectangleEdge26);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle29.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str32 = rectangleEdge31.toString();
        textTitle29.setPosition(rectangleEdge31);
        double double34 = categoryAxis0.getCategoryEnd((int) (short) 1, (int) (byte) 10, rectangle2D24, rectangleEdge31);
        categoryAxis0.setCategoryLabelPositionOffset((int) (byte) 1);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "RectangleEdge.TOP" + "'", str32.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart3.getPadding();
        org.jfree.chart.event.ChartProgressListener chartProgressListener5 = null;
        jFreeChart3.removeProgressListener(chartProgressListener5);
        int int7 = jFreeChart3.getSubtitleCount();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.PiePlotState piePlotState10 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo9);
        org.jfree.chart.util.UnitType unitType11 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType11, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType11, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle22.getBounds();
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets21.createOutsetRectangle(rectangle2D23, true, true);
        piePlotState10.setLinkArea(rectangle2D26);
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        xYPlot28.clearRangeAxes();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D35 = textTitle34.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double37 = categoryAxis31.getCategoryStart(255, (int) (short) -1, rectangle2D35, rectangleEdge36);
        java.awt.geom.Point2D point2D38 = null;
        org.jfree.chart.plot.PlotState plotState39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        xYPlot28.draw(graphics2D30, rectangle2D35, point2D38, plotState39, plotRenderingInfo40);
        piePlotState10.setExplodedPieArea(rectangle2D35);
        try {
            jFreeChart3.draw(graphics2D8, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font2);
        java.awt.Color color4 = java.awt.Color.orange;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font2, (java.awt.Paint) color4, (float) (-1), textMeasurer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D3 = textTitle2.getBounds();
        java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D3);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = piePlot2.getLabelDistributor();
        piePlot0.setLabelDistributor(abstractPieLabelDistributor3);
        java.awt.Paint paint5 = piePlot0.getLabelOutlinePaint();
        piePlot0.setNoDataMessage("Rotation.ANTICLOCKWISE");
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape3);
        numberAxis2.setUpArrow(shape3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean7 = numberAxis2.equals((java.lang.Object) color6);
        org.jfree.chart.util.ObjectList objectList8 = new org.jfree.chart.util.ObjectList();
        int int10 = objectList8.indexOf((java.lang.Object) 1);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        int int12 = objectList8.indexOf((java.lang.Object) stroke11);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color6, stroke11);
        java.awt.Stroke stroke14 = valueMarker13.getStroke();
        java.lang.Class class15 = null;
        try {
            java.util.EventListener[] eventListenerArray16 = valueMarker13.getListeners(class15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        double double7 = piePlot0.getLabelGap();
        org.jfree.data.general.PieDataset pieDataset8 = piePlot0.getDataset();
        try {
            piePlot0.setInteriorGap((double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (-1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025d + "'", double7 == 0.025d);
        org.junit.Assert.assertNull(pieDataset8);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image7 = null;
        projectInfo6.setLogo(image7);
        projectInfo6.setName("1.2.0-pre");
        java.util.List list11 = projectInfo6.getContributors();
        xYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot0.getDomainMarkers(layer13);
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = legendItemCollection0.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = null;
        try {
            legendItemCollection0.addAll(legendItemCollection2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        multiplePiePlot1.setDataset(categoryDataset2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        multiplePiePlot1.handleClick((int) '#', 10, plotRenderingInfo6);
        java.lang.Comparable comparable8 = multiplePiePlot1.getAggregatedItemsKey();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + "Other" + "'", comparable8.equals("Other"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit3, false, false);
        java.awt.Font font7 = numberAxis2.getLabelFont();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        int int9 = xYPlot8.getSeriesCount();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Rotation.ANTICLOCKWISE", font7, (org.jfree.chart.plot.Plot) xYPlot8, true);
        xYPlot8.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Paint paint2 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.data.Range range6 = xYPlot0.getDataRange(valueAxis5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        int int8 = xYPlot0.indexOf(xYDataset7);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textTitle1.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment3, (double) 'a', (double) (byte) 0);
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment3, (double) 64, 90.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, false, false);
        numberAxis3.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3.getLabelInsets();
        boolean boolean11 = xYPlot0.equals((java.lang.Object) rectangleInsets10);
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = waferMapPlot0.getDataset();
        org.junit.Assert.assertNull(waferMapDataset1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        piePlot0.setOutlinePaint((java.awt.Paint) color9);
        java.awt.Paint paint11 = null;
        try {
            piePlot0.setNoDataMessagePaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker3.getLabelOffset();
        java.awt.Paint paint5 = valueMarker3.getOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = valueMarker3.getLabelOffset();
        org.jfree.chart.util.Layer layer7 = null;
        try {
            boolean boolean8 = categoryPlot0.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker3, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor2 = piePlot1.getLabelDistributor();
        java.awt.Paint paint3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot1.setLabelBackgroundPaint(paint3);
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        piePlot1.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color6);
        boolean boolean8 = chartChangeEventType0.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 0.2d, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) '4', (double) 100L, (double) 0.0f, (double) (-16744448));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart3.clearSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        try {
            java.awt.image.BufferedImage bufferedImage9 = jFreeChart3.createBufferedImage((int) (byte) -1, (int) (byte) 10, 2, chartRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (10) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType3 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets14.getUnitType();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle16.getBounds();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets14.createInsetRectangle(rectangle2D17);
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets13.createOutsetRectangle(rectangle2D17, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double23 = categoryAxis0.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D21, rectangleEdge22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis29.setTickUnit(numberTickUnit30, false, false);
        numberAxis29.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle();
        textTitle36.setExpandToFitSpace(false);
        java.lang.String str39 = textTitle36.getURLText();
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle36.getBounds();
        numberAxis29.setDownArrow((java.awt.Shape) rectangle2D40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge42);
        double double44 = categoryAxis0.getCategoryMiddle((int) (byte) 100, (int) (short) -1, rectangle2D40, rectangleEdge43);
        categoryAxis0.setMaximumCategoryLabelLines((int) (byte) 0);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(numberTickUnit30);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperBound();
        java.awt.Paint paint3 = null;
        try {
            numberAxis1.setAxisLinePaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        boolean boolean2 = color0.equals((java.lang.Object) textLine1);
        boolean boolean4 = textLine1.equals((java.lang.Object) (short) 1);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font6);
        textLine1.addFragment(textFragment7);
        float float9 = textFragment7.getBaselineOffset();
        java.awt.Font font10 = textFragment7.getFont();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 100, axisLocation3, true);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Paint[] paintArray0 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7 };
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray10 = new java.awt.Shape[] { shape9 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray8, shapeArray10);
        java.awt.Stroke stroke12 = defaultDrawingSupplier11.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shapeArray10);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Multiple Pie Plot");
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", graphics2D1, 0.0f, (float) 1L, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.clearRangeAxes();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle12.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double15 = categoryAxis9.getCategoryStart(255, (int) (short) -1, rectangle2D13, rectangleEdge14);
        java.awt.geom.Point2D point2D16 = null;
        org.jfree.chart.plot.PlotState plotState17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        xYPlot6.draw(graphics2D8, rectangle2D13, point2D16, plotState17, plotRenderingInfo18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge20);
        double double22 = dateAxis4.valueToJava2D((double) 10, rectangle2D13, rectangleEdge21);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.clearRangeAxes();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle29.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double32 = categoryAxis26.getCategoryStart(255, (int) (short) -1, rectangle2D30, rectangleEdge31);
        java.awt.geom.Point2D point2D33 = null;
        org.jfree.chart.plot.PlotState plotState34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        xYPlot23.draw(graphics2D25, rectangle2D30, point2D33, plotState34, plotRenderingInfo35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean38 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        try {
            org.jfree.chart.axis.AxisState axisState40 = dateAxis0.draw(graphics2D2, 0.0d, rectangle2D13, rectangle2D30, rectangleEdge37, plotRenderingInfo39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = null;
        try {
            categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(pieSectionLabelGenerator10);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Other", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart3.getPadding();
        java.awt.Image image5 = null;
        jFreeChart3.setBackgroundImage(image5);
        boolean boolean7 = jFreeChart3.getAntiAlias();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot8 = jFreeChart3.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.WaferMapPlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(arrangement1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("org.jfree.chart.event.ChartChangeEvent[source=0]", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart3.getPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        try {
            java.awt.image.BufferedImage bufferedImage8 = jFreeChart3.createBufferedImage(1, (-1), chartRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (1) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("org.jfree.chart.event.ChartChangeEvent[source=0]", graphics2D1, (float) (-16744448), (float) (byte) 100, (double) 10L, 0.0f, (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle0.getMargin();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle0.getVerticalAlignment();
        textTitle0.setToolTipText("RectangleEdge.TOP");
        double double6 = textTitle0.getContentYOffset();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("org.jfree.chart.event.ChartChangeEvent[source=0]");
        float float2 = categoryAxis3D1.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setUpperMargin(1.0d);
        numberAxis2.setAutoTickUnitSelection(true, false);
        java.awt.Stroke stroke8 = numberAxis2.getTickMarkStroke();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        textTitle9.setExpandToFitSpace(false);
        java.lang.String str12 = textTitle9.getURLText();
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle9.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle9.getMargin();
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke8, rectangleInsets14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle19.getBounds();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets17.createInsetRectangle(rectangle2D20);
        lineBorder15.draw(graphics2D16, rectangle2D20);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit3, false, false);
        java.awt.Font font7 = numberAxis2.getLabelFont();
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot8.getLabelDistributor();
        double double10 = piePlot8.getStartAngle();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        piePlot8.setLabelBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("Rotation.ANTICLOCKWISE", font7, (java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        try {
            java.lang.Object obj3 = jFreeChartResources0.getObject("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key hi!");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeAxes();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double11 = categoryAxis5.getCategoryStart(255, (int) (short) -1, rectangle2D9, rectangleEdge10);
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot2.draw(graphics2D4, rectangle2D9, point2D12, plotState13, plotRenderingInfo14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge16);
        double double18 = dateAxis0.valueToJava2D((double) 10, rectangle2D9, rectangleEdge17);
        java.lang.Object obj19 = dateAxis0.clone();
        try {
            dateAxis0.setRange((double) 100.0f, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeAxes();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double11 = categoryAxis5.getCategoryStart(255, (int) (short) -1, rectangle2D9, rectangleEdge10);
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot2.draw(graphics2D4, rectangle2D9, point2D12, plotState13, plotRenderingInfo14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge16);
        double double18 = dateAxis0.valueToJava2D((double) 10, rectangle2D9, rectangleEdge17);
        org.jfree.data.Range range19 = null;
        try {
            dateAxis0.setRangeWithMargins(range19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setNegativeArrowVisible(false);
        java.lang.String str6 = numberAxis1.getLabelURL();
        numberAxis1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart3.clearSubtitles();
        jFreeChart3.setNotify(false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color4);
        boolean boolean6 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 1, axisLocation8, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        try {
            xYPlot0.addRangeMarker(marker16, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("RectangleConstraintType.RANGE", 255, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0d);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = chartChangeEvent1.getType();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.setUpperMargin(0.025d);
        org.jfree.data.RangeType rangeType8 = numberAxis1.getRangeType();
        java.awt.Paint paint9 = numberAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(rangeType8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D1 = xYPlot0.getQuadrantOrigin();
        xYPlot0.setRangeCrosshairValue((double) 10L);
        org.junit.Assert.assertNotNull(point2D1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        org.jfree.chart.util.SortOrder sortOrder16 = null;
        try {
            categoryPlot15.setColumnRenderingOrder(sortOrder16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType3 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets14.getUnitType();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle16.getBounds();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets14.createInsetRectangle(rectangle2D17);
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets13.createOutsetRectangle(rectangle2D17, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double23 = categoryAxis0.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D21, rectangleEdge22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color24);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (byte) -1, "java.awt.Color[r=128,g=128,b=255]");
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color4);
        boolean boolean6 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 1, axisLocation8, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.resizeRange((double) 255);
        java.awt.Shape shape8 = numberAxis1.getRightArrow();
        boolean boolean9 = numberAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        piePlot0.setDataset(pieDataset2);
        java.awt.Paint paint4 = piePlot0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        numberAxis1.setUpArrow(shape2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean6 = numberAxis1.equals((java.lang.Object) color5);
        numberAxis1.setRangeAboutValue((double) ' ', (double) 10L);
        numberAxis1.setAutoRangeMinimumSize((double) '4', false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, false, false);
        numberAxis3.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3.getLabelInsets();
        boolean boolean11 = xYPlot0.equals((java.lang.Object) rectangleInsets10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = new org.jfree.chart.LegendItemCollection();
        xYPlot0.setFixedLegendItems(legendItemCollection12);
        java.awt.Stroke stroke14 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            xYPlot0.handleClick((int) (short) 10, (int) (short) -1, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("UnitType.ABSOLUTE", graphics2D1, (float) 100L, (float) ' ', (double) '4', (float) 2, (float) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, false, false);
        numberAxis3.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3.getLabelInsets();
        boolean boolean11 = xYPlot0.equals((java.lang.Object) rectangleInsets10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = new org.jfree.chart.LegendItemCollection();
        xYPlot0.setFixedLegendItems(legendItemCollection12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot0.getDomainAxis((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=128,g=128,b=255]", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "1.2.0-pre");
        java.lang.String str5 = basicProjectInfo4.getCopyright();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit3, false, false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.UnitType unitType9 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets20.getUnitType();
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle22.getBounds();
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets20.createInsetRectangle(rectangle2D23);
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets19.createOutsetRectangle(rectangle2D23, true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType29 = rectangleInsets28.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor31 = piePlot30.getLabelDistributor();
        java.awt.Paint paint32 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot30.setLabelBackgroundPaint(paint32);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator34 = piePlot30.getLegendLabelURLGenerator();
        java.awt.Paint paint35 = piePlot30.getBaseSectionOutlinePaint();
        boolean boolean36 = rectangleInsets28.equals((java.lang.Object) piePlot30);
        org.jfree.chart.util.UnitType unitType37 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets(unitType37, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = new org.jfree.chart.util.RectangleInsets(unitType37, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType49 = rectangleInsets48.getUnitType();
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D51 = textTitle50.getBounds();
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets48.createInsetRectangle(rectangle2D51);
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets47.createOutsetRectangle(rectangle2D51, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType56 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets28.createAdjustedRectangle(rectangle2D51, lengthAdjustmentType56, lengthAdjustmentType57);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment60 = textTitle59.getHorizontalAlignment();
        double double61 = textTitle59.getHeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge62);
        textTitle59.setPosition(rectangleEdge62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        try {
            org.jfree.chart.axis.AxisState axisState66 = dateAxis0.draw(graphics2D7, 0.0d, rectangle2D27, rectangle2D51, rectangleEdge62, plotRenderingInfo65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(unitType29);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(pieURLGenerator34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(unitType37);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(unitType49);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(horizontalAlignment60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "{0}", "", "1.2.0-pre", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle0.getMargin();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle0.getVerticalAlignment();
        java.awt.Paint paint4 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray26, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray30);
        categoryPlot15.setDataset(1, categoryDataset31);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset31, false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(range34);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("UnitType.ABSOLUTE", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleConstraintType.RANGE", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray11);
        try {
            java.lang.Number number13 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0d);
        org.jfree.chart.JFreeChart jFreeChart2 = chartChangeEvent1.getChart();
        org.junit.Assert.assertNull(jFreeChart2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        boolean boolean2 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        try {
            java.awt.Color color1 = java.awt.Color.decode("{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"{0}\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) 'a', (double) (byte) 0);
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        boolean boolean7 = verticalAlignment2.equals((java.lang.Object) font6);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot0.getLabelDistributor();
        piePlot0.setIgnoreZeroValues(true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        xYPlot0.axisChanged(axisChangeEvent4);
        boolean boolean6 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.clearDomainMarkers((int) (byte) -1);
        double double9 = xYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        categoryPlot0.setRenderer(3, categoryItemRenderer2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = valueMarker6.getLabelOffset();
        try {
            boolean boolean8 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Paint paint4 = piePlot0.getLabelShadowPaint();
        piePlot0.setExplodePercent((java.lang.Comparable) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", (double) 100.0f);
        boolean boolean8 = piePlot0.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D1 = xYPlot0.getQuadrantOrigin();
        java.awt.Paint paint2 = xYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(point2D1);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, plot2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) chartEntity1);
        java.lang.String str3 = chartEntity1.getURLText();
        java.lang.String str4 = chartEntity1.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str4.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.String str2 = textTitle0.getURLText();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Color color1 = java.awt.Color.getColor("1.2.0-pre version 1.2.0-pre.\nRotation.ANTICLOCKWISE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY 1.2.0-pre:None\n1.2.0-pre LICENCE TERMS:\nRectangleEdge.TOP");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        java.awt.Paint paint4 = dateAxis0.getAxisLinePaint();
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        java.lang.Object obj1 = null;
        boolean boolean2 = textAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = piePlot0.getBaseSectionOutlinePaint();
        piePlot0.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot0.getLabelPadding();
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor15 = piePlot14.getLabelDistributor();
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("", font18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("hi!", font18, (java.awt.Paint) color20);
        piePlot14.setLabelOutlinePaint((java.awt.Paint) color20);
        java.awt.Paint paint23 = piePlot14.getBaseSectionOutlinePaint();
        piePlot14.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = piePlot14.getLabelPadding();
        piePlot0.setLabelPadding(rectangleInsets27);
        boolean boolean29 = piePlot0.getLabelLinksVisible();
        java.lang.Object obj30 = piePlot0.clone();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = piePlot2.getLabelDistributor();
        piePlot0.setLabelDistributor(abstractPieLabelDistributor3);
        java.awt.Paint paint5 = piePlot0.getLabelOutlinePaint();
        java.awt.Paint paint6 = piePlot0.getLabelBackgroundPaint();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Paint paint2 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj7 = dateAxis6.clone();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double10 = numberAxis9.getUpperBound();
        boolean boolean11 = numberAxis9.isTickMarksVisible();
        boolean boolean12 = numberAxis9.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot13 = numberAxis9.getPlot();
        org.jfree.data.Range range14 = numberAxis9.getDefaultAutoRange();
        dateAxis6.setRange(range14, true, false);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperBound();
        boolean boolean4 = numberAxis2.isTickMarksVisible();
        boolean boolean5 = numberAxis2.isNegativeArrowVisible();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis8.setTickUnit(numberTickUnit9, false, false);
        java.awt.Font font13 = numberAxis8.getLabelFont();
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        int int15 = xYPlot14.getSeriesCount();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("Rotation.ANTICLOCKWISE", font13, (org.jfree.chart.plot.Plot) xYPlot14, true);
        numberAxis2.setLabelFont(font13);
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor20 = piePlot19.getLabelDistributor();
        java.awt.Paint paint21 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot19.setLabelBackgroundPaint(paint21);
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        piePlot19.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color24);
        int int26 = piePlot19.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator27 = piePlot19.getURLGenerator();
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_YELLOW;
        piePlot19.setOutlinePaint((java.awt.Paint) color28);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer32 = new org.jfree.chart.text.G2TextMeasurer(graphics2D31);
        try {
            org.jfree.chart.text.TextBlock textBlock33 = org.jfree.chart.text.TextUtilities.createTextBlock("Multiple Pie Plot", font13, (java.awt.Paint) color28, (float) 3, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNull(pieURLGenerator27);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("org.jfree.chart.event.ChartChangeEvent[source=0]");
        boolean boolean2 = categoryAxis3D1.isTickMarksVisible();
        java.lang.Object obj3 = categoryAxis3D1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = piePlot2.getLabelDistributor();
        piePlot0.setLabelDistributor(abstractPieLabelDistributor3);
        java.awt.Paint paint5 = piePlot0.getLabelOutlinePaint();
        piePlot0.setLabelLinkMargin((double) 2);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        textTitle0.setPosition(rectangleEdge2);
        textTitle0.setID("");
        textTitle0.setText("hi!");
        org.jfree.chart.block.BlockBorder blockBorder9 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean11 = blockBorder9.equals((java.lang.Object) textAnchor10);
        textTitle0.setFrame((org.jfree.chart.block.BlockFrame) blockBorder9);
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertNotNull(blockBorder9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        double double2 = piePlotState1.getPieCenterY();
        double double3 = piePlotState1.getPieWRadius();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.util.Iterator iterator1 = legendItemCollection0.iterator();
        org.junit.Assert.assertNotNull(iterator1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxisForDataset((int) (byte) 100);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis4.setVerticalTickLabels(false);
        boolean boolean8 = numberAxis4.equals((java.lang.Object) (-1L));
        int int9 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            categoryPlot0.handleClick((int) (short) 10, (int) (short) 1, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.calculateRightInset((double) (byte) 0);
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot4.getLabelDistributor();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("", font8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font8, (java.awt.Paint) color10);
        piePlot4.setLabelOutlinePaint((java.awt.Paint) color10);
        java.awt.Paint paint13 = piePlot4.getBaseSectionOutlinePaint();
        piePlot4.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = piePlot4.getLabelPadding();
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor19 = piePlot18.getLabelDistributor();
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("", font22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine("hi!", font22, (java.awt.Paint) color24);
        piePlot18.setLabelOutlinePaint((java.awt.Paint) color24);
        java.awt.Paint paint27 = piePlot18.getBaseSectionOutlinePaint();
        piePlot18.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = piePlot18.getLabelPadding();
        piePlot4.setLabelPadding(rectangleInsets31);
        boolean boolean33 = piePlot4.getLabelLinksVisible();
        boolean boolean34 = rectangleInsets0.equals((java.lang.Object) piePlot4);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("{0}");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            float float4 = textFragment1.calculateBaselineOffset(graphics2D2, textAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setExpandToFitSpace(false);
        java.lang.String str3 = textTitle0.getURLText();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle0.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle0.getMargin();
        boolean boolean6 = textTitle0.getNotify();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis8.setTickUnit(numberTickUnit9, false, false);
        numberAxis8.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis8.getLabelInsets();
        java.lang.String str16 = numberAxis8.getLabelToolTip();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        numberAxis8.setLabelFont(font17);
        textTitle0.setFont(font17);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape3);
        numberAxis2.setUpArrow(shape3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean7 = numberAxis2.equals((java.lang.Object) color6);
        int int8 = color6.getGreen();
        java.awt.color.ColorSpace colorSpace9 = color6.getColorSpace();
        float[] floatArray18 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray19 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray18);
        float[] floatArray20 = color0.getColorComponents(colorSpace9, floatArray18);
        java.awt.Color color21 = java.awt.Color.CYAN;
        java.awt.color.ColorSpace colorSpace22 = color21.getColorSpace();
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("", font25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine28 = new org.jfree.chart.text.TextLine("hi!", font25, (java.awt.Paint) color27);
        int int29 = color27.getAlpha();
        float[] floatArray38 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray39 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray38);
        float[] floatArray40 = color27.getColorComponents(floatArray39);
        float[] floatArray41 = color0.getComponents(colorSpace22, floatArray39);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(colorSpace22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 255 + "'", int29 == 255);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray26, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray30);
        categoryPlot15.setDataset(1, categoryDataset31);
        try {
            org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset31, (java.lang.Comparable) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot15.getRenderer(0);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray26, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray30);
        categoryPlot15.setDataset(categoryDataset31);
        java.awt.Paint paint33 = categoryPlot15.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryItemRenderer18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image7 = null;
        projectInfo6.setLogo(image7);
        projectInfo6.setName("1.2.0-pre");
        java.util.List list11 = projectInfo6.getContributors();
        xYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list11);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = valueMarker15.getLabelOffset();
        org.jfree.chart.util.Layer layer17 = null;
        try {
            xYPlot0.addDomainMarker(10, (org.jfree.chart.plot.Marker) valueMarker15, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType3 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets14.getUnitType();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle16.getBounds();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets14.createInsetRectangle(rectangle2D17);
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets13.createOutsetRectangle(rectangle2D17, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double23 = categoryAxis0.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D21, rectangleEdge22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis29.setTickUnit(numberTickUnit30, false, false);
        numberAxis29.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle();
        textTitle36.setExpandToFitSpace(false);
        java.lang.String str39 = textTitle36.getURLText();
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle36.getBounds();
        numberAxis29.setDownArrow((java.awt.Shape) rectangle2D40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge42);
        double double44 = categoryAxis0.getCategoryMiddle((int) (byte) 100, (int) (short) -1, rectangle2D40, rectangleEdge43);
        int int45 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(numberTickUnit30);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearDomainMarkers();
        boolean boolean2 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot3.getLabelDistributor();
        java.awt.Paint paint5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot3.setLabelBackgroundPaint(paint5);
        xYPlot0.setRangeZeroBaselinePaint(paint5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(false);
        boolean boolean4 = numberAxis1.isAutoRange();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = piePlot5.getLabelDistributor();
        java.awt.Paint paint7 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot5.setLabelBackgroundPaint(paint7);
        java.awt.Color color10 = java.awt.Color.LIGHT_GRAY;
        piePlot5.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color10);
        int int12 = piePlot5.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot5.getURLGenerator();
        java.awt.Color color15 = java.awt.Color.DARK_GRAY;
        piePlot5.setSectionOutlinePaint((java.lang.Comparable) "Multiple Pie Plot", (java.awt.Paint) color15);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator17 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot5.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator17);
        java.text.NumberFormat numberFormat19 = standardPieSectionLabelGenerator17.getNumberFormat();
        numberAxis1.setNumberFormatOverride(numberFormat19);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(numberFormat19);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxisForDataset((int) (byte) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot3.setRenderer(3, categoryItemRenderer5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot3.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9);
        categoryPlot0.mapDatasetToDomainAxis((int) (byte) 10, (-1));
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color4);
        xYPlot0.setDomainCrosshairValue(0.0d);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        categoryPlot0.setRenderer(3, categoryItemRenderer2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color4);
        boolean boolean6 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 1, axisLocation8, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D20 = xYPlot19.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes(0.0d, (double) 15, plotRenderingInfo18, point2D20);
        java.awt.Image image22 = xYPlot0.getBackgroundImage();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertNull(image22);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = piePlot0.getLabelPadding();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        java.awt.Paint paint3 = valueMarker1.getOutlinePaint();
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = piePlot4.getLabelDistributor();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("", font8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font8, (java.awt.Paint) color10);
        piePlot4.setLabelOutlinePaint((java.awt.Paint) color10);
        java.awt.Paint paint13 = piePlot4.getBaseSectionOutlinePaint();
        piePlot4.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        piePlot4.setMinimumArcAngleToDraw((double) 100L);
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) piePlot4);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int21 = color20.getRed();
        piePlot4.setBackgroundPaint((java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        numberAxis1.setUpArrow(shape2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean6 = numberAxis1.equals((java.lang.Object) color5);
        numberAxis1.setRangeAboutValue((double) ' ', (double) 10L);
        numberAxis1.setAutoRangeMinimumSize((double) 0.5f, true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = piePlot0.getBaseSectionOutlinePaint();
        piePlot0.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        piePlot0.setSectionOutlinesVisible(false);
        java.awt.Paint paint15 = piePlot0.getLabelPaint();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        categoryPlot0.setRenderer(3, categoryItemRenderer2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = categoryPlot0.getLegendItems();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getDomainMarkers(0, layer6);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("Multiple Pie Plot", "Multiple Pie Plot", "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "Rotation.ANTICLOCKWISE");
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) "Multiple Pie Plot", (java.awt.Paint) color10);
        java.awt.Color color12 = java.awt.Color.orange;
        piePlot0.setOutlinePaint((java.awt.Paint) color12);
        java.awt.Stroke stroke15 = piePlot0.getSectionOutlineStroke((java.lang.Comparable) "Multiple Pie Plot");
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(stroke15);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.Class<?> wildcardClass2 = textBlockAnchor1.getClass();
        java.io.InputStream inputStream3 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("java.awt.Color[r=128,g=128,b=255]", (java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(inputStream3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
        java.lang.String str3 = licences0.getLGPL();
        java.lang.String str4 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color4);
        boolean boolean6 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 1, axisLocation8, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation15 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.clearRangeAxes();
        xYPlot1.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot1.zoomRangeAxes((double) 0L, plotRenderingInfo6, point2D7);
        xYPlot1.setDomainCrosshairLockedOnData(false);
        boolean boolean11 = rectangleInsets0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        xYPlot0.setDomainAxisLocation((int) (short) 100, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot0.getDomainMarkers(layer6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets9.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor12 = piePlot11.getLabelDistributor();
        java.awt.Paint paint13 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot11.setLabelBackgroundPaint(paint13);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = piePlot11.getLegendLabelURLGenerator();
        java.awt.Paint paint16 = piePlot11.getBaseSectionOutlinePaint();
        boolean boolean17 = rectangleInsets9.equals((java.lang.Object) piePlot11);
        org.jfree.chart.util.UnitType unitType18 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets(unitType18, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets(unitType18, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType30 = rectangleInsets29.getUnitType();
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D32 = textTitle31.getBounds();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets29.createInsetRectangle(rectangle2D32);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets28.createOutsetRectangle(rectangle2D32, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType37 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = rectangleInsets9.createAdjustedRectangle(rectangle2D32, lengthAdjustmentType37, lengthAdjustmentType38);
        try {
            xYPlot0.drawBackground(graphics2D8, rectangle2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(pieURLGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(unitType30);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D39);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image3 = null;
        projectInfo2.setLogo(image3);
        boolean boolean5 = textTitle0.equals((java.lang.Object) projectInfo2);
        java.lang.Object obj6 = textTitle0.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType6 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(unitType6, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType6, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle19.getBounds();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets17.createInsetRectangle(rectangle2D20);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets16.createOutsetRectangle(rectangle2D20, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double26 = categoryAxis3.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D24, rectangleEdge25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis3.setTickLabelPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis32.setTickUnit(numberTickUnit33, false, false);
        numberAxis32.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle();
        textTitle39.setExpandToFitSpace(false);
        java.lang.String str42 = textTitle39.getURLText();
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle39.getBounds();
        numberAxis32.setDownArrow((java.awt.Shape) rectangle2D43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge45);
        double double47 = categoryAxis3.getCategoryMiddle((int) (byte) 100, (int) (short) -1, rectangle2D43, rectangleEdge46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        xYPlot0.drawAnnotations(graphics2D2, rectangle2D43, plotRenderingInfo48);
        org.jfree.chart.entity.ChartEntity chartEntity51 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D43, "");
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(numberTickUnit33);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent2.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent2.getType();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis6.getLabelInsets();
        java.lang.String str14 = numberAxis6.getLabelToolTip();
        boolean boolean15 = chartChangeEventType4.equals((java.lang.Object) str14);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        xYPlot0.axisChanged(axisChangeEvent4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace6);
        xYPlot0.mapDatasetToDomainAxis(0, (int) (byte) 100);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setInfo("hi!");
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Paint paint4 = piePlot0.getLabelShadowPaint();
        java.awt.Stroke stroke5 = piePlot0.getLabelOutlineStroke();
        double double6 = piePlot0.getStartAngle();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 90.0d + "'", double6 == 90.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType3 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets14.getUnitType();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle16.getBounds();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets14.createInsetRectangle(rectangle2D17);
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets13.createOutsetRectangle(rectangle2D17, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double23 = categoryAxis0.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D21, rectangleEdge22);
        categoryAxis0.setUpperMargin((double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryAxis0.getLabelInsets();
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle3.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double6 = categoryAxis0.getCategoryStart(255, (int) (short) -1, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit11, false, false);
        numberAxis10.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        textTitle17.setExpandToFitSpace(false);
        java.lang.String str20 = textTitle17.getURLText();
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle17.getBounds();
        numberAxis10.setDownArrow((java.awt.Shape) rectangle2D21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge23);
        double double25 = categoryAxis0.getCategoryEnd(0, (int) (short) 100, rectangle2D21, rectangleEdge23);
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10L);
        java.awt.Color color28 = java.awt.Color.GRAY;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis30.setUpperMargin(1.0d);
        numberAxis30.setAutoTickUnitSelection(true, false);
        java.awt.Stroke stroke36 = numberAxis30.getTickMarkStroke();
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle();
        textTitle37.setExpandToFitSpace(false);
        java.lang.String str40 = textTitle37.getURLText();
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle37.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = textTitle37.getMargin();
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color28, stroke36, rectangleInsets42);
        categoryAxis0.setTickMarkStroke(stroke36);
        categoryAxis0.configure();
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (byte) 0, 1.0E-8d);
        size2D2.width = 1L;
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getUpperBound();
        boolean boolean5 = numberAxis3.isTickMarksVisible();
        boolean boolean6 = numberAxis3.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot7 = numberAxis3.getPlot();
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        dateAxis0.setRange(range8, true, false);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range8, (org.jfree.data.Range) dateRange12);
        java.lang.String str14 = rectangleConstraint13.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint13.getHeightConstraintType();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj17 = dateAxis16.clone();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double20 = numberAxis19.getUpperBound();
        boolean boolean21 = numberAxis19.isTickMarksVisible();
        boolean boolean22 = numberAxis19.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot23 = numberAxis19.getPlot();
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        dateAxis16.setRange(range24, true, false);
        org.jfree.data.time.DateRange dateRange28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range24, (org.jfree.data.Range) dateRange28);
        java.lang.String str30 = rectangleConstraint29.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType31 = rectangleConstraint29.getHeightConstraintType();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double34 = numberAxis33.getUpperBound();
        boolean boolean35 = numberAxis33.isTickMarksVisible();
        boolean boolean36 = numberAxis33.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot37 = numberAxis33.getPlot();
        org.jfree.data.Range range38 = numberAxis33.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint29.toRangeWidth(range38);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint13.toRangeWidth(range38);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str14.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(plot23);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(dateRange28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str30.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(plot37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        org.jfree.chart.util.UnitType unitType4 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        double double16 = rectangleInsets14.calculateRightOutset((double) 'a');
        piePlot0.setInsets(rectangleInsets14, true);
        double double19 = piePlot0.getLabelGap();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.clearRangeAxes();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle26.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double29 = categoryAxis23.getCategoryStart(255, (int) (short) -1, rectangle2D27, rectangleEdge28);
        java.awt.geom.Point2D point2D30 = null;
        org.jfree.chart.plot.PlotState plotState31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        xYPlot20.draw(graphics2D22, rectangle2D27, point2D30, plotState31, plotRenderingInfo32);
        java.awt.Stroke stroke34 = xYPlot20.getDomainCrosshairStroke();
        piePlot0.setBaseSectionOutlineStroke(stroke34);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-48.743718592964825d) + "'", double16 == (-48.743718592964825d));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.025d + "'", double19 == 0.025d);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getDepthFactor();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.12d + "'", double2 == 0.12d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        waferMapPlot2.setRenderer(waferMapRenderer4);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.AxisState axisState17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis19.setTickUnit(numberTickUnit20, false, false);
        numberAxis19.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        textTitle26.setExpandToFitSpace(false);
        java.lang.String str29 = textTitle26.getURLText();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle26.getBounds();
        numberAxis19.setDownArrow((java.awt.Shape) rectangle2D30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D39 = textTitle38.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double41 = categoryAxis35.getCategoryStart(255, (int) (short) -1, rectangle2D39, rectangleEdge40);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit46 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis45.setTickUnit(numberTickUnit46, false, false);
        numberAxis45.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle52 = new org.jfree.chart.title.TextTitle();
        textTitle52.setExpandToFitSpace(false);
        java.lang.String str55 = textTitle52.getURLText();
        java.awt.geom.Rectangle2D rectangle2D56 = textTitle52.getBounds();
        numberAxis45.setDownArrow((java.awt.Shape) rectangle2D56);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge58);
        double double60 = categoryAxis35.getCategoryEnd(0, (int) (short) 100, rectangle2D56, rectangleEdge58);
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D62 = textTitle61.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str64 = rectangleEdge63.toString();
        textTitle61.setPosition(rectangleEdge63);
        double double66 = categoryAxis32.getCategoryEnd((int) (short) 1, (int) (byte) 10, rectangle2D56, rectangleEdge63);
        java.util.List list67 = categoryAxis1.refreshTicks(graphics2D16, axisState17, rectangle2D30, rectangleEdge63);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit46);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "RectangleEdge.TOP" + "'", str64.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(list67);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setCategoryLabelPositionOffset(2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        double double7 = rectangleInsets4.calculateRightInset((double) (byte) 0);
        categoryAxis1.setTickLabelInsets(rectangleInsets4);
        boolean boolean9 = legendItemCollection0.equals((java.lang.Object) categoryAxis1);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeAxes();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double11 = categoryAxis5.getCategoryStart(255, (int) (short) -1, rectangle2D9, rectangleEdge10);
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot2.draw(graphics2D4, rectangle2D9, point2D12, plotState13, plotRenderingInfo14);
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        xYPlot2.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = xYPlot2.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        int int20 = xYPlot2.indexOf(xYDataset19);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("1.2.0-pre", font1, (org.jfree.chart.plot.Plot) xYPlot2, true);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart22.getTitle();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(textTitle23);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape3);
        numberAxis2.setUpArrow(shape3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean7 = numberAxis2.equals((java.lang.Object) color6);
        org.jfree.chart.util.ObjectList objectList8 = new org.jfree.chart.util.ObjectList();
        int int10 = objectList8.indexOf((java.lang.Object) 1);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        int int12 = objectList8.indexOf((java.lang.Object) stroke11);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color6, stroke11);
        try {
            valueMarker13.setAlpha((float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        java.lang.String str3 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit3, false, false);
        java.awt.Font font7 = numberAxis2.getLabelFont();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        int int9 = xYPlot8.getSeriesCount();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Rotation.ANTICLOCKWISE", font7, (org.jfree.chart.plot.Plot) xYPlot8, true);
        java.awt.Color color12 = java.awt.Color.lightGray;
        xYPlot8.setDomainCrosshairPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Paint paint2 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        xYPlot0.clearDomainAxes();
        java.lang.Object obj7 = xYPlot0.clone();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getUpperBound();
        boolean boolean5 = numberAxis3.isTickMarksVisible();
        boolean boolean6 = numberAxis3.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot7 = numberAxis3.getPlot();
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        dateAxis0.setRange(range8, true, false);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range8, (org.jfree.data.Range) dateRange12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj15 = dateAxis14.clone();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getUpperBound();
        boolean boolean19 = numberAxis17.isTickMarksVisible();
        boolean boolean20 = numberAxis17.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot21 = numberAxis17.getPlot();
        org.jfree.data.Range range22 = numberAxis17.getDefaultAutoRange();
        dateAxis14.setRange(range22, true, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint13.toRangeWidth(range22);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint26.toUnconstrainedWidth();
        double double28 = rectangleConstraint27.getHeight();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        numberAxis1.setAutoTickUnitSelection(true, false);
        java.awt.Stroke stroke7 = numberAxis1.getTickMarkStroke();
        try {
            numberAxis1.setRangeWithMargins((double) (short) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit3, false, false);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.clearRangeAxes();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle14.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double17 = categoryAxis11.getCategoryStart(255, (int) (short) -1, rectangle2D15, rectangleEdge16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        xYPlot8.draw(graphics2D10, rectangle2D15, point2D18, plotState19, plotRenderingInfo20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        double double24 = dateAxis0.valueToJava2D((double) 1.0f, rectangle2D15, rectangleEdge23);
        try {
            dateAxis0.setRange(0.0d, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("http://www.jfree.org/jfreechart/index.html", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "RectangleEdge.TOP", "http://www.jfree.org/jfreechart/index.html");
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.util.Locale locale1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.Class<?> wildcardClass3 = textBlockAnchor2.getClass();
        java.lang.ClassLoader classLoader4 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass3);
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("", locale1, classLoader4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(classLoader4);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets20.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor23 = piePlot22.getLabelDistributor();
        java.awt.Paint paint24 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot22.setLabelBackgroundPaint(paint24);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator26 = piePlot22.getLegendLabelURLGenerator();
        java.awt.Paint paint27 = piePlot22.getBaseSectionOutlinePaint();
        boolean boolean28 = rectangleInsets20.equals((java.lang.Object) piePlot22);
        org.jfree.chart.util.UnitType unitType29 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType41 = rectangleInsets40.getUnitType();
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle42.getBounds();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets40.createInsetRectangle(rectangle2D43);
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets39.createOutsetRectangle(rectangle2D43, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets20.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType48, lengthAdjustmentType49);
        xYPlot0.drawBackgroundImage(graphics2D19, rectangle2D50);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray52 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray52);
        java.awt.Paint paint55 = xYPlot0.getQuadrantPaint(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D60 = xYPlot59.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) (-1L), 0.025d, plotRenderingInfo58, point2D60);
        org.jfree.data.category.CategoryDataset categoryDataset62 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot63 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset62);
        java.awt.Stroke stroke64 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot63.setOutlineStroke(stroke64);
        org.jfree.data.general.DatasetGroup datasetGroup66 = multiplePiePlot63.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset67 = null;
        multiplePiePlot63.setDataset(categoryDataset67);
        org.jfree.chart.plot.PiePlot piePlot69 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor70 = piePlot69.getLabelDistributor();
        java.awt.Font font73 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment74 = new org.jfree.chart.text.TextFragment("", font73);
        java.awt.Color color75 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine76 = new org.jfree.chart.text.TextLine("hi!", font73, (java.awt.Paint) color75);
        piePlot69.setLabelOutlinePaint((java.awt.Paint) color75);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent78 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot69);
        multiplePiePlot63.notifyListeners(plotChangeEvent78);
        xYPlot0.notifyListeners(plotChangeEvent78);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(pieURLGenerator26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(unitType29);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(unitType41);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(xYItemRendererArray52);
        org.junit.Assert.assertNull(paint55);
        org.junit.Assert.assertNotNull(point2D60);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNull(datasetGroup66);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor70);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertNotNull(color75);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isRangeZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot3.zoomDomainAxes((double) '4', plotRenderingInfo6, point2D7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor3 = piePlot2.getLabelDistributor();
        java.awt.Paint paint4 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot2.setLabelBackgroundPaint(paint4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot2.getLegendLabelURLGenerator();
        java.awt.Paint paint7 = piePlot2.getBaseSectionOutlinePaint();
        boolean boolean8 = rectangleInsets0.equals((java.lang.Object) piePlot2);
        double double10 = rectangleInsets0.extendHeight((double) 255);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 255.0d + "'", double10 == 255.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("org.jfree.chart.event.ChartChangeEvent[source=0]");
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot15.setDataset(categoryDataset18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent20);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.clearRangeAxes();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle30.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double33 = categoryAxis27.getCategoryStart(255, (int) (short) -1, rectangle2D31, rectangleEdge32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        xYPlot24.draw(graphics2D26, rectangle2D31, point2D34, plotState35, plotRenderingInfo36);
        java.awt.Color color38 = java.awt.Color.LIGHT_GRAY;
        xYPlot24.setRangeZeroBaselinePaint((java.awt.Paint) color38);
        java.awt.Stroke stroke40 = xYPlot24.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        int int42 = xYPlot24.indexOf(xYDataset41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("1.2.0-pre", font23, (org.jfree.chart.plot.Plot) xYPlot24, true);
        categoryPlot15.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        double double47 = categoryAxis46.getCategoryMargin();
        java.lang.String str49 = categoryAxis46.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        java.awt.Paint paint50 = categoryAxis46.getLabelPaint();
        categoryPlot15.setDomainAxis(categoryAxis46);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.2d + "'", double47 == 0.2d);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.String[] strArray3 = jFreeChartResources0.getStringArray("1.2.0-pre");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key 1.2.0-pre");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType6 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(unitType6, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType6, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle19.getBounds();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets17.createInsetRectangle(rectangle2D20);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets16.createOutsetRectangle(rectangle2D20, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double26 = categoryAxis3.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D24, rectangleEdge25);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D24, "{0}", "org.jfree.chart.event.ChartChangeEvent[source=0]");
        java.awt.geom.AffineTransform affineTransform30 = null;
        java.awt.RenderingHints renderingHints31 = null;
        java.awt.PaintContext paintContext32 = color0.createContext(colorModel1, rectangle2, rectangle2D24, affineTransform30, renderingHints31);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext32);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomRangeAxes((double) 0L, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxis((int) '4');
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = valueMarker11.getLabelOffset();
        java.awt.Paint paint13 = valueMarker11.getOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = valueMarker11.getLabelOffset();
        org.jfree.chart.util.Layer layer15 = null;
        try {
            boolean boolean16 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker11, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Color color0 = java.awt.Color.gray;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str1.equals("java.awt.Color[r=128,g=128,b=128]"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, false, false);
        numberAxis3.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3.getLabelInsets();
        boolean boolean11 = xYPlot0.equals((java.lang.Object) rectangleInsets10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis13.setTickUnit(numberTickUnit14, false, false);
        numberAxis13.resizeRange((double) 255);
        java.awt.Shape shape20 = numberAxis13.getRightArrow();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        double double23 = categoryAxis22.getCategoryMargin();
        java.lang.String str25 = categoryAxis22.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis27.setTickUnit(numberTickUnit28, false, false);
        numberAxis27.resizeRange((double) 255);
        java.awt.Shape shape34 = numberAxis27.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis27, categoryItemRenderer35);
        java.awt.Paint paint37 = categoryPlot36.getDomainGridlinePaint();
        numberAxis13.setLabelPaint(paint37);
        boolean boolean39 = numberAxis13.isVerticalTickLabels();
        org.jfree.data.Range range40 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(numberTickUnit28);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(range40);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str1.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit3, false, false);
        java.awt.Font font7 = numberAxis2.getLabelFont();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        int int9 = xYPlot8.getSeriesCount();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Rotation.ANTICLOCKWISE", font7, (org.jfree.chart.plot.Plot) xYPlot8, true);
        xYPlot8.mapDatasetToRangeAxis((int) '4', (int) (byte) 100);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = valueMarker17.getLabelOffset();
        org.jfree.chart.util.Layer layer19 = null;
        try {
            boolean boolean20 = xYPlot8.removeDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) valueMarker17, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomRangeAxes((double) 0L, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxis((int) '4');
        org.jfree.chart.plot.Plot plot10 = xYPlot0.getParent();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray11 = null;
        try {
            xYPlot0.setRenderers(xYItemRendererArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNull(plot10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot15.getFixedRangeAxisSpace();
        categoryPlot15.setOutlineVisible(true);
        org.jfree.chart.util.SortOrder sortOrder19 = null;
        try {
            categoryPlot15.setColumnRenderingOrder(sortOrder19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(axisSpace16);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 1L, (double) (-1), 0.0d, 0.0d);
        java.awt.Paint paint16 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder(rectangleInsets15, paint16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("");
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent2.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent2.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent2.setType(chartChangeEventType5);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets20.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor23 = piePlot22.getLabelDistributor();
        java.awt.Paint paint24 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot22.setLabelBackgroundPaint(paint24);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator26 = piePlot22.getLegendLabelURLGenerator();
        java.awt.Paint paint27 = piePlot22.getBaseSectionOutlinePaint();
        boolean boolean28 = rectangleInsets20.equals((java.lang.Object) piePlot22);
        org.jfree.chart.util.UnitType unitType29 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType41 = rectangleInsets40.getUnitType();
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle42.getBounds();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets40.createInsetRectangle(rectangle2D43);
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets39.createOutsetRectangle(rectangle2D43, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets20.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType48, lengthAdjustmentType49);
        xYPlot0.drawBackgroundImage(graphics2D19, rectangle2D50);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray52 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray52);
        xYPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        xYPlot57.clearRangeAxes();
        java.awt.Stroke stroke59 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot57.setRangeGridlineStroke(stroke59);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent61 = null;
        xYPlot57.axisChanged(axisChangeEvent61);
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot();
        xYPlot64.clearRangeAxes();
        java.awt.Stroke stroke66 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot64.setRangeGridlineStroke(stroke66);
        java.awt.Color color68 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot64.setRangeZeroBaselinePaint((java.awt.Paint) color68);
        boolean boolean70 = xYPlot64.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation72 = null;
        xYPlot64.setRangeAxisLocation((int) (short) 1, axisLocation72, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = null;
        java.awt.geom.Point2D point2D77 = null;
        xYPlot64.zoomRangeAxes(0.0d, plotRenderingInfo76, point2D77);
        org.jfree.chart.axis.AxisLocation axisLocation79 = xYPlot64.getDomainAxisLocation();
        xYPlot57.setRangeAxisLocation(64, axisLocation79);
        org.jfree.chart.plot.PlotOrientation plotOrientation81 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation79, plotOrientation81);
        try {
            xYPlot0.setDomainAxisLocation((int) (short) -1, axisLocation79, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(pieURLGenerator26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(unitType29);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(unitType41);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(xYItemRendererArray52);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(axisLocation79);
        org.junit.Assert.assertNotNull(plotOrientation81);
        org.junit.Assert.assertNotNull(rectangleEdge82);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        boolean boolean3 = textTitle0.equals((java.lang.Object) "(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean4 = textTitle0.getNotify();
        textTitle0.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot15.setDataset(categoryDataset18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot15.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNull(axisSpace20);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("hi!", font3, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font3);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean13 = blockBorder11.equals((java.lang.Object) textAnchor12);
        try {
            textLine7.draw(graphics2D8, 0.0f, (float) 100, textAnchor12, (float) 2, (float) 10, (-48.743718592964825d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot2.setOutlineStroke(stroke3);
        org.jfree.data.general.DatasetGroup datasetGroup5 = multiplePiePlot2.getDatasetGroup();
        boolean boolean6 = multiplePiePlot2.isSubplot();
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) chartChangeEventType0, (java.lang.Object) boolean6);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(datasetGroup5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis13.setTickUnit(numberTickUnit14, false, false);
        numberAxis13.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        textTitle20.setExpandToFitSpace(false);
        java.lang.String str23 = textTitle20.getURLText();
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle20.getBounds();
        numberAxis13.setDownArrow((java.awt.Shape) rectangle2D24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge26);
        double double28 = categoryAxis3.getCategoryEnd(0, (int) (short) 100, rectangle2D24, rectangleEdge26);
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle29.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str32 = rectangleEdge31.toString();
        textTitle29.setPosition(rectangleEdge31);
        double double34 = categoryAxis0.getCategoryEnd((int) (short) 1, (int) (byte) 10, rectangle2D24, rectangleEdge31);
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 'a');
        java.awt.Stroke stroke37 = categoryAxis0.getAxisLineStroke();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 0.2d);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "RectangleEdge.TOP" + "'", str32.equals("RectangleEdge.TOP"));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart3.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = jFreeChart3.getPadding();
        double double7 = rectangleInsets5.calculateRightOutset(101.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType3 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets14.getUnitType();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle16.getBounds();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets14.createInsetRectangle(rectangle2D17);
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets13.createOutsetRectangle(rectangle2D17, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double23 = categoryAxis0.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D21, rectangleEdge22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis29.setTickUnit(numberTickUnit30, false, false);
        numberAxis29.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle36 = new org.jfree.chart.title.TextTitle();
        textTitle36.setExpandToFitSpace(false);
        java.lang.String str39 = textTitle36.getURLText();
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle36.getBounds();
        numberAxis29.setDownArrow((java.awt.Shape) rectangle2D40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge42);
        double double44 = categoryAxis0.getCategoryMiddle((int) (byte) 100, (int) (short) -1, rectangle2D40, rectangleEdge43);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        xYPlot46.clearRangeAxes();
        java.awt.Stroke stroke48 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot46.setRangeGridlineStroke(stroke48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine51 = new org.jfree.chart.text.TextLine();
        boolean boolean52 = color50.equals((java.lang.Object) textLine51);
        float[] floatArray61 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray62 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray61);
        float[] floatArray63 = color50.getRGBComponents(floatArray62);
        xYPlot46.setDomainZeroBaselinePaint((java.awt.Paint) color50);
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 0.08d, (java.awt.Paint) color50);
        org.jfree.chart.plot.Plot plot66 = categoryAxis0.getPlot();
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(numberTickUnit30);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNull(plot66);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit3, false, false);
        java.awt.Font font7 = numberAxis2.getLabelFont();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        int int9 = xYPlot8.getSeriesCount();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("Rotation.ANTICLOCKWISE", font7, (org.jfree.chart.plot.Plot) xYPlot8, true);
        float float12 = xYPlot8.getBackgroundImageAlpha();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot8.getRangeMarkers(layer13);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateTopInset(100.0d);
        double double4 = rectangleInsets0.calculateBottomOutset((double) (-16744448));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot0.getToolTipGenerator();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.configure();
        org.jfree.chart.axis.Timeline timeline4 = dateAxis2.getTimeline();
        dateAxis0.setTimeline(timeline4);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(timeline4);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        valueMarker1.setValue(0.2d);
        org.jfree.chart.text.TextAnchor textAnchor5 = valueMarker1.getLabelTextAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        try {
            valueMarker1.setLabelOffsetType(lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 10L, (float) (-1L), textAnchor4, (double) 10.0f, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.awt.Paint[] paintArray0 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = new java.awt.Stroke[] {};
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Stroke[] strokeArray8 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7 };
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray10 = new java.awt.Shape[] { shape9 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray8, shapeArray10);
        java.lang.Object obj12 = defaultDrawingSupplier11.clone();
        try {
            java.awt.Stroke stroke13 = defaultDrawingSupplier11.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(strokeArray8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shapeArray10);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        numberAxis1.setUpArrow(shape2);
        double double5 = numberAxis1.getUpperMargin();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart3.getPadding();
        double double6 = rectangleInsets4.calculateTopOutset(0.14d);
        double double7 = rectangleInsets4.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = standardPieSectionLabelGenerator0.getAttributedLabel(3);
        org.junit.Assert.assertNull(attributedString2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Stroke stroke14 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        multiplePiePlot1.setOutlineStroke(stroke2);
        java.awt.Paint paint4 = multiplePiePlot1.getNoDataMessagePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = multiplePiePlot1.getInsets();
        double double6 = multiplePiePlot1.getLimit();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = multiplePiePlot1.getLegendItems();
        org.jfree.chart.plot.Plot plot8 = multiplePiePlot1.getRootPlot();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(plot8);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        piePlotState1.setLinkArea(rectangle2D2);
        piePlotState1.setPieWRadius((double) 10);
        piePlotState1.setPieCenterY((-5.0d));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (byte) 1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getLabelPadding();
        try {
            piePlot0.setInteriorGap((double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (10.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        java.lang.String str2 = horizontalAlignment1.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HorizontalAlignment.CENTER" + "'", str2.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        numberAxis3.setUpArrow(shape4);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean8 = numberAxis3.equals((java.lang.Object) color7);
        org.jfree.chart.util.ObjectList objectList9 = new org.jfree.chart.util.ObjectList();
        int int11 = objectList9.indexOf((java.lang.Object) 1);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        int int13 = objectList9.indexOf((java.lang.Object) stroke12);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color7, stroke12);
        java.awt.Stroke stroke15 = valueMarker14.getStroke();
        org.jfree.chart.util.UnitType unitType16 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets(unitType16, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets(unitType16, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType28 = rectangleInsets27.getUnitType();
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle29.getBounds();
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets27.createInsetRectangle(rectangle2D30);
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets26.createOutsetRectangle(rectangle2D30, true, false);
        org.jfree.chart.block.LineBorder lineBorder35 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke15, rectangleInsets26);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(unitType16);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(unitType28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D34);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.height = 10.0d;
        size2D0.height = 0.0d;
        double double5 = size2D0.height;
        size2D0.width = (-1.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        org.jfree.chart.util.UnitType unitType2 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets(unitType2, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType2, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle13.getBounds();
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets12.createOutsetRectangle(rectangle2D14, true, true);
        piePlotState1.setLinkArea(rectangle2D17);
        double double19 = piePlotState1.getPieCenterY();
        org.junit.Assert.assertNotNull(unitType2);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        piePlot0.setOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot0.setURLGenerator(pieURLGenerator11);
        boolean boolean13 = piePlot0.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setAutoRangeMinimumSize((double) (short) 10, true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        boolean boolean2 = color0.equals((java.lang.Object) textLine1);
        float[] floatArray11 = new float[] { 0.0f, (-1), (byte) -1, 10L, 100L };
        float[] floatArray12 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) (byte) 1, (int) (byte) 100, floatArray11);
        float[] floatArray13 = color0.getRGBComponents(floatArray12);
        int int14 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        double double2 = piePlot0.getStartAngle();
        java.awt.Paint paint4 = piePlot0.getSectionPaint((java.lang.Comparable) 1L);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = piePlot6.getLabelDistributor();
        java.awt.Paint paint8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot6.setLabelBackgroundPaint(paint8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot6.getLegendLabelURLGenerator();
        java.awt.Paint paint11 = piePlot6.getBaseSectionOutlinePaint();
        boolean boolean12 = rectangleInsets4.equals((java.lang.Object) piePlot6);
        org.jfree.chart.util.UnitType unitType13 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets(unitType13, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets(unitType13, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType25 = rectangleInsets24.getUnitType();
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets24.createInsetRectangle(rectangle2D27);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets23.createOutsetRectangle(rectangle2D27, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType32 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets4.createAdjustedRectangle(rectangle2D27, lengthAdjustmentType32, lengthAdjustmentType33);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle();
        textTitle35.setExpandToFitSpace(false);
        java.lang.String str38 = textTitle35.getURLText();
        java.awt.geom.Rectangle2D rectangle2D39 = textTitle35.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = textTitle35.getMargin();
        boolean boolean41 = textTitle35.getNotify();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = textTitle35.getPosition();
        try {
            java.util.List list43 = dateAxis0.refreshTicks(graphics2D2, axisState3, rectangle2D34, rectangleEdge42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(pieURLGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(unitType13);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot15.getRenderer(0);
        java.lang.Number[] numberArray23 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] { numberArray23, numberArray26, numberArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray30);
        categoryPlot15.setDataset(categoryDataset31);
        org.jfree.data.KeyToGroupMap keyToGroupMap33 = null;
        try {
            org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset31, keyToGroupMap33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryItemRenderer18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("1.2.0-pre version 1.2.0-pre.\nRotation.ANTICLOCKWISE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY 1.2.0-pre:None\n1.2.0-pre LICENCE TERMS:\nRectangleEdge.TOP", "Pie Plot", "1.2.0-pre version 1.2.0-pre.\nRotation.ANTICLOCKWISE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY 1.2.0-pre:None\n1.2.0-pre LICENCE TERMS:\nRectangleEdge.TOP", image3, "org.jfree.chart.event.ChartChangeEvent[source=0]", "1.2.0-pre", "Other");
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.String str4 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis6.setTickUnit(numberTickUnit7, false, false);
        numberAxis6.resizeRange((double) 255);
        java.awt.Shape shape13 = numberAxis6.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot15.setDataset(categoryDataset18);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent20 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent20);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.clearRangeAxes();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D31 = textTitle30.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double33 = categoryAxis27.getCategoryStart(255, (int) (short) -1, rectangle2D31, rectangleEdge32);
        java.awt.geom.Point2D point2D34 = null;
        org.jfree.chart.plot.PlotState plotState35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        xYPlot24.draw(graphics2D26, rectangle2D31, point2D34, plotState35, plotRenderingInfo36);
        java.awt.Color color38 = java.awt.Color.LIGHT_GRAY;
        xYPlot24.setRangeZeroBaselinePaint((java.awt.Paint) color38);
        java.awt.Stroke stroke40 = xYPlot24.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        int int42 = xYPlot24.indexOf(xYDataset41);
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("1.2.0-pre", font23, (org.jfree.chart.plot.Plot) xYPlot24, true);
        categoryPlot15.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        try {
            jFreeChart44.handleClick(0, (int) '#', chartRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(numberTickUnit7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType6 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(unitType6, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets(unitType6, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets17.getUnitType();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle19.getBounds();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets17.createInsetRectangle(rectangle2D20);
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets16.createOutsetRectangle(rectangle2D20, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double26 = categoryAxis3.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D24, rectangleEdge25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis3.setTickLabelPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit33 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis32.setTickUnit(numberTickUnit33, false, false);
        numberAxis32.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle();
        textTitle39.setExpandToFitSpace(false);
        java.lang.String str42 = textTitle39.getURLText();
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle39.getBounds();
        numberAxis32.setDownArrow((java.awt.Shape) rectangle2D43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge45);
        double double47 = categoryAxis3.getCategoryMiddle((int) (byte) 100, (int) (short) -1, rectangle2D43, rectangleEdge46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        xYPlot0.drawAnnotations(graphics2D2, rectangle2D43, plotRenderingInfo48);
        int int50 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(numberTickUnit33);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setUpperMargin(1.0d);
        numberAxis2.setAutoTickUnitSelection(true, false);
        java.awt.Stroke stroke8 = numberAxis2.getTickMarkStroke();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        textTitle9.setExpandToFitSpace(false);
        java.lang.String str12 = textTitle9.getURLText();
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle9.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle9.getMargin();
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke8, rectangleInsets14);
        double double17 = rectangleInsets14.extendWidth((double) (short) 100);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Paint paint2 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray4 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer3 };
        xYPlot0.setRenderers(xYItemRendererArray4);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace7 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis9.setVerticalTickLabels(false);
        numberAxis9.setNegativeArrowVisible(false);
        org.jfree.data.Range range14 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.lang.Object obj15 = xYPlot0.clone();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(xYItemRendererArray4);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("hi!", font4, (java.awt.Paint) color6);
        piePlot0.setLabelOutlinePaint((java.awt.Paint) color6);
        java.awt.Paint paint9 = piePlot0.getBaseSectionOutlinePaint();
        piePlot0.setExplodePercent((java.lang.Comparable) "{0}", (double) '4');
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis14.setUpperMargin(1.0d);
        numberAxis14.setAutoTickUnitSelection(true, false);
        java.awt.Stroke stroke20 = numberAxis14.getTickMarkStroke();
        piePlot0.setLabelOutlineStroke(stroke20);
        piePlot0.setIgnoreNullValues(true);
        java.awt.Paint paint24 = piePlot0.getLabelBackgroundPaint();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent2.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent2.getType();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean6 = chartChangeEventType4.equals((java.lang.Object) color5);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis0.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj5 = dateAxis4.clone();
        org.jfree.chart.axis.Timeline timeline6 = dateAxis4.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis4.setTickUnit(dateTickUnit7, false, false);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.clearRangeAxes();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle18.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double21 = categoryAxis15.getCategoryStart(255, (int) (short) -1, rectangle2D19, rectangleEdge20);
        java.awt.geom.Point2D point2D22 = null;
        org.jfree.chart.plot.PlotState plotState23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        xYPlot12.draw(graphics2D14, rectangle2D19, point2D22, plotState23, plotRenderingInfo24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge26);
        double double28 = dateAxis4.valueToJava2D((double) 1.0f, rectangle2D19, rectangleEdge27);
        java.util.Date date29 = dateAxis4.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj31 = dateAxis30.clone();
        org.jfree.chart.axis.Timeline timeline32 = dateAxis30.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis30.setTickUnit(dateTickUnit33, false, false);
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        xYPlot38.clearRangeAxes();
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D45 = textTitle44.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double47 = categoryAxis41.getCategoryStart(255, (int) (short) -1, rectangle2D45, rectangleEdge46);
        java.awt.geom.Point2D point2D48 = null;
        org.jfree.chart.plot.PlotState plotState49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        xYPlot38.draw(graphics2D40, rectangle2D45, point2D48, plotState49, plotRenderingInfo50);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge52);
        double double54 = dateAxis30.valueToJava2D((double) 1.0f, rectangle2D45, rectangleEdge53);
        java.util.Date date55 = dateAxis30.getMinimumDate();
        try {
            dateAxis0.setRange(date29, date55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(timeline6);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(timeline32);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(date55);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeAxes();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double11 = categoryAxis5.getCategoryStart(255, (int) (short) -1, rectangle2D9, rectangleEdge10);
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot2.draw(graphics2D4, rectangle2D9, point2D12, plotState13, plotRenderingInfo14);
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        xYPlot2.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = xYPlot2.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        int int20 = xYPlot2.indexOf(xYDataset19);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("1.2.0-pre", font1, (org.jfree.chart.plot.Plot) xYPlot2, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.clearRangeAxes();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot26.setRangeGridlineStroke(stroke28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        xYPlot26.setRangeZeroBaselinePaint((java.awt.Paint) color30);
        boolean boolean32 = xYPlot26.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        xYPlot26.setRangeAxisLocation((int) (short) 1, axisLocation34, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot26.zoomRangeAxes(0.0d, plotRenderingInfo38, point2D39);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot26.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D46 = xYPlot45.getQuadrantOrigin();
        xYPlot26.zoomDomainAxes(0.0d, (double) 15, plotRenderingInfo44, point2D46);
        xYPlot2.zoomRangeAxes((double) '#', 101.0d, plotRenderingInfo25, point2D46);
        java.lang.String str49 = xYPlot2.getPlotType();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(point2D46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "XY Plot" + "'", str49.equals("XY Plot"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        try {
            textTitle0.setPosition(rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor1 = categoryPlot0.getDomainGridlinePosition();
        boolean boolean2 = categoryPlot0.isDomainGridlinesVisible();
        java.util.List list3 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(categoryAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        categoryPlot0.setRenderer(categoryItemRenderer2, false);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            categoryPlot0.addDomainMarker(2, categoryMarker8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle0.getMargin();
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = textTitle0.getVerticalAlignment();
        textTitle0.setToolTipText("RectangleEdge.TOP");
        double double6 = textTitle0.getHeight();
        double double7 = textTitle0.getWidth();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        java.lang.String str2 = chartEntity1.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setExpandToFitSpace(false);
        java.lang.String str3 = textTitle0.getURLText();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle0.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle0.getMargin();
        boolean boolean6 = textTitle0.getNotify();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle0.getPosition();
        org.jfree.chart.util.UnitType unitType8 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint20 = defaultDrawingSupplier19.getNextPaint();
        boolean boolean21 = unitType8.equals((java.lang.Object) defaultDrawingSupplier19);
        boolean boolean22 = rectangleEdge7.equals((java.lang.Object) defaultDrawingSupplier19);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        int int16 = color14.getAlpha();
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(false);
        boolean boolean5 = numberAxis1.equals((java.lang.Object) (-1L));
        java.lang.String str6 = numberAxis1.getLabelURL();
        numberAxis1.resizeRange((double) (byte) 1, (double) (-1L));
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis11.setTickUnit(numberTickUnit12, false, false);
        numberAxis11.resizeRange((double) 255);
        java.awt.Shape shape18 = numberAxis11.getRightArrow();
        numberAxis1.setLeftArrow(shape18);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "XY Plot");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis1.getLabelInsets();
        java.lang.String str9 = numberAxis1.getLabelToolTip();
        numberAxis1.setUpperBound((double) 0.5f);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("XY Plot", "http://www.jfree.org/jfreechart/index.html");
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("1.2.0-pre version 1.2.0-pre.\nRotation.ANTICLOCKWISE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY 1.2.0-pre:None\n1.2.0-pre LICENCE TERMS:\nRectangleEdge.TOP");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj3 = dateAxis2.clone();
        org.jfree.chart.axis.Timeline timeline4 = dateAxis2.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis2.setTickUnit(dateTickUnit5, false, false);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.clearRangeAxes();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle16.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double19 = categoryAxis13.getCategoryStart(255, (int) (short) -1, rectangle2D17, rectangleEdge18);
        java.awt.geom.Point2D point2D20 = null;
        org.jfree.chart.plot.PlotState plotState21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot10.draw(graphics2D12, rectangle2D17, point2D20, plotState21, plotRenderingInfo22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge24);
        double double26 = dateAxis2.valueToJava2D((double) 1.0f, rectangle2D17, rectangleEdge25);
        java.util.Date date27 = dateAxis2.getMinimumDate();
        dateAxis1.setMaximumDate(date27);
        dateAxis1.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(timeline4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        double double2 = dateRange1.getLength();
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange1, (double) 0L);
        dateAxis0.setRange((org.jfree.data.Range) dateRange1, false, true);
        dateAxis0.setInverted(false);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        jFreeChart3.removeLegend();
        java.awt.Color color8 = java.awt.Color.getHSBColor(100.0f, (float) (byte) 0, (-1.0f));
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo11);
        org.jfree.chart.util.UnitType unitType13 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets(unitType13, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets(unitType13, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D25 = textTitle24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets23.createOutsetRectangle(rectangle2D25, true, true);
        piePlotState12.setLinkArea(rectangle2D28);
        java.awt.geom.AffineTransform affineTransform30 = null;
        java.awt.RenderingHints renderingHints31 = null;
        java.awt.PaintContext paintContext32 = color8.createContext(colorModel9, rectangle10, rectangle2D28, affineTransform30, renderingHints31);
        jFreeChart3.setBorderPaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(unitType13);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(paintContext32);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        org.jfree.chart.util.UnitType unitType4 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        double double16 = rectangleInsets14.calculateRightOutset((double) 'a');
        piePlot0.setInsets(rectangleInsets14, true);
        org.jfree.data.general.WaferMapDataset waferMapDataset20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset20);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot21);
        jFreeChart22.removeLegend();
        piePlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart22);
        piePlot0.setLabelGap(1.0d);
        piePlot0.setIgnoreZeroValues(true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-48.743718592964825d) + "'", double16 == (-48.743718592964825d));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets20.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor23 = piePlot22.getLabelDistributor();
        java.awt.Paint paint24 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot22.setLabelBackgroundPaint(paint24);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator26 = piePlot22.getLegendLabelURLGenerator();
        java.awt.Paint paint27 = piePlot22.getBaseSectionOutlinePaint();
        boolean boolean28 = rectangleInsets20.equals((java.lang.Object) piePlot22);
        org.jfree.chart.util.UnitType unitType29 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType41 = rectangleInsets40.getUnitType();
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle42.getBounds();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets40.createInsetRectangle(rectangle2D43);
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets39.createOutsetRectangle(rectangle2D43, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets20.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType48, lengthAdjustmentType49);
        xYPlot0.drawBackgroundImage(graphics2D19, rectangle2D50);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray52 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray52);
        java.awt.Paint paint55 = xYPlot0.getQuadrantPaint(1);
        xYPlot0.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(pieURLGenerator26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(unitType29);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(unitType41);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(xYItemRendererArray52);
        org.junit.Assert.assertNull(paint55);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setRangeGridlineStroke(stroke2);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        xYPlot0.axisChanged(axisChangeEvent4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets9.getUnitType();
        double double12 = rectangleInsets9.calculateRightInset((double) (byte) 0);
        xYPlot0.setInsets(rectangleInsets9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = xYPlot0.getRenderer();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(unitType10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer14);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = abstractPieLabelDistributor1.getPieLabelRecord((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isRangeZoomable();
        boolean boolean5 = polarPlot3.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.geom.Point2D point2D9 = xYPlot8.getQuadrantOrigin();
        try {
            polarPlot3.zoomRangeAxes((double) (short) -1, plotRenderingInfo7, point2D9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(point2D9);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit3, false, false);
        numberAxis2.resizeRange((double) 255);
        java.awt.Shape shape9 = numberAxis2.getRightArrow();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        double double12 = categoryAxis11.getCategoryMargin();
        java.lang.String str14 = categoryAxis11.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis16.setTickUnit(numberTickUnit17, false, false);
        numberAxis16.resizeRange((double) 255);
        java.awt.Shape shape23 = numberAxis16.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer24);
        java.awt.Paint paint26 = categoryPlot25.getDomainGridlinePaint();
        numberAxis2.setLabelPaint(paint26);
        org.jfree.data.Range range28 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType29 = null;
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        double double33 = categoryAxis32.getCategoryMargin();
        java.lang.String str35 = categoryAxis32.getCategoryLabelToolTip((java.lang.Comparable) 0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit38 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis37.setTickUnit(numberTickUnit38, false, false);
        numberAxis37.resizeRange((double) 255);
        java.awt.Shape shape44 = numberAxis37.getRightArrow();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer45);
        java.awt.Paint paint47 = categoryPlot46.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace48 = categoryPlot46.getFixedDomainAxisSpace();
        java.lang.Number[] numberArray54 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray57 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[] numberArray60 = new java.lang.Number[] { 10.0f, 90.0d };
        java.lang.Number[][] numberArray61 = new java.lang.Number[][] { numberArray54, numberArray57, numberArray60 };
        org.jfree.data.category.CategoryDataset categoryDataset62 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "org.jfree.chart.event.ChartChangeEvent[source=0]", numberArray61);
        categoryPlot46.setDataset(1, categoryDataset62);
        org.jfree.data.Range range64 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset62);
        org.jfree.data.Range range67 = org.jfree.data.Range.expand(range64, 0.0d, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint69 = new org.jfree.chart.block.RectangleConstraint(range64, (double) (short) 100);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType70 = org.jfree.chart.block.LengthConstraintType.FIXED;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint71 = new org.jfree.chart.block.RectangleConstraint((double) 10, range28, lengthConstraintType29, 1.0E-8d, range64, lengthConstraintType70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(numberTickUnit17);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(numberTickUnit38);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNull(axisSpace48);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(numberArray61);
        org.junit.Assert.assertNotNull(categoryDataset62);
        org.junit.Assert.assertNotNull(range64);
        org.junit.Assert.assertNotNull(range67);
        org.junit.Assert.assertNotNull(lengthConstraintType70);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        boolean boolean4 = polarPlot3.isRangeZoomable();
        polarPlot3.removeCornerTextItem("1.2.0-pre version 1.2.0-pre.\nRotation.ANTICLOCKWISE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY 1.2.0-pre:None\n1.2.0-pre LICENCE TERMS:\nRectangleEdge.TOP");
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape9);
        numberAxis8.setUpArrow(shape9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean13 = numberAxis8.equals((java.lang.Object) color12);
        int int14 = color12.getGreen();
        java.awt.color.ColorSpace colorSpace15 = color12.getColorSpace();
        polarPlot3.setAngleGridlinePaint((java.awt.Paint) color12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
        org.junit.Assert.assertNotNull(colorSpace15);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit3, false, false);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.clearRangeAxes();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle14.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double17 = categoryAxis11.getCategoryStart(255, (int) (short) -1, rectangle2D15, rectangleEdge16);
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        xYPlot8.draw(graphics2D10, rectangle2D15, point2D18, plotState19, plotRenderingInfo20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        double double24 = dateAxis0.valueToJava2D((double) 1.0f, rectangle2D15, rectangleEdge23);
        java.util.Date date25 = dateAxis0.getMinimumDate();
        org.jfree.data.Range range26 = dateAxis0.getRange();
        double double27 = range26.getUpperBound();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("", font1);
        float float3 = textFragment2.getBaselineOffset();
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean5 = textFragment2.equals((java.lang.Object) columnArrangement4);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int2 = objectList0.indexOf((java.lang.Object) 1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        int int4 = objectList0.indexOf((java.lang.Object) stroke3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj6 = dateAxis5.clone();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double9 = numberAxis8.getUpperBound();
        boolean boolean10 = numberAxis8.isTickMarksVisible();
        boolean boolean11 = numberAxis8.isNegativeArrowVisible();
        org.jfree.chart.plot.Plot plot12 = numberAxis8.getPlot();
        org.jfree.data.Range range13 = numberAxis8.getDefaultAutoRange();
        dateAxis5.setRange(range13, true, false);
        org.jfree.data.time.DateRange dateRange17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(range13, (org.jfree.data.Range) dateRange17);
        java.lang.String str19 = rectangleConstraint18.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = rectangleConstraint18.getHeightConstraintType();
        java.lang.String str21 = lengthConstraintType20.toString();
        boolean boolean22 = objectList0.equals((java.lang.Object) lengthConstraintType20);
        java.lang.Object obj23 = objectList0.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(dateRange17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str19.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleConstraintType.RANGE" + "'", str21.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        dateAxis0.setLabelPaint((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("1.2.0-pre version 1.2.0-pre.\nRotation.ANTICLOCKWISE.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY 1.2.0-pre:None\n1.2.0-pre LICENCE TERMS:\nRectangleEdge.TOP", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 10.0d);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot4 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset3);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot4);
        chartChangeEvent1.setChart(jFreeChart5);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (byte) 0, 1.0E-8d);
        try {
            java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setUpperMargin(1.0d);
        numberAxis1.setAutoTickUnitSelection(true, false);
        java.awt.Stroke stroke7 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis9.setTickUnit(numberTickUnit10, false, false);
        numberAxis9.setUpperMargin(0.025d);
        org.jfree.data.RangeType rangeType16 = numberAxis9.getRangeType();
        numberAxis1.setRangeType(rangeType16);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertNotNull(rangeType16);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle6.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double9 = categoryAxis3.getCategoryStart(255, (int) (short) -1, rectangle2D7, rectangleEdge8);
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        xYPlot0.draw(graphics2D2, rectangle2D7, point2D10, plotState11, plotRenderingInfo12);
        java.awt.Color color14 = java.awt.Color.LIGHT_GRAY;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        int int18 = xYPlot0.indexOf(xYDataset17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets20.getUnitType();
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor23 = piePlot22.getLabelDistributor();
        java.awt.Paint paint24 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot22.setLabelBackgroundPaint(paint24);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator26 = piePlot22.getLegendLabelURLGenerator();
        java.awt.Paint paint27 = piePlot22.getBaseSectionOutlinePaint();
        boolean boolean28 = rectangleInsets20.equals((java.lang.Object) piePlot22);
        org.jfree.chart.util.UnitType unitType29 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets(unitType29, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType41 = rectangleInsets40.getUnitType();
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle42.getBounds();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets40.createInsetRectangle(rectangle2D43);
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets39.createOutsetRectangle(rectangle2D43, true, false);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets20.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType48, lengthAdjustmentType49);
        xYPlot0.drawBackgroundImage(graphics2D19, rectangle2D50);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray52 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray52);
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.Layer layer57 = null;
        try {
            xYPlot0.addDomainMarker(64, (org.jfree.chart.plot.Marker) valueMarker56, layer57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(pieURLGenerator26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(unitType29);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(unitType41);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(xYItemRendererArray52);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = valueMarker1.getLabelOffset();
        java.awt.Paint paint3 = valueMarker1.getOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        java.lang.Object obj5 = valueMarker1.clone();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot0.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord11 = abstractPieLabelDistributor9.getPieLabelRecord(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit4, false, false);
        numberAxis3.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = numberAxis3.getLabelInsets();
        boolean boolean11 = xYPlot0.equals((java.lang.Object) rectangleInsets10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = new org.jfree.chart.LegendItemCollection();
        xYPlot0.setFixedLegendItems(legendItemCollection12);
        org.jfree.chart.LegendItem legendItem14 = null;
        legendItemCollection12.add(legendItem14);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("org.jfree.chart.event.ChartChangeEvent[source=0]");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.UnitType unitType7 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType7, (double) (byte) -1, 0.0d, 0.0d, (double) 0L);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets(unitType7, (double) (byte) 100, (double) 100L, 0.05d, (double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType19 = rectangleInsets18.getUnitType();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle20.getBounds();
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets18.createInsetRectangle(rectangle2D21);
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets17.createOutsetRectangle(rectangle2D21, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double27 = categoryAxis4.getCategoryMiddle((int) (byte) 10, (int) (short) 10, rectangle2D25, rectangleEdge26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        categoryAxis4.setTickLabelPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis33.setTickUnit(numberTickUnit34, false, false);
        numberAxis33.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle();
        textTitle40.setExpandToFitSpace(false);
        java.lang.String str43 = textTitle40.getURLText();
        java.awt.geom.Rectangle2D rectangle2D44 = textTitle40.getBounds();
        numberAxis33.setDownArrow((java.awt.Shape) rectangle2D44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge46);
        double double48 = categoryAxis4.getCategoryMiddle((int) (byte) 100, (int) (short) -1, rectangle2D44, rectangleEdge47);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double50 = categoryAxis3D1.getCategoryMiddle((int) '4', 100, rectangle2D44, rectangleEdge49);
        float float51 = categoryAxis3D1.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(numberTickUnit34);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 0.0f + "'", float51 == 0.0f);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D1 = textTitle0.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = textTitle0.getMargin();
        textTitle0.setHeight(0.05d);
        double double5 = textTitle0.getContentXOffset();
        org.junit.Assert.assertNotNull(rectangle2D1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(libraryArray2);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) "Multiple Pie Plot", (java.awt.Paint) color10);
        java.awt.Color color12 = java.awt.Color.orange;
        piePlot0.setOutlinePaint((java.awt.Paint) color12);
        int int14 = color12.getAlpha();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "HorizontalAlignment.CENTER", "RectangleEdge.BOTTOM", "HorizontalAlignment.CENTER");
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot0.getURLGenerator();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        piePlot0.setOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot0.setURLGenerator(pieURLGenerator11);
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor14 = piePlot13.getLabelDistributor();
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot13.setLabelBackgroundPaint(paint15);
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        piePlot13.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color18);
        int int20 = piePlot13.getPieIndex();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator21 = piePlot13.getURLGenerator();
        java.awt.Color color23 = java.awt.Color.DARK_GRAY;
        piePlot13.setSectionOutlinePaint((java.lang.Comparable) "Multiple Pie Plot", (java.awt.Paint) color23);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator25 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot13.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator25);
        java.text.NumberFormat numberFormat27 = standardPieSectionLabelGenerator25.getNumberFormat();
        piePlot0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator25);
        double double29 = piePlot0.getMinimumArcAngleToDraw();
        java.awt.Paint paint30 = piePlot0.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(pieURLGenerator21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(numberFormat27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0E-5d + "'", double29 == 1.0E-5d);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit2, false, false);
        numberAxis1.resizeRange((double) 255);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis1.getLabelInsets();
        java.lang.String str9 = numberAxis1.getLabelToolTip();
        java.lang.String str10 = numberAxis1.getLabel();
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.awt.Paint paint1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        numberAxis4.setUpArrow(shape5);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        boolean boolean9 = numberAxis4.equals((java.lang.Object) color8);
        org.jfree.chart.util.ObjectList objectList10 = new org.jfree.chart.util.ObjectList();
        int int12 = objectList10.indexOf((java.lang.Object) 1);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        int int14 = objectList10.indexOf((java.lang.Object) stroke13);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color8, stroke13);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 0L, paint1, stroke13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = jFreeChart3.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = jFreeChart3.getPadding();
        org.jfree.chart.event.ChartProgressListener chartProgressListener6 = null;
        jFreeChart3.removeProgressListener(chartProgressListener6);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        java.lang.String str3 = projectInfo0.getInfo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setExpandToFitSpace(false);
        java.lang.String str3 = textTitle0.getURLText();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle0.getBounds();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle0.getMargin();
        boolean boolean6 = textTitle0.getNotify();
        org.jfree.data.general.WaferMapDataset waferMapDataset8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = jFreeChart10.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = jFreeChart10.getPadding();
        textTitle0.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart10);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle3.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double6 = categoryAxis0.getCategoryStart(255, (int) (short) -1, rectangle2D4, rectangleEdge5);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis10.setTickUnit(numberTickUnit11, false, false);
        numberAxis10.setUpperMargin(0.025d);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        textTitle17.setExpandToFitSpace(false);
        java.lang.String str20 = textTitle17.getURLText();
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle17.getBounds();
        numberAxis10.setDownArrow((java.awt.Shape) rectangle2D21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge23);
        double double25 = categoryAxis0.getCategoryEnd(0, (int) (short) 100, rectangle2D21, rectangleEdge23);
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryAxis0.getTickLabelInsets();
        java.awt.Paint paint30 = null;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 4, paint30);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10);
        java.lang.Object obj2 = valueMarker1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.Object obj1 = dateAxis0.clone();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit3, false, false);
        java.util.TimeZone timeZone7 = dateAxis0.getTimeZone();
        try {
            dateAxis0.zoomRange(7.0d, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (7.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.Class<?> wildcardClass3 = textBlockAnchor2.getClass();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.Class<?> wildcardClass5 = textBlockAnchor4.getClass();
        java.lang.ClassLoader classLoader6 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
        java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleEdge.TOP", (java.lang.Class) wildcardClass3, (java.lang.Class) wildcardClass5);
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleAnchor.LEFT", (java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(classLoader6);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(inputStream8);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart("1.2.0-pre", (org.jfree.chart.plot.Plot) waferMapPlot2);
        org.jfree.chart.plot.Plot plot4 = jFreeChart3.getPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = jFreeChart3.getPadding();
        jFreeChart3.fireChartChanged();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.addProgressListener(chartProgressListener7);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor1 = piePlot0.getLabelDistributor();
        java.awt.Paint paint2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot0.setLabelBackgroundPaint(paint2);
        java.awt.Color color5 = java.awt.Color.LIGHT_GRAY;
        piePlot0.setSectionPaint((java.lang.Comparable) true, (java.awt.Paint) color5);
        int int7 = piePlot0.getPieIndex();
        java.awt.Paint paint8 = piePlot0.getBackgroundPaint();
        piePlot0.setLabelLinkMargin((double) 10L);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(paint8);
    }
}

