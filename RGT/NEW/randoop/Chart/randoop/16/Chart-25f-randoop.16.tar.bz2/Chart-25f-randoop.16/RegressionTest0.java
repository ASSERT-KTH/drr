import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Font font1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.text.TextMeasurer textMeasurer4 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color2, (float) 0, textMeasurer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color2, (float) 100, (int) (byte) 1, textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 10, (float) 10, (float) 100L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-123) + "'", int3 == (-123));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        float[] floatArray5 = new float[] { 100L, 0.0f };
        try {
            float[] floatArray6 = java.awt.Color.RGBtoHSB(0, 10, (int) (short) 0, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) (-1), 100.0f, textAnchor4, (double) (short) 10, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor2, (double) (byte) 1, categoryLabelWidthType4, (float) (-123));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelWidthType4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.0d, "", textAnchor2, textAnchor3, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 100.0f, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition1, categoryLabelPosition2, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.axis.Axis axis0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        try {
            org.jfree.chart.entity.AxisLabelEntity axisLabelEntity6 = new org.jfree.chart.entity.AxisLabelEntity(axis0, shape3, "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Class<?> wildcardClass4 = textAnchor3.getClass();
        org.jfree.chart.text.TextAnchor textAnchor5 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick7 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 1.0f, "hi!", textAnchor3, textAnchor5, (double) (-123));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 'a', (float) 10, textAnchor4, (double) 10L, (float) ' ', (float) (short) -1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean2 = color0.equals((java.lang.Object) 10.0d);
        int int3 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16727872) + "'", int3 == (-16727872));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0d, (float) (short) 1, (float) (byte) 10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        boolean boolean2 = verticalAlignment0.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 100.0f, (double) (short) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str7 = layer6.toString();
        try {
            categoryPlot4.addDomainMarker(categoryMarker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Layer.BACKGROUND" + "'", str7.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) 0, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Font font1 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color5 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape4, (java.awt.Paint) color5);
        try {
            org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.axis.Axis axis0 = null;
        try {
            org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent(axis0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        java.awt.Image image8 = categoryPlot4.getBackgroundImage();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str12 = layer11.toString();
        try {
            categoryPlot4.addRangeMarker(100, marker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Layer.BACKGROUND" + "'", str12.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Stroke stroke5 = legendGraphic4.getLineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = legendGraphic4.arrange(graphics2D6, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = legendGraphic4.getOutlinePaint();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            legendGraphic4.draw(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Object obj3 = keyedObjects2D0.getObject((int) '#', (-123));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.GRAY;
        int int6 = color5.getRed();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color14 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape13, (java.awt.Paint) color14);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color19 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color19);
        legendGraphic15.setShape(shape18);
        java.awt.Color color22 = java.awt.Color.lightGray;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color24 = java.awt.Color.MAGENTA;
        int int25 = color24.getRed();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape18, (java.awt.Paint) color22, stroke23, (java.awt.Paint) color24);
        java.awt.Paint paint27 = null;
        try {
            org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem(attributedString0, "Layer.BACKGROUND", "hi!", "VerticalAlignment.CENTER", shape4, (java.awt.Paint) color5, stroke23, paint27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 128 + "'", int6 == 128);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range1);
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D((double) 1L, (double) (short) 1);
        size2D5.setHeight(0.0d);
        try {
            org.jfree.chart.util.Size2D size2D8 = rectangleConstraint2.calculateConstrainedSize(size2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(128);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, 10.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.axis.Axis axis0 = null;
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.entity.AxisLabelEntity axisLabelEntity4 = new org.jfree.chart.entity.AxisLabelEntity(axis0, shape1, "Layer.BACKGROUND", "VerticalAlignment.CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        try {
            axisSpace0.ensureAtLeast((double) 0.0f, rectangleEdge3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: AxisSpace.ensureAtLeast(): unrecognised AxisLocation.");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Stroke stroke5 = legendGraphic4.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendGraphic4.getShapeLocation();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = null;
        try {
            legendGraphic4.setFillPaintTransformer(gradientPaintTransformer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = axisSpace0.reserved(rectangle2D2, rectangleEdge3);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = axisSpace0.reserved(rectangle2D5, rectangleEdge6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertNull(rectangle2D7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 255, (float) 1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range1);
        org.jfree.chart.util.Size2D size2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = rectangleConstraint2.calculateConstrainedSize(size2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100L, (float) '4', (float) 100);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Class<?> wildcardClass3 = textAnchor2.getClass();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Class<?> wildcardClass6 = textAnchor5.getClass();
        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass6);
        java.lang.Object obj8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass3, (java.lang.Class) wildcardClass6);
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(uRL7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(uRL9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 3.0d);
        try {
            java.lang.Comparable comparable4 = keyedObjects2D0.getRowKey((-123));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -123");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightInset((double) 2);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray1, doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (int) (short) 100);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset3);
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, 0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.util.UnitType unitType1 = org.jfree.chart.util.UnitType.RELATIVE;
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) chartChangeEventType0, (java.lang.Object) unitType1);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getColumnKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8323073) + "'", int1 == (-8323073));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 100, (java.lang.Number) 128);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            legendTitle6.draw(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot19 = categoryPlot4.getParent();
        org.jfree.chart.ChartColor chartColor23 = new org.jfree.chart.ChartColor(0, 100, (int) 'a');
        try {
            plot19.setOutlinePaint((java.awt.Paint) chartColor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Comparable comparable1 = null;
        try {
            java.awt.Paint paint2 = categoryAxis0.getTickLabelPaint(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("VerticalAlignment.CENTER", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getRowKey((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 1L, (double) (short) 1);
        size2D2.setHeight(0.0d);
        double double5 = size2D2.width;
        java.lang.String str6 = size2D2.toString();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Size2D[width=1.0, height=0.0]" + "'", str6.equals("Size2D[width=1.0, height=0.0]"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        boolean boolean11 = legendGraphic4.isShapeVisible();
        boolean boolean12 = legendGraphic4.isShapeFilled();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.awt.Paint paint7 = categoryPlot4.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            categoryPlot4.drawOutline(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Size2D[width=1.0, height=0.0]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (byte) 100, (byte) 0, 10.0f, 0.05d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 100, (byte) 0, 10.0f, 0.05d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) 100, (byte) 0, 10.0f, 0.05d };
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray17);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection9 = categoryPlot4.getRangeMarkers(0, layer8);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray10);
        categoryPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        categoryPlot4.clearAnnotations();
        float float9 = categoryPlot4.getBackgroundAlpha();
        org.jfree.data.general.DatasetGroup datasetGroup10 = categoryPlot4.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNull(datasetGroup10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setAnchorValue(0.0d, true);
        java.awt.Font font10 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("hi!", font10);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.GENERAL", font10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = null;
        try {
            textTitle12.setTextAlignment(horizontalAlignment13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        categoryPlot5.setAnchorValue(0.0d, true);
        java.awt.Font font9 = categoryPlot5.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!", font9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            labelBlock10.draw(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("ItemLabelAnchor.OUTSIDE9");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ItemLabelAnchor.OUTSIDE9, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        java.awt.Stroke stroke2 = null;
        try {
            categoryAxis0.setAxisLineStroke(stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        float float8 = categoryPlot4.getBackgroundAlpha();
        categoryPlot4.clearDomainMarkers((-1));
        boolean boolean11 = categoryPlot4.isRangeZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot4.zoomDomainAxes((double) (short) 10, (double) (-123), plotRenderingInfo14, point2D15);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        boolean boolean11 = legendGraphic4.isShapeVisible();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            legendGraphic4.draw(graphics2D12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ItemLabelAnchor.OUTSIDE9", graphics2D1, (float) (byte) -1, (float) (byte) 100, textAnchor4, (double) (-1), textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color13 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape12, (java.awt.Paint) color13);
        legendGraphic9.setShape(shape12);
        java.awt.Color color16 = java.awt.Color.lightGray;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color18 = java.awt.Color.MAGENTA;
        int int19 = color18.getRed();
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape12, (java.awt.Paint) color16, stroke17, (java.awt.Paint) color18);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape12, (double) (-1), 0.0f, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getLegendItemGraphicEdge();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            legendTitle6.draw(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = axisSpace0.reserved(rectangle2D2, rectangleEdge3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.trimWidth((double) 1);
        double double4 = rectangleInsets0.calculateBottomInset((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Paint paint15 = null;
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color23 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic24 = new org.jfree.chart.title.LegendGraphic(shape22, (java.awt.Paint) color23);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color28 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic29 = new org.jfree.chart.title.LegendGraphic(shape27, (java.awt.Paint) color28);
        legendGraphic24.setShape(shape27);
        java.awt.Color color31 = java.awt.Color.lightGray;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color33 = java.awt.Color.MAGENTA;
        int int34 = color33.getRed();
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape27, (java.awt.Paint) color31, stroke32, (java.awt.Paint) color33);
        java.awt.Stroke stroke36 = legendItem35.getOutlineStroke();
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint38 = blockBorder37.getPaint();
        try {
            org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "VerticalAlignment.CENTER", "", "", shape11, paint15, stroke36, paint38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 1L, (double) (short) 1);
        size2D2.setHeight(0.0d);
        java.lang.String str5 = size2D2.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Size2D[width=1.0, height=0.0]" + "'", str5.equals("Size2D[width=1.0, height=0.0]"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("VerticalAlignment.CENTER", graphics2D1, (float) 255, (float) 1L, textAnchor4, (double) (byte) 10, (float) 0L, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) 10L);
        axisState0.cursorDown(0.0d);
        axisState0.setCursor((double) (-123));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.lightGray;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        try {
            java.awt.Shape shape11 = textBlock3.calculateBounds(graphics2D4, (float) (short) 100, 0.0f, textBlockAnchor7, (float) 128, (float) (byte) 100, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Color color1 = java.awt.Color.getColor("VerticalAlignment.CENTER");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Color color2 = java.awt.Color.getColor("Size2D[width=1.0, height=0.0]", (-1));
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray1, doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (int) (short) 100);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3, (double) (-1L));
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset3);
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0d + "'", number8.equals(0.0d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        categoryPlot5.setAnchorValue(0.0d, true);
        java.awt.Font font9 = categoryPlot5.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!", font9);
        java.lang.String str11 = labelBlock10.getToolTipText();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        java.awt.Paint paint18 = categoryPlot17.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = legendTitle19.getLegendItemGraphicEdge();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.data.Range range23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range23);
        org.jfree.chart.util.Size2D size2D25 = legendTitle19.arrange(graphics2D21, rectangleConstraint24);
        try {
            org.jfree.chart.util.Size2D size2D26 = labelBlock10.arrange(graphics2D12, rectangleConstraint24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(size2D25);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        try {
            java.lang.Comparable comparable5 = defaultStatisticalCategoryDataset0.getColumnKey(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        boolean boolean5 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot4.getDomainAxis((int) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        try {
            categoryPlot4.setRangeAxisLocation(0, axisLocation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryAxis7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.getDrawSharedDomainAxis();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        boolean boolean12 = categoryPlot6.render(graphics2D8, rectangle2D9, 2, plotRenderingInfo11);
        boolean boolean13 = unitType0.equals((java.lang.Object) boolean12);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets8.calculateRightInset((double) 2);
        categoryPlot4.setInsets(rectangleInsets8, true);
        org.jfree.chart.util.UnitType unitType13 = rectangleInsets8.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets8.createOutsetRectangle(rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(unitType13);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        categoryPlot5.setAnchorValue(0.0d, true);
        java.awt.Font font9 = categoryPlot5.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!", font9);
        java.lang.String str11 = labelBlock10.getToolTipText();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.Range range14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range14);
        try {
            org.jfree.chart.util.Size2D size2D16 = labelBlock10.arrange(graphics2D12, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Stroke stroke5 = legendGraphic4.getLineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.lang.Object obj8 = null;
        try {
            java.lang.Object obj9 = legendGraphic4.draw(graphics2D6, rectangle2D7, obj8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (-16727872));
        double double3 = range2.getLength();
        boolean boolean5 = range2.contains((double) 1L);
        double double6 = range2.getLength();
        java.lang.String str7 = range2.toString();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[-1.6727872E7,-1.6727872E7]" + "'", str7.equals("Range[-1.6727872E7,-1.6727872E7]"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        categoryPlot5.setAnchorValue(0.0d, true);
        java.awt.Font font9 = categoryPlot5.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!", font9);
        java.lang.String str11 = labelBlock10.getToolTipText();
        labelBlock10.setWidth(3.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        double double31 = rectangleInsets29.calculateRightInset((double) 2);
        categoryPlot25.setInsets(rectangleInsets29, true);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets29.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets29);
        java.awt.Color color36 = java.awt.Color.PINK;
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color36);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color5 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape4, (java.awt.Paint) color5);
        try {
            paintList0.setPaint((-16727872), (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets8.calculateRightInset((double) 2);
        categoryPlot4.setInsets(rectangleInsets8, true);
        org.jfree.chart.util.UnitType unitType13 = rectangleInsets8.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets8.createInsetRectangle(rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(unitType13);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection9 = categoryPlot4.getRangeMarkers(layer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot4.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = null;
        try {
            categoryPlot4.addDomainMarker(categoryMarker6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range3, (double) (-16727872));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range3, (double) 0.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint7.toUnconstrainedHeight();
        try {
            org.jfree.chart.util.Size2D size2D9 = flowArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        categoryPlot4.clearAnnotations();
        float float9 = categoryPlot4.getBackgroundAlpha();
        java.awt.Image image10 = categoryPlot4.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNull(image10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        keyedObjects0.addObject((java.lang.Comparable) (byte) 0, (java.lang.Object) font2);
        java.lang.Comparable comparable4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        keyedObjects0.addObject(comparable4, (java.lang.Object) layer5);
        try {
            keyedObjects0.removeValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(layer5);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        boolean boolean5 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot4.getDomainAxis((int) (byte) 10);
        int int8 = categoryPlot4.getWeight();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        boolean boolean5 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str8 = layer7.toString();
        java.util.Collection collection9 = categoryPlot4.getRangeMarkers(0, layer7);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Layer.BACKGROUND" + "'", str8.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo0.setLicenceName("AxisLocation.BOTTOM_OR_RIGHT");
        projectInfo0.setLicenceText("UnitType.RELATIVE");
        projectInfo0.setLicenceName("");
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        objectList1.clear();
        int int3 = objectList1.size();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        double double5 = categoryAxis4.getLabelAngle();
        double double6 = categoryAxis4.getCategoryMargin();
        java.lang.String str7 = categoryAxis4.getLabelToolTip();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis4.setAxisLinePaint((java.awt.Paint) color8);
        int int10 = objectList1.indexOf((java.lang.Object) categoryAxis4);
        categoryAxis4.setMaximumCategoryLabelWidthRatio((float) (-1));
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getLegendItemGraphicEdge();
        try {
            double double24 = categoryAxis4.getCategoryStart(0, (int) '#', rectangle2D15, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection9 = categoryPlot4.getRangeMarkers(layer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot4.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = categoryPlot4.getDrawingSupplier();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot4.getDomainAxis();
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNull(categoryAxis13);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        java.awt.Paint paint8 = categoryPlot7.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = categoryLabelPositions2.getLabelPosition(rectangleEdge10);
        try {
            double double12 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(categoryLabelPosition11);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        java.awt.Paint paint18 = categoryPlot17.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot17);
        flowArrangement12.add((org.jfree.chart.block.Block) legendTitle19, (java.lang.Object) (-16727872));
        java.awt.Paint paint22 = legendTitle19.getItemPaint();
        try {
            statisticalBarRenderer0.setSeriesOutlinePaint((-1), paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Paint paint6 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        try {
            double double9 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        org.jfree.data.KeyedObjects keyedObjects2 = new org.jfree.data.KeyedObjects();
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        keyedObjects2.addObject((java.lang.Comparable) (byte) 0, (java.lang.Object) font4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        keyedObjects2.addObject(comparable6, (java.lang.Object) layer7);
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation1, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(layer7);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection9 = categoryPlot4.getRangeMarkers(0, layer8);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = null;
        try {
            legendTitle12.setLegendItemGraphicPadding(rectangleInsets13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockContainer0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        keyedObjects2D0.addObject((java.lang.Object) datasetRenderingOrder1, (java.lang.Comparable) 2, (java.lang.Comparable) "Size2D[width=1.0, height=0.0]");
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        org.jfree.chart.JFreeChart jFreeChart4 = axisChangeEvent3.getChart();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(jFreeChart4);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        double double31 = rectangleInsets29.calculateRightInset((double) 2);
        categoryPlot25.setInsets(rectangleInsets29, true);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets29.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets29);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot4.getRangeAxisEdge();
        categoryPlot4.clearDomainMarkers();
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("Size2D[width=1.0, height=0.0]", "");
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        categoryPlot4.clearAnnotations();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        categoryPlot4.setDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9);
        org.jfree.data.Range range12 = defaultStatisticalCategoryDataset9.getRangeBounds(false);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 1, (float) 2, (float) (-8323073));
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (-16727872));
        double double3 = range2.getLength();
        double double4 = range2.getLength();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot4.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.plot.Marker marker12 = null;
        try {
            categoryPlot4.addRangeMarker(marker12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot6.setDomainAxis(categoryAxis7);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot6.setDomainAxisLocation((int) (short) 10, axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        jFreeChart18.setTitle("Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        java.awt.Paint paint27 = categoryPlot26.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = legendTitle28.getVerticalAlignment();
        try {
            jFreeChart18.addSubtitle((int) (byte) 100, (org.jfree.chart.title.Title) legendTitle28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(verticalAlignment29);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.Number number0 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick(number0, "", textAnchor2, textAnchor3, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection9 = categoryPlot4.getRangeMarkers(0, layer8);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray10);
        java.awt.Font font13 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot18.setDomainAxis(categoryAxis19);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot18.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation25, plotOrientation26);
        categoryPlot18.setDomainAxisLocation((int) (short) 10, axisLocation25);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font13, (org.jfree.chart.plot.Plot) categoryPlot18, true);
        org.jfree.data.KeyedObjects2D keyedObjects2D31 = new org.jfree.data.KeyedObjects2D();
        int int33 = keyedObjects2D31.getColumnIndex((java.lang.Comparable) 3.0d);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean35 = keyedObjects2D31.equals((java.lang.Object) chartChangeEventType34);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot4, jFreeChart30, chartChangeEventType34);
        java.awt.RenderingHints renderingHints37 = null;
        try {
            jFreeChart30.setRenderingHints(renderingHints37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(chartChangeEventType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("AxisLocation.BOTTOM_OR_RIGHT", font2);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color11 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic12 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color11);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color16 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color16);
        legendGraphic12.setShape(shape15);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color20 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape15, stroke19, (java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer25 = new org.jfree.chart.text.G2TextMeasurer(graphics2D24);
        try {
            org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", font2, (java.awt.Paint) color20, (float) '#', (int) (byte) 1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color18 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape17, (java.awt.Paint) color18);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color23 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic24 = new org.jfree.chart.title.LegendGraphic(shape22, (java.awt.Paint) color23);
        legendGraphic19.setShape(shape22);
        java.awt.Color color26 = java.awt.Color.lightGray;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color28 = java.awt.Color.MAGENTA;
        int int29 = color28.getRed();
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape22, (java.awt.Paint) color26, stroke27, (java.awt.Paint) color28);
        java.awt.Stroke stroke31 = legendItem30.getOutlineStroke();
        legendGraphic4.setOutlineStroke(stroke31);
        boolean boolean33 = legendGraphic4.isShapeVisible();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 255 + "'", int29 == 255);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ChartChangeEventType.GENERAL", "VerticalAlignment.CENTER");
        java.lang.String str3 = contributor2.getEmail();
        java.lang.String str4 = contributor2.getEmail();
        java.lang.String str5 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.CENTER" + "'", str3.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "VerticalAlignment.CENTER" + "'", str4.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str5.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean2 = color0.equals((java.lang.Object) 10.0d);
        int int3 = color0.getRGB();
        java.awt.Color color4 = java.awt.Color.lightGray;
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color6 = color5.darker();
        java.awt.Color color7 = java.awt.Color.BLUE;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color0, color4, color6, color7 };
        java.awt.Paint[] paintArray9 = null;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke10, stroke11, stroke12, stroke13 };
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke15, stroke16, stroke17 };
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color25 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic26 = new org.jfree.chart.title.LegendGraphic(shape24, (java.awt.Paint) color25);
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color30 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic31 = new org.jfree.chart.title.LegendGraphic(shape29, (java.awt.Paint) color30);
        legendGraphic26.setShape(shape29);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Shape shape38 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color39 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic40 = new org.jfree.chart.title.LegendGraphic(shape38, (java.awt.Paint) color39);
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color44 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic45 = new org.jfree.chart.title.LegendGraphic(shape43, (java.awt.Paint) color44);
        legendGraphic40.setShape(shape43);
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color50 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic51 = new org.jfree.chart.title.LegendGraphic(shape49, (java.awt.Paint) color50);
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Shape[] shapeArray55 = new java.awt.Shape[] { shape21, shape29, shape35, shape43, shape49, shape54 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier56 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray8, paintArray9, strokeArray14, strokeArray18, shapeArray55);
        java.awt.Stroke stroke57 = defaultDrawingSupplier56.getNextStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16727872) + "'", int3 == (-16727872));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(shapeArray55);
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Stroke stroke5 = legendGraphic4.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendGraphic4.getShapeLocation();
        legendGraphic4.setID("PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color14 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape13, (java.awt.Paint) color14);
        org.jfree.chart.title.LegendGraphic legendGraphic16 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color14);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape19, (java.awt.Paint) color20);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color25 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic26 = new org.jfree.chart.title.LegendGraphic(shape24, (java.awt.Paint) color25);
        legendGraphic21.setShape(shape24);
        legendGraphic21.setHeight(0.0d);
        java.awt.Shape shape30 = legendGraphic21.getShape();
        legendGraphic16.setShape(shape30);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        java.lang.Boolean boolean8 = statisticalBarRenderer0.getSeriesCreateEntities((int) (short) -1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(layer10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection9 = categoryPlot4.getRangeMarkers(0, layer8);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray10);
        java.awt.Font font13 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot18.setDomainAxis(categoryAxis19);
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot18.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation25, plotOrientation26);
        categoryPlot18.setDomainAxisLocation((int) (short) 10, axisLocation25);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font13, (org.jfree.chart.plot.Plot) categoryPlot18, true);
        org.jfree.data.KeyedObjects2D keyedObjects2D31 = new org.jfree.data.KeyedObjects2D();
        int int33 = keyedObjects2D31.getColumnIndex((java.lang.Comparable) 3.0d);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean35 = keyedObjects2D31.equals((java.lang.Object) chartChangeEventType34);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot4, jFreeChart30, chartChangeEventType34);
        org.jfree.chart.util.SortOrder sortOrder37 = categoryPlot4.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(chartChangeEventType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(sortOrder37);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection9 = categoryPlot4.getRangeMarkers(layer8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot4.getRenderer(128);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(categoryItemRenderer11);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = legendTitle6.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent8 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle6);
        boolean boolean9 = legendTitle6.getNotify();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            legendTitle6.setBounds(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Color color1 = java.awt.Color.getColor("ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (-16727872));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 0.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint4.toUnconstrainedHeight();
        double double6 = rectangleConstraint5.getWidth();
        double double7 = rectangleConstraint5.getHeight();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 3.0d);
        java.lang.Comparable comparable3 = null;
        java.lang.Object obj5 = keyedObjects2D0.getObject(comparable3, (java.lang.Comparable) (byte) -1);
        try {
            keyedObjects2D0.removeColumn(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("AxisLocation.BOTTOM_OR_RIGHT", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            textLine2.draw(graphics2D3, (float) (byte) 0, (float) 'a', textAnchor6, (float) 100, (float) (-16727872), (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Layer.BACKGROUND", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        double double2 = axisSpace0.getTop();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = axisSpace0.expand(rectangle2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        java.awt.Paint paint8 = categoryPlot7.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = categoryLabelPositions2.getLabelPosition(rectangleEdge10);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(categoryLabelPosition11);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.SortOrder sortOrder5 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot4.setRowRenderingOrder(sortOrder5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) 255, (double) 10);
        boolean boolean10 = sortOrder5.equals((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        categoryPlot4.setAnchorValue((double) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        try {
            categoryPlot4.setRangeAxisLocation((-8323073), axisLocation12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (-16727872));
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range0, (double) (byte) 10);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setAxisLineVisible(true);
        categoryAxis0.setLabelAngle((double) (-123));
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        boolean boolean6 = categoryAxis0.equals((java.lang.Object) color5);
        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double10 = statisticalBarRenderer9.getBase();
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer9);
        statisticalBarRenderer9.setDrawBarOutline(true);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        categoryPlot11.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double17 = rectangleInsets15.calculateRightInset((double) 2);
        categoryPlot11.setInsets(rectangleInsets15, true);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets15.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets15);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent22);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(unitType20);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        categoryPlot4.setRangeGridlinesVisible(true);
        categoryPlot4.clearRangeMarkers((int) (short) 100);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        float float8 = categoryPlot4.getBackgroundAlpha();
        categoryPlot4.clearAnnotations();
        boolean boolean10 = categoryPlot4.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.Marker marker11 = null;
        try {
            categoryPlot4.addRangeMarker(marker11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        double double4 = range3.getLength();
        boolean boolean6 = range3.contains((double) 1L);
        double double7 = range3.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 2, range3);
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) (-16727872));
        double double12 = range11.getLength();
        boolean boolean14 = range11.contains((double) 1L);
        double double15 = range11.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint8.toRangeWidth(range11);
        boolean boolean18 = range11.contains((double) ' ');
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType1, Double.NaN, 0.0d, (double) (-8323073), 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100.0f, (java.lang.Object) color1);
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.AffineTransform affineTransform6 = null;
        java.awt.RenderingHints renderingHints7 = null;
        java.awt.PaintContext paintContext8 = color1.createContext(colorModel3, rectangle4, rectangle2D5, affineTransform6, renderingHints7);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor0, jFreeChart1, 255, (int) (short) 1);
        chartProgressEvent4.setPercent(255);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis0.setLabelPaint((java.awt.Paint) color4);
        categoryAxis0.setLabelURL("hi!");
        java.lang.Object obj8 = null;
        boolean boolean9 = categoryAxis0.equals(obj8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        legendGraphic4.setHeight(0.0d);
        java.awt.Shape shape13 = legendGraphic4.getShape();
        legendGraphic4.setID("ChartChangeEventType.GENERAL");
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = legendGraphic4.arrange(graphics2D16);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(size2D17);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        statisticalBarRenderer0.setBase((double) 100);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("Size2D[width=1.0, height=0.0]", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setBaseSeriesVisible(true, false);
        statisticalBarRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, false);
        statisticalBarRenderer0.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisState0.moveCursor((-1.0d), rectangleEdge2);
        axisState0.setCursor((double) (-1.0f));
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 3.0d);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean4 = keyedObjects2D0.equals((java.lang.Object) chartChangeEventType3);
        org.jfree.chart.block.BlockBorder blockBorder5 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean6 = keyedObjects2D0.equals((java.lang.Object) blockBorder5);
        java.lang.Object obj7 = null;
        boolean boolean8 = keyedObjects2D0.equals(obj7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setAxisLineVisible(true);
        categoryAxis9.setLabelAngle((double) (-123));
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        boolean boolean15 = categoryAxis9.equals((java.lang.Object) color14);
        java.awt.Paint paint16 = categoryAxis9.getTickLabelPaint();
        keyedObjects2D0.setObject((java.lang.Object) categoryAxis9, (java.lang.Comparable) 0.2d, (java.lang.Comparable) "Size2D[width=1.0, height=0.0]");
        categoryAxis9.setCategoryLabelPositionOffset((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(blockBorder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = legendTitle6.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent8 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle6);
        org.jfree.chart.title.Title title9 = titleChangeEvent8.getTitle();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = titleChangeEvent8.getType();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(title9);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (-8323073));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getItemLabelPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean9 = rectangleInsets7.equals((java.lang.Object) verticalAlignment8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets7.createInsetRectangle(rectangle2D10, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) 100.0f, range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getWidthConstraintType();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) '4');
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getLegendItemGraphicEdge();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range10);
        org.jfree.chart.util.Size2D size2D12 = legendTitle6.arrange(graphics2D8, rectangleConstraint11);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer();
        legendTitle6.setWrapper(blockContainer13);
        org.jfree.chart.block.Arrangement arrangement15 = blockContainer13.getArrangement();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(arrangement15);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { "AxisLocation.BOTTOM_OR_RIGHT" };
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] {};
        double[] doubleArray6 = new double[] { (byte) 100, 10.0d, 128 };
        double[] doubleArray10 = new double[] { (byte) 100, 10.0d, 128 };
        double[] doubleArray14 = new double[] { (byte) 100, 10.0d, 128 };
        double[][] doubleArray15 = new double[][] { doubleArray6, doubleArray10, doubleArray14 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray2, doubleArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("TextBlockAnchor.BOTTOM_CENTER", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        objectList1.clear();
        int int3 = objectList1.size();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        double double5 = categoryAxis4.getLabelAngle();
        double double6 = categoryAxis4.getCategoryMargin();
        java.lang.String str7 = categoryAxis4.getLabelToolTip();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis4.setAxisLinePaint((java.awt.Paint) color8);
        int int10 = objectList1.indexOf((java.lang.Object) categoryAxis4);
        categoryAxis4.setMaximumCategoryLabelWidthRatio((float) (-1));
        double double13 = categoryAxis4.getUpperMargin();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getLegendItemGraphicEdge();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = legendTitle6.getVerticalAlignment();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            legendTitle6.draw(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(verticalAlignment8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setBaseSeriesVisible(true, false);
        statisticalBarRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, false);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        double double17 = categoryAxis16.getLabelAngle();
        double double18 = categoryAxis16.getCategoryMargin();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = categoryPlot25.getRangeMarkers(layer29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        statisticalBarRenderer0.drawAnnotations(graphics2D14, rectangle2D15, categoryAxis16, valueAxis20, layer29, plotRenderingInfo31);
        float float33 = categoryAxis16.getTickMarkInsideLength();
        categoryAxis16.setCategoryMargin((double) 10L);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor0, jFreeChart1, 255, (int) (short) 1);
        chartProgressEvent4.setPercent(0);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.0d, (double) (-123), (int) '#', comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color11 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic12 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color11);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color16 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color16);
        legendGraphic12.setShape(shape15);
        java.awt.Color color19 = java.awt.Color.lightGray;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color21 = java.awt.Color.MAGENTA;
        int int22 = color21.getRed();
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape15, (java.awt.Paint) color19, stroke20, (java.awt.Paint) color21);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color27 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color27);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color32 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape31, (java.awt.Paint) color32);
        legendGraphic28.setShape(shape31);
        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) shape31);
        boolean boolean36 = org.jfree.chart.util.ShapeUtilities.equal(shape15, shape31);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis37.setTickLabelsVisible(false);
        java.awt.Stroke stroke40 = categoryAxis37.getTickMarkStroke();
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color44 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic45 = new org.jfree.chart.title.LegendGraphic(shape43, (java.awt.Paint) color44);
        java.awt.Paint paint46 = legendGraphic45.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = legendGraphic45.getShapeLocation();
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color55 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic56 = new org.jfree.chart.title.LegendGraphic(shape54, (java.awt.Paint) color55);
        java.awt.Shape shape59 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color60 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic61 = new org.jfree.chart.title.LegendGraphic(shape59, (java.awt.Paint) color60);
        legendGraphic56.setShape(shape59);
        java.awt.Color color63 = java.awt.Color.lightGray;
        java.awt.Stroke stroke64 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color65 = java.awt.Color.MAGENTA;
        int int66 = color65.getRed();
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape59, (java.awt.Paint) color63, stroke64, (java.awt.Paint) color65);
        legendGraphic45.setFillPaint((java.awt.Paint) color65);
        try {
            org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem(attributedString0, "Range[-1.6727872E7,-1.6727872E7]", "TextBlockAnchor.BOTTOM_CENTER", "TextBlockAnchor.BOTTOM_CENTER", shape31, stroke40, (java.awt.Paint) color65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 255 + "'", int66 == 255);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        double double3 = rectangleInsets0.trimWidth((double) 10.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        boolean boolean2 = textBlockAnchor0.equals((java.lang.Object) itemLabelAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.lightGray;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, (java.awt.Paint) color3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color6 = color5.darker();
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("ChartChangeEventType.GENERAL", font2, (java.awt.Paint) color5, (float) 1L, (-1), textMeasurer9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        double double31 = rectangleInsets29.calculateRightInset((double) 2);
        categoryPlot25.setInsets(rectangleInsets29, true);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets29.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets29);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot4.setRenderer(categoryItemRenderer37, false);
        categoryPlot4.mapDatasetToDomainAxis((int) (short) 100, 10);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (-16727872));
        double double3 = range2.getLength();
        double double4 = range2.getCentralValue();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.6727872E7d) + "'", double4 == (-1.6727872E7d));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = categoryLabelPositions1.getLabelPosition(rectangleEdge2);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        java.awt.Paint paint11 = categoryPlot10.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = legendTitle12.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = categoryLabelPositions5.getLabelPosition(rectangleEdge13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = categoryLabelPosition14.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType16 = categoryLabelPosition14.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = categoryLabelPosition14.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions1, categoryLabelPosition14);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions18, categoryLabelPosition19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNull(categoryLabelPosition3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(categoryLabelPosition14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(categoryLabelWidthType16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        java.lang.String str3 = projectInfo0.getInfo();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot19 = categoryPlot4.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray21 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer20 };
        categoryPlot4.setRenderers(categoryItemRendererArray21);
        java.awt.Stroke stroke23 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection26 = categoryPlot4.getRangeMarkers((int) (byte) 1, layer25);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertNull(collection26);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) (short) 1, (java.lang.Number) 1.0f);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (short) 1 + "'", number3.equals((short) 1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer0.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color12);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = statisticalBarRenderer0.getURLGenerator(0, 1);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        try {
            statisticalBarRenderer0.setSeriesOutlinePaint((-16727872), (java.awt.Paint) color18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(categoryURLGenerator16);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = statisticalBarRenderer0.initialise(graphics2D8, rectangle2D9, categoryPlot10, 1, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 3.0d);
        java.lang.Comparable comparable3 = null;
        java.lang.Object obj5 = keyedObjects2D0.getObject(comparable3, (java.lang.Comparable) (byte) -1);
        java.util.List list6 = keyedObjects2D0.getColumnKeys();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color4 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape3, (java.awt.Paint) color4);
        java.awt.Paint paint6 = legendGraphic5.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendGraphic5.getShapeLocation();
        try {
            java.awt.geom.Point2D point2D8 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Layer.BACKGROUND", graphics2D1, (float) 255, (float) 255, (double) 2, 10.0f, (float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot4.getRangeMarkers(layer9);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        categoryAxis0.setTickLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(layer12);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Stroke stroke5 = legendGraphic4.getLineStroke();
        legendGraphic4.setLineVisible(false);
        java.awt.Paint paint8 = legendGraphic4.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 1L, (double) (short) 1);
        size2D2.setHeight(0.0d);
        double double5 = size2D2.width;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        boolean boolean7 = size2D2.equals((java.lang.Object) itemLabelAnchor6);
        double double8 = size2D2.width;
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets8.calculateRightInset((double) 2);
        categoryPlot4.setInsets(rectangleInsets8, true);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer15.setSeriesFillPaint(0, (java.awt.Paint) color17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer15.getBasePositiveItemLabelPosition();
        categoryPlot4.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation22 = null;
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str24 = layer23.toString();
        try {
            statisticalBarRenderer15.addAnnotation(categoryAnnotation22, layer23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.BACKGROUND" + "'", str24.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer0.setBaseCreateEntities(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        java.awt.Paint paint12 = categoryPlot11.getRangeGridlinePaint();
        boolean boolean13 = categoryPlot11.getDrawSharedDomainAxis();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            barRenderer0.drawOutline(graphics2D6, categoryPlot11, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation8 = axisLocation7.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation9, plotOrientation10);
        java.lang.String str12 = plotOrientation10.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation8, plotOrientation10);
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge13);
        try {
            double double15 = categoryAxis0.getCategoryMiddle((int) (byte) 10, 0, rectangle2D6, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str12.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color16 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape11, stroke15, (java.awt.Paint) color16);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, (double) (short) 1, (float) 100L, (float) 128);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity22 = new org.jfree.chart.entity.LegendItemEntity(shape21);
        java.awt.Shape shape23 = legendItemEntity22.getArea();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 0, (-1.0f));
        boolean boolean27 = org.jfree.chart.util.ShapeUtilities.equal(shape23, shape26);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setVisible(false);
        categoryAxis0.setLabel("ItemLabelAnchor.OUTSIDE9");
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot12.setDomainAxis(categoryAxis13);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection17 = categoryPlot12.getRangeMarkers(0, layer16);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray18 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot12.setDomainAxes(categoryAxisArray18);
        categoryPlot12.setRangeGridlinesVisible(false);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(categoryAxisArray18);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot4.setDomainAxis((int) (byte) 1, categoryAxis18);
        java.awt.Stroke stroke20 = categoryPlot4.getRangeGridlineStroke();
        categoryPlot4.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setBaseSeriesVisible(true, false);
        statisticalBarRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, false);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        double double17 = categoryAxis16.getLabelAngle();
        double double18 = categoryAxis16.getCategoryMargin();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = categoryPlot25.getRangeMarkers(layer29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        statisticalBarRenderer0.drawAnnotations(graphics2D14, rectangle2D15, categoryAxis16, valueAxis20, layer29, plotRenderingInfo31);
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, categoryItemRenderer39);
        categoryPlot40.setAnchorValue(0.0d, true);
        float float44 = categoryPlot40.getBackgroundAlpha();
        categoryPlot40.clearDomainMarkers((-1));
        boolean boolean47 = categoryPlot40.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        double double49 = categoryAxis48.getLabelAngle();
        double double50 = categoryAxis48.getCategoryMargin();
        java.lang.String str51 = categoryAxis48.getLabelToolTip();
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis48.setAxisLinePaint((java.awt.Paint) color52);
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset55 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range56 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset55);
        int int58 = defaultStatisticalCategoryDataset55.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset59, categoryAxis60, valueAxis61, categoryItemRenderer62);
        java.awt.Paint paint64 = categoryPlot63.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset55.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot63);
        org.jfree.data.general.PieDataset pieDataset67 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset55, (int) (byte) 10);
        try {
            statisticalBarRenderer0.drawItem(graphics2D33, categoryItemRendererState34, rectangle2D35, categoryPlot40, categoryAxis48, valueAxis54, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset55, (int) (byte) 100, (int) (byte) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 1.0f + "'", float44 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.2d + "'", double50 == 0.2d);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNull(range56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(pieDataset67);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "Layer.BACKGROUND", font4);
        float float6 = categoryAxis0.getTickMarkOutsideLength();
        double double7 = categoryAxis0.getLabelAngle();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Paint paint12 = statisticalBarRenderer0.getSeriesPaint(10);
        java.awt.Color color13 = java.awt.Color.cyan;
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color13);
        java.awt.Paint paint16 = null;
        statisticalBarRenderer0.setSeriesFillPaint((int) (byte) 10, paint16, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) 10L);
        axisState0.cursorRight(0.0d);
        java.util.List list5 = axisState0.getTicks();
        double double6 = axisState0.getCursor();
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-10.0d) + "'", double6 == (-10.0d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Font font1 = null;
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor(0, 100, (int) 'a');
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("ThreadContext", font1, (java.awt.Paint) chartColor5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Paint paint6 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) (-16727872));
        org.jfree.chart.block.BlockContainer blockContainer10 = null;
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) 10, (double) (-8323073));
        try {
            org.jfree.chart.util.Size2D size2D15 = flowArrangement0.arrange(blockContainer10, graphics2D11, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot19 = categoryPlot4.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot4.setRenderer(1, categoryItemRenderer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot4.getDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup24 = categoryPlot4.getDatasetGroup();
        int int25 = categoryPlot4.getRangeAxisCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation26 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNull(datasetGroup24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        java.awt.Stroke stroke10 = legendGraphic9.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendGraphic9.getShapeLocation();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, rectangleAnchor11, (double) (short) 10, (double) 0L);
        java.awt.Paint paint15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic16 = new org.jfree.chart.title.LegendGraphic(shape14, paint15);
        legendGraphic16.setHeight((double) 0L);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        legendTitle6.setItemLabelPadding(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Color color15 = java.awt.Color.lightGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        int int18 = color17.getRed();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape11, (java.awt.Paint) color15, stroke16, (java.awt.Paint) color17);
        java.awt.Stroke stroke20 = legendItem19.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = categoryPlot25.getRangeMarkers(layer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        int int32 = categoryPlot25.getIndexOf(categoryItemRenderer31);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier33 = categoryPlot25.getDrawingSupplier();
        boolean boolean34 = legendItem19.equals((java.lang.Object) categoryPlot25);
        legendItem19.setSeriesKey((java.lang.Comparable) (short) -1);
        int int37 = legendItem19.getDatasetIndex();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(drawingSupplier33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str3 = verticalAlignment2.toString();
        boolean boolean4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) rectangleAnchor1, (java.lang.Object) verticalAlignment2);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, 0.0d, (double) 1);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color11 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic12 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color11);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color16 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color16);
        legendGraphic12.setShape(shape15);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color26 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic27 = new org.jfree.chart.title.LegendGraphic(shape25, (java.awt.Paint) color26);
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color31 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic32 = new org.jfree.chart.title.LegendGraphic(shape30, (java.awt.Paint) color31);
        legendGraphic27.setShape(shape30);
        java.awt.Color color34 = java.awt.Color.lightGray;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color36 = java.awt.Color.MAGENTA;
        int int37 = color36.getRed();
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape30, (java.awt.Paint) color34, stroke35, (java.awt.Paint) color36);
        java.awt.Stroke stroke39 = legendItem38.getOutlineStroke();
        legendGraphic12.setOutlineStroke(stroke39);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer41 = legendGraphic12.getFillPaintTransformer();
        org.jfree.chart.ui.Contributor contributor44 = new org.jfree.chart.ui.Contributor("ChartChangeEventType.GENERAL", "VerticalAlignment.CENTER");
        java.lang.String str45 = contributor44.getEmail();
        java.lang.String str46 = contributor44.getEmail();
        columnArrangement7.add((org.jfree.chart.block.Block) legendGraphic12, (java.lang.Object) str46);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.CENTER" + "'", str3.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 255 + "'", int37 == 255);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(gradientPaintTransformer41);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "VerticalAlignment.CENTER" + "'", str45.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "VerticalAlignment.CENTER" + "'", str46.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getLegendItemGraphicEdge();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range10);
        org.jfree.chart.util.Size2D size2D12 = legendTitle6.arrange(graphics2D8, rectangleConstraint11);
        double double13 = size2D12.getHeight();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = legendGraphic4.getOutlinePaint();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = legendGraphic4.arrange(graphics2D6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        java.awt.Paint paint13 = categoryPlot12.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle14.getItemLabelPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean17 = rectangleInsets15.equals((java.lang.Object) verticalAlignment16);
        java.lang.String str18 = rectangleInsets15.toString();
        legendGraphic4.setPadding(rectangleInsets15);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets15.createInsetRectangle(rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]" + "'", str18.equals("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        categoryPlot4.clearAnnotations();
        categoryPlot4.setForegroundAlpha((float) '#');
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        categoryPlot15.setDomainAxis(categoryAxis16);
        java.lang.Comparable[] comparableArray18 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray19 = new java.lang.Comparable[] {};
        double[][] doubleArray20 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray18, comparableArray19, doubleArray20);
        org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset21, (int) (short) 100);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset21, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot15.getRendererForDataset(categoryDataset21);
        java.awt.Paint paint27 = categoryPlot15.getNoDataMessagePaint();
        categoryPlot4.setDomainGridlinePaint(paint27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str30 = axisLocation29.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType31 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str32 = categoryLabelWidthType31.toString();
        boolean boolean33 = axisLocation29.equals((java.lang.Object) str32);
        categoryPlot4.setRangeAxisLocation(axisLocation29, false);
        org.junit.Assert.assertNotNull(comparableArray18);
        org.junit.Assert.assertNotNull(comparableArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(pieDataset23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(categoryItemRenderer26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str30.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelWidthType31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str32.equals("CategoryLabelWidthType.CATEGORY"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.lightGray;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        try {
            textBlock3.draw(graphics2D4, (float) (byte) 10, (float) 128, textBlockAnchor7, (float) '4', (float) (-16727872), (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.clearRangeAxes();
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.awt.Color color1 = java.awt.Color.cyan;
        java.awt.Stroke stroke2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        java.awt.Paint paint8 = categoryPlot7.getRangeGridlinePaint();
        org.jfree.chart.util.ObjectList objectList10 = new org.jfree.chart.util.ObjectList(0);
        objectList10.clear();
        int int12 = objectList10.size();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        double double14 = categoryAxis13.getLabelAngle();
        double double15 = categoryAxis13.getCategoryMargin();
        java.lang.String str16 = categoryAxis13.getLabelToolTip();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis13.setAxisLinePaint((java.awt.Paint) color17);
        int int19 = objectList10.indexOf((java.lang.Object) categoryAxis13);
        java.awt.Stroke stroke20 = categoryAxis13.getAxisLineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-16727872), (java.awt.Paint) color1, stroke2, paint8, stroke20, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.2d + "'", double15 == 0.2d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) 1L);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color16 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape11, stroke15, (java.awt.Paint) color16);
        int int18 = legendItem17.getDatasetIndex();
        java.lang.Comparable comparable19 = legendItem17.getSeriesKey();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(comparable19);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color4);
        categoryAxis0.setFixedDimension((double) 10L);
        org.jfree.chart.plot.Plot plot8 = categoryAxis0.getPlot();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setBaseSeriesVisible(true, false);
        java.awt.Paint paint11 = statisticalBarRenderer0.lookupSeriesFillPaint(2);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Color color15 = java.awt.Color.lightGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        int int18 = color17.getRed();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape11, (java.awt.Paint) color15, stroke16, (java.awt.Paint) color17);
        java.awt.Paint paint20 = legendItem19.getOutlinePaint();
        java.text.AttributedString attributedString21 = legendItem19.getAttributedLabel();
        org.jfree.chart.block.BlockParams blockParams22 = new org.jfree.chart.block.BlockParams();
        blockParams22.setTranslateY((double) (byte) 100);
        boolean boolean25 = legendItem19.equals((java.lang.Object) (byte) 100);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(attributedString21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        legendGraphic4.setHeight(0.0d);
        java.lang.String str13 = legendGraphic4.getID();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double15 = statisticalBarRenderer14.getBase();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = null;
        statisticalBarRenderer14.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator17);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color27 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color27);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color32 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape31, (java.awt.Paint) color32);
        legendGraphic28.setShape(shape31);
        java.awt.Stroke stroke35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color36 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape31, stroke35, (java.awt.Paint) color36);
        statisticalBarRenderer14.setSeriesFillPaint(1, (java.awt.Paint) color36, true);
        java.awt.Stroke stroke40 = statisticalBarRenderer14.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer41 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer41.setSeriesFillPaint(0, (java.awt.Paint) color43);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator46 = null;
        statisticalBarRenderer41.setSeriesURLGenerator(255, categoryURLGenerator46);
        statisticalBarRenderer41.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke53 = statisticalBarRenderer41.getItemStroke(255, (int) 'a');
        statisticalBarRenderer41.setAutoPopulateSeriesPaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition58 = statisticalBarRenderer41.getPositiveItemLabelPosition((int) ' ', (int) (byte) -1);
        statisticalBarRenderer14.setBasePositiveItemLabelPosition(itemLabelPosition58, true);
        boolean boolean61 = legendGraphic4.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(itemLabelPosition58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke12 = statisticalBarRenderer0.getItemStroke(255, (int) 'a');
        statisticalBarRenderer0.setAutoPopulateSeriesPaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) ' ', (int) (byte) -1);
        boolean boolean19 = statisticalBarRenderer0.isSeriesVisible((-8323073));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = legendGraphic4.getOutlinePaint();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = legendGraphic4.arrange(graphics2D6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        java.awt.Paint paint13 = categoryPlot12.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle14.getItemLabelPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean17 = rectangleInsets15.equals((java.lang.Object) verticalAlignment16);
        java.lang.String str18 = rectangleInsets15.toString();
        legendGraphic4.setPadding(rectangleInsets15);
        java.awt.Paint paint20 = legendGraphic4.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]" + "'", str18.equals("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"));
        org.junit.Assert.assertNull(paint20);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation3.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation5, plotOrientation6);
        java.lang.String str8 = plotOrientation6.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation4, plotOrientation6);
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = axisSpace0.reserved(rectangle2D2, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str8.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.data.KeyedObjects keyedObjects5 = new org.jfree.data.KeyedObjects();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        keyedObjects5.addObject((java.lang.Comparable) (byte) 0, (java.lang.Object) font7);
        java.lang.Comparable comparable10 = keyedObjects5.getKey(0);
        boolean boolean11 = itemLabelPosition4.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (byte) 0 + "'", comparable10.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Paint paint6 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = legendTitle7.getVerticalAlignment();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Class<?> wildcardClass10 = textAnchor9.getClass();
        boolean boolean11 = verticalAlignment8.equals((java.lang.Object) wildcardClass10);
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ItemLabelAnchor.OUTSIDE9", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(inputStream12);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj3 = objectList1.get(255);
        java.lang.Object obj5 = objectList1.get((int) '4');
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer7.setSeriesFillPaint(0, (java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = statisticalBarRenderer7.getBasePositiveItemLabelPosition();
        java.awt.Paint paint14 = statisticalBarRenderer7.getItemFillPaint((int) (short) 100, 1);
        try {
            objectList1.set(0, (java.lang.Object) statisticalBarRenderer7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 128, 0.0d, 1.0d, Double.NaN, (java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            blockBorder5.draw(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getItemLabelPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean9 = rectangleInsets7.equals((java.lang.Object) verticalAlignment8);
        double double10 = rectangleInsets7.getBottom();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets8.calculateRightInset((double) 2);
        categoryPlot4.setInsets(rectangleInsets8, true);
        categoryPlot4.clearRangeAxes();
        java.awt.Stroke stroke14 = categoryPlot4.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setBaseSeriesVisible(true, false);
        statisticalBarRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setAnchorValue(0.0d, true);
        categoryPlot21.clearAnnotations();
        categoryPlot21.setForegroundAlpha((float) '#');
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        categoryPlot32.setDomainAxis(categoryAxis33);
        java.lang.Comparable[] comparableArray35 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray36 = new java.lang.Comparable[] {};
        double[][] doubleArray37 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray35, comparableArray36, doubleArray37);
        org.jfree.data.general.PieDataset pieDataset40 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset38, (int) (short) 100);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset38, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = categoryPlot32.getRendererForDataset(categoryDataset38);
        java.awt.Paint paint44 = categoryPlot32.getNoDataMessagePaint();
        categoryPlot21.setDomainGridlinePaint(paint44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset48 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset48);
        try {
            statisticalBarRenderer0.drawItem(graphics2D14, categoryItemRendererState15, rectangle2D16, categoryPlot21, categoryAxis46, valueAxis47, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset48, (int) (short) 0, (int) 'a', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(comparableArray35);
        org.junit.Assert.assertNotNull(comparableArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(pieDataset40);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNull(categoryItemRenderer43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNull(range49);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color4);
        categoryAxis0.setVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 0, (-1.0f));
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor(0, 100, (int) 'a');
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double15 = statisticalBarRenderer14.getBase();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = null;
        statisticalBarRenderer14.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator17);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color27 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color27);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color32 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape31, (java.awt.Paint) color32);
        legendGraphic28.setShape(shape31);
        java.awt.Stroke stroke35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color36 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape31, stroke35, (java.awt.Paint) color36);
        statisticalBarRenderer14.setSeriesFillPaint(1, (java.awt.Paint) color36, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer40 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer40.setSeriesFillPaint(0, (java.awt.Paint) color42);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = statisticalBarRenderer40.getPositiveItemLabelPosition((int) (byte) 100, (int) 'a');
        java.awt.Stroke stroke48 = statisticalBarRenderer40.lookupSeriesOutlineStroke((int) (byte) 1);
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color57 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic58 = new org.jfree.chart.title.LegendGraphic(shape56, (java.awt.Paint) color57);
        java.awt.Shape shape61 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color62 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic63 = new org.jfree.chart.title.LegendGraphic(shape61, (java.awt.Paint) color62);
        legendGraphic58.setShape(shape61);
        java.awt.Color color65 = java.awt.Color.lightGray;
        java.awt.Stroke stroke66 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color67 = java.awt.Color.MAGENTA;
        int int68 = color67.getRed();
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape61, (java.awt.Paint) color65, stroke66, (java.awt.Paint) color67);
        org.jfree.chart.entity.ChartEntity chartEntity70 = new org.jfree.chart.entity.ChartEntity(shape61);
        java.awt.Shape shape77 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color78 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic79 = new org.jfree.chart.title.LegendGraphic(shape77, (java.awt.Paint) color78);
        java.awt.Shape shape82 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color83 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic84 = new org.jfree.chart.title.LegendGraphic(shape82, (java.awt.Paint) color83);
        legendGraphic79.setShape(shape82);
        java.awt.Color color86 = java.awt.Color.lightGray;
        java.awt.Stroke stroke87 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color88 = java.awt.Color.MAGENTA;
        int int89 = color88.getRed();
        org.jfree.chart.LegendItem legendItem90 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape82, (java.awt.Paint) color86, stroke87, (java.awt.Paint) color88);
        java.awt.Stroke stroke91 = legendItem90.getLineStroke();
        java.awt.Color color92 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean94 = color92.equals((java.lang.Object) 10.0d);
        try {
            org.jfree.chart.LegendItem legendItem95 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "hi!", "Size2D[width=1.0, height=0.0]", true, shape7, false, (java.awt.Paint) chartColor12, true, (java.awt.Paint) color36, stroke48, true, shape61, stroke91, (java.awt.Paint) color92);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 255 + "'", int68 == 255);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(shape82);
        org.junit.Assert.assertNotNull(color83);
        org.junit.Assert.assertNotNull(color86);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertNotNull(color88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 255 + "'", int89 == 255);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNotNull(color92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("{0}");
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 255, (double) 10);
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D((double) 1L, (double) (short) 1);
        org.jfree.chart.util.Size2D size2D6 = rectangleConstraint2.calculateConstrainedSize(size2D5);
        java.lang.String str7 = size2D6.toString();
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Size2D[width=255.0, height=10.0]" + "'", str7.equals("Size2D[width=255.0, height=10.0]"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        objectList1.clear();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection12 = categoryPlot7.getRangeMarkers(layer11);
        int int13 = objectList1.indexOf((java.lang.Object) collection12);
        java.lang.Object obj14 = objectList1.clone();
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot8);
        try {
            java.lang.Number number13 = defaultStatisticalCategoryDataset0.getStdDevValue(1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot7.setDomainAxis(categoryAxis8);
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray11 = new java.lang.Comparable[] {};
        double[][] doubleArray12 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray10, comparableArray11, doubleArray12);
        org.jfree.data.general.PieDataset pieDataset15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset13, (int) (short) 100);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset13, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot7.getRendererForDataset(categoryDataset13);
        java.awt.Paint paint19 = categoryPlot7.getNoDataMessagePaint();
        categoryPlot7.setBackgroundImageAlpha(0.0f);
        categoryPlot7.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        categoryPlot28.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = new org.jfree.chart.util.RectangleInsets();
        double double34 = rectangleInsets32.calculateRightInset((double) 2);
        categoryPlot28.setInsets(rectangleInsets32, true);
        org.jfree.chart.util.UnitType unitType37 = rectangleInsets32.getUnitType();
        categoryPlot7.setAxisOffset(rectangleInsets32);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot7.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        categoryPlot7.setRenderer(categoryItemRenderer40, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor43 = categoryPlot7.getDomainGridlinePosition();
        java.lang.String str44 = categoryAnchor43.toString();
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, valueAxis50, categoryItemRenderer51);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        categoryPlot52.setDomainAxis(categoryAxis53);
        java.lang.Comparable[] comparableArray55 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray56 = new java.lang.Comparable[] {};
        double[][] doubleArray57 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset58 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray55, comparableArray56, doubleArray57);
        org.jfree.data.general.PieDataset pieDataset60 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset58, (int) (short) 100);
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset58, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = categoryPlot52.getRendererForDataset(categoryDataset58);
        java.awt.Paint paint64 = categoryPlot52.getNoDataMessagePaint();
        categoryPlot52.setBackgroundImageAlpha(0.0f);
        categoryPlot52.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset69 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = null;
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer72 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset69, categoryAxis70, valueAxis71, categoryItemRenderer72);
        categoryPlot73.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = new org.jfree.chart.util.RectangleInsets();
        double double79 = rectangleInsets77.calculateRightInset((double) 2);
        categoryPlot73.setInsets(rectangleInsets77, true);
        org.jfree.chart.util.UnitType unitType82 = rectangleInsets77.getUnitType();
        categoryPlot52.setAxisOffset(rectangleInsets77);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = categoryPlot52.getRangeAxisEdge();
        boolean boolean85 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge84);
        try {
            double double86 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor43, 0, (-16727872), rectangle2D47, rectangleEdge84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(comparableArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(pieDataset15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(categoryItemRenderer18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(unitType37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(categoryAnchor43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str44.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertNotNull(comparableArray55);
        org.junit.Assert.assertNotNull(comparableArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(categoryDataset58);
        org.junit.Assert.assertNotNull(pieDataset60);
        org.junit.Assert.assertNull(range62);
        org.junit.Assert.assertNull(categoryItemRenderer63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0d + "'", double79 == 1.0d);
        org.junit.Assert.assertNotNull(unitType82);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        objectList1.clear();
        int int3 = objectList1.size();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        double double5 = categoryAxis4.getLabelAngle();
        double double6 = categoryAxis4.getCategoryMargin();
        java.lang.String str7 = categoryAxis4.getLabelToolTip();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis4.setAxisLinePaint((java.awt.Paint) color8);
        int int10 = objectList1.indexOf((java.lang.Object) categoryAxis4);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer11.setSeriesFillPaint(0, (java.awt.Paint) color13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = statisticalBarRenderer11.getPositiveItemLabelPosition((int) (byte) 100, (int) 'a');
        java.awt.Stroke stroke19 = statisticalBarRenderer11.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("AxisLocation.BOTTOM_OR_RIGHT", font22);
        textTitle20.setFont(font22);
        statisticalBarRenderer11.setBaseItemLabelFont(font22, true);
        categoryAxis4.setLabelFont(font22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color4);
        categoryAxis0.setFixedDimension((double) 10L);
        categoryAxis0.setTickLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer1.getPositiveItemLabelPosition((int) (byte) 100, (int) 'a');
        java.awt.Stroke stroke9 = statisticalBarRenderer1.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("AxisLocation.BOTTOM_OR_RIGHT", font12);
        textTitle10.setFont(font12);
        statisticalBarRenderer1.setBaseItemLabelFont(font12, true);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("TextAnchor.HALF_ASCENT_RIGHT", font12);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis0.setLabelPaint((java.awt.Paint) color4);
        categoryAxis0.setLabelURL("hi!");
        categoryAxis0.setUpperMargin((double) (-16727872));
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = null;
        try {
            categoryAxis0.setLabelInsets(rectangleInsets10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("UnitType.RELATIVE", "Layer.BACKGROUND");
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) 10L);
        axisState0.setCursor(10.0d);
        axisState0.cursorDown((double) (byte) 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getInfo();
        java.awt.Image image2 = projectInfo0.getLogo();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        double double31 = rectangleInsets29.calculateRightInset((double) 2);
        categoryPlot25.setInsets(rectangleInsets29, true);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets29.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets29);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot4.setRenderer(categoryItemRenderer37, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor40 = categoryPlot4.getDomainGridlinePosition();
        org.jfree.chart.axis.ValueAxis valueAxis42 = categoryPlot4.getRangeAxisForDataset((int) (byte) 1);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(categoryAnchor40);
        org.junit.Assert.assertNull(valueAxis42);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        categoryPlot4.clearAnnotations();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        categoryPlot4.setDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9);
        java.lang.Object obj11 = categoryPlot4.clone();
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        boolean boolean7 = statisticalBarRenderer0.getItemVisible(128, (int) '#');
        java.awt.Stroke stroke8 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer0.setItemMargin(0.2d);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot11.setDomainAxis(categoryAxis12);
        java.lang.Comparable[] comparableArray14 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray15 = new java.lang.Comparable[] {};
        double[][] doubleArray16 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray14, comparableArray15, doubleArray16);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset17, (int) (short) 100);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset17, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot11.getRendererForDataset(categoryDataset17);
        java.awt.Paint paint23 = categoryPlot11.getNoDataMessagePaint();
        barRenderer0.setSeriesFillPaint(0, paint23);
        boolean boolean26 = barRenderer0.isSeriesVisibleInLegend((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(comparableArray14);
        org.junit.Assert.assertNotNull(comparableArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "Layer.BACKGROUND", font4);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = legendTitle17.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = categoryLabelPositions10.getLabelPosition(rectangleEdge18);
        try {
            double double20 = categoryAxis0.getCategoryMiddle((int) (byte) 0, 0, rectangle2D8, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(categoryLabelPosition19);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 3.0d);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean4 = keyedObjects2D0.equals((java.lang.Object) chartChangeEventType3);
        org.jfree.chart.block.BlockBorder blockBorder5 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean6 = keyedObjects2D0.equals((java.lang.Object) blockBorder5);
        java.lang.Object obj7 = null;
        boolean boolean8 = keyedObjects2D0.equals(obj7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setAxisLineVisible(true);
        categoryAxis9.setLabelAngle((double) (-123));
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        boolean boolean15 = categoryAxis9.equals((java.lang.Object) color14);
        java.awt.Paint paint16 = categoryAxis9.getTickLabelPaint();
        keyedObjects2D0.setObject((java.lang.Object) categoryAxis9, (java.lang.Comparable) 0.2d, (java.lang.Comparable) "Size2D[width=1.0, height=0.0]");
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color27 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color27);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color32 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape31, (java.awt.Paint) color32);
        legendGraphic28.setShape(shape31);
        java.awt.Color color35 = java.awt.Color.lightGray;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color37 = java.awt.Color.MAGENTA;
        int int38 = color37.getRed();
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape31, (java.awt.Paint) color35, stroke36, (java.awt.Paint) color37);
        categoryAxis9.setTickLabelPaint((java.awt.Paint) color37);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(blockBorder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 255 + "'", int38 == 255);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        categoryPlot4.setRangeGridlinesVisible(true);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.data.KeyedObject keyedObject23 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100.0f, (java.lang.Object) color22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        categoryPlot28.setDomainAxis(categoryAxis29);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection33 = categoryPlot28.getRangeMarkers(0, layer32);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray34 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot28.setDomainAxes(categoryAxisArray34);
        boolean boolean36 = keyedObject23.equals((java.lang.Object) categoryAxisArray34);
        categoryPlot4.setDomainAxes(categoryAxisArray34);
        categoryPlot4.setRangeCrosshairValue((double) (byte) 10);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertNotNull(categoryAxisArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Color color15 = java.awt.Color.lightGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        int int18 = color17.getRed();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape11, (java.awt.Paint) color15, stroke16, (java.awt.Paint) color17);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color23 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic24 = new org.jfree.chart.title.LegendGraphic(shape22, (java.awt.Paint) color23);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color28 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic29 = new org.jfree.chart.title.LegendGraphic(shape27, (java.awt.Paint) color28);
        legendGraphic24.setShape(shape27);
        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) shape27);
        boolean boolean32 = org.jfree.chart.util.ShapeUtilities.equal(shape11, shape27);
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity(shape27, "ThreadContext");
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer0.setSeriesVisible(0, (java.lang.Boolean) true, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer8.setSeriesFillPaint(0, (java.awt.Paint) color10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalBarRenderer8.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor13 = itemLabelPosition12.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = itemLabelPosition12.getItemLabelAnchor();
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer0.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color12);
        java.awt.Paint paint15 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (short) 0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] {};
        double[][] doubleArray3 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray2, doubleArray3);
        boolean boolean5 = projectInfo0.equals((java.lang.Object) categoryDataset4);
        java.lang.String str6 = projectInfo0.getCopyright();
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(categoryDataset4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot19 = categoryPlot4.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot4.setRenderer(1, categoryItemRenderer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot4.getDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup24 = categoryPlot4.getDatasetGroup();
        float float25 = categoryPlot4.getBackgroundImageAlpha();
        boolean boolean26 = categoryPlot4.isSubplot();
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNull(datasetGroup24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        boolean boolean5 = categoryPlot4.getDrawSharedDomainAxis();
        java.awt.Stroke stroke6 = categoryPlot4.getOutlineStroke();
        boolean boolean7 = categoryPlot4.isSubplot();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot4.getDataset();
        categoryPlot4.setOutlineVisible(true);
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNull(categoryDataset8);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getItemLabelPadding();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        legendTitle6.setWrapper(blockContainer8);
        blockContainer8.clear();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection9 = categoryPlot4.getRangeMarkers(0, layer8);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot17.setDomainAxis(categoryAxis18);
        java.lang.Comparable[] comparableArray20 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray21 = new java.lang.Comparable[] {};
        double[][] doubleArray22 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray20, comparableArray21, doubleArray22);
        org.jfree.data.general.PieDataset pieDataset25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset23, (int) (short) 100);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset23, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot17.getRendererForDataset(categoryDataset23);
        java.awt.Paint paint29 = categoryPlot17.getNoDataMessagePaint();
        categoryPlot17.setBackgroundImageAlpha(0.0f);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = categoryPlot17.getRendererForDataset(categoryDataset32);
        boolean boolean34 = legendTitle12.equals((java.lang.Object) categoryPlot17);
        org.jfree.chart.block.BlockContainer blockContainer35 = legendTitle12.getItemContainer();
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertNotNull(comparableArray20);
        org.junit.Assert.assertNotNull(comparableArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(pieDataset25);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNull(categoryItemRenderer28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(categoryItemRenderer33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(blockContainer35);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.awt.Shape shape0 = null;
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] {};
        double[][] doubleArray6 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray4, comparableArray5, doubleArray6);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset7, (int) (short) 100);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset9, (java.lang.Comparable) 0.2d, (double) (-123));
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 128, (org.jfree.data.KeyedValues) pieDataset12);
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "", "Size2D[width=1.0, height=0.0]", categoryDataset13, (java.lang.Comparable) "Layer.BACKGROUND", (java.lang.Comparable) (-8323073));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNotNull(categoryDataset13);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        objectList1.clear();
        int int3 = objectList1.size();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        double double5 = categoryAxis4.getLabelAngle();
        double double6 = categoryAxis4.getCategoryMargin();
        java.lang.String str7 = categoryAxis4.getLabelToolTip();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis4.setAxisLinePaint((java.awt.Paint) color8);
        int int10 = objectList1.indexOf((java.lang.Object) categoryAxis4);
        java.awt.Stroke stroke11 = categoryAxis4.getAxisLineStroke();
        categoryAxis4.setTickLabelsVisible(false);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation17, plotOrientation18);
        try {
            double double20 = categoryAxis4.getCategoryStart((int) (byte) 0, (int) (short) 0, rectangle2D16, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setAnchorValue(0.0d, true);
        java.awt.Font font10 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("hi!", font10);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.GENERAL", font10);
        textTitle12.setExpandToFitSpace(true);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray1, doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (int) (short) 100);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3, (double) (-1L));
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, 10);
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(pieDataset10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot19 = categoryPlot4.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot4.setRenderer(1, categoryItemRenderer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot4.getDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup24 = categoryPlot4.getDatasetGroup();
        int int25 = categoryPlot4.getRangeAxisCount();
        java.util.List list26 = categoryPlot4.getCategories();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot4.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNull(datasetGroup24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor0, jFreeChart1, 255, (int) (short) 1);
        java.awt.Font font6 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot11.setDomainAxis(categoryAxis12);
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot11.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation18, plotOrientation19);
        categoryPlot11.setDomainAxisLocation((int) (short) 10, axisLocation18);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font6, (org.jfree.chart.plot.Plot) categoryPlot11, true);
        jFreeChart23.setTitle("Layer.BACKGROUND");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer26.setSeriesFillPaint(0, (java.awt.Paint) color28);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator31 = null;
        statisticalBarRenderer26.setSeriesURLGenerator(255, categoryURLGenerator31);
        statisticalBarRenderer26.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer26.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color38);
        jFreeChart23.setBorderPaint((java.awt.Paint) color38);
        chartProgressEvent4.setChart(jFreeChart23);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, valueAxis46, categoryItemRenderer47);
        categoryPlot48.setAnchorValue(0.0d, true);
        categoryPlot48.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation54 = categoryPlot48.getRangeAxisLocation(255);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = null;
        java.awt.geom.Point2D point2D60 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D58, rectangleAnchor59);
        categoryPlot48.zoomRangeAxes((double) 'a', (double) 'a', plotRenderingInfo57, point2D60);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo62 = null;
        try {
            jFreeChart23.draw(graphics2D42, rectangle2D43, point2D60, chartRenderingInfo62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(axisLocation54);
        org.junit.Assert.assertNotNull(point2D60);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        legendGraphic4.setHeight(0.0d);
        java.awt.Shape shape13 = legendGraphic4.getShape();
        legendGraphic4.setID("ChartChangeEventType.GENERAL");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendGraphic4.getPadding();
        java.awt.Paint paint17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        legendGraphic4.setLinePaint(paint17);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setURLText("VerticalAlignment.CENTER");
        boolean boolean4 = textTitle1.getNotify();
        java.awt.Paint paint5 = textTitle1.getPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-8323073), 0, 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getBase();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        statisticalBarRenderer0.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator3);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color13 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape12, (java.awt.Paint) color13);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color18 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape17, (java.awt.Paint) color18);
        legendGraphic14.setShape(shape17);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color22 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape17, stroke21, (java.awt.Paint) color22);
        statisticalBarRenderer0.setSeriesFillPaint(1, (java.awt.Paint) color22, true);
        java.awt.Stroke stroke26 = statisticalBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer27.setSeriesFillPaint(0, (java.awt.Paint) color29);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = null;
        statisticalBarRenderer27.setSeriesURLGenerator(255, categoryURLGenerator32);
        statisticalBarRenderer27.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke39 = statisticalBarRenderer27.getItemStroke(255, (int) 'a');
        statisticalBarRenderer27.setAutoPopulateSeriesPaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = statisticalBarRenderer27.getPositiveItemLabelPosition((int) ' ', (int) (byte) -1);
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition44, true);
        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color51 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic52 = new org.jfree.chart.title.LegendGraphic(shape50, (java.awt.Paint) color51);
        java.awt.Shape shape55 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color56 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic57 = new org.jfree.chart.title.LegendGraphic(shape55, (java.awt.Paint) color56);
        java.awt.Stroke stroke58 = legendGraphic57.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = legendGraphic57.getShapeLocation();
        java.awt.Shape shape62 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape50, rectangleAnchor59, (double) (short) 10, (double) 0L);
        statisticalBarRenderer0.setSeriesShape(100, shape62, true);
        java.awt.Graphics2D graphics2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.data.category.CategoryDataset categoryDataset67 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis68 = null;
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot(categoryDataset67, categoryAxis68, valueAxis69, categoryItemRenderer70);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = null;
        categoryPlot71.setDomainAxis(categoryAxis72);
        java.lang.Comparable[] comparableArray74 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray75 = new java.lang.Comparable[] {};
        double[][] doubleArray76 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset77 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray74, comparableArray75, doubleArray76);
        org.jfree.data.general.PieDataset pieDataset79 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset77, (int) (short) 100);
        org.jfree.data.Range range81 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset77, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer82 = categoryPlot71.getRendererForDataset(categoryDataset77);
        java.awt.Paint paint83 = categoryPlot71.getNoDataMessagePaint();
        categoryPlot71.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot86 = categoryPlot71.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer88 = null;
        categoryPlot71.setRenderer(1, categoryItemRenderer88);
        org.jfree.chart.axis.CategoryAxis categoryAxis90 = categoryPlot71.getDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup91 = categoryPlot71.getDatasetGroup();
        int int92 = categoryPlot71.getRangeAxisCount();
        java.util.List list93 = categoryPlot71.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo95 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState96 = statisticalBarRenderer0.initialise(graphics2D65, rectangle2D66, categoryPlot71, 10, plotRenderingInfo95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(itemLabelPosition44);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNull(stroke58);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(comparableArray74);
        org.junit.Assert.assertNotNull(comparableArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(categoryDataset77);
        org.junit.Assert.assertNotNull(pieDataset79);
        org.junit.Assert.assertNull(range81);
        org.junit.Assert.assertNull(categoryItemRenderer82);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNull(plot86);
        org.junit.Assert.assertNull(categoryAxis90);
        org.junit.Assert.assertNull(datasetGroup91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNull(list93);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("AxisLocation.BOTTOM_OR_RIGHT", font3);
        textTitle1.setFont(font3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        java.awt.Paint paint14 = categoryPlot13.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle15.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = categoryLabelPositions8.getLabelPosition(rectangleEdge16);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        java.awt.Paint paint25 = categoryPlot24.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot24);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle26.getItemLabelPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean29 = rectangleInsets27.equals((java.lang.Object) verticalAlignment28);
        try {
            org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("hi!", font3, (java.awt.Paint) color6, rectangleEdge16, horizontalAlignment18, verticalAlignment19, rectangleInsets27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(categoryLabelPosition17);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setCategoryLabelPositionOffset(255);
        java.lang.String str6 = categoryAxis0.getLabelToolTip();
        double double7 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis0.setLabelPaint((java.awt.Paint) color4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisState10.moveCursor((-1.0d), rectangleEdge12);
        try {
            double double14 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor6, (int) (byte) 1, (int) ' ', rectangle2D9, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Color color15 = java.awt.Color.lightGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        int int18 = color17.getRed();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape11, (java.awt.Paint) color15, stroke16, (java.awt.Paint) color17);
        java.awt.Stroke stroke20 = legendItem19.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = categoryPlot25.getRangeMarkers(layer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        int int32 = categoryPlot25.getIndexOf(categoryItemRenderer31);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier33 = categoryPlot25.getDrawingSupplier();
        boolean boolean34 = legendItem19.equals((java.lang.Object) categoryPlot25);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray35 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot25.setRangeAxes(valueAxisArray35);
        categoryPlot25.clearDomainMarkers((-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = new org.jfree.chart.util.RectangleInsets();
        double double41 = rectangleInsets39.trimWidth((double) 1);
        categoryPlot25.setInsets(rectangleInsets39);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(drawingSupplier33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(valueAxisArray35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-1.0d) + "'", double41 == (-1.0d));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        double double31 = rectangleInsets29.calculateRightInset((double) 2);
        categoryPlot25.setInsets(rectangleInsets29, true);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets29.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets29);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot4.setRenderer(categoryItemRenderer37, false);
        boolean boolean40 = categoryPlot4.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        double double2 = axisSpace0.getTop();
        java.lang.String str3 = axisSpace0.toString();
        axisSpace0.setBottom((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getItemLabelPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean9 = rectangleInsets7.equals((java.lang.Object) verticalAlignment8);
        double double11 = rectangleInsets7.extendWidth((double) (short) 10);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 14.0d + "'", double11 == 14.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setCategoryLabelPositionOffset(255);
        java.lang.String str6 = categoryAxis0.getLabelToolTip();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "LegendItemEntity: seriesKey=null, dataset=null", font8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getItemLabelPadding();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        legendTitle6.setWrapper(blockContainer8);
        java.lang.Object obj10 = legendTitle6.clone();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setVisible(false);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        textTitle8.draw(graphics2D9, rectangle2D10);
        java.awt.Paint paint12 = textTitle8.getPaint();
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 2, paint12);
        categoryAxis0.setUpperMargin((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot10.setDomainAxis(categoryAxis11);
        java.lang.Comparable[] comparableArray13 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray14 = new java.lang.Comparable[] {};
        double[][] doubleArray15 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray13, comparableArray14, doubleArray15);
        org.jfree.data.general.PieDataset pieDataset18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, (int) (short) 100);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset16, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot10.getRendererForDataset(categoryDataset16);
        java.awt.Paint paint22 = categoryPlot10.getNoDataMessagePaint();
        categoryPlot10.setBackgroundImageAlpha(0.0f);
        categoryPlot10.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        categoryPlot31.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = new org.jfree.chart.util.RectangleInsets();
        double double37 = rectangleInsets35.calculateRightInset((double) 2);
        categoryPlot31.setInsets(rectangleInsets35, true);
        org.jfree.chart.util.UnitType unitType40 = rectangleInsets35.getUnitType();
        categoryPlot10.setAxisOffset(rectangleInsets35);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot10.getRangeAxisEdge();
        try {
            java.util.List list43 = categoryAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray13);
        org.junit.Assert.assertNotNull(comparableArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(pieDataset18);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(unitType40);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Paint paint6 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) (-16727872));
        java.awt.Paint paint10 = legendTitle7.getItemPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.trimWidth((double) 1);
        legendTitle7.setItemLabelPadding(rectangleInsets11);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot19.setDomainAxis(categoryAxis20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        categoryPlot26.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets();
        double double32 = rectangleInsets30.calculateRightInset((double) 2);
        categoryPlot26.setInsets(rectangleInsets30, true);
        org.jfree.chart.util.UnitType unitType35 = rectangleInsets30.getUnitType();
        categoryPlot19.setAxisOffset(rectangleInsets30);
        double double37 = rectangleInsets30.getBottom();
        legendTitle7.setMargin(rectangleInsets30);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str42 = axisLocation41.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation43 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation41, plotOrientation43);
        try {
            java.lang.Object obj45 = legendTitle7.draw(graphics2D39, rectangle2D40, (java.lang.Object) plotOrientation43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(unitType35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str42.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(2.0d, 0.0d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color4);
        categoryAxis0.setFixedDimension((double) 10L);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot12.setDomainAxis(categoryAxis13);
        java.lang.Comparable[] comparableArray15 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray16 = new java.lang.Comparable[] {};
        double[][] doubleArray17 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray15, comparableArray16, doubleArray17);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset18, (int) (short) 100);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset18, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot12.getRendererForDataset(categoryDataset18);
        java.awt.Paint paint24 = categoryPlot12.getNoDataMessagePaint();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean29 = barRenderer26.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer26.setSeriesVisible(0, (java.lang.Boolean) true, true);
        categoryPlot12.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer26);
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        categoryPlot42.setDomainAxis(categoryAxis43);
        java.lang.Comparable[] comparableArray45 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray46 = new java.lang.Comparable[] {};
        double[][] doubleArray47 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray45, comparableArray46, doubleArray47);
        org.jfree.data.general.PieDataset pieDataset50 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset48, (int) (short) 100);
        org.jfree.data.Range range52 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset48, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = categoryPlot42.getRendererForDataset(categoryDataset48);
        java.awt.Paint paint54 = categoryPlot42.getNoDataMessagePaint();
        categoryPlot42.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot57 = categoryPlot42.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray59 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer58 };
        categoryPlot42.setRenderers(categoryItemRendererArray59);
        java.awt.Stroke stroke61 = categoryPlot42.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color63 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryAxis62.setAxisLinePaint((java.awt.Paint) color63);
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset66 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range67 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset66);
        int int69 = defaultStatisticalCategoryDataset66.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset70 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = null;
        org.jfree.chart.axis.ValueAxis valueAxis72 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer73 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot(categoryDataset70, categoryAxis71, valueAxis72, categoryItemRenderer73);
        java.awt.Paint paint75 = categoryPlot74.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset66.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot74);
        try {
            barRenderer26.drawItem(graphics2D35, categoryItemRendererState36, rectangle2D37, categoryPlot42, categoryAxis62, valueAxis65, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset66, (int) (short) 0, 2, 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(comparableArray15);
        org.junit.Assert.assertNotNull(comparableArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(comparableArray45);
        org.junit.Assert.assertNotNull(comparableArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(pieDataset50);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNull(categoryItemRenderer53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNull(plot57);
        org.junit.Assert.assertNotNull(categoryItemRendererArray59);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNull(range67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNotNull(paint75);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        categoryAxis0.setLabelPaint((java.awt.Paint) color4);
        categoryAxis0.setLabelURL("hi!");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double13 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor8, (int) (short) 1, 255, rectangle2D11, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(categoryAnchor8);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        boolean boolean5 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot4.getDomainAxis((int) (byte) 10);
        java.awt.Paint paint8 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryPlot4.setOutlinePaint(paint8);
        float float10 = categoryPlot4.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot19 = categoryPlot4.getParent();
        categoryPlot4.setAnchorValue(0.0d, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer24.setSeriesFillPaint(0, (java.awt.Paint) color26);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator29 = null;
        statisticalBarRenderer24.setSeriesURLGenerator(255, categoryURLGenerator29);
        statisticalBarRenderer24.setSeriesVisible(100, (java.lang.Boolean) false, true);
        categoryPlot4.setRenderer(128, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer24);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer36.setSeriesFillPaint(0, (java.awt.Paint) color38);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        statisticalBarRenderer36.setSeriesURLGenerator(255, categoryURLGenerator41);
        statisticalBarRenderer36.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer36.setErrorIndicatorStroke(stroke46);
        statisticalBarRenderer24.setBaseStroke(stroke46, true);
        org.jfree.chart.util.ObjectList objectList52 = new org.jfree.chart.util.ObjectList(0);
        objectList52.clear();
        int int54 = objectList52.size();
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis();
        double double56 = categoryAxis55.getLabelAngle();
        double double57 = categoryAxis55.getCategoryMargin();
        java.lang.String str58 = categoryAxis55.getLabelToolTip();
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis55.setAxisLinePaint((java.awt.Paint) color59);
        int int61 = objectList52.indexOf((java.lang.Object) categoryAxis55);
        java.awt.Stroke stroke62 = categoryAxis55.getAxisLineStroke();
        try {
            statisticalBarRenderer24.setSeriesOutlineStroke((-1), stroke62, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.2d + "'", double57 == 0.2d);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(stroke62);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        categoryPlot13.setAnchorValue(0.0d, true);
        java.awt.Font font17 = categoryPlot13.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("hi!", font17);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.GENERAL", font17);
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("ThreadContext", font17);
        try {
            statisticalBarRenderer0.setSeriesItemLabelFont((-16727872), font17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Paint paint12 = statisticalBarRenderer0.getSeriesPaint(10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        double double15 = categoryAxis14.getLabelAngle();
        double double16 = categoryAxis14.getCategoryMargin();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis14);
        java.awt.Font font18 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        categoryAxis14.setTickLabelFont(font18);
        statisticalBarRenderer0.setSeriesItemLabelFont(10, font18, false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.util.Iterator iterator1 = legendItemCollection0.iterator();
        org.junit.Assert.assertNotNull(iterator1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke12 = statisticalBarRenderer0.getItemStroke(255, (int) 'a');
        statisticalBarRenderer0.setAutoPopulateSeriesPaint(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = statisticalBarRenderer0.getSeriesToolTipGenerator((int) (short) 100);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key hi!");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer0.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color12);
        java.awt.Paint paint15 = statisticalBarRenderer0.getSeriesOutlinePaint((int) (byte) 100);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getInfo();
        java.lang.String str2 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets8.calculateRightInset((double) 2);
        categoryPlot4.setInsets(rectangleInsets8, true);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer15.setSeriesFillPaint(0, (java.awt.Paint) color17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer15.getBasePositiveItemLabelPosition();
        categoryPlot4.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot4.getRenderer((int) (short) -1);
        java.lang.Object obj24 = categoryPlot4.clone();
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        categoryPlot30.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection35 = categoryPlot30.getRangeMarkers(layer34);
        try {
            categoryPlot4.addDomainMarker(categoryMarker25, layer34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertNull(collection35);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        double double6 = categoryPlot4.getAnchorValue();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot6.setDomainAxis(categoryAxis7);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot6.setDomainAxisLocation((int) (short) 10, axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        categoryPlot26.setAnchorValue(0.0d, true);
        categoryPlot26.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot26.getRangeAxisLocation(255);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = null;
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D36, rectangleAnchor37);
        categoryPlot26.zoomRangeAxes((double) 'a', (double) 'a', plotRenderingInfo35, point2D38);
        categoryPlot6.zoomRangeAxes(0.0d, (double) (short) 0, plotRenderingInfo21, point2D38);
        boolean boolean41 = categoryPlot6.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        categoryPlot5.setAnchorValue(0.0d, true);
        java.awt.Font font9 = categoryPlot5.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!", font9);
        java.lang.String str11 = labelBlock10.getToolTipText();
        java.awt.Paint paint12 = labelBlock10.getPaint();
        java.lang.String str13 = labelBlock10.getToolTipText();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = org.jfree.chart.axis.CategoryAnchor.END;
        try {
            java.lang.Object obj17 = labelBlock10.draw(graphics2D14, rectangle2D15, (java.lang.Object) categoryAnchor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(categoryAnchor16);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot8);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int12 = defaultStatisticalCategoryDataset0.getRowCount();
        java.lang.Number number13 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number17 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) (-1.6727872E7d), (java.lang.Comparable) 1);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertEquals((double) number11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0d + "'", number13.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double6 = categoryAxis0.getCategoryStart((int) '4', (int) (short) 1, rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 3.0d);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean4 = keyedObjects2D0.equals((java.lang.Object) chartChangeEventType3);
        org.jfree.chart.block.BlockBorder blockBorder5 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean6 = keyedObjects2D0.equals((java.lang.Object) blockBorder5);
        java.lang.Object obj7 = null;
        boolean boolean8 = keyedObjects2D0.equals(obj7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setAxisLineVisible(true);
        categoryAxis9.setLabelAngle((double) (-123));
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        boolean boolean15 = categoryAxis9.equals((java.lang.Object) color14);
        java.awt.Paint paint16 = categoryAxis9.getTickLabelPaint();
        keyedObjects2D0.setObject((java.lang.Object) categoryAxis9, (java.lang.Comparable) 0.2d, (java.lang.Comparable) "Size2D[width=1.0, height=0.0]");
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 10);
        boolean boolean22 = categoryAxis9.equals((java.lang.Object) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(blockBorder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = legendTitle6.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent8 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle6);
        org.jfree.chart.title.Title title9 = titleChangeEvent8.getTitle();
        org.jfree.chart.title.Title title10 = titleChangeEvent8.getTitle();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(title9);
        org.junit.Assert.assertNotNull(title10);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        double double31 = rectangleInsets29.calculateRightInset((double) 2);
        categoryPlot25.setInsets(rectangleInsets29, true);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets29.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets29);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot4.setRenderer(categoryItemRenderer37, false);
        categoryPlot4.setBackgroundImageAlignment((int) (byte) 1);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Paint paint6 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) (-16727872));
        java.awt.Paint paint10 = legendTitle7.getItemPaint();
        java.awt.Paint paint11 = legendTitle7.getBackgroundPaint();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color4 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape3, (java.awt.Paint) color4);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic(shape8, (java.awt.Paint) color9);
        legendGraphic5.setShape(shape8);
        legendGraphic5.setHeight(0.0d);
        java.awt.Shape shape14 = legendGraphic5.getShape();
        legendGraphic5.setID("ChartChangeEventType.GENERAL");
        flowArrangement0.add((org.jfree.chart.block.Block) legendGraphic5, (java.lang.Object) "CategoryLabelWidthType.CATEGORY");
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        java.lang.Class<?> wildcardClass4 = axisChangeEvent3.getClass();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        axisChangeEvent3.setType(chartChangeEventType5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.lang.String str5 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        boolean boolean11 = legendGraphic4.isShapeVisible();
        java.awt.Paint paint12 = legendGraphic4.getOutlinePaint();
        legendGraphic4.setID("AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = legendGraphic4.getFillPaintTransformer();
        legendGraphic4.setShapeVisible(false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 3.0d);
        java.lang.Comparable comparable3 = null;
        java.lang.Object obj5 = keyedObjects2D0.getObject(comparable3, (java.lang.Comparable) (byte) -1);
        try {
            keyedObjects2D0.removeColumn((-16727872));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        boolean boolean5 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot4.getDomainAxis((int) (byte) 10);
        java.awt.Paint paint8 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryPlot4.setOutlinePaint(paint8);
        java.lang.Object obj10 = categoryPlot4.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color18 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape17, (java.awt.Paint) color18);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color23 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic24 = new org.jfree.chart.title.LegendGraphic(shape22, (java.awt.Paint) color23);
        legendGraphic19.setShape(shape22);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color27 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape22, stroke26, (java.awt.Paint) color27);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) (short) 1, (float) 100L, (float) 128);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity33 = new org.jfree.chart.entity.LegendItemEntity(shape32);
        java.awt.Shape shape34 = legendItemEntity33.getArea();
        statisticalBarRenderer0.setBaseShape(shape34);
        java.awt.Paint paint37 = statisticalBarRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator38 = statisticalBarRenderer0.getBaseURLGenerator();
        java.awt.Paint paint40 = null;
        statisticalBarRenderer0.setSeriesFillPaint((int) (short) 1, paint40);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(categoryURLGenerator38);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer3.setSeriesFillPaint(0, (java.awt.Paint) color5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer3.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 255, "ItemLabelAnchor.OUTSIDE9", textAnchor8, textAnchor9, (double) (byte) 100);
        double double12 = numberTick11.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor13 = numberTick11.getRotationAnchor();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color21 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic22 = new org.jfree.chart.title.LegendGraphic(shape20, (java.awt.Paint) color21);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color26 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic27 = new org.jfree.chart.title.LegendGraphic(shape25, (java.awt.Paint) color26);
        legendGraphic22.setShape(shape25);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color30 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape25, stroke29, (java.awt.Paint) color30);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape25, (double) (short) 1, (float) 100L, (float) 128);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity36 = new org.jfree.chart.entity.LegendItemEntity(shape35);
        java.awt.Shape shape37 = legendItemEntity36.getArea();
        java.awt.Shape shape38 = legendItemEntity36.getArea();
        java.awt.Shape shape39 = legendItemEntity36.getArea();
        boolean boolean40 = numberTick11.equals((java.lang.Object) shape39);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightInset((double) 2);
        double double4 = rectangleInsets0.calculateLeftInset((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot6.setDomainAxis(categoryAxis7);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot6.setDomainAxisLocation((int) (short) 10, axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        jFreeChart18.setTitle("Layer.BACKGROUND");
        jFreeChart18.setBackgroundImageAlignment((int) (byte) 10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        try {
            java.awt.image.BufferedImage bufferedImage26 = jFreeChart18.createBufferedImage((int) (short) 10, (int) (byte) 0, chartRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (10) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        float[] floatArray3 = null;
        float[] floatArray4 = java.awt.Color.RGBtoHSB(128, (-16727872), (-8323073), floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 2, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
        java.lang.String str3 = plotOrientation1.toString();
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean5 = plotOrientation1.equals((java.lang.Object) strokeArray4);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str3.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setAxisLineVisible(true);
        categoryAxis0.setLabelAngle((double) (-123));
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        boolean boolean6 = categoryAxis0.equals((java.lang.Object) color5);
        java.awt.Paint paint7 = categoryAxis0.getTickLabelPaint();
        categoryAxis0.setLabelToolTip("TextAnchor.HALF_ASCENT_RIGHT");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot6.setDomainAxis(categoryAxis7);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot6.setDomainAxisLocation((int) (short) 10, axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        jFreeChart18.setTitle("Layer.BACKGROUND");
        jFreeChart18.setBackgroundImageAlignment((int) (byte) 10);
        boolean boolean23 = jFreeChart18.isNotify();
        org.jfree.chart.event.ChartChangeListener chartChangeListener24 = null;
        try {
            jFreeChart18.addChangeListener(chartChangeListener24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        keyedObjects0.addObject((java.lang.Comparable) (byte) 0, (java.lang.Object) font2);
        java.lang.Comparable comparable5 = keyedObjects0.getKey(0);
        java.lang.Object obj7 = keyedObjects0.getObject((-16727872));
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 0 + "'", comparable5.equals((byte) 0));
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        categoryPlot5.setAnchorValue(0.0d, true);
        java.awt.Font font9 = categoryPlot5.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!", font9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        categoryPlot17.setAnchorValue(0.0d, true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot17.getDataset();
        categoryPlot17.setOutlineVisible(true);
        try {
            java.lang.Object obj24 = labelBlock10.draw(graphics2D11, rectangle2D12, (java.lang.Object) true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(categoryDataset21);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4145152) + "'", int1 == (-4145152));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot19 = categoryPlot4.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot4.setRenderer(1, categoryItemRenderer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot4.getDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup24 = categoryPlot4.getDatasetGroup();
        int int25 = categoryPlot4.getRangeAxisCount();
        java.awt.Stroke stroke26 = categoryPlot4.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNull(datasetGroup24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("AxisLocation.BOTTOM_OR_RIGHT", "{0}", "", image3, "ThreadContext", "", "Layer.BACKGROUND");
        java.lang.String str8 = projectInfo7.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT version {0}.\nThreadContext.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY AxisLocation.BOTTOM_OR_RIGHT:None\nAxisLocation.BOTTOM_OR_RIGHT LICENCE TERMS:\nLayer.BACKGROUND" + "'", str8.equals("AxisLocation.BOTTOM_OR_RIGHT version {0}.\nThreadContext.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY AxisLocation.BOTTOM_OR_RIGHT:None\nAxisLocation.BOTTOM_OR_RIGHT LICENCE TERMS:\nLayer.BACKGROUND"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        textTitle1.draw(graphics2D2, rectangle2D3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = null;
        try {
            textTitle1.setTextAlignment(horizontalAlignment5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font2 = barRenderer0.getSeriesItemLabelFont(100);
        boolean boolean5 = barRenderer0.getItemVisible((int) (short) 10, (int) (byte) 0);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("154,-24,153,-25,154,-25,154,-25,153,-25,153,-26,153,-26,153,-25,152,-24,152,-24,153,-25,154,-24,154,-24", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str3 = verticalAlignment2.toString();
        boolean boolean4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) rectangleAnchor1, (java.lang.Object) verticalAlignment2);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment2, 0.0d, (double) 1);
        java.awt.Color color8 = java.awt.Color.WHITE;
        boolean boolean9 = verticalAlignment2.equals((java.lang.Object) color8);
        java.lang.String str10 = verticalAlignment2.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.CENTER" + "'", str3.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "VerticalAlignment.CENTER" + "'", str10.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.awt.Paint paint7 = categoryPlot4.getRangeGridlinePaint();
        boolean boolean8 = categoryPlot4.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        double double11 = categoryAxis10.getLabelAngle();
        double double12 = categoryAxis10.getCategoryMargin();
        java.lang.String str13 = categoryAxis10.getLabelToolTip();
        categoryAxis10.setVisible(false);
        categoryPlot4.setDomainAxis((int) (short) 100, categoryAxis10);
        java.awt.Paint paint17 = categoryAxis10.getAxisLinePaint();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        try {
            java.lang.Object obj4 = jFreeChartResources0.getObject("AxisLocation.BOTTOM_OR_RIGHT version {0}.\nThreadContext.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY AxisLocation.BOTTOM_OR_RIGHT:None\nAxisLocation.BOTTOM_OR_RIGHT LICENCE TERMS:\nLayer.BACKGROUND");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key AxisLocation.BOTTOM_OR_RIGHT version {0}.\nThreadContext.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY AxisLocation.BOTTOM_OR_RIGHT:None\nAxisLocation.BOTTOM_OR_RIGHT LICENCE TERMS:\nLayer.BACKGROUND");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        double double2 = axisSpace0.getTop();
        org.jfree.chart.axis.AxisSpace axisSpace3 = new org.jfree.chart.axis.AxisSpace();
        double double4 = axisSpace3.getTop();
        axisSpace3.setRight(0.0d);
        axisSpace0.ensureAtLeast(axisSpace3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list4 = defaultStatisticalCategoryDataset3.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity7 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "", "TextBlockAnchor.BOTTOM_CENTER", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) "TextBlockAnchor.BOTTOM_CENTER", (java.lang.Comparable) (-123));
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0d + "'", number8.equals(0.0d));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 100);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (short) 1, (double) 128, 128, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer3.setSeriesFillPaint(0, (java.awt.Paint) color5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer3.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 255, "ItemLabelAnchor.OUTSIDE9", textAnchor8, textAnchor9, (double) (byte) 100);
        double double12 = numberTick11.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor13 = numberTick11.getRotationAnchor();
        double double14 = numberTick11.getValue();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 255.0d + "'", double14 == 255.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot4.setRangeAxis(0, valueAxis8, false);
        int int11 = categoryPlot4.getWeight();
        categoryPlot4.setAnchorValue((double) '4', true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot4.getRangeAxisLocation(255);
        int int11 = categoryPlot4.getRangeAxisCount();
        categoryPlot4.clearRangeMarkers(10);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "CategoryLabelWidthType.CATEGORY", numberArray2);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        categoryPlot5.setAnchorValue(0.0d, true);
        java.awt.Font font9 = categoryPlot5.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!", font9);
        java.lang.String str11 = labelBlock10.getToolTipText();
        java.awt.Paint paint12 = labelBlock10.getPaint();
        java.lang.String str13 = labelBlock10.getToolTipText();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color17 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color17);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color22 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic23 = new org.jfree.chart.title.LegendGraphic(shape21, (java.awt.Paint) color22);
        legendGraphic18.setShape(shape21);
        boolean boolean25 = legendGraphic18.isShapeVisible();
        java.awt.Paint paint26 = legendGraphic18.getOutlinePaint();
        boolean boolean27 = labelBlock10.equals((java.lang.Object) legendGraphic18);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.Size2D size2D29 = legendGraphic18.arrange(graphics2D28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = legendGraphic18.getPadding();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("{0}", (int) (short) 100, (-16727872));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        double double31 = rectangleInsets29.calculateRightInset((double) 2);
        categoryPlot25.setInsets(rectangleInsets29, true);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets29.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets29);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot4.setRenderer(categoryItemRenderer37, false);
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setDomainAxisLocation(axisLocation40);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder42 = categoryPlot4.getDatasetRenderingOrder();
        java.awt.Image image43 = null;
        categoryPlot4.setBackgroundImage(image43);
        categoryPlot4.configureDomainAxes();
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(datasetRenderingOrder42);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot19 = categoryPlot4.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot4.setRenderer(1, categoryItemRenderer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot4.getDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup24 = categoryPlot4.getDatasetGroup();
        int int25 = categoryPlot4.getRangeAxisCount();
        java.util.List list26 = categoryPlot4.getCategories();
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot4.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNull(datasetGroup24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNull(axisSpace27);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color1);
        java.lang.String str3 = categoryAxis0.getLabel();
        double double4 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 255, (double) 10);
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D((double) 1L, (double) (short) 1);
        org.jfree.chart.util.Size2D size2D6 = rectangleConstraint2.calculateConstrainedSize(size2D5);
        double double7 = size2D6.height;
        double double8 = size2D6.height;
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        java.awt.Paint paint6 = statisticalBarRenderer0.getItemPaint((int) '#', 0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 255, (double) 10);
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D((double) 1L, (double) (short) 1);
        org.jfree.chart.util.Size2D size2D6 = rectangleConstraint2.calculateConstrainedSize(size2D5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean8 = size2D5.equals((java.lang.Object) axisLocation7);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot6.setDomainAxis(categoryAxis7);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot6.setDomainAxisLocation((int) (short) 10, axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        jFreeChart18.setTitle("Layer.BACKGROUND");
        int int21 = jFreeChart18.getSubtitleCount();
        jFreeChart18.setNotify(false);
        jFreeChart18.setBorderVisible(true);
        java.lang.Object obj26 = null;
        try {
            jFreeChart18.setTextAntiAlias(obj26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo0.setLicenceName("AxisLocation.BOTTOM_OR_RIGHT");
        java.lang.String str5 = projectInfo0.getLicenceText();
        projectInfo0.setLicenceName("");
        java.lang.String str8 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color16 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape11, stroke15, (java.awt.Paint) color16);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, (double) (short) 1, (float) 100L, (float) 128);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1L, (float) (short) 100);
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.equal(shape21, shape24);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer0.setSeriesVisible(0, (java.lang.Boolean) true, true);
        java.awt.Shape shape8 = barRenderer0.getBaseShape();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        legendGraphic4.setHeight(0.0d);
        java.awt.Shape shape13 = legendGraphic4.getShape();
        legendGraphic4.setID("ChartChangeEventType.GENERAL");
        org.jfree.chart.block.BlockFrame blockFrame16 = legendGraphic4.getFrame();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(blockFrame16);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Stroke stroke3 = categoryAxis0.getTickMarkStroke();
        boolean boolean5 = categoryAxis0.equals((java.lang.Object) 10.0d);
        java.lang.String str6 = categoryAxis0.getLabelToolTip();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot6.setDomainAxis(categoryAxis7);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot6.setDomainAxisLocation((int) (short) 10, axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        jFreeChart18.setBackgroundImageAlignment((-123));
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle8.getItemLabelPadding();
        double double11 = rectangleInsets9.trimWidth((double) 0L);
        boolean boolean12 = numberAxis1.equals((java.lang.Object) double11);
        org.jfree.data.Range range13 = numberAxis1.getRange();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-4.0d) + "'", double11 == (-4.0d));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        axisSpace0.setLeft((double) (-16727872));
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisState5.moveCursor((-1.0d), rectangleEdge7);
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = axisSpace0.reserved(rectangle2D4, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray8 = legendTitle6.getSources();
        boolean boolean9 = legendTitle6.getNotify();
        legendTitle6.setHeight((double) (-4145152));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(legendItemSourceArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) 1);
        boolean boolean3 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot19 = categoryPlot4.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot4.setRenderer(1, categoryItemRenderer21);
        java.awt.Stroke stroke23 = categoryPlot4.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = axisSpace0.reserved(rectangle2D2, rectangleEdge3);
        double double5 = axisSpace0.getBottom();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        boolean boolean5 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot4.getDomainAxis((int) (byte) 10);
        java.awt.Paint paint8 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryPlot4.setOutlinePaint(paint8);
        java.lang.String str10 = categoryPlot4.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke12 = statisticalBarRenderer0.getItemStroke(255, (int) 'a');
        boolean boolean15 = statisticalBarRenderer0.getItemVisible(0, (int) (short) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer17.setSeriesFillPaint(0, (java.awt.Paint) color19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = statisticalBarRenderer17.getPositiveItemLabelPosition((int) (byte) 100, (int) 'a');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor24 = itemLabelPosition23.getItemLabelAnchor();
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition(128, itemLabelPosition23);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator27 = null;
        try {
            statisticalBarRenderer0.setSeriesItemLabelGenerator((-1), categoryItemLabelGenerator27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(itemLabelAnchor24);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.centerRange((double) 100L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Paint paint6 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) (-16727872));
        java.awt.Paint paint10 = legendTitle7.getItemPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.trimWidth((double) 1);
        legendTitle7.setItemLabelPadding(rectangleInsets11);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color18 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape17, (java.awt.Paint) color18);
        int int20 = color18.getTransparency();
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(rectangleInsets11, (java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer3.setSeriesFillPaint(0, (java.awt.Paint) color5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer3.getBasePositiveItemLabelPosition();
        java.awt.Paint paint10 = statisticalBarRenderer3.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke13 = statisticalBarRenderer3.getItemStroke((int) 'a', (int) (byte) 10);
        strokeList0.setStroke((int) (short) 0, stroke13);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot4.getDomainMarkers(layer10);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot19 = categoryPlot4.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray21 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer20 };
        categoryPlot4.setRenderers(categoryItemRendererArray21);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        float float25 = categoryAxis24.getTickMarkInsideLength();
        boolean boolean26 = categoryAxis24.isTickLabelsVisible();
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean28 = categoryAxis24.equals((java.lang.Object) layer27);
        try {
            categoryPlot4.addDomainMarker(categoryMarker23, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray21);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets8.calculateRightInset((double) 2);
        categoryPlot4.setInsets(rectangleInsets8, true);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer15.setSeriesFillPaint(0, (java.awt.Paint) color17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer15.getBasePositiveItemLabelPosition();
        categoryPlot4.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot4.getRenderer((int) (short) -1);
        java.lang.Object obj24 = categoryPlot4.clone();
        try {
            categoryPlot4.setBackgroundImageAlpha((float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray1, doubleArray2);
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] {};
        double[][] doubleArray6 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray4, comparableArray5, doubleArray6);
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] {};
        double[][] doubleArray10 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray8, comparableArray9, doubleArray10);
        java.lang.Comparable[] comparableArray12 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray13 = new java.lang.Comparable[] {};
        double[][] doubleArray14 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray12, comparableArray13, doubleArray14);
        double[][] doubleArray16 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray9, comparableArray12, doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray5, doubleArray16);
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(comparableArray12);
        org.junit.Assert.assertNotNull(comparableArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = statisticalBarRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator4);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setBaseSeriesVisible(true, false);
        statisticalBarRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, false);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        double double17 = categoryAxis16.getLabelAngle();
        double double18 = categoryAxis16.getCategoryMargin();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = categoryPlot25.getRangeMarkers(layer29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        statisticalBarRenderer0.drawAnnotations(graphics2D14, rectangle2D15, categoryAxis16, valueAxis20, layer29, plotRenderingInfo31);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        statisticalBarRenderer0.setSeriesVisibleInLegend(15, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNull(itemLabelPosition33);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        double double7 = axisSpace6.getRight();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = axisSpace6.reserved(rectangle2D8, rectangleEdge9);
        categoryPlot4.setFixedDomainAxisSpace(axisSpace6);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = null;
        java.awt.geom.Point2D point2D16 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D14, rectangleAnchor15);
        org.jfree.chart.plot.PlotState plotState17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            categoryPlot4.draw(graphics2D12, rectangle2D13, point2D16, plotState17, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(rectangle2D10);
        org.junit.Assert.assertNotNull(point2D16);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        double double2 = categoryAxis1.getLabelAngle();
        double double3 = categoryAxis1.getCategoryMargin();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        boolean boolean5 = categoryAxis1.isTickMarksVisible();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        java.awt.Paint paint13 = categoryPlot12.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle14.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition16 = categoryLabelPositions7.getLabelPosition(rectangleEdge15);
        axisCollection0.add((org.jfree.chart.axis.Axis) categoryAxis1, rectangleEdge15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(categoryLabelPosition16);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color4);
        categoryAxis0.setFixedDimension((double) 10L);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot12.setDomainAxis(categoryAxis13);
        java.lang.Comparable[] comparableArray15 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray16 = new java.lang.Comparable[] {};
        double[][] doubleArray17 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray15, comparableArray16, doubleArray17);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset18, (int) (short) 100);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset18, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot12.getRendererForDataset(categoryDataset18);
        java.awt.Paint paint24 = categoryPlot12.getNoDataMessagePaint();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean29 = barRenderer26.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer26.setSeriesVisible(0, (java.lang.Boolean) true, true);
        categoryPlot12.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer26);
        boolean boolean35 = categoryPlot12.isSubplot();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(comparableArray15);
        org.junit.Assert.assertNotNull(comparableArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer0.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color12);
        double double14 = statisticalBarRenderer0.getMinimumBarLength();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer0.setBaseStroke(stroke15);
        boolean boolean17 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer18.setSeriesFillPaint(0, (java.awt.Paint) color20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = statisticalBarRenderer18.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor23 = itemLabelPosition22.getRotationAnchor();
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition22, true);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) (short) 10, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(textAnchor23);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo0.setLicenceName("AxisLocation.BOTTOM_OR_RIGHT");
        projectInfo0.setLicenceText("UnitType.RELATIVE");
        java.lang.String str7 = projectInfo0.getVersion();
        projectInfo0.setName("LegendItemEntity: seriesKey=null, dataset=null");
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(128, (int) (short) 100, (int) ' ');
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Color color15 = java.awt.Color.lightGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        int int18 = color17.getRed();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape11, (java.awt.Paint) color15, stroke16, (java.awt.Paint) color17);
        java.awt.Paint paint20 = legendItem19.getOutlinePaint();
        java.text.AttributedString attributedString21 = legendItem19.getAttributedLabel();
        java.lang.String str22 = legendItem19.getURLText();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(attributedString21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "VerticalAlignment.CENTER" + "'", str22.equals("VerticalAlignment.CENTER"));
    }
}

