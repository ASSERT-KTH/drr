import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Size2D[width=1.0, height=0.0]");
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        double double4 = categoryAxis0.getUpperMargin();
        java.lang.String str5 = categoryAxis0.getLabelURL();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (-16727872));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 0.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint4.toUnconstrainedHeight();
        org.jfree.data.Range range6 = rectangleConstraint4.getWidthRange();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getItemLabelPadding();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        legendTitle6.setWrapper(blockContainer8);
        org.jfree.chart.block.BlockContainer blockContainer10 = legendTitle6.getItemContainer();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(blockContainer10);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isTickLabelsVisible();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        boolean boolean5 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot4.getDomainAxis((int) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot4.setDataset(categoryDataset8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        double double11 = categoryAxis10.getLabelAngle();
        categoryAxis10.setMaximumCategoryLabelWidthRatio((float) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setAxisLineVisible(true);
        categoryAxis15.setLabelAngle((double) (-123));
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryAxis15.setTickLabelPaint(paint20);
        categoryAxis10.setTickLabelPaint((java.lang.Comparable) Double.NaN, paint20);
        categoryPlot4.setDomainAxis(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (-16727872));
        double double3 = range2.getLength();
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range2, (double) 100L);
        double double6 = range2.getCentralValue();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.6727872E7d) + "'", double6 == (-1.6727872E7d));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font3 = barRenderer0.getItemLabelFont(10, (-1));
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color14 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape13, (java.awt.Paint) color14);
        org.jfree.chart.title.LegendGraphic legendGraphic16 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color14);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape19, (java.awt.Paint) color20);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color25 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic26 = new org.jfree.chart.title.LegendGraphic(shape24, (java.awt.Paint) color25);
        legendGraphic21.setShape(shape24);
        boolean boolean28 = legendGraphic21.isShapeVisible();
        java.awt.Paint paint29 = legendGraphic21.getOutlinePaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer30 = legendGraphic21.getFillPaintTransformer();
        legendGraphic16.setFillPaintTransformer(gradientPaintTransformer30);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(gradientPaintTransformer30);
    }
}

