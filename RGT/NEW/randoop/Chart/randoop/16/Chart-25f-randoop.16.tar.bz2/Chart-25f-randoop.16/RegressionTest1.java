import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.awt.Color color1 = java.awt.Color.getColor("{0}");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (-16727872));
        double double3 = range2.getLength();
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range2, (double) 100L);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) 0.5f);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, 4.0d, (double) '4');
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.clone(shape5);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (byte) 100, (int) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot11.setDomainAxis(categoryAxis12);
        java.lang.Comparable[] comparableArray14 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray15 = new java.lang.Comparable[] {};
        double[][] doubleArray16 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray14, comparableArray15, doubleArray16);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset17, (int) (short) 100);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset17, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot11.getRendererForDataset(categoryDataset17);
        java.awt.Paint paint23 = categoryPlot11.getNoDataMessagePaint();
        categoryPlot11.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot26 = categoryPlot11.getParent();
        categoryPlot11.setAnchorValue(0.0d, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer31.setSeriesFillPaint(0, (java.awt.Paint) color33);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator36 = null;
        statisticalBarRenderer31.setSeriesURLGenerator(255, categoryURLGenerator36);
        statisticalBarRenderer31.setSeriesVisible(100, (java.lang.Boolean) false, true);
        categoryPlot11.setRenderer(128, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer31);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot11);
        boolean boolean46 = statisticalBarRenderer0.getItemCreateEntity(0, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator48 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator48);
        java.awt.Shape shape56 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color57 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic58 = new org.jfree.chart.title.LegendGraphic(shape56, (java.awt.Paint) color57);
        java.awt.Shape shape61 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color62 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic63 = new org.jfree.chart.title.LegendGraphic(shape61, (java.awt.Paint) color62);
        legendGraphic58.setShape(shape61);
        java.awt.Color color65 = java.awt.Color.lightGray;
        java.awt.Stroke stroke66 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color67 = java.awt.Color.MAGENTA;
        int int68 = color67.getRed();
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape61, (java.awt.Paint) color65, stroke66, (java.awt.Paint) color67);
        java.awt.Stroke stroke70 = legendItem69.getOutlineStroke();
        statisticalBarRenderer0.setBaseStroke(stroke70, true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(comparableArray14);
        org.junit.Assert.assertNotNull(comparableArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(plot26);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNull(itemLabelPosition47);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 255 + "'", int68 == 255);
        org.junit.Assert.assertNotNull(stroke70);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1.0f), (java.lang.Number) (byte) 0, (java.lang.Comparable) "ItemLabelAnchor.OUTSIDE9", (java.lang.Comparable) (-4145152));
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ChartChangeEventType.GENERAL");
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator1.clone();
        boolean boolean4 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) "ChartChangeEventType.GENERAL");
        java.lang.Object obj5 = standardCategorySeriesLabelGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, 0.05d);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(0.05d, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = legendGraphic4.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendGraphic4.getShapeAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = categoryLabelPositions9.getLabelPosition(rectangleEdge10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        java.awt.Paint paint19 = categoryPlot18.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = legendTitle20.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = categoryLabelPositions13.getLabelPosition(rectangleEdge21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = categoryLabelPosition22.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType24 = categoryLabelPosition22.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = categoryLabelPosition22.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions26 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions9, categoryLabelPosition22);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor27 = categoryLabelPosition22.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType30 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str31 = categoryLabelWidthType30.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition33 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor27, textAnchor28, (double) (byte) 0, categoryLabelWidthType30, 100.0f);
        legendGraphic4.setShapeLocation(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNull(categoryLabelPosition11);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(categoryLabelPosition22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(categoryLabelWidthType24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(categoryLabelPositions26);
        org.junit.Assert.assertNotNull(textBlockAnchor27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(categoryLabelWidthType30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str31.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setURLText("VerticalAlignment.CENTER");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) 255, (double) 10);
        org.jfree.chart.util.Size2D size2D10 = new org.jfree.chart.util.Size2D((double) 1L, (double) (short) 1);
        org.jfree.chart.util.Size2D size2D11 = rectangleConstraint7.calculateConstrainedSize(size2D10);
        try {
            org.jfree.chart.util.Size2D size2D12 = textTitle1.arrange(graphics2D4, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(size2D11);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.add((double) (-1.0f), (double) (-16751519), (java.lang.Comparable) 10.0d, (java.lang.Comparable) 0.5f);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) 255);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        double double4 = range3.getLength();
        boolean boolean6 = range3.contains((double) 1L);
        double double7 = range3.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 2, range3);
        org.jfree.chart.util.Size2D size2D9 = null;
        try {
            org.jfree.chart.util.Size2D size2D10 = rectangleConstraint8.calculateConstrainedSize(size2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "Layer.BACKGROUND", font4);
        float float6 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color14 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape13, (java.awt.Paint) color14);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color19 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color19);
        legendGraphic15.setShape(shape18);
        java.awt.Color color22 = java.awt.Color.lightGray;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color24 = java.awt.Color.MAGENTA;
        int int25 = color24.getRed();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape18, (java.awt.Paint) color22, stroke23, (java.awt.Paint) color24);
        java.awt.Stroke stroke27 = legendItem26.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        categoryPlot32.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection37 = categoryPlot32.getRangeMarkers(layer36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        int int39 = categoryPlot32.getIndexOf(categoryItemRenderer38);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier40 = categoryPlot32.getDrawingSupplier();
        boolean boolean41 = legendItem26.equals((java.lang.Object) categoryPlot32);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray42 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot32.setRangeAxes(valueAxisArray42);
        categoryPlot32.clearDomainMarkers((-1));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = categoryPlot32.getRenderer(128);
        boolean boolean48 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot32);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions49 = new org.jfree.chart.axis.CategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions49);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(drawingSupplier40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(valueAxisArray42);
        org.junit.Assert.assertNull(categoryItemRenderer47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (-16727872));
        double double3 = range2.getLength();
        double double4 = range2.getUpperBound();
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) (-16727872));
        double double9 = range8.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range12 = null;
        org.jfree.data.Range range14 = org.jfree.data.Range.expandToInclude(range12, (double) (-16727872));
        double double15 = range14.getLength();
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range14, (double) 100L);
        double double19 = range17.constrain((double) (-1));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType20 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) 128, range8, lengthConstraintType10, 255.0d, range17, lengthConstraintType20);
        org.jfree.data.Range range22 = org.jfree.data.Range.combine(range2, range8);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.6727872E7d) + "'", double4 == (-1.6727872E7d));
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType10);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNotNull(lengthConstraintType20);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot16.setDomainAxis(categoryAxis17);
        java.lang.Comparable[] comparableArray19 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray20 = new java.lang.Comparable[] {};
        double[][] doubleArray21 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray19, comparableArray20, doubleArray21);
        org.jfree.data.general.PieDataset pieDataset24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset22, (int) (short) 100);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset22, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = categoryPlot16.getRendererForDataset(categoryDataset22);
        java.awt.Paint paint28 = categoryPlot16.getNoDataMessagePaint();
        statisticalBarRenderer0.setBasePaint(paint28, false);
        int int31 = statisticalBarRenderer0.getColumnCount();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(comparableArray19);
        org.junit.Assert.assertNotNull(comparableArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(pieDataset24);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNull(categoryItemRenderer27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Paint paint6 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) (-16727872));
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle11.setURLText("VerticalAlignment.CENTER");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle11.getMargin();
        legendTitle7.setPadding(rectangleInsets14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle7.getItemLabelPadding();
        java.awt.Font font17 = null;
        try {
            legendTitle7.setItemFont(font17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation11, plotOrientation12);
        categoryPlot4.setDomainAxisLocation(15, axisLocation11);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot4.getRangeMarkers(layer15);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(collection16);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getLibraries();
        projectInfo0.setInfo("AxisLocation.BOTTOM_OR_RIGHT version {0}.\nThreadContext.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY AxisLocation.BOTTOM_OR_RIGHT:None\nAxisLocation.BOTTOM_OR_RIGHT LICENCE TERMS:\nLayer.BACKGROUND");
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list4 = defaultStatisticalCategoryDataset3.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity7 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "", "TextBlockAnchor.BOTTOM_CENTER", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) "TextBlockAnchor.BOTTOM_CENTER", (java.lang.Comparable) (-123));
        categoryItemEntity7.setColumnKey((java.lang.Comparable) "java.awt.Color[r=0,g=0,b=192]");
        categoryItemEntity7.setColumnKey((java.lang.Comparable) (short) 0);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) 100.0f, range1);
        java.lang.String str5 = rectangleConstraint4.toString();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]" + "'", str5.equals("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("PlotOrientation.HORIZONTAL", "", "UnitType.RELATIVE", "ChartChangeEventType.GENERAL");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo5);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Paint paint6 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) (-16727872));
        java.awt.Paint paint10 = legendTitle7.getItemPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.trimWidth((double) 1);
        legendTitle7.setItemLabelPadding(rectangleInsets11);
        java.awt.Font font15 = legendTitle7.getItemFont();
        java.awt.Color color16 = java.awt.Color.BLUE;
        java.awt.Color color17 = java.awt.Color.green;
        float[] floatArray24 = new float[] { 0L, 10, (-8323073), 'a', (byte) 10, 0.0f };
        float[] floatArray25 = color17.getRGBComponents(floatArray24);
        float[] floatArray26 = color16.getColorComponents(floatArray24);
        legendTitle7.setBackgroundPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str1 = axisLocation0.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation2);
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str1.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        try {
            java.lang.Number number4 = defaultStatisticalCategoryDataset0.getStdDevValue((int) 'a', (-16751519));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Color color8 = java.awt.Color.blue;
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color8, true);
        java.awt.Color color11 = color8.darker();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        java.lang.Object obj2 = keyedObjects0.getObject(comparable1);
        java.lang.Object obj4 = keyedObjects0.getObject((int) (short) 100);
        java.lang.Comparable comparable6 = keyedObjects0.getKey(2);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(comparable6);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot9.setDomainAxis(categoryAxis10);
        java.lang.Comparable[] comparableArray12 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray13 = new java.lang.Comparable[] {};
        double[][] doubleArray14 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray12, comparableArray13, doubleArray14);
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset15, (int) (short) 100);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot9.getRendererForDataset(categoryDataset15);
        java.awt.Paint paint21 = categoryPlot9.getNoDataMessagePaint();
        categoryPlot9.setBackgroundImageAlpha(0.0f);
        categoryPlot9.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        categoryPlot30.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets();
        double double36 = rectangleInsets34.calculateRightInset((double) 2);
        categoryPlot30.setInsets(rectangleInsets34, true);
        org.jfree.chart.util.UnitType unitType39 = rectangleInsets34.getUnitType();
        categoryPlot9.setAxisOffset(rectangleInsets34);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot9.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        categoryPlot9.setRenderer(categoryItemRenderer42, false);
        org.jfree.chart.axis.AxisLocation axisLocation45 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot9.setDomainAxisLocation(axisLocation45);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder47 = categoryPlot9.getDatasetRenderingOrder();
        java.awt.Image image48 = null;
        categoryPlot9.setBackgroundImage(image48);
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, valueAxis53, categoryItemRenderer54);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        categoryPlot55.setDomainAxis(categoryAxis56);
        java.lang.Comparable[] comparableArray58 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray59 = new java.lang.Comparable[] {};
        double[][] doubleArray60 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset61 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray58, comparableArray59, doubleArray60);
        org.jfree.data.general.PieDataset pieDataset63 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset61, (int) (short) 100);
        org.jfree.data.Range range65 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset61, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer66 = categoryPlot55.getRendererForDataset(categoryDataset61);
        java.awt.Paint paint67 = categoryPlot55.getNoDataMessagePaint();
        categoryPlot55.setBackgroundImageAlpha(0.0f);
        categoryPlot55.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset72 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = null;
        org.jfree.chart.axis.ValueAxis valueAxis74 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer75 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot(categoryDataset72, categoryAxis73, valueAxis74, categoryItemRenderer75);
        categoryPlot76.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = new org.jfree.chart.util.RectangleInsets();
        double double82 = rectangleInsets80.calculateRightInset((double) 2);
        categoryPlot76.setInsets(rectangleInsets80, true);
        org.jfree.chart.util.UnitType unitType85 = rectangleInsets80.getUnitType();
        categoryPlot55.setAxisOffset(rectangleInsets80);
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = categoryPlot55.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace88 = new org.jfree.chart.axis.AxisSpace();
        double double89 = axisSpace88.getTop();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace90 = numberAxis1.reserveSpace(graphics2D4, (org.jfree.chart.plot.Plot) categoryPlot9, rectangle2D50, rectangleEdge87, axisSpace88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray12);
        org.junit.Assert.assertNotNull(comparableArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(unitType39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(datasetRenderingOrder47);
        org.junit.Assert.assertNotNull(comparableArray58);
        org.junit.Assert.assertNotNull(comparableArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(categoryDataset61);
        org.junit.Assert.assertNotNull(pieDataset63);
        org.junit.Assert.assertNull(range65);
        org.junit.Assert.assertNull(categoryItemRenderer66);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.0d + "'", double82 == 1.0d);
        org.junit.Assert.assertNotNull(unitType85);
        org.junit.Assert.assertNotNull(rectangleEdge87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color16 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape11, stroke15, (java.awt.Paint) color16);
        java.text.AttributedString attributedString18 = legendItem17.getAttributedLabel();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(attributedString18);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot6.setDomainAxis(categoryAxis7);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot6.setDomainAxisLocation((int) (short) 10, axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        jFreeChart18.setTitle("Layer.BACKGROUND");
        jFreeChart18.fireChartChanged();
        jFreeChart18.clearSubtitles();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 1L, (double) (short) 1);
        size2D2.setHeight(0.0d);
        double double5 = size2D2.width;
        size2D2.width = 10.0d;
        size2D2.setWidth((double) (short) 0);
        java.lang.String str10 = size2D2.toString();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str10.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Paint paint1 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer2.setSeriesFillPaint(0, (java.awt.Paint) color4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        statisticalBarRenderer2.setSeriesURLGenerator(255, categoryURLGenerator7);
        statisticalBarRenderer2.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer2.setErrorIndicatorStroke(stroke12);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 2, paint1, stroke12);
        java.awt.Paint paint15 = valueMarker14.getLabelPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Stroke stroke5 = legendGraphic4.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendGraphic4.getShapeLocation();
        boolean boolean7 = legendGraphic4.isShapeFilled();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendGraphic4.getShapeLocation();
        java.lang.String str9 = legendGraphic4.getID();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Color color15 = java.awt.Color.lightGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        int int18 = color17.getRed();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape11, (java.awt.Paint) color15, stroke16, (java.awt.Paint) color17);
        java.awt.Stroke stroke20 = legendItem19.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = categoryPlot25.getRangeMarkers(layer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        int int32 = categoryPlot25.getIndexOf(categoryItemRenderer31);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier33 = categoryPlot25.getDrawingSupplier();
        boolean boolean34 = legendItem19.equals((java.lang.Object) categoryPlot25);
        legendItem19.setSeriesKey((java.lang.Comparable) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder37 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean38 = legendItem19.equals((java.lang.Object) blockBorder37);
        java.awt.Paint paint39 = legendItem19.getOutlinePaint();
        java.lang.String str40 = legendItem19.getDescription();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(drawingSupplier33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(blockBorder37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "VerticalAlignment.CENTER" + "'", str40.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Stroke stroke12 = statisticalBarRenderer0.getSeriesOutlineStroke((int) '4');
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = statisticalBarRenderer0.getGradientPaintTransformer();
        java.awt.Color color17 = java.awt.Color.GRAY;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color17);
        statisticalBarRenderer0.setSeriesFillPaint((int) ' ', (java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer3.setSeriesFillPaint(0, (java.awt.Paint) color5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer3.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 255, "ItemLabelAnchor.OUTSIDE9", textAnchor8, textAnchor9, (double) (byte) 100);
        double double12 = numberTick11.getAngle();
        double double13 = numberTick11.getValue();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 255.0d + "'", double13 == 255.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] {};
        double[][] doubleArray3 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray2, doubleArray3);
        boolean boolean5 = projectInfo0.equals((java.lang.Object) categoryDataset4);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset4, (double) (byte) 0);
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(categoryDataset4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets8.calculateRightInset((double) 2);
        categoryPlot4.setInsets(rectangleInsets8, true);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer15.setSeriesFillPaint(0, (java.awt.Paint) color17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer15.getBasePositiveItemLabelPosition();
        categoryPlot4.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = null;
        statisticalBarRenderer15.setGradientPaintTransformer(gradientPaintTransformer22);
        statisticalBarRenderer15.setDrawBarOutline(false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.awt.Paint paint1 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer2.setSeriesFillPaint(0, (java.awt.Paint) color4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        statisticalBarRenderer2.setSeriesURLGenerator(255, categoryURLGenerator7);
        statisticalBarRenderer2.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer2.setErrorIndicatorStroke(stroke12);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 2, paint1, stroke12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = valueMarker14.getLabelOffset();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot20);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = legendTitle22.getItemLabelPadding();
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean25 = rectangleInsets23.equals((java.lang.Object) verticalAlignment24);
        valueMarker14.setLabelOffset(rectangleInsets23);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot19 = categoryPlot4.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot4.setRenderer(1, categoryItemRenderer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot4.getDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup24 = categoryPlot4.getDatasetGroup();
        int int25 = categoryPlot4.getRangeAxisCount();
        java.util.List list26 = categoryPlot4.getCategories();
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setRangeAxisLocation(2, axisLocation28);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNull(datasetGroup24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(list26);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabel();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 'a', numberFormat1, 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        java.awt.Font font8 = categoryPlot4.getNoDataMessageFont();
        double double9 = categoryPlot4.getRangeCrosshairValue();
        boolean boolean10 = categoryPlot4.isDomainZoomable();
        categoryPlot4.setBackgroundImageAlignment(192);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot6.setDomainAxis(categoryAxis7);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot6.setDomainAxisLocation((int) (short) 10, axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        jFreeChart18.setTitle("Layer.BACKGROUND");
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = jFreeChart18.getPadding();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list4 = defaultStatisticalCategoryDataset3.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity7 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "", "TextBlockAnchor.BOTTOM_CENTER", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) "TextBlockAnchor.BOTTOM_CENTER", (java.lang.Comparable) (-123));
        java.lang.Object obj8 = categoryItemEntity7.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (byte) 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        boolean boolean11 = legendGraphic4.isShapeVisible();
        java.awt.Paint paint12 = legendGraphic4.getOutlinePaint();
        legendGraphic4.setID("AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = legendGraphic4.getFillPaintTransformer();
        legendGraphic4.setShapeOutlineVisible(true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 3.0d);
        try {
            java.lang.Comparable comparable4 = keyedObjects2D0.getColumnKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color4);
        categoryAxis0.setFixedDimension((double) 10L);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot12.setDomainAxis(categoryAxis13);
        java.lang.Comparable[] comparableArray15 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray16 = new java.lang.Comparable[] {};
        double[][] doubleArray17 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray15, comparableArray16, doubleArray17);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset18, (int) (short) 100);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset18, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot12.getRendererForDataset(categoryDataset18);
        java.awt.Paint paint24 = categoryPlot12.getNoDataMessagePaint();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        int int26 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(comparableArray15);
        org.junit.Assert.assertNotNull(comparableArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str3 = projectInfo2.getInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        java.lang.String str5 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("LegendItemEntity: seriesKey=null, dataset=null", "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]", "{0}", "Range[-1.6727872E7,-1.6727872E7]");
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot4.getRendererForDataset(categoryDataset16);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNull(categoryItemRenderer17);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        categoryPlot4.clearAnnotations();
        float float9 = categoryPlot4.getBackgroundAlpha();
        java.awt.Font font10 = categoryPlot4.getNoDataMessageFont();
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (byte) 100, (int) 'a');
        java.awt.Stroke stroke8 = statisticalBarRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        double double12 = categoryAxis11.getLabelAngle();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.KeyedObjects keyedObjects14 = new org.jfree.data.KeyedObjects();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        keyedObjects14.addObject((java.lang.Comparable) (byte) 0, (java.lang.Object) font16);
        java.lang.Comparable comparable18 = null;
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        keyedObjects14.addObject(comparable18, (java.lang.Object) layer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        statisticalBarRenderer0.drawAnnotations(graphics2D9, rectangle2D10, categoryAxis11, valueAxis13, layer19, plotRenderingInfo21);
        try {
            statisticalBarRenderer0.setSeriesVisible((-8323073), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(layer19);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets8.calculateRightInset((double) 2);
        categoryPlot4.setInsets(rectangleInsets8, true);
        java.awt.Stroke stroke13 = categoryPlot4.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = rendererState1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot8);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int12 = defaultStatisticalCategoryDataset0.getRowCount();
        java.lang.Number number13 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        try {
            java.lang.Number number16 = defaultStatisticalCategoryDataset0.getValue(15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertEquals((double) number11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0d + "'", number13.equals(0.0d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.LEFT" + "'", str1.equals("RectangleAnchor.LEFT"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle8.getItemLabelPadding();
        double double11 = rectangleInsets9.trimWidth((double) 0L);
        boolean boolean12 = numberAxis1.equals((java.lang.Object) double11);
        boolean boolean13 = numberAxis1.isAutoRange();
        java.awt.Shape shape14 = numberAxis1.getRightArrow();
        boolean boolean15 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-4.0d) + "'", double11 == (-4.0d));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE1" + "'", str1.equals("ItemLabelAnchor.OUTSIDE1"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        statisticalBarRenderer0.setSeriesVisible((int) (byte) 10, (java.lang.Boolean) false, false);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot8.getDomainAxisLocation();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets8.calculateRightInset((double) 2);
        categoryPlot4.setInsets(rectangleInsets8, true);
        org.jfree.chart.util.UnitType unitType13 = rectangleInsets8.getUnitType();
        org.jfree.chart.util.UnitType unitType14 = rectangleInsets8.getUnitType();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(unitType13);
        org.junit.Assert.assertNotNull(unitType14);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getBase();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        statisticalBarRenderer0.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator3);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color13 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape12, (java.awt.Paint) color13);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color18 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape17, (java.awt.Paint) color18);
        legendGraphic14.setShape(shape17);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color22 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape17, stroke21, (java.awt.Paint) color22);
        statisticalBarRenderer0.setSeriesFillPaint(1, (java.awt.Paint) color22, true);
        java.awt.Stroke stroke26 = statisticalBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer27.setSeriesFillPaint(0, (java.awt.Paint) color29);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = null;
        statisticalBarRenderer27.setSeriesURLGenerator(255, categoryURLGenerator32);
        statisticalBarRenderer27.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke39 = statisticalBarRenderer27.getItemStroke(255, (int) 'a');
        statisticalBarRenderer27.setAutoPopulateSeriesPaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = statisticalBarRenderer27.getPositiveItemLabelPosition((int) ' ', (int) (byte) -1);
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition44, true);
        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color51 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic52 = new org.jfree.chart.title.LegendGraphic(shape50, (java.awt.Paint) color51);
        java.awt.Shape shape55 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color56 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic57 = new org.jfree.chart.title.LegendGraphic(shape55, (java.awt.Paint) color56);
        java.awt.Stroke stroke58 = legendGraphic57.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = legendGraphic57.getShapeLocation();
        java.awt.Shape shape62 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape50, rectangleAnchor59, (double) (short) 10, (double) 0L);
        statisticalBarRenderer0.setSeriesShape(100, shape62, true);
        statisticalBarRenderer0.setItemMargin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(itemLabelPosition44);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNull(stroke58);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
        org.junit.Assert.assertNotNull(shape62);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getBase();
        statisticalBarRenderer0.removeAnnotations();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot8.setDomainAxis(categoryAxis9);
        java.awt.Paint paint11 = categoryPlot8.getRangeGridlinePaint();
        boolean boolean12 = categoryPlot8.isRangeZoomable();
        categoryPlot8.setRangeCrosshairValue((double) (byte) 10, false);
        categoryPlot8.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        java.awt.Paint paint25 = categoryPlot24.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot24);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle26.getItemLabelPadding();
        double double29 = rectangleInsets27.trimWidth((double) 0L);
        boolean boolean30 = numberAxis19.equals((java.lang.Object) double29);
        boolean boolean31 = numberAxis19.isAutoRange();
        numberAxis19.setAutoRangeIncludesZero(false);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        statisticalBarRenderer0.drawRangeGridline(graphics2D3, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis19, rectangle2D34, (double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-4.0d) + "'", double29 == (-4.0d));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo0.setLicenceName("AxisLocation.BOTTOM_OR_RIGHT");
        projectInfo0.addOptionalLibrary("UnitType.RELATIVE");
        org.jfree.chart.util.ObjectList objectList8 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj10 = objectList8.get(255);
        boolean boolean11 = projectInfo0.equals((java.lang.Object) 255);
        org.jfree.chart.ui.ProjectInfo projectInfo12 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo13 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo12.addLibrary((org.jfree.chart.ui.Library) projectInfo13);
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo13);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (byte) 100, (int) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot11.setDomainAxis(categoryAxis12);
        java.lang.Comparable[] comparableArray14 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray15 = new java.lang.Comparable[] {};
        double[][] doubleArray16 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray14, comparableArray15, doubleArray16);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset17, (int) (short) 100);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset17, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot11.getRendererForDataset(categoryDataset17);
        java.awt.Paint paint23 = categoryPlot11.getNoDataMessagePaint();
        categoryPlot11.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot26 = categoryPlot11.getParent();
        categoryPlot11.setAnchorValue(0.0d, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer31.setSeriesFillPaint(0, (java.awt.Paint) color33);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator36 = null;
        statisticalBarRenderer31.setSeriesURLGenerator(255, categoryURLGenerator36);
        statisticalBarRenderer31.setSeriesVisible(100, (java.lang.Boolean) false, true);
        categoryPlot11.setRenderer(128, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer31);
        statisticalBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot11);
        boolean boolean46 = statisticalBarRenderer0.getItemCreateEntity(0, 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator48 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator48);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = null;
        try {
            statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition50, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(comparableArray14);
        org.junit.Assert.assertNotNull(comparableArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(pieDataset19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(plot26);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNull(itemLabelPosition47);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Color color15 = java.awt.Color.lightGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        int int18 = color17.getRed();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape11, (java.awt.Paint) color15, stroke16, (java.awt.Paint) color17);
        float[] floatArray20 = null;
        float[] floatArray21 = color17.getRGBColorComponents(floatArray20);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        java.lang.Object obj2 = null;
        boolean boolean3 = strokeList0.equals(obj2);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100.0f, (java.lang.Object) color1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot7.setDomainAxis(categoryAxis8);
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection12 = categoryPlot7.getRangeMarkers(0, layer11);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray13 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot7.setDomainAxes(categoryAxisArray13);
        boolean boolean15 = keyedObject2.equals((java.lang.Object) categoryAxisArray13);
        java.lang.Comparable comparable16 = keyedObject2.getKey();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNotNull(categoryAxisArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 100.0f + "'", comparable16.equals(100.0f));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        boolean boolean11 = legendGraphic4.isShapeVisible();
        boolean boolean12 = legendGraphic4.isLineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation14 = axisLocation13.getOpposite();
        boolean boolean15 = legendGraphic4.equals((java.lang.Object) axisLocation14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            legendGraphic4.draw(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.setAnchorValue(0.0d, true);
        java.awt.Font font11 = categoryPlot7.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("hi!", font11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.GENERAL", font11);
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("ThreadContext", font11);
        java.awt.Font font15 = labelBlock14.getFont();
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Stroke stroke5 = legendGraphic4.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendGraphic4.getShapeLocation();
        boolean boolean7 = legendGraphic4.isShapeFilled();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendGraphic4.getShapeLocation();
        boolean boolean9 = legendGraphic4.isLineVisible();
        boolean boolean10 = legendGraphic4.isLineVisible();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Paint paint12 = statisticalBarRenderer0.getSeriesFillPaint((-123));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer13.setSeriesFillPaint(0, (java.awt.Paint) color15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer13.getPositiveItemLabelPosition((int) (byte) 100, (int) 'a');
        java.awt.Stroke stroke21 = statisticalBarRenderer13.lookupSeriesOutlineStroke((int) (byte) 1);
        statisticalBarRenderer0.setBaseStroke(stroke21, false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo0.setLicenceName("AxisLocation.BOTTOM_OR_RIGHT");
        java.lang.String str5 = projectInfo0.getVersion();
        projectInfo0.setVersion("{0}");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer0.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color12);
        int int14 = statisticalBarRenderer0.getColumnCount();
        try {
            statisticalBarRenderer0.setSeriesCreateEntities((-123), (java.lang.Boolean) true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot4.setDomainAxis((int) (byte) 1, categoryAxis18);
        java.awt.Stroke stroke20 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent21);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        double double31 = rectangleInsets29.calculateRightInset((double) 2);
        categoryPlot25.setInsets(rectangleInsets29, true);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets29.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets29);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot4.setRenderer(categoryItemRenderer37, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor40 = categoryPlot4.getDomainGridlinePosition();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.UnitType unitType42 = rectangleInsets41.getUnitType();
        categoryPlot4.setInsets(rectangleInsets41, false);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(categoryAnchor40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(unitType42);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] {};
        double[][] doubleArray3 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray2, doubleArray3);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset4, (int) (short) 100);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset6, (java.lang.Comparable) 0.2d, (double) (-123));
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset9, (java.lang.Comparable) 2.0d, (double) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 100.0f, (org.jfree.data.KeyedValues) pieDataset12);
        try {
            java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(categoryDataset4);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNotNull(categoryDataset13);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer0.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        categoryPlot18.setAnchorValue(0.0d, true);
        org.jfree.chart.axis.AxisSpace axisSpace22 = categoryPlot18.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double24 = statisticalBarRenderer23.getBase();
        categoryPlot18.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer23);
        statisticalBarRenderer0.setPlot(categoryPlot18);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str3 = projectInfo2.getInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        projectInfo2.setLicenceText("");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str3);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 1L, (double) (short) 1);
        size2D2.setHeight(0.0d);
        double double5 = size2D2.width;
        size2D2.width = 10.0d;
        size2D2.setHeight((double) '4');
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setBaseSeriesVisible(true, false);
        boolean boolean10 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str1.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        java.awt.Image image8 = categoryPlot4.getBackgroundImage();
        categoryPlot4.configureDomainAxes();
        categoryPlot4.setRangeCrosshairLockedOnData(false);
        boolean boolean12 = categoryPlot4.isRangeCrosshairVisible();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot8.setDomainAxis(categoryAxis9);
        categoryPlot8.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot8.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation15, plotOrientation16);
        categoryPlot8.setDomainAxisLocation((int) (short) 10, axisLocation15);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font3, (org.jfree.chart.plot.Plot) categoryPlot8, true);
        jFreeChart20.setTitle("Layer.BACKGROUND");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer23.setSeriesFillPaint(0, (java.awt.Paint) color25);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = null;
        statisticalBarRenderer23.setSeriesURLGenerator(255, categoryURLGenerator28);
        statisticalBarRenderer23.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer23.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color35);
        jFreeChart20.setBorderPaint((java.awt.Paint) color35);
        java.awt.RenderingHints renderingHints38 = jFreeChart20.getRenderingHints();
        java.awt.Color color39 = java.awt.Color.WHITE;
        jFreeChart20.setBackgroundPaint((java.awt.Paint) color39);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) unitType1, jFreeChart20);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        textTitle43.draw(graphics2D44, rectangle2D45);
        jFreeChart20.setTitle(textTitle43);
        java.awt.Stroke stroke48 = jFreeChart20.getBorderStroke();
        int int49 = jFreeChart20.getSubtitleCount();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(renderingHints38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        categoryPlot4.clearAnnotations();
        categoryPlot4.setOutlineVisible(false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer0.setSeriesVisible(0, (java.lang.Boolean) true, true);
        java.lang.Boolean boolean9 = barRenderer0.getSeriesItemLabelsVisible(128);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setBaseSeriesVisible(true, false);
        statisticalBarRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, false);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        double double17 = categoryAxis16.getLabelAngle();
        double double18 = categoryAxis16.getCategoryMargin();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = categoryPlot25.getRangeMarkers(layer29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        statisticalBarRenderer0.drawAnnotations(graphics2D14, rectangle2D15, categoryAxis16, valueAxis20, layer29, plotRenderingInfo31);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        statisticalBarRenderer0.removeAnnotations();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNull(itemLabelPosition33);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.isItemLabelVisible((int) (short) 100, (-123));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer0.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color12);
        int int14 = statisticalBarRenderer0.getColumnCount();
        java.awt.Stroke stroke17 = statisticalBarRenderer0.getItemOutlineStroke(10, (int) '#');
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        categoryPlot22.setDomainAxis(categoryAxis23);
        java.lang.Comparable[] comparableArray25 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray26 = new java.lang.Comparable[] {};
        double[][] doubleArray27 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray25, comparableArray26, doubleArray27);
        org.jfree.data.general.PieDataset pieDataset30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset28, (int) (short) 100);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset28, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = categoryPlot22.getRendererForDataset(categoryDataset28);
        java.awt.Paint paint34 = categoryPlot22.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot22.setDomainAxis((int) (byte) 1, categoryAxis36);
        java.awt.Stroke stroke38 = categoryPlot22.getRangeGridlineStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke38, true);
        try {
            statisticalBarRenderer0.setSeriesVisible((int) (short) -1, (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(comparableArray25);
        org.junit.Assert.assertNotNull(comparableArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(pieDataset30);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNull(categoryItemRenderer33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray1, doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (int) (short) 100);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset5, (java.lang.Comparable) 0.2d, (double) (-123));
        org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset8, (java.lang.Comparable) (byte) 100, 0.0d);
        org.jfree.data.general.PieDataset pieDataset15 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset11, (java.lang.Comparable) (-1.0f), (double) ' ', (-8323073));
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNotNull(pieDataset11);
        org.junit.Assert.assertNotNull(pieDataset15);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.setAnchorValue(0.0d, true);
        java.awt.Font font11 = categoryPlot7.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("hi!", font11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.GENERAL", font11);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color21 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic22 = new org.jfree.chart.title.LegendGraphic(shape20, (java.awt.Paint) color21);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color26 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic27 = new org.jfree.chart.title.LegendGraphic(shape25, (java.awt.Paint) color26);
        legendGraphic22.setShape(shape25);
        java.awt.Color color29 = java.awt.Color.lightGray;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color31 = java.awt.Color.MAGENTA;
        int int32 = color31.getRed();
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape25, (java.awt.Paint) color29, stroke30, (java.awt.Paint) color31);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer37 = new org.jfree.chart.text.G2TextMeasurer(graphics2D36);
        try {
            org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("Range[-1.6727872E7,-1.6727872E7]", font11, (java.awt.Paint) color31, (float) (-16727872), (int) (short) 10, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 255 + "'", int32 == 255);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (byte) 100, (int) 'a');
        boolean boolean8 = statisticalBarRenderer0.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.get((-16727872));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.awt.Paint paint7 = categoryPlot4.getRangeGridlinePaint();
        boolean boolean8 = categoryPlot4.isRangeZoomable();
        categoryPlot4.setRangeCrosshairValue((double) (byte) 10, false);
        int int12 = categoryPlot4.getBackgroundImageAlignment();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color20 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape19, (java.awt.Paint) color20);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color25 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic26 = new org.jfree.chart.title.LegendGraphic(shape24, (java.awt.Paint) color25);
        legendGraphic21.setShape(shape24);
        java.awt.Color color28 = java.awt.Color.lightGray;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color30 = java.awt.Color.MAGENTA;
        int int31 = color30.getRed();
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape24, (java.awt.Paint) color28, stroke29, (java.awt.Paint) color30);
        java.awt.Stroke stroke33 = legendItem32.getLineStroke();
        categoryPlot4.setOutlineStroke(stroke33);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = categoryPlot4.getFixedLegendItems();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 255 + "'", int31 == 255);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(legendItemCollection35);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Paint paint12 = statisticalBarRenderer0.getSeriesPaint(10);
        java.awt.Color color13 = java.awt.Color.cyan;
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color13);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        categoryPlot20.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection25 = categoryPlot20.getRangeMarkers(layer24);
        java.lang.String str26 = layer24.toString();
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation15, layer24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Layer.FOREGROUND" + "'", str26.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Class<?> wildcardClass6 = textAnchor5.getClass();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.text.TextUtilities.drawAlignedString("154,-24,153,-25,154,-25,154,-25,153,-25,153,-26,153,-26,153,-25,152,-24,152,-24,153,-25,154,-24,154,-24", graphics2D1, (float) (-4145152), 1.0f, textAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer0.setSeriesVisible(0, (java.lang.Boolean) true, true);
        boolean boolean8 = barRenderer0.getAutoPopulateSeriesFillPaint();
        boolean boolean9 = barRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Color color15 = java.awt.Color.lightGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        int int18 = color17.getRed();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape11, (java.awt.Paint) color15, stroke16, (java.awt.Paint) color17);
        java.awt.Stroke stroke20 = legendItem19.getLineStroke();
        legendItem19.setSeriesIndex((int) '#');
        boolean boolean23 = legendItem19.isLineVisible();
        java.awt.Paint paint24 = legendItem19.getFillPaint();
        java.lang.String str25 = legendItem19.getURLText();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "VerticalAlignment.CENTER" + "'", str25.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getBase();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        statisticalBarRenderer0.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator3);
        java.awt.Shape shape5 = statisticalBarRenderer0.getBaseShape();
        java.awt.Stroke stroke7 = null;
        statisticalBarRenderer0.setSeriesOutlineStroke((int) (byte) 10, stroke7, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getItemLabelPadding();
        double double9 = rectangleInsets7.calculateBottomOutset((double) (-8323073));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Class<?> wildcardClass5 = textAnchor4.getClass();
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass5);
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("{0}", (java.lang.Class) wildcardClass5);
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Class<?> wildcardClass10 = textAnchor9.getClass();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Class<?> wildcardClass13 = textAnchor12.getClass();
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass13);
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass10, (java.lang.Class) wildcardClass13);
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass10);
        java.net.URL uRL17 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("AxisLocation.BOTTOM_OR_RIGHT version {0}.\nThreadContext.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY AxisLocation.BOTTOM_OR_RIGHT:None\nAxisLocation.BOTTOM_OR_RIGHT LICENCE TERMS:\nLayer.BACKGROUND", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(uRL6);
        org.junit.Assert.assertNull(inputStream7);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(uRL14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNull(uRL17);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint2 = defaultDrawingSupplier1.getNextOutlinePaint();
        java.awt.Paint paint3 = defaultDrawingSupplier1.getNextPaint();
        int int4 = numberTickUnit0.compareTo((java.lang.Object) paint3);
        java.lang.String str6 = numberTickUnit0.valueToString((double) 'a');
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "97" + "'", str6.equals("97"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.Stroke stroke4 = numberAxis1.getAxisLineStroke();
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color18 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape17, (java.awt.Paint) color18);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color23 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic24 = new org.jfree.chart.title.LegendGraphic(shape22, (java.awt.Paint) color23);
        legendGraphic19.setShape(shape22);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color27 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape22, stroke26, (java.awt.Paint) color27);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) (short) 1, (float) 100L, (float) 128);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity33 = new org.jfree.chart.entity.LegendItemEntity(shape32);
        java.awt.Shape shape34 = legendItemEntity33.getArea();
        statisticalBarRenderer0.setBaseShape(shape34);
        java.awt.Font font36 = null;
        statisticalBarRenderer0.setBaseItemLabelFont(font36, true);
        org.jfree.chart.block.BlockBorder blockBorder40 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint41 = blockBorder40.getPaint();
        statisticalBarRenderer0.setSeriesItemLabelPaint(255, paint41);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Stroke stroke12 = statisticalBarRenderer0.getSeriesOutlineStroke((int) '4');
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = statisticalBarRenderer0.getGradientPaintTransformer();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine18 = new org.jfree.chart.text.TextLine("AxisLocation.BOTTOM_OR_RIGHT", font17);
        statisticalBarRenderer0.setBaseItemLabelFont(font17);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color22 = color21.darker();
        try {
            statisticalBarRenderer0.setSeriesOutlinePaint((-123), (java.awt.Paint) color21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray8 = legendTitle6.getSources();
        boolean boolean9 = legendTitle6.getNotify();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        legendTitle6.setHorizontalAlignment(horizontalAlignment10);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(legendItemSourceArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation11, plotOrientation12);
        categoryPlot4.setDomainAxisLocation(15, axisLocation11);
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot20);
        flowArrangement15.add((org.jfree.chart.block.Block) legendTitle22, (java.lang.Object) (-16727872));
        java.awt.Paint paint25 = legendTitle22.getItemPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets();
        double double28 = rectangleInsets26.trimWidth((double) 1);
        legendTitle22.setItemLabelPadding(rectangleInsets26);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets();
        double double32 = rectangleInsets30.trimWidth((double) 1);
        boolean boolean33 = rectangleInsets26.equals((java.lang.Object) rectangleInsets30);
        categoryPlot4.setInsets(rectangleInsets26);
        double double35 = rectangleInsets26.getRight();
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-1.0d) + "'", double28 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Paint paint12 = statisticalBarRenderer0.getSeriesPaint(10);
        java.awt.Color color13 = java.awt.Color.cyan;
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color13);
        java.awt.Paint paint16 = statisticalBarRenderer0.getSeriesPaint((-1));
        java.awt.Paint paint17 = statisticalBarRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = categoryLabelPositions2.getLabelPosition(rectangleEdge3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        java.awt.Paint paint12 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle13.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = categoryLabelPositions6.getLabelPosition(rectangleEdge14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = categoryLabelPosition15.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType17 = categoryLabelPosition15.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = categoryLabelPosition15.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions2, categoryLabelPosition15);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = categoryLabelPosition15.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType23 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str24 = categoryLabelWidthType23.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor20, textAnchor21, (double) (byte) 0, categoryLabelWidthType23, 100.0f);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor27 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions29 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
        java.awt.Paint paint35 = categoryPlot34.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot34);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = legendTitle36.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition38 = categoryLabelPositions29.getLabelPosition(rectangleEdge37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = categoryLabelPosition38.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType40 = categoryLabelPosition38.getWidthType();
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition42 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor27, categoryLabelWidthType40, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNull(categoryLabelPosition4);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(categoryLabelPosition15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(categoryLabelWidthType17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(categoryLabelWidthType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str24.equals("CategoryLabelWidthType.CATEGORY"));
        org.junit.Assert.assertNotNull(categoryLabelPositions29);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(categoryLabelPosition38);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(categoryLabelWidthType40);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot4.getDataset();
        categoryPlot4.setOutlineVisible(true);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list12 = defaultStatisticalCategoryDataset11.getColumnKeys();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot4.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11);
        float float14 = categoryPlot4.getBackgroundImageAlpha();
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double[] doubleArray5 = new double[] { 0.5f, (byte) -1, (-1) };
        double[] doubleArray9 = new double[] { 0.5f, (byte) -1, (-1) };
        double[] doubleArray13 = new double[] { 0.5f, (byte) -1, (-1) };
        double[] doubleArray17 = new double[] { 0.5f, (byte) -1, (-1) };
        double[] doubleArray21 = new double[] { 0.5f, (byte) -1, (-1) };
        double[] doubleArray25 = new double[] { 0.5f, (byte) -1, (-1) };
        double[][] doubleArray26 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17, doubleArray21, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[-1.6727872E7,-1.6727872E7]", "TextBlockAnchor.BOTTOM_CENTER", doubleArray26);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset27, false);
        boolean boolean31 = range29.contains((-10.0d));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setVisible(false);
        categoryAxis0.setLabel("ItemLabelAnchor.OUTSIDE9");
        java.lang.String str9 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 0.5f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Paint paint6 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.Range range11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range11);
        org.jfree.chart.util.Size2D size2D13 = legendTitle7.arrange(graphics2D9, rectangleConstraint12);
        boolean boolean14 = legendItemCollection0.equals((java.lang.Object) rectangleConstraint12);
        java.util.Iterator iterator15 = legendItemCollection0.iterator();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(iterator15);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer6.setSeriesFillPaint(0, (java.awt.Paint) color8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        statisticalBarRenderer6.setSeriesURLGenerator(255, categoryURLGenerator11);
        statisticalBarRenderer6.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer6.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color18);
        int int20 = statisticalBarRenderer6.getColumnCount();
        java.awt.Stroke stroke23 = statisticalBarRenderer6.getItemOutlineStroke(10, (int) '#');
        java.awt.Paint paint26 = statisticalBarRenderer6.getItemLabelPaint((int) (short) 0, (int) (byte) 10);
        categoryAxis0.setTickMarkPaint(paint26);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color16 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape11, stroke15, (java.awt.Paint) color16);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, (double) (short) 1, (float) 100L, (float) 128);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity22 = new org.jfree.chart.entity.LegendItemEntity(shape21);
        java.lang.Object obj23 = legendItemEntity22.clone();
        java.lang.String str24 = legendItemEntity22.getURLText();
        java.lang.String str25 = legendItemEntity22.toString();
        legendItemEntity22.setURLText("hi!");
        java.lang.String str28 = legendItemEntity22.getShapeCoords();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str25.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "154,-24,153,-25,154,-25,154,-25,153,-25,153,-26,153,-26,153,-25,152,-24,152,-24,153,-25,154,-24,154,-24" + "'", str28.equals("154,-24,153,-25,154,-25,154,-25,153,-25,153,-26,153,-26,153,-25,152,-24,152,-24,153,-25,154,-24,154,-24"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Stroke stroke5 = legendGraphic4.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendGraphic4.getShapeLocation();
        boolean boolean7 = legendGraphic4.isShapeFilled();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendGraphic4.getShapeLocation();
        boolean boolean9 = legendGraphic4.isLineVisible();
        double double10 = legendGraphic4.getContentXOffset();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color16 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape11, stroke15, (java.awt.Paint) color16);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, (double) (short) 1, (float) 100L, (float) 128);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity22 = new org.jfree.chart.entity.LegendItemEntity(shape21);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape21);
        java.awt.Shape shape24 = chartEntity23.getArea();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.data.RangeType rangeType4 = numberAxis1.getRangeType();
        java.awt.Shape shape5 = numberAxis1.getUpArrow();
        double double6 = numberAxis1.getLabelAngle();
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        double double4 = range3.getLength();
        boolean boolean6 = range3.contains((double) 1L);
        double double7 = range3.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 2, range3);
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) (-16727872));
        double double12 = range11.getLength();
        boolean boolean14 = range11.contains((double) 1L);
        double double15 = range11.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint8.toRangeWidth(range11);
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range17, (double) (-16727872));
        double double20 = range19.getLength();
        double double21 = range19.getUpperBound();
        double double23 = range19.constrain((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint16.toRangeHeight(range19);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.6727872E7d) + "'", double21 == (-1.6727872E7d));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-1.6727872E7d) + "'", double23 == (-1.6727872E7d));
        org.junit.Assert.assertNotNull(rectangleConstraint24);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = legendTitle6.getVerticalAlignment();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Class<?> wildcardClass9 = textAnchor8.getClass();
        boolean boolean10 = verticalAlignment7.equals((java.lang.Object) wildcardClass9);
        java.lang.String str11 = verticalAlignment7.toString();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "VerticalAlignment.CENTER" + "'", str11.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Paint paint6 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray9 = legendTitle7.getSources();
        boolean boolean10 = legendTitle7.getNotify();
        boolean boolean11 = gradientPaintTransformType0.equals((java.lang.Object) legendTitle7);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(legendItemSourceArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot8);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int12 = defaultStatisticalCategoryDataset0.getRowCount();
        int int13 = defaultStatisticalCategoryDataset0.getRowCount();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertEquals((double) number11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot8);
        categoryPlot8.setRangeCrosshairVisible(false);
        categoryPlot8.clearDomainAxes();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        legendGraphic4.setHeight(0.0d);
        legendGraphic4.setShapeOutlineVisible(false);
        legendGraphic4.setLineVisible(false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        categoryPlot5.setAnchorValue(0.0d, true);
        java.awt.Font font9 = categoryPlot5.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!", font9);
        java.awt.Paint paint11 = labelBlock10.getPaint();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        float[] floatArray16 = new float[] { 1.0f, (-8323073), (short) 0 };
        float[] floatArray17 = color12.getRGBColorComponents(floatArray16);
        labelBlock10.setPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double10 = statisticalBarRenderer9.getBase();
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer9);
        statisticalBarRenderer9.setMinimumBarLength(0.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = statisticalBarRenderer9.getPlot();
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(categoryPlot14);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color4);
        categoryAxis0.setFixedDimension((double) 10L);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot12.setDomainAxis(categoryAxis13);
        java.lang.Comparable[] comparableArray15 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray16 = new java.lang.Comparable[] {};
        double[][] doubleArray17 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray15, comparableArray16, doubleArray17);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset18, (int) (short) 100);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset18, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot12.getRendererForDataset(categoryDataset18);
        java.awt.Paint paint24 = categoryPlot12.getNoDataMessagePaint();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean29 = barRenderer26.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer26.setSeriesVisible(0, (java.lang.Boolean) true, true);
        categoryPlot12.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer26);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis38, categoryItemRenderer39);
        java.awt.Paint paint41 = categoryPlot40.getRangeGridlinePaint();
        categoryPlot40.clearAnnotations();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer43 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer43.setSeriesFillPaint(0, (java.awt.Paint) color45);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = statisticalBarRenderer43.getBasePositiveItemLabelPosition();
        java.awt.Paint paint50 = statisticalBarRenderer43.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke53 = statisticalBarRenderer43.getItemStroke((int) 'a', (int) (byte) 10);
        categoryPlot40.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer43, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = statisticalBarRenderer43.getSeriesNegativeItemLabelPosition(2);
        java.awt.Color color58 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color59 = color58.darker();
        statisticalBarRenderer43.setBaseItemLabelPaint((java.awt.Paint) color58);
        barRenderer26.setSeriesPaint(10, (java.awt.Paint) color58);
        java.awt.color.ColorSpace colorSpace62 = color58.getColorSpace();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(comparableArray15);
        org.junit.Assert.assertNotNull(comparableArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(itemLabelPosition57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(colorSpace62);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 3.0d);
        java.lang.Comparable comparable3 = null;
        java.lang.Object obj5 = keyedObjects2D0.getObject(comparable3, (java.lang.Comparable) (byte) -1);
        int int7 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot6.setDomainAxis(categoryAxis7);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot6.setDomainAxisLocation((int) (short) 10, axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        jFreeChart18.setTitle("Layer.BACKGROUND");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer21.setSeriesFillPaint(0, (java.awt.Paint) color23);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = null;
        statisticalBarRenderer21.setSeriesURLGenerator(255, categoryURLGenerator26);
        statisticalBarRenderer21.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer21.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color33);
        jFreeChart18.setBorderPaint((java.awt.Paint) color33);
        java.awt.RenderingHints renderingHints36 = jFreeChart18.getRenderingHints();
        org.jfree.chart.title.LegendTitle legendTitle38 = jFreeChart18.getLegend((int) (byte) 100);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(renderingHints36);
        org.junit.Assert.assertNull(legendTitle38);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ChartChangeEventType.GENERAL");
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator1.clone();
        boolean boolean4 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) "ChartChangeEventType.GENERAL");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer5.setSeriesFillPaint(0, (java.awt.Paint) color7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        statisticalBarRenderer5.setSeriesURLGenerator(255, categoryURLGenerator10);
        statisticalBarRenderer5.setBaseSeriesVisible(true, false);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color19 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color19);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color24 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic25 = new org.jfree.chart.title.LegendGraphic(shape23, (java.awt.Paint) color24);
        legendGraphic20.setShape(shape23);
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color30 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic31 = new org.jfree.chart.title.LegendGraphic(shape29, (java.awt.Paint) color30);
        org.jfree.chart.title.LegendGraphic legendGraphic32 = new org.jfree.chart.title.LegendGraphic(shape23, (java.awt.Paint) color30);
        statisticalBarRenderer5.setSeriesShape((int) 'a', shape23);
        boolean boolean34 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) statisticalBarRenderer5);
        java.lang.Object obj35 = standardCategorySeriesLabelGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        float[] floatArray5 = new float[] { 1.0f, (-8323073), (short) 0 };
        float[] floatArray6 = color1.getRGBColorComponents(floatArray5);
        try {
            float[] floatArray7 = color0.getComponents(floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setVisible(false);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        textTitle8.draw(graphics2D9, rectangle2D10);
        java.awt.Paint paint12 = textTitle8.getPaint();
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 2, paint12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets14.getUnitType();
        java.awt.Font font17 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        categoryPlot22.setDomainAxis(categoryAxis23);
        categoryPlot22.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot22.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation29, plotOrientation30);
        categoryPlot22.setDomainAxisLocation((int) (short) 10, axisLocation29);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font17, (org.jfree.chart.plot.Plot) categoryPlot22, true);
        jFreeChart34.setTitle("Layer.BACKGROUND");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer37.setSeriesFillPaint(0, (java.awt.Paint) color39);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator42 = null;
        statisticalBarRenderer37.setSeriesURLGenerator(255, categoryURLGenerator42);
        statisticalBarRenderer37.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer37.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color49);
        jFreeChart34.setBorderPaint((java.awt.Paint) color49);
        java.awt.RenderingHints renderingHints52 = jFreeChart34.getRenderingHints();
        java.awt.Color color53 = java.awt.Color.WHITE;
        jFreeChart34.setBackgroundPaint((java.awt.Paint) color53);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent55 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) unitType15, jFreeChart34);
        java.lang.Object obj56 = jFreeChart34.getTextAntiAlias();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType57 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent58 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis0, jFreeChart34, chartChangeEventType57);
        java.awt.Font font60 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color61 = java.awt.Color.lightGray;
        org.jfree.chart.text.TextBlock textBlock62 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font60, (java.awt.Paint) color61);
        int int63 = color61.getRed();
        jFreeChart34.setBackgroundPaint((java.awt.Paint) color61);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(renderingHints52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNull(obj56);
        org.junit.Assert.assertNotNull(chartChangeEventType57);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(textBlock62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 192 + "'", int63 == 192);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        axisSpace0.setLeft((double) (-16727872));
        axisSpace0.setLeft((double) (-16751519));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 2.0f, (java.lang.Number) 0.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer0.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color12);
        double double14 = statisticalBarRenderer0.getMinimumBarLength();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color22 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic23 = new org.jfree.chart.title.LegendGraphic(shape21, (java.awt.Paint) color22);
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color27 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color27);
        legendGraphic23.setShape(shape26);
        java.awt.Color color30 = java.awt.Color.lightGray;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color32 = java.awt.Color.MAGENTA;
        int int33 = color32.getRed();
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape26, (java.awt.Paint) color30, stroke31, (java.awt.Paint) color32);
        java.lang.String str35 = legendItem34.getLabel();
        java.awt.Shape shape36 = legendItem34.getLine();
        statisticalBarRenderer0.setBaseShape(shape36, false);
        statisticalBarRenderer0.setMinimumBarLength((double) (byte) 10);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 255 + "'", int33 == 255);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(shape36);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement3 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement3.clear();
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        blockContainer5.clear();
        blockContainer5.setPadding((-1.0d), 100.0d, (double) (short) 100, (double) 10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) 255, (double) 10);
        org.jfree.chart.util.Size2D size2D16 = borderArrangement3.arrange(blockContainer5, graphics2D12, rectangleConstraint15);
        try {
            org.jfree.chart.util.Size2D size2D17 = textTitle1.arrange(graphics2D2, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(size2D16);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1));
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        boolean boolean11 = legendGraphic4.isShapeVisible();
        boolean boolean12 = legendGraphic4.isLineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation14 = axisLocation13.getOpposite();
        boolean boolean15 = legendGraphic4.equals((java.lang.Object) axisLocation14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendGraphic4.getMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        double double18 = categoryAxis17.getLabelAngle();
        double double19 = categoryAxis17.getCategoryMargin();
        java.lang.String str20 = categoryAxis17.getLabelToolTip();
        categoryAxis17.setCategoryLabelPositionOffset(255);
        java.lang.String str23 = categoryAxis17.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis17.getLabelInsets();
        double double26 = rectangleInsets24.calculateBottomInset((double) 1L);
        legendGraphic4.setPadding(rectangleInsets24);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.2d + "'", double19 == 0.2d);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.0d + "'", double26 == 3.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        categoryPlot4.setRangeAxis(0, valueAxis8, false);
        categoryPlot4.clearAnnotations();
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 0L, (-4.0d), (-16727872), comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 0.0f, 0.0d, (double) 255, (double) (short) 1, (java.awt.Paint) color4);
        int int6 = color4.getRed();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 128 + "'", int6 == 128);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = legendTitle6.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent8 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle6);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            legendTitle6.draw(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(verticalAlignment7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) "SortOrder.DESCENDING", "Category Plot");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) 10L);
        axisState0.cursorRight(0.0d);
        axisState0.setMax((double) 100);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer0.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color12);
        double double14 = statisticalBarRenderer0.getMinimumBarLength();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer0.setBaseStroke(stroke15);
        java.awt.Shape shape18 = statisticalBarRenderer0.getSeriesShape((int) (short) -1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(shape18);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setCategoryLabelPositionOffset(255);
        java.lang.String str6 = categoryAxis0.getLabelToolTip();
        java.lang.String str7 = categoryAxis0.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", graphics2D1, 0.5f, (float) '#', (double) (-123), 2.0f, (float) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        try {
            java.lang.String[] strArray3 = jFreeChartResources0.getStringArray("Layer.FOREGROUND");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key Layer.FOREGROUND");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        double double31 = rectangleInsets29.calculateRightInset((double) 2);
        categoryPlot25.setInsets(rectangleInsets29, true);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets29.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets29);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot4.setRenderer(categoryItemRenderer37, false);
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setDomainAxisLocation(axisLocation40);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color43 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryAxis42.setAxisLinePaint((java.awt.Paint) color43);
        java.awt.Paint[] paintArray45 = new java.awt.Paint[] { color43 };
        java.awt.Paint[] paintArray46 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray47 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray48 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray49 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier50 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray45, paintArray46, strokeArray47, strokeArray48, shapeArray49);
        org.jfree.chart.block.FlowArrangement flowArrangement51 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset52 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset52, categoryAxis53, valueAxis54, categoryItemRenderer55);
        java.awt.Paint paint57 = categoryPlot56.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot56);
        flowArrangement51.add((org.jfree.chart.block.Block) legendTitle58, (java.lang.Object) (-16727872));
        org.jfree.chart.title.TextTitle textTitle62 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle62.setURLText("VerticalAlignment.CENTER");
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = textTitle62.getMargin();
        legendTitle58.setPadding(rectangleInsets65);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = legendTitle58.getItemLabelPadding();
        boolean boolean68 = defaultDrawingSupplier50.equals((java.lang.Object) rectangleInsets67);
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier50);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(paintArray45);
        org.junit.Assert.assertNotNull(paintArray46);
        org.junit.Assert.assertNotNull(strokeArray47);
        org.junit.Assert.assertNotNull(strokeArray48);
        org.junit.Assert.assertNotNull(shapeArray49);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.data.Range range4 = null;
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range4, (double) (-16727872));
        boolean boolean8 = range6.contains((double) (-1L));
        numberAxis1.setRangeWithMargins(range6, false, true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        java.lang.String str1 = rangeType0.toString();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getRangeGridlinePaint();
        categoryPlot6.clearAnnotations();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer9.setSeriesFillPaint(0, (java.awt.Paint) color11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = statisticalBarRenderer9.getBasePositiveItemLabelPosition();
        java.awt.Paint paint16 = statisticalBarRenderer9.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke19 = statisticalBarRenderer9.getItemStroke((int) 'a', (int) (byte) 10);
        categoryPlot6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer9, true);
        java.awt.Stroke stroke22 = statisticalBarRenderer9.getBaseOutlineStroke();
        boolean boolean23 = rangeType0.equals((java.lang.Object) statisticalBarRenderer9);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.NEGATIVE" + "'", str1.equals("RangeType.NEGATIVE"));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        java.awt.Paint paint12 = statisticalBarRenderer0.getItemPaint(128, 0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle8.getItemLabelPadding();
        double double11 = rectangleInsets9.trimWidth((double) 0L);
        boolean boolean12 = numberAxis1.equals((java.lang.Object) double11);
        boolean boolean13 = numberAxis1.isPositiveArrowVisible();
        double double14 = numberAxis1.getLowerBound();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        categoryPlot20.setAnchorValue(0.0d, true);
        org.jfree.chart.axis.AxisSpace axisSpace24 = categoryPlot20.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot20.getRenderer();
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot20.getDatasetGroup();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        double double30 = axisSpace29.getTop();
        double double31 = axisSpace29.getTop();
        java.lang.String str32 = axisSpace29.toString();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace33 = numberAxis1.reserveSpace(graphics2D15, (org.jfree.chart.plot.Plot) categoryPlot20, rectangle2D27, rectangleEdge28, axisSpace29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-4.0d) + "'", double11 == (-4.0d));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(axisSpace24);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertNull(datasetGroup26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str10 = layer9.toString();
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Layer.BACKGROUND" + "'", str10.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor0, jFreeChart1, 255, (int) (short) 1);
        java.awt.Font font6 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot11.setDomainAxis(categoryAxis12);
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot11.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation18, plotOrientation19);
        categoryPlot11.setDomainAxisLocation((int) (short) 10, axisLocation18);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font6, (org.jfree.chart.plot.Plot) categoryPlot11, true);
        jFreeChart23.setTitle("Layer.BACKGROUND");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer26.setSeriesFillPaint(0, (java.awt.Paint) color28);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator31 = null;
        statisticalBarRenderer26.setSeriesURLGenerator(255, categoryURLGenerator31);
        statisticalBarRenderer26.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer26.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color38);
        jFreeChart23.setBorderPaint((java.awt.Paint) color38);
        chartProgressEvent4.setChart(jFreeChart23);
        java.awt.Image image42 = jFreeChart23.getBackgroundImage();
        org.jfree.chart.block.BlockBorder blockBorder43 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint44 = blockBorder43.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = blockBorder43.getInsets();
        jFreeChart23.setPadding(rectangleInsets45);
        jFreeChart23.removeLegend();
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.awt.Font font51 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset52 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset52, categoryAxis53, valueAxis54, categoryItemRenderer55);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        categoryPlot56.setDomainAxis(categoryAxis57);
        categoryPlot56.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace61 = categoryPlot56.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation63 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation64 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation63, plotOrientation64);
        categoryPlot56.setDomainAxisLocation((int) (short) 10, axisLocation63);
        org.jfree.chart.JFreeChart jFreeChart68 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font51, (org.jfree.chart.plot.Plot) categoryPlot56, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        org.jfree.data.category.CategoryDataset categoryDataset72 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = null;
        org.jfree.chart.axis.ValueAxis valueAxis74 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer75 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot(categoryDataset72, categoryAxis73, valueAxis74, categoryItemRenderer75);
        categoryPlot76.setAnchorValue(0.0d, true);
        categoryPlot76.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation82 = categoryPlot76.getRangeAxisLocation(255);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo85 = null;
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor87 = null;
        java.awt.geom.Point2D point2D88 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D86, rectangleAnchor87);
        categoryPlot76.zoomRangeAxes((double) 'a', (double) 'a', plotRenderingInfo85, point2D88);
        categoryPlot56.zoomRangeAxes(0.0d, (double) (short) 0, plotRenderingInfo71, point2D88);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo91 = null;
        try {
            jFreeChart23.draw(graphics2D48, rectangle2D49, point2D88, chartRenderingInfo91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNull(image42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNull(axisSpace61);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertNotNull(plotOrientation64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertNotNull(axisLocation82);
        org.junit.Assert.assertNotNull(point2D88);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        float float8 = categoryPlot4.getBackgroundAlpha();
        categoryPlot4.clearDomainMarkers((-1));
        boolean boolean11 = categoryPlot4.isRangeZoomable();
        categoryPlot4.setAnchorValue((double) 255);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setAxisLineVisible(true);
        categoryAxis14.setLabelAngle((double) (-123));
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        boolean boolean20 = categoryAxis14.equals((java.lang.Object) color19);
        categoryPlot4.setDomainAxis(categoryAxis14);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer22.setSeriesFillPaint(0, (java.awt.Paint) color24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = statisticalBarRenderer22.getBasePositiveItemLabelPosition();
        java.awt.Paint paint29 = statisticalBarRenderer22.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke32 = statisticalBarRenderer22.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Stroke stroke34 = statisticalBarRenderer22.getSeriesOutlineStroke((int) '4');
        statisticalBarRenderer22.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer37 = statisticalBarRenderer22.getGradientPaintTransformer();
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine40 = new org.jfree.chart.text.TextLine("AxisLocation.BOTTOM_OR_RIGHT", font39);
        statisticalBarRenderer22.setBaseItemLabelFont(font39);
        java.awt.Paint paint43 = statisticalBarRenderer22.lookupSeriesOutlinePaint(1);
        categoryAxis14.setTickMarkPaint(paint43);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(stroke34);
        org.junit.Assert.assertNotNull(gradientPaintTransformer37);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setAnchorValue(0.0d, true);
        java.awt.Font font10 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("hi!", font10);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.GENERAL", font10);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent13 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle12);
        textTitle12.setText("ThreadContext");
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        textTitle12.draw(graphics2D16, rectangle2D17);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getLegendItemGraphicEdge();
        java.lang.Object obj8 = legendTitle6.clone();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.awt.Shape shape0 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor1, jFreeChart2, 255, (int) (short) 1);
        java.awt.Font font7 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot12.setDomainAxis(categoryAxis13);
        categoryPlot12.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot12.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation19, plotOrientation20);
        categoryPlot12.setDomainAxisLocation((int) (short) 10, axisLocation19);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font7, (org.jfree.chart.plot.Plot) categoryPlot12, true);
        jFreeChart24.setTitle("Layer.BACKGROUND");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer27 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer27.setSeriesFillPaint(0, (java.awt.Paint) color29);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = null;
        statisticalBarRenderer27.setSeriesURLGenerator(255, categoryURLGenerator32);
        statisticalBarRenderer27.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer27.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color39);
        jFreeChart24.setBorderPaint((java.awt.Paint) color39);
        chartProgressEvent5.setChart(jFreeChart24);
        java.awt.Image image43 = jFreeChart24.getBackgroundImage();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        boolean boolean45 = jFreeChart24.equals((java.lang.Object) rectangleAnchor44);
        try {
            java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor44, 255.0d, 14.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(image43);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        boolean boolean5 = categoryPlot4.getDrawSharedDomainAxis();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot4.render(graphics2D6, rectangle2D7, 2, plotRenderingInfo9);
        java.awt.Paint paint11 = categoryPlot4.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Stroke stroke3 = categoryAxis0.getTickMarkStroke();
        boolean boolean5 = categoryAxis0.equals((java.lang.Object) 10.0d);
        categoryAxis0.setLabel("AxisLocation.BOTTOM_OR_RIGHT version {0}.\nThreadContext.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY AxisLocation.BOTTOM_OR_RIGHT:None\nAxisLocation.BOTTOM_OR_RIGHT LICENCE TERMS:\nLayer.BACKGROUND");
        java.awt.Font font9 = categoryAxis0.getTickLabelFont((java.lang.Comparable) "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        double double4 = range3.getLength();
        boolean boolean6 = range3.contains((double) 1L);
        double double7 = range3.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 2, range3);
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) (-16727872));
        double double12 = range11.getLength();
        boolean boolean14 = range11.contains((double) 1L);
        double double15 = range11.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint8.toRangeWidth(range11);
        org.jfree.data.Range range17 = rectangleConstraint8.getHeightRange();
        org.jfree.data.Range range19 = null;
        org.jfree.data.Range range21 = org.jfree.data.Range.expandToInclude(range19, (double) (-16727872));
        double double22 = range21.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType23 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range25 = null;
        org.jfree.data.Range range27 = org.jfree.data.Range.expandToInclude(range25, (double) (-16727872));
        double double28 = range27.getLength();
        org.jfree.data.Range range30 = org.jfree.data.Range.expandToInclude(range27, (double) 100L);
        double double32 = range30.constrain((double) (-1));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint((double) 128, range21, lengthConstraintType23, 255.0d, range30, lengthConstraintType33);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = rectangleConstraint8.toRangeWidth(range30);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType36 = rectangleConstraint35.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((double) 255, (double) 10);
        org.jfree.chart.util.Size2D size2D42 = new org.jfree.chart.util.Size2D((double) 1L, (double) (short) 1);
        org.jfree.chart.util.Size2D size2D43 = rectangleConstraint39.calculateConstrainedSize(size2D42);
        double double44 = size2D43.width;
        org.jfree.chart.util.Size2D size2D45 = rectangleConstraint35.calculateConstrainedSize(size2D43);
        double double46 = rectangleConstraint35.getHeight();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType23);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32 == (-1.0d));
        org.junit.Assert.assertNotNull(lengthConstraintType33);
        org.junit.Assert.assertNotNull(rectangleConstraint35);
        org.junit.Assert.assertNotNull(lengthConstraintType36);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 255.0d + "'", double44 == 255.0d);
        org.junit.Assert.assertNotNull(size2D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Class<?> wildcardClass5 = textAnchor4.getClass();
        org.jfree.chart.ui.Contributor contributor8 = new org.jfree.chart.ui.Contributor("VerticalAlignment.CENTER", "Layer.BACKGROUND");
        boolean boolean9 = textAnchor4.equals((java.lang.Object) "Layer.BACKGROUND");
        org.jfree.chart.axis.TickType tickType11 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer14.setSeriesFillPaint(0, (java.awt.Paint) color16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = statisticalBarRenderer14.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition18.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick22 = new org.jfree.chart.axis.NumberTick(tickType11, (double) 255, "ItemLabelAnchor.OUTSIDE9", textAnchor19, textAnchor20, (double) (byte) 100);
        java.awt.Shape shape23 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) 100, (float) 255, textAnchor4, (double) (byte) 0, textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNull(shape23);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        double double2 = axisSpace0.getLeft();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer0.setSeriesVisible(0, (java.lang.Boolean) true, true);
        boolean boolean8 = barRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot17.setDomainAxis(categoryAxis18);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection22 = categoryPlot17.getRangeMarkers(0, layer21);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray23 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot17.setDomainAxes(categoryAxisArray23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = null;
        java.awt.geom.Point2D point2D29 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D27, rectangleAnchor28);
        categoryPlot17.zoomRangeAxes((-1.0d), plotRenderingInfo26, point2D29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState33 = barRenderer0.initialise(graphics2D11, rectangle2D12, categoryPlot17, (int) (byte) -1, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNotNull(categoryAxisArray23);
        org.junit.Assert.assertNotNull(point2D29);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit4);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        java.awt.Paint paint13 = categoryPlot12.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle14.getLegendItemGraphicEdge();
        try {
            double double16 = numberAxis1.valueToJava2D((double) 255, rectangle2D7, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setURLText("VerticalAlignment.CENTER");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle1.getMargin();
        java.lang.Object obj5 = null;
        boolean boolean6 = rectangleInsets4.equals(obj5);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot4.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer19.setSeriesFillPaint(0, (java.awt.Paint) color21);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = statisticalBarRenderer19.getBasePositiveItemLabelPosition();
        java.awt.Paint paint26 = statisticalBarRenderer19.getItemFillPaint((int) (short) 100, 1);
        statisticalBarRenderer19.setAutoPopulateSeriesShape(false);
        boolean boolean29 = axisSpace17.equals((java.lang.Object) false);
        double double30 = axisSpace17.getRight();
        double double31 = axisSpace17.getBottom();
        double double32 = axisSpace17.getTop();
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection9 = categoryPlot4.getRangeMarkers(0, layer8);
        categoryPlot4.clearRangeMarkers((int) (byte) 1);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 3.0d);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean4 = keyedObjects2D0.equals((java.lang.Object) chartChangeEventType3);
        org.jfree.chart.block.BlockBorder blockBorder5 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean6 = keyedObjects2D0.equals((java.lang.Object) blockBorder5);
        java.lang.Object obj7 = null;
        boolean boolean8 = keyedObjects2D0.equals(obj7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setAxisLineVisible(true);
        categoryAxis9.setLabelAngle((double) (-123));
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        boolean boolean15 = categoryAxis9.equals((java.lang.Object) color14);
        java.awt.Paint paint16 = categoryAxis9.getTickLabelPaint();
        keyedObjects2D0.setObject((java.lang.Object) categoryAxis9, (java.lang.Comparable) 0.2d, (java.lang.Comparable) "Size2D[width=1.0, height=0.0]");
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(blockBorder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot5.setDomainAxis(categoryAxis6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        categoryPlot12.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets();
        double double18 = rectangleInsets16.calculateRightInset((double) 2);
        categoryPlot12.setInsets(rectangleInsets16, true);
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets16.getUnitType();
        categoryPlot5.setAxisOffset(rectangleInsets16);
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("TextAnchor.HALF_ASCENT_RIGHT", (org.jfree.chart.plot.Plot) categoryPlot5);
        java.awt.Paint paint26 = categoryPlot5.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.5f, (float) (byte) 1, textAnchor4, (double) (byte) 10, (-1.0f), 0.5f);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color4 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape3, (java.awt.Paint) color4);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic(shape8, (java.awt.Paint) color9);
        java.awt.Stroke stroke11 = legendGraphic10.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendGraphic10.getShapeLocation();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor12, (double) (short) 10, (double) 0L);
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape15, paint16);
        boolean boolean18 = projectInfo0.equals((java.lang.Object) shape15);
        org.jfree.data.KeyedObjects keyedObjects19 = new org.jfree.data.KeyedObjects();
        java.util.List list20 = keyedObjects19.getKeys();
        projectInfo0.setContributors(list20);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(list20);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        java.lang.Class class0 = null;
//        try {
//            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) "Layer.BACKGROUND", font5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer7.setSeriesFillPaint(0, (java.awt.Paint) color9);
        java.awt.Color color11 = color9.brighter();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font5, (java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.lightGray;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color2);
        java.util.List list4 = textBlock3.getLines();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.lang.String str9 = textBlockAnchor8.toString();
        try {
            textBlock3.draw(graphics2D5, 1.0f, (float) (byte) -1, textBlockAnchor8, (float) '#', (float) (-4145152), 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextBlockAnchor.BOTTOM_CENTER" + "'", str9.equals("TextBlockAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ItemLabelAnchor.OUTSIDE9", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) keyedObjects0);
        java.lang.Object obj3 = keyedObjects0.clone();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        keyedObjects0.addObject((java.lang.Comparable) (byte) 0, (java.lang.Object) font2);
        java.lang.Comparable comparable5 = keyedObjects0.getKey(0);
        try {
            keyedObjects0.removeValue((-8323073));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -8323073");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 0 + "'", comparable5.equals((byte) 0));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot8);
        org.jfree.data.Range range12 = defaultStatisticalCategoryDataset0.getRangeBounds(true);
        org.jfree.data.general.DatasetGroup datasetGroup13 = defaultStatisticalCategoryDataset0.getGroup();
        java.lang.Object obj14 = datasetGroup13.clone();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(datasetGroup13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot8);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int12 = defaultStatisticalCategoryDataset0.getRowCount();
        java.lang.Number number13 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        try {
            java.lang.Comparable comparable16 = defaultStatisticalCategoryDataset0.getColumnKey((-16727872));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertEquals((double) number11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0d + "'", number13.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.setAnchorValue(0.0d, true);
        java.awt.Font font11 = categoryPlot7.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("hi!", font11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.GENERAL", font11);
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("ThreadContext", font11);
        java.lang.String str15 = labelBlock14.getURLText();
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot4.getRangeAxisLocation(255);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        categoryPlot4.setOutlineVisible(true);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        objectList1.clear();
        int int3 = objectList1.size();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        double double5 = categoryAxis4.getLabelAngle();
        double double6 = categoryAxis4.getCategoryMargin();
        java.lang.String str7 = categoryAxis4.getLabelToolTip();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis4.setAxisLinePaint((java.awt.Paint) color8);
        int int10 = objectList1.indexOf((java.lang.Object) categoryAxis4);
        categoryAxis4.setTickLabelsVisible(true);
        categoryAxis4.setTickMarkOutsideLength((float) 1L);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity20 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis4, shape17, "CategoryAnchor.MIDDLE", "{0}");
        org.jfree.chart.axis.Axis axis21 = axisLabelEntity20.getAxis();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(axis21);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        boolean boolean6 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer8.setSeriesFillPaint(0, (java.awt.Paint) color10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = statisticalBarRenderer8.getPositiveItemLabelPosition((int) (byte) 100, (int) 'a');
        java.awt.Stroke stroke16 = statisticalBarRenderer8.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("AxisLocation.BOTTOM_OR_RIGHT", font19);
        textTitle17.setFont(font19);
        statisticalBarRenderer8.setBaseItemLabelFont(font19, true);
        categoryPlot4.setRenderer(10, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8, true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 1L, (double) (short) 1);
        size2D2.setHeight(0.0d);
        double double5 = size2D2.width;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) 10.0f, (double) (short) 0, rectangleAnchor8);
        java.lang.Object obj10 = size2D2.clone();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNull(rectangle2D9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Size2D[width=255.0, height=10.0]");
        boolean boolean2 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        defaultStatisticalCategoryDataset0.add((double) (-1.0f), (double) (-16751519), (java.lang.Comparable) 10.0d, (java.lang.Comparable) 0.5f);
        java.util.List list7 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color4);
        categoryAxis0.configure();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Color color15 = java.awt.Color.lightGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        int int18 = color17.getRed();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape11, (java.awt.Paint) color15, stroke16, (java.awt.Paint) color17);
        java.awt.Stroke stroke20 = legendItem19.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = categoryPlot25.getRangeMarkers(layer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        int int32 = categoryPlot25.getIndexOf(categoryItemRenderer31);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier33 = categoryPlot25.getDrawingSupplier();
        boolean boolean34 = legendItem19.equals((java.lang.Object) categoryPlot25);
        java.awt.Paint paint35 = legendItem19.getLinePaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(drawingSupplier33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        legendGraphic4.setHeight(0.0d);
        java.awt.Shape shape13 = legendGraphic4.getShape();
        legendGraphic4.setID("ChartChangeEventType.GENERAL");
        java.awt.Color color16 = java.awt.Color.WHITE;
        legendGraphic4.setFillPaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.TOP;
        legendGraphic4.setShapeLocation(rectangleAnchor18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder();
        legendGraphic4.setFrame((org.jfree.chart.block.BlockFrame) blockBorder20);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Range[-1.6727872E7,-1.6727872E7]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot4.setDomainAxis((int) (byte) 1, categoryAxis18);
        java.awt.Stroke stroke20 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = categoryPlot4.getDrawingSupplier();
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(drawingSupplier21);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 1L, (double) (short) 1);
        size2D2.setHeight(0.0d);
        double double5 = size2D2.width;
        size2D2.width = 10.0d;
        size2D2.setWidth((double) (short) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean11 = size2D2.equals((java.lang.Object) rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.Block block1 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.lang.String str3 = textAnchor2.toString();
        try {
            borderArrangement0.add(block1, (java.lang.Object) textAnchor2);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.text.TextAnchor cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str3.equals("TextAnchor.HALF_ASCENT_RIGHT"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        axisSpace0.setRight(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        axisSpace0.ensureAtLeast(0.2d, rectangleEdge5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        boolean boolean6 = categoryPlot4.getDrawSharedDomainAxis();
        categoryPlot4.setForegroundAlpha((float) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot4.getDomainAxis((int) 'a');
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryAxis10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getBase();
        statisticalBarRenderer0.removeAnnotations();
        java.awt.Font font3 = statisticalBarRenderer0.getBaseItemLabelFont();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color17 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color17);
        legendGraphic13.setShape(shape16);
        java.awt.Color color20 = java.awt.Color.lightGray;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color22 = java.awt.Color.MAGENTA;
        int int23 = color22.getRed();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape16, (java.awt.Paint) color20, stroke21, (java.awt.Paint) color22);
        java.awt.Paint paint25 = legendItem24.getOutlinePaint();
        java.lang.String str26 = legendItem24.getURLText();
        java.awt.Paint paint27 = legendItem24.getOutlinePaint();
        statisticalBarRenderer0.setSeriesItemLabelPaint(192, paint27, true);
        double double30 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 255 + "'", int23 == 255);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "VerticalAlignment.CENTER" + "'", str26.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets8.calculateRightInset((double) 2);
        categoryPlot4.setInsets(rectangleInsets8, true);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer15.setSeriesFillPaint(0, (java.awt.Paint) color17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer15.getBasePositiveItemLabelPosition();
        categoryPlot4.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = null;
        statisticalBarRenderer15.setGradientPaintTransformer(gradientPaintTransformer22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        boolean boolean30 = categoryPlot29.getDrawSharedDomainAxis();
        java.awt.Stroke stroke31 = categoryPlot29.getOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis36, categoryItemRenderer37);
        java.awt.Paint paint39 = categoryPlot38.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot38);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = legendTitle40.getItemLabelPadding();
        double double43 = rectangleInsets41.trimWidth((double) 0L);
        boolean boolean44 = numberAxis33.equals((java.lang.Object) double43);
        boolean boolean45 = numberAxis33.isPositiveArrowVisible();
        double double46 = numberAxis33.getLowerBound();
        java.awt.Paint paint48 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer49 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color51 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer49.setSeriesFillPaint(0, (java.awt.Paint) color51);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator54 = null;
        statisticalBarRenderer49.setSeriesURLGenerator(255, categoryURLGenerator54);
        statisticalBarRenderer49.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer49.setErrorIndicatorStroke(stroke59);
        org.jfree.chart.plot.ValueMarker valueMarker61 = new org.jfree.chart.plot.ValueMarker((double) 2, paint48, stroke59);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = valueMarker61.getLabelOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = valueMarker61.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        statisticalBarRenderer15.drawRangeMarker(graphics2D24, categoryPlot29, (org.jfree.chart.axis.ValueAxis) numberAxis33, (org.jfree.chart.plot.Marker) valueMarker61, rectangle2D64);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-4.0d) + "'", double43 == (-4.0d));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(rectangleInsets63);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        keyedObjects0.addObject((java.lang.Comparable) (byte) 0, (java.lang.Object) font2);
        int int4 = keyedObjects0.getItemCount();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.data.RangeType rangeType4 = numberAxis1.getRangeType();
        java.awt.Shape shape5 = numberAxis1.getUpArrow();
        numberAxis1.setAutoRangeIncludesZero(true);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = legendTitle8.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = categoryLabelPositions1.getLabelPosition(rectangleEdge9);
        float float11 = categoryLabelPosition10.getWidthRatio();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = categoryLabelPosition10.getLabelAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(categoryLabelPosition10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) (byte) 100, (int) 'a');
        java.awt.Stroke stroke7 = statisticalBarRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorDown(10.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        java.awt.Paint paint11 = categoryPlot10.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = legendTitle12.getLegendItemGraphicEdge();
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge13);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = categoryLabelPositions5.getLabelPosition(rectangleEdge13);
        axisState0.moveCursor((double) '#', rectangleEdge13);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition15);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Color color15 = java.awt.Color.lightGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        int int18 = color17.getRed();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape11, (java.awt.Paint) color15, stroke16, (java.awt.Paint) color17);
        java.awt.Stroke stroke20 = legendItem19.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = categoryPlot25.getRangeMarkers(layer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        int int32 = categoryPlot25.getIndexOf(categoryItemRenderer31);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier33 = categoryPlot25.getDrawingSupplier();
        boolean boolean34 = legendItem19.equals((java.lang.Object) categoryPlot25);
        legendItem19.setSeriesKey((java.lang.Comparable) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder37 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean38 = legendItem19.equals((java.lang.Object) blockBorder37);
        java.awt.Paint paint39 = legendItem19.getOutlinePaint();
        java.lang.String str40 = legendItem19.getURLText();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(drawingSupplier33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(blockBorder37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "VerticalAlignment.CENTER" + "'", str40.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer2.setSeriesFillPaint(0, (java.awt.Paint) color4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        statisticalBarRenderer2.setSeriesURLGenerator(255, categoryURLGenerator7);
        statisticalBarRenderer2.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer2.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color14);
        int int16 = statisticalBarRenderer2.getColumnCount();
        keyedObjects0.setObject(comparable1, (java.lang.Object) int16);
        java.lang.Object obj19 = keyedObjects0.getObject((int) (byte) -1);
        int int20 = keyedObjects0.getItemCount();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateLeftInset((double) (-4145152));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setURLText("VerticalAlignment.CENTER");
        boolean boolean4 = textTitle1.getNotify();
        java.awt.Color color5 = java.awt.Color.GRAY;
        textTitle1.setPaint((java.awt.Paint) color5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        java.awt.Stroke stroke12 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color13 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape12, (java.awt.Paint) color13);
        legendGraphic9.setShape(shape12);
        java.awt.Color color16 = java.awt.Color.lightGray;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color18 = java.awt.Color.MAGENTA;
        int int19 = color18.getRed();
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape12, (java.awt.Paint) color16, stroke17, (java.awt.Paint) color18);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape12);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape12, (double) (-1L), 10.0f, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color13 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape12, (java.awt.Paint) color13);
        legendGraphic9.setShape(shape12);
        java.awt.Color color16 = java.awt.Color.lightGray;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color18 = java.awt.Color.MAGENTA;
        int int19 = color18.getRed();
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape12, (java.awt.Paint) color16, stroke17, (java.awt.Paint) color18);
        java.lang.String str21 = legendItem20.getLabel();
        java.awt.Shape shape22 = legendItem20.getLine();
        boolean boolean23 = legendItemCollection0.equals((java.lang.Object) shape22);
        int int24 = legendItemCollection0.getItemCount();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color16 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape11, stroke15, (java.awt.Paint) color16);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, (double) (short) 1, (float) 100L, (float) 128);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity22 = new org.jfree.chart.entity.LegendItemEntity(shape21);
        java.lang.Comparable comparable23 = legendItemEntity22.getSeriesKey();
        org.jfree.data.general.Dataset dataset24 = legendItemEntity22.getDataset();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(comparable23);
        org.junit.Assert.assertNull(dataset24);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(false);
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "Layer.BACKGROUND", font4);
        float float6 = categoryAxis0.getTickMarkOutsideLength();
        categoryAxis0.setLabelURL("CategoryLabelWidthType.CATEGORY");
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 0.0f);
        keyedObjects2D0.removeColumn((java.lang.Comparable) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        boolean boolean3 = jFreeChartResources0.containsKey("");
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Class<?> wildcardClass6 = textAnchor5.getClass();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("PlotOrientation.HORIZONTAL", graphics2D1, (float) (byte) -1, (float) (short) 100, textAnchor5, (double) 100.0f, (float) 255, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setAxisLineVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        try {
            axisCollection0.add((org.jfree.chart.axis.Axis) categoryAxis2, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE10" + "'", str1.equals("ItemLabelAnchor.INSIDE10"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setBaseSeriesVisible(true, false);
        statisticalBarRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, false);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        double double17 = categoryAxis16.getLabelAngle();
        double double18 = categoryAxis16.getCategoryMargin();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = categoryPlot25.getRangeMarkers(layer29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        statisticalBarRenderer0.drawAnnotations(graphics2D14, rectangle2D15, categoryAxis16, valueAxis20, layer29, plotRenderingInfo31);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = statisticalBarRenderer0.getSeriesNegativeItemLabelPosition((int) (byte) 1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        double double31 = rectangleInsets29.calculateRightInset((double) 2);
        categoryPlot25.setInsets(rectangleInsets29, true);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets29.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets29);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot4.setRenderer(categoryItemRenderer37, false);
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setDomainAxisLocation(axisLocation40);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder42 = categoryPlot4.getDatasetRenderingOrder();
        java.lang.Object obj43 = null;
        boolean boolean44 = datasetRenderingOrder42.equals(obj43);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer45 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double46 = statisticalBarRenderer45.getBase();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator48 = null;
        statisticalBarRenderer45.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator48);
        java.awt.Shape shape57 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color58 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic59 = new org.jfree.chart.title.LegendGraphic(shape57, (java.awt.Paint) color58);
        java.awt.Shape shape62 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color63 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic64 = new org.jfree.chart.title.LegendGraphic(shape62, (java.awt.Paint) color63);
        legendGraphic59.setShape(shape62);
        java.awt.Stroke stroke66 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color67 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape62, stroke66, (java.awt.Paint) color67);
        statisticalBarRenderer45.setSeriesFillPaint(1, (java.awt.Paint) color67, true);
        java.awt.Stroke stroke71 = statisticalBarRenderer45.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer72 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color74 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer72.setSeriesFillPaint(0, (java.awt.Paint) color74);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator77 = null;
        statisticalBarRenderer72.setSeriesURLGenerator(255, categoryURLGenerator77);
        statisticalBarRenderer72.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke84 = statisticalBarRenderer72.getItemStroke(255, (int) 'a');
        statisticalBarRenderer72.setAutoPopulateSeriesPaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition89 = statisticalBarRenderer72.getPositiveItemLabelPosition((int) ' ', (int) (byte) -1);
        statisticalBarRenderer45.setBasePositiveItemLabelPosition(itemLabelPosition89, true);
        boolean boolean92 = datasetRenderingOrder42.equals((java.lang.Object) statisticalBarRenderer45);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(datasetRenderingOrder42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(stroke84);
        org.junit.Assert.assertNotNull(itemLabelPosition89);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        double double4 = range3.getLength();
        double double5 = range3.getUpperBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range0, range3);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.6727872E7d) + "'", double5 == (-1.6727872E7d));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        objectList1.clear();
        int int3 = objectList1.size();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        double double5 = categoryAxis4.getLabelAngle();
        double double6 = categoryAxis4.getCategoryMargin();
        java.lang.String str7 = categoryAxis4.getLabelToolTip();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis4.setAxisLinePaint((java.awt.Paint) color8);
        int int10 = objectList1.indexOf((java.lang.Object) categoryAxis4);
        java.awt.Stroke stroke11 = categoryAxis4.getAxisLineStroke();
        categoryAxis4.setTickLabelsVisible(false);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = categoryAxis4.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = categoryLabelPositions16.getLabelPosition(rectangleEdge17);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        java.awt.Paint paint26 = categoryPlot25.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = legendTitle27.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition29 = categoryLabelPositions20.getLabelPosition(rectangleEdge28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = categoryLabelPosition29.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType31 = categoryLabelPosition29.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = categoryLabelPosition29.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions33 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions16, categoryLabelPosition29);
        float float34 = categoryLabelPosition29.getWidthRatio();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions35 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions14, categoryLabelPosition29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryLabelPositions14);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNull(categoryLabelPosition18);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(categoryLabelPosition29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(categoryLabelWidthType31);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(categoryLabelPositions33);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.5f + "'", float34 == 0.5f);
        org.junit.Assert.assertNotNull(categoryLabelPositions35);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 0L, (float) (short) 10, (float) (byte) 0);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        double double4 = range3.getLength();
        boolean boolean6 = range3.contains((double) 1L);
        double double7 = range3.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 2, range3);
        boolean boolean10 = range3.contains(0.2d);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setAnchorValue(0.0d, true);
        java.awt.Font font10 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("hi!", font10);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.GENERAL", font10);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent13 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryAxis14.setAxisLinePaint((java.awt.Paint) color15);
        int int17 = color15.getBlue();
        textTitle12.setBackgroundPaint((java.awt.Paint) color15);
        java.awt.Font font19 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        textTitle12.setFont(font19);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 192 + "'", int17 == 192);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getLegendItemGraphicEdge();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (short) 100, range10);
        org.jfree.chart.util.Size2D size2D12 = legendTitle6.arrange(graphics2D8, rectangleConstraint11);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer();
        legendTitle6.setWrapper(blockContainer13);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle6);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(size2D12);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 3.0d);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean4 = keyedObjects2D0.equals((java.lang.Object) chartChangeEventType3);
        org.jfree.chart.block.BlockBorder blockBorder5 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean6 = keyedObjects2D0.equals((java.lang.Object) blockBorder5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot11.setDomainAxis(categoryAxis12);
        java.awt.Paint paint14 = categoryPlot11.getRangeGridlinePaint();
        boolean boolean15 = categoryPlot11.isRangeZoomable();
        categoryPlot11.setRangeCrosshairValue((double) (byte) 10, false);
        int int19 = categoryPlot11.getBackgroundImageAlignment();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color27 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic28 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color27);
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color32 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape31, (java.awt.Paint) color32);
        legendGraphic28.setShape(shape31);
        java.awt.Color color35 = java.awt.Color.lightGray;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color37 = java.awt.Color.MAGENTA;
        int int38 = color37.getRed();
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape31, (java.awt.Paint) color35, stroke36, (java.awt.Paint) color37);
        java.awt.Stroke stroke40 = legendItem39.getLineStroke();
        categoryPlot11.setOutlineStroke(stroke40);
        boolean boolean42 = blockBorder5.equals((java.lang.Object) stroke40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(blockBorder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 255 + "'", int38 == 255);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot8);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int12 = defaultStatisticalCategoryDataset0.getRowCount();
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 0.0d);
        double double16 = defaultStatisticalCategoryDataset0.getRangeLowerBound(true);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertEquals((double) number11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("AxisLocation.BOTTOM_OR_RIGHT", "{0}", "", image3, "ThreadContext", "", "Layer.BACKGROUND");
        java.lang.String str8 = projectInfo7.getLicenceName();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        java.awt.Stroke stroke14 = legendGraphic13.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendGraphic13.getShapeLocation();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, rectangleAnchor15, (double) (short) 10, (double) 0L);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.lang.String str20 = color19.toString();
        try {
            org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem(attributedString0, "TextBlockAnchor.BOTTOM_CENTER", "AxisLabelEntity: label = null", "Category Plot", shape6, (java.awt.Paint) color19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=0,g=0,b=192]" + "'", str20.equals("java.awt.Color[r=0,g=0,b=192]"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setAutoRangeStickyZero(false);
        boolean boolean4 = numberAxis1.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.Color color1 = java.awt.Color.green;
        float[] floatArray8 = new float[] { 0L, 10, (-8323073), 'a', (byte) 10, 0.0f };
        float[] floatArray9 = color1.getRGBComponents(floatArray8);
        float[] floatArray10 = color0.getColorComponents(floatArray9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("AxisLocation.BOTTOM_OR_RIGHT version {0}.\nThreadContext.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY AxisLocation.BOTTOM_OR_RIGHT:None\nAxisLocation.BOTTOM_OR_RIGHT LICENCE TERMS:\nLayer.BACKGROUND", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color16 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape11, stroke15, (java.awt.Paint) color16);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, (double) (short) 1, (float) 100L, (float) 128);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity22 = new org.jfree.chart.entity.LegendItemEntity(shape21);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape21);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator24 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator25 = null;
        java.lang.String str26 = chartEntity23.getImageMapAreaTag(toolTipTagFragmentGenerator24, uRLTagFragmentGenerator25);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getItemLabelPadding();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        legendTitle6.setWrapper(blockContainer8);
        org.jfree.chart.block.Arrangement arrangement10 = blockContainer8.getArrangement();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(arrangement10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.lightGray;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color2);
        java.util.List list4 = textBlock3.getLines();
        org.jfree.chart.text.TextLine textLine5 = textBlock3.getLastLine();
        java.awt.Graphics2D graphics2D6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = textLine5.calculateDimensions(graphics2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(textLine5);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        categoryPlot4.clearAnnotations();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer7.setSeriesFillPaint(0, (java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = statisticalBarRenderer7.getBasePositiveItemLabelPosition();
        java.awt.Paint paint14 = statisticalBarRenderer7.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke17 = statisticalBarRenderer7.getItemStroke((int) 'a', (int) (byte) 10);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer7, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = statisticalBarRenderer7.getSeriesNegativeItemLabelPosition(2);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color23 = color22.darker();
        statisticalBarRenderer7.setBaseItemLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = null;
        try {
            statisticalBarRenderer7.setSeriesURLGenerator((-8323073), categoryURLGenerator26, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.lang.Object obj0 = null;
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot7.setDomainAxis(categoryAxis8);
        categoryPlot7.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot7.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        categoryPlot7.setDomainAxisLocation((int) (short) 10, axisLocation14);
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font2, (org.jfree.chart.plot.Plot) categoryPlot7, true);
        jFreeChart19.setTitle("Layer.BACKGROUND");
        int int22 = jFreeChart19.getSubtitleCount();
        float float23 = jFreeChart19.getBackgroundImageAlpha();
        java.lang.Object obj24 = jFreeChart19.getTextAntiAlias();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str26 = chartChangeEventType25.toString();
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart19, chartChangeEventType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNotNull(chartChangeEventType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str26.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getBase();
        statisticalBarRenderer0.removeAnnotations();
        java.awt.Color color4 = java.awt.Color.RED;
        statisticalBarRenderer0.setSeriesFillPaint((int) 'a', (java.awt.Paint) color4, true);
        java.lang.Boolean boolean8 = statisticalBarRenderer0.getSeriesItemLabelsVisible((int) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Paint paint6 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = legendTitle7.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment9, (double) (-1.0f), Double.NaN);
        org.jfree.chart.block.BlockContainer blockContainer13 = null;
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((double) 255, (double) 10);
        try {
            org.jfree.chart.util.Size2D size2D18 = flowArrangement12.arrange(blockContainer13, graphics2D14, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(verticalAlignment9);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        categoryPlot4.clearAnnotations();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer7.setSeriesFillPaint(0, (java.awt.Paint) color9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = statisticalBarRenderer7.getBasePositiveItemLabelPosition();
        java.awt.Paint paint14 = statisticalBarRenderer7.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke17 = statisticalBarRenderer7.getItemStroke((int) 'a', (int) (byte) 10);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer7, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = statisticalBarRenderer7.getSeriesNegativeItemLabelPosition(2);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        statisticalBarRenderer7.setSeriesToolTipGenerator(10, categoryToolTipGenerator23);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer25.setSeriesFillPaint(0, (java.awt.Paint) color27);
        java.awt.Color color29 = color27.brighter();
        statisticalBarRenderer7.setBaseFillPaint((java.awt.Paint) color29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        statisticalBarRenderer7.setSeriesOutlinePaint((int) (byte) 1, (java.awt.Paint) color32);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        objectList1.clear();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        int int4 = objectList1.indexOf((java.lang.Object) chartChangeEventType3);
        java.lang.Object obj5 = null;
        boolean boolean6 = objectList1.equals(obj5);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        categoryPlot11.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double17 = rectangleInsets15.calculateRightInset((double) 2);
        categoryPlot11.setInsets(rectangleInsets15, true);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets15.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets15);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        categoryPlot26.setDomainAxis(categoryAxis27);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection31 = categoryPlot26.getRangeMarkers(0, layer30);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray32 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot26.setDomainAxes(categoryAxisArray32);
        java.awt.Paint paint35 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer36.setSeriesFillPaint(0, (java.awt.Paint) color38);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        statisticalBarRenderer36.setSeriesURLGenerator(255, categoryURLGenerator41);
        statisticalBarRenderer36.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer36.setErrorIndicatorStroke(stroke46);
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker((double) 2, paint35, stroke46);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = valueMarker48.getLabelOffset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer50 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color52 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer50.setSeriesFillPaint(0, (java.awt.Paint) color52);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator55 = null;
        statisticalBarRenderer50.setSeriesURLGenerator(255, categoryURLGenerator55);
        statisticalBarRenderer50.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer50.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color62);
        int int64 = statisticalBarRenderer50.getColumnCount();
        java.awt.Stroke stroke67 = statisticalBarRenderer50.getItemOutlineStroke(10, (int) '#');
        org.jfree.data.category.CategoryDataset categoryDataset68 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = null;
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset68, categoryAxis69, valueAxis70, categoryItemRenderer71);
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = null;
        categoryPlot72.setDomainAxis(categoryAxis73);
        java.lang.Comparable[] comparableArray75 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray76 = new java.lang.Comparable[] {};
        double[][] doubleArray77 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset78 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray75, comparableArray76, doubleArray77);
        org.jfree.data.general.PieDataset pieDataset80 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset78, (int) (short) 100);
        org.jfree.data.Range range82 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset78, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer83 = categoryPlot72.getRendererForDataset(categoryDataset78);
        java.awt.Paint paint84 = categoryPlot72.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis86 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot72.setDomainAxis((int) (byte) 1, categoryAxis86);
        java.awt.Stroke stroke88 = categoryPlot72.getRangeGridlineStroke();
        statisticalBarRenderer50.setBaseOutlineStroke(stroke88, true);
        valueMarker48.setOutlineStroke(stroke88);
        categoryPlot26.setOutlineStroke(stroke88);
        categoryPlot4.setRangeGridlineStroke(stroke88);
        java.awt.Stroke stroke94 = categoryPlot4.getRangeCrosshairStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation95 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str96 = plotOrientation95.toString();
        categoryPlot4.setOrientation(plotOrientation95);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(categoryAxisArray32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(comparableArray75);
        org.junit.Assert.assertNotNull(comparableArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(categoryDataset78);
        org.junit.Assert.assertNotNull(pieDataset80);
        org.junit.Assert.assertNull(range82);
        org.junit.Assert.assertNull(categoryItemRenderer83);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertNotNull(stroke88);
        org.junit.Assert.assertNotNull(stroke94);
        org.junit.Assert.assertNotNull(plotOrientation95);
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str96.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer0.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color12);
        int int14 = statisticalBarRenderer0.getColumnCount();
        java.awt.Stroke stroke17 = statisticalBarRenderer0.getItemOutlineStroke(10, (int) '#');
        int int18 = statisticalBarRenderer0.getColumnCount();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        categoryPlot24.setAnchorValue(0.0d, true);
        org.jfree.chart.axis.AxisSpace axisSpace28 = categoryPlot24.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double30 = statisticalBarRenderer29.getBase();
        categoryPlot24.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer29);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot24.getRangeAxis();
        java.lang.String str33 = categoryPlot24.getNoDataMessage();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis36, categoryItemRenderer37);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        categoryPlot38.setDomainAxis(categoryAxis39);
        java.lang.Comparable[] comparableArray41 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray42 = new java.lang.Comparable[] {};
        double[][] doubleArray43 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray41, comparableArray42, doubleArray43);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset44, (int) (short) 100);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset44, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot38.getRendererForDataset(categoryDataset44);
        java.awt.Paint paint50 = categoryPlot38.getNoDataMessagePaint();
        categoryPlot38.setBackgroundImageAlpha(0.0f);
        categoryPlot38.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis56, valueAxis57, categoryItemRenderer58);
        categoryPlot59.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets();
        double double65 = rectangleInsets63.calculateRightInset((double) 2);
        categoryPlot59.setInsets(rectangleInsets63, true);
        org.jfree.chart.util.UnitType unitType68 = rectangleInsets63.getUnitType();
        categoryPlot38.setAxisOffset(rectangleInsets63);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = categoryPlot38.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = null;
        categoryPlot38.setRenderer(categoryItemRenderer71, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor74 = categoryPlot38.getDomainGridlinePosition();
        java.lang.String str75 = categoryAnchor74.toString();
        categoryPlot24.setDomainGridlinePosition(categoryAnchor74);
        org.jfree.chart.axis.CategoryAxis categoryAxis77 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis77.setAxisLineVisible(true);
        categoryAxis77.setLabelAngle((double) (-123));
        categoryAxis77.setCategoryMargin((double) 1.0f);
        float float84 = categoryAxis77.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryMarker categoryMarker85 = null;
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        try {
            statisticalBarRenderer0.drawDomainMarker(graphics2D19, categoryPlot24, categoryAxis77, categoryMarker85, rectangle2D86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(axisSpace28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(comparableArray41);
        org.junit.Assert.assertNotNull(comparableArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertNotNull(unitType68);
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertNotNull(categoryAnchor74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str75.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + float84 + "' != '" + 2.0f + "'", float84 == 2.0f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj3 = objectList1.get(255);
        java.lang.Object obj5 = objectList1.get((int) '4');
        int int6 = objectList1.size();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextOutlinePaint();
        java.awt.Paint paint4 = defaultDrawingSupplier2.getNextPaint();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer7 = new org.jfree.chart.text.G2TextMeasurer(graphics2D6);
        try {
            org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryAnchor.MIDDLE", font1, paint4, (float) (-1L), (org.jfree.chart.text.TextMeasurer) g2TextMeasurer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.data.RangeType rangeType4 = numberAxis1.getRangeType();
        java.awt.Shape shape5 = numberAxis1.getUpArrow();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis1.setMarkerBand(markerAxisBand6);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot6.setDomainAxis(categoryAxis7);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot6.setDomainAxisLocation((int) (short) 10, axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        jFreeChart18.setTitle("Layer.BACKGROUND");
        jFreeChart18.setBackgroundImageAlignment((int) (byte) 10);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        try {
            jFreeChart18.draw(graphics2D23, rectangle2D24, chartRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot4.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        categoryPlot13.setAnchorValue(0.0d, true);
        categoryPlot13.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot13.getRangeAxisLocation(255);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = null;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D23, rectangleAnchor24);
        categoryPlot13.zoomRangeAxes((double) 'a', (double) 'a', plotRenderingInfo22, point2D25);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset27 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range28 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset27);
        int int30 = defaultStatisticalCategoryDataset27.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        java.awt.Paint paint36 = categoryPlot35.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset27.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot35);
        org.jfree.data.general.PieDataset pieDataset39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset27, (int) (byte) 10);
        categoryPlot13.setDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset27);
        try {
            org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryDataset8, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(pieDataset39);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState();
        axisState1.cursorLeft((double) 10L);
        axisState1.cursorDown(0.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        java.awt.Paint paint14 = categoryPlot13.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle15.getLegendItemGraphicEdge();
        boolean boolean17 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge16);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = categoryLabelPositions8.getLabelPosition(rectangleEdge16);
        axisState1.moveCursor((double) 255, rectangleEdge16);
        try {
            double double20 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition18);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) (byte) 100);
        double double3 = blockParams0.getTranslateY();
        double double4 = blockParams0.getTranslateX();
        double double5 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color16 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape11, stroke15, (java.awt.Paint) color16);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, (double) (short) 1, (float) 100L, (float) 128);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity22 = new org.jfree.chart.entity.LegendItemEntity(shape21);
        legendItemEntity22.setSeriesKey((java.lang.Comparable) (-1.0d));
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        categoryPlot9.setAnchorValue(0.0d, true);
        java.awt.Image image13 = categoryPlot9.getBackgroundImage();
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation15 = axisLocation14.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation16 = axisLocation14.getOpposite();
        categoryPlot9.setDomainAxisLocation(axisLocation14, false);
        categoryPlot4.setRangeAxisLocation(axisLocation14);
        org.junit.Assert.assertNull(image13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        categoryPlot5.setAnchorValue(0.0d, true);
        java.awt.Font font9 = categoryPlot5.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!", font9);
        java.lang.String str11 = labelBlock10.getToolTipText();
        java.awt.Paint paint12 = labelBlock10.getPaint();
        labelBlock10.setHeight(0.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) 10L);
        axisState0.cursorDown(0.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        java.awt.Paint paint13 = categoryPlot12.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle14.getLegendItemGraphicEdge();
        boolean boolean16 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge15);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = categoryLabelPositions7.getLabelPosition(rectangleEdge15);
        axisState0.moveCursor((double) 255, rectangleEdge15);
        axisState0.cursorLeft((double) (-16727872));
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition17);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        int int2 = numberTickUnit1.getMinorTickCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Paint paint1 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer2.setSeriesFillPaint(0, (java.awt.Paint) color4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        statisticalBarRenderer2.setSeriesURLGenerator(255, categoryURLGenerator7);
        statisticalBarRenderer2.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer2.setErrorIndicatorStroke(stroke12);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 2, paint1, stroke12);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot19.setDomainAxis(categoryAxis20);
        java.awt.Paint paint22 = categoryPlot19.getRangeGridlinePaint();
        boolean boolean23 = categoryPlot19.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        double double26 = categoryAxis25.getLabelAngle();
        double double27 = categoryAxis25.getCategoryMargin();
        java.lang.String str28 = categoryAxis25.getLabelToolTip();
        categoryAxis25.setVisible(false);
        categoryPlot19.setDomainAxis((int) (short) 100, categoryAxis25);
        valueMarker14.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot19);
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Class<?> wildcardClass34 = textAnchor33.getClass();
        org.jfree.chart.ui.Contributor contributor37 = new org.jfree.chart.ui.Contributor("VerticalAlignment.CENTER", "Layer.BACKGROUND");
        boolean boolean38 = textAnchor33.equals((java.lang.Object) "Layer.BACKGROUND");
        valueMarker14.setLabelTextAnchor(textAnchor33);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("Size2D[width=255.0, height=10.0]", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets8.calculateRightInset((double) 2);
        categoryPlot4.setInsets(rectangleInsets8, true);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer15.setSeriesFillPaint(0, (java.awt.Paint) color17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer15.getBasePositiveItemLabelPosition();
        categoryPlot4.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = null;
        statisticalBarRenderer15.setGradientPaintTransformer(gradientPaintTransformer22);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = null;
        try {
            statisticalBarRenderer15.setBasePositiveItemLabelPosition(itemLabelPosition24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100.0f, (java.lang.Object) color1);
        java.lang.Object obj3 = keyedObject2.getObject();
        java.lang.Object obj4 = keyedObject2.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        double double4 = range3.getLength();
        boolean boolean6 = range3.contains((double) 1L);
        double double7 = range3.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 2, range3);
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) (-16727872));
        double double12 = range11.getLength();
        boolean boolean14 = range11.contains((double) 1L);
        double double15 = range11.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint8.toRangeWidth(range11);
        org.jfree.data.Range range17 = rectangleConstraint8.getHeightRange();
        org.jfree.data.Range range19 = null;
        org.jfree.data.Range range21 = org.jfree.data.Range.expandToInclude(range19, (double) (-16727872));
        double double22 = range21.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType23 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range25 = null;
        org.jfree.data.Range range27 = org.jfree.data.Range.expandToInclude(range25, (double) (-16727872));
        double double28 = range27.getLength();
        org.jfree.data.Range range30 = org.jfree.data.Range.expandToInclude(range27, (double) 100L);
        double double32 = range30.constrain((double) (-1));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint((double) 128, range21, lengthConstraintType23, 255.0d, range30, lengthConstraintType33);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = rectangleConstraint8.toRangeWidth(range30);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType36 = rectangleConstraint35.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((double) 255, (double) 10);
        org.jfree.chart.util.Size2D size2D42 = new org.jfree.chart.util.Size2D((double) 1L, (double) (short) 1);
        org.jfree.chart.util.Size2D size2D43 = rectangleConstraint39.calculateConstrainedSize(size2D42);
        double double44 = size2D43.width;
        org.jfree.chart.util.Size2D size2D45 = rectangleConstraint35.calculateConstrainedSize(size2D43);
        double double46 = size2D43.height;
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType23);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32 == (-1.0d));
        org.junit.Assert.assertNotNull(lengthConstraintType33);
        org.junit.Assert.assertNotNull(rectangleConstraint35);
        org.junit.Assert.assertNotNull(lengthConstraintType36);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 255.0d + "'", double44 == 255.0d);
        org.junit.Assert.assertNotNull(size2D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 10.0d + "'", double46 == 10.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = legendGraphic4.getOutlinePaint();
        java.lang.Object obj6 = legendGraphic4.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (short) 0, (java.lang.Number) 3.0d, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) 1L);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 0);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(pieDataset10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.awt.Paint paint1 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer2.setSeriesFillPaint(0, (java.awt.Paint) color4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        statisticalBarRenderer2.setSeriesURLGenerator(255, categoryURLGenerator7);
        statisticalBarRenderer2.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer2.setErrorIndicatorStroke(stroke12);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 2, paint1, stroke12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = valueMarker14.getLabelOffset();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer16.setSeriesFillPaint(0, (java.awt.Paint) color18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = null;
        statisticalBarRenderer16.setSeriesURLGenerator(255, categoryURLGenerator21);
        statisticalBarRenderer16.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer16.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color28);
        int int30 = statisticalBarRenderer16.getColumnCount();
        java.awt.Stroke stroke33 = statisticalBarRenderer16.getItemOutlineStroke(10, (int) '#');
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis36, categoryItemRenderer37);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        categoryPlot38.setDomainAxis(categoryAxis39);
        java.lang.Comparable[] comparableArray41 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray42 = new java.lang.Comparable[] {};
        double[][] doubleArray43 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset44 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray41, comparableArray42, doubleArray43);
        org.jfree.data.general.PieDataset pieDataset46 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset44, (int) (short) 100);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset44, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot38.getRendererForDataset(categoryDataset44);
        java.awt.Paint paint50 = categoryPlot38.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot38.setDomainAxis((int) (byte) 1, categoryAxis52);
        java.awt.Stroke stroke54 = categoryPlot38.getRangeGridlineStroke();
        statisticalBarRenderer16.setBaseOutlineStroke(stroke54, true);
        valueMarker14.setOutlineStroke(stroke54);
        valueMarker14.setValue((double) (-4145152));
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(comparableArray41);
        org.junit.Assert.assertNotNull(comparableArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(categoryDataset44);
        org.junit.Assert.assertNotNull(pieDataset46);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.lang.String str2 = textTitle1.getText();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle1.getPosition();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setCategoryLabelPositionOffset(255);
        java.lang.String str6 = categoryAxis0.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(Double.NaN, (double) 1, 0.0d, (double) 0.0f);
        categoryAxis0.setTickLabelInsets(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        categoryPlot11.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double17 = rectangleInsets15.calculateRightInset((double) 2);
        categoryPlot11.setInsets(rectangleInsets15, true);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets15.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets15);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot4.getRangeAxisForDataset(128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertNull(valueAxis24);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.awt.Paint paint1 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer2.setSeriesFillPaint(0, (java.awt.Paint) color4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        statisticalBarRenderer2.setSeriesURLGenerator(255, categoryURLGenerator7);
        statisticalBarRenderer2.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer2.setErrorIndicatorStroke(stroke12);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 2, paint1, stroke12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = valueMarker14.getLabelOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setAxisLineVisible(true);
        categoryAxis16.setLabelAngle((double) (-123));
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryAxis16.setTickLabelPaint(paint21);
        valueMarker14.setPaint(paint21);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer0.setSeriesVisible(0, (java.lang.Boolean) true, true);
        boolean boolean8 = barRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(itemLabelPosition11);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        double double2 = numberAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color4);
        categoryAxis0.setFixedDimension((double) 10L);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot12.setDomainAxis(categoryAxis13);
        java.lang.Comparable[] comparableArray15 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray16 = new java.lang.Comparable[] {};
        double[][] doubleArray17 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray15, comparableArray16, doubleArray17);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset18, (int) (short) 100);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset18, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot12.getRendererForDataset(categoryDataset18);
        java.awt.Paint paint24 = categoryPlot12.getNoDataMessagePaint();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean29 = barRenderer26.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer26.setSeriesVisible(0, (java.lang.Boolean) true, true);
        categoryPlot12.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer26);
        java.awt.Font font35 = barRenderer26.getBaseItemLabelFont();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(comparableArray15);
        org.junit.Assert.assertNotNull(comparableArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(categoryItemRenderer23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        double double4 = range3.getLength();
        boolean boolean6 = range3.contains((double) 1L);
        double double7 = range3.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 2, range3);
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) (-16727872));
        double double12 = range11.getLength();
        boolean boolean14 = range11.contains((double) 1L);
        double double15 = range11.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint8.toRangeWidth(range11);
        double double17 = range11.getLowerBound();
        double double18 = range11.getCentralValue();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.6727872E7d) + "'", double17 == (-1.6727872E7d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.6727872E7d) + "'", double18 == (-1.6727872E7d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        double double4 = range3.getLength();
        boolean boolean6 = range3.contains((double) 1L);
        double double7 = range3.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 2, range3);
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) (-16727872));
        double double12 = range11.getLength();
        boolean boolean14 = range11.contains((double) 1L);
        double double15 = range11.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint8.toRangeWidth(range11);
        org.jfree.data.Range range17 = rectangleConstraint8.getHeightRange();
        org.jfree.data.Range range19 = null;
        org.jfree.data.Range range21 = org.jfree.data.Range.expandToInclude(range19, (double) (-16727872));
        double double22 = range21.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType23 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range25 = null;
        org.jfree.data.Range range27 = org.jfree.data.Range.expandToInclude(range25, (double) (-16727872));
        double double28 = range27.getLength();
        org.jfree.data.Range range30 = org.jfree.data.Range.expandToInclude(range27, (double) 100L);
        double double32 = range30.constrain((double) (-1));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint((double) 128, range21, lengthConstraintType23, 255.0d, range30, lengthConstraintType33);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = rectangleConstraint8.toRangeWidth(range30);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = rectangleConstraint8.toFixedHeight(0.0d);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType23);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32 == (-1.0d));
        org.junit.Assert.assertNotNull(lengthConstraintType33);
        org.junit.Assert.assertNotNull(rectangleConstraint35);
        org.junit.Assert.assertNotNull(rectangleConstraint37);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = legendGraphic4.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendGraphic4.getShapeLocation();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color14 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape13, (java.awt.Paint) color14);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color19 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color19);
        legendGraphic15.setShape(shape18);
        java.awt.Color color22 = java.awt.Color.lightGray;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color24 = java.awt.Color.MAGENTA;
        int int25 = color24.getRed();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape18, (java.awt.Paint) color22, stroke23, (java.awt.Paint) color24);
        legendGraphic4.setFillPaint((java.awt.Paint) color24);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.awt.Font font31 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color32 = java.awt.Color.lightGray;
        org.jfree.chart.text.TextBlock textBlock33 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font31, (java.awt.Paint) color32);
        try {
            java.lang.Object obj34 = legendGraphic4.draw(graphics2D28, rectangle2D29, (java.lang.Object) font31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(textBlock33);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        categoryPlot4.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets();
        double double31 = rectangleInsets29.calculateRightInset((double) 2);
        categoryPlot25.setInsets(rectangleInsets29, true);
        org.jfree.chart.util.UnitType unitType34 = rectangleInsets29.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets29);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot4.setRenderer(categoryItemRenderer37, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor40 = categoryPlot4.getDomainGridlinePosition();
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_CYAN;
        boolean boolean43 = color41.equals((java.lang.Object) 10.0d);
        int int44 = color41.getRGB();
        java.awt.Color color45 = java.awt.Color.lightGray;
        java.awt.Color color46 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color47 = color46.darker();
        java.awt.Color color48 = java.awt.Color.BLUE;
        java.awt.Paint[] paintArray49 = new java.awt.Paint[] { color41, color45, color47, color48 };
        java.awt.Paint[] paintArray50 = null;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke52 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray55 = new java.awt.Stroke[] { stroke51, stroke52, stroke53, stroke54 };
        java.awt.Stroke stroke56 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke57 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke[] strokeArray59 = new java.awt.Stroke[] { stroke56, stroke57, stroke58 };
        java.awt.Shape shape62 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Shape shape65 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color66 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic67 = new org.jfree.chart.title.LegendGraphic(shape65, (java.awt.Paint) color66);
        java.awt.Shape shape70 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color71 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic72 = new org.jfree.chart.title.LegendGraphic(shape70, (java.awt.Paint) color71);
        legendGraphic67.setShape(shape70);
        java.awt.Shape shape76 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Shape shape79 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color80 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic81 = new org.jfree.chart.title.LegendGraphic(shape79, (java.awt.Paint) color80);
        java.awt.Shape shape84 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color85 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic86 = new org.jfree.chart.title.LegendGraphic(shape84, (java.awt.Paint) color85);
        legendGraphic81.setShape(shape84);
        java.awt.Shape shape90 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color91 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic92 = new org.jfree.chart.title.LegendGraphic(shape90, (java.awt.Paint) color91);
        java.awt.Shape shape95 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Shape[] shapeArray96 = new java.awt.Shape[] { shape62, shape70, shape76, shape84, shape90, shape95 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier97 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray49, paintArray50, strokeArray55, strokeArray59, shapeArray96);
        boolean boolean98 = categoryAnchor40.equals((java.lang.Object) strokeArray59);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(unitType34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(categoryAnchor40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-16727872) + "'", int44 == (-16727872));
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(paintArray49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(strokeArray55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(strokeArray59);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(shape70);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNotNull(shape84);
        org.junit.Assert.assertNotNull(color85);
        org.junit.Assert.assertNotNull(shape90);
        org.junit.Assert.assertNotNull(color91);
        org.junit.Assert.assertNotNull(shape95);
        org.junit.Assert.assertNotNull(shapeArray96);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Stroke stroke5 = legendGraphic4.getOutlineStroke();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic(shape8, (java.awt.Paint) color9);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color14 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape13, (java.awt.Paint) color14);
        legendGraphic10.setShape(shape13);
        boolean boolean17 = legendGraphic10.isShapeVisible();
        java.awt.Paint paint18 = legendGraphic10.getOutlinePaint();
        legendGraphic10.setID("AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = legendGraphic10.getFillPaintTransformer();
        legendGraphic4.setFillPaintTransformer(gradientPaintTransformer21);
        java.awt.Paint paint23 = legendGraphic4.getOutlinePaint();
        legendGraphic4.setHeight((double) 0.0f);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(gradientPaintTransformer21);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.lightGray;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, (java.awt.Paint) color3);
        java.util.List list5 = textBlock4.getLines();
        org.jfree.chart.text.TextLine textLine6 = textBlock4.getLastLine();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer8.setSeriesFillPaint(0, (java.awt.Paint) color10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalBarRenderer8.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor13 = itemLabelPosition12.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick15 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) "SortOrder.DESCENDING", textBlock4, textBlockAnchor7, textAnchor13, (double) 0.0f);
        java.lang.Comparable comparable16 = categoryTick15.getCategory();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(textLine6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + "SortOrder.DESCENDING" + "'", comparable16.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Paint paint6 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) (-16727872));
        java.awt.Paint paint10 = legendTitle7.getItemPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.trimWidth((double) 1);
        legendTitle7.setItemLabelPadding(rectangleInsets11);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double17 = rectangleInsets15.trimWidth((double) 1);
        boolean boolean18 = rectangleInsets11.equals((java.lang.Object) rectangleInsets15);
        double double20 = rectangleInsets11.extendWidth(Double.NaN);
        double double22 = rectangleInsets11.extendWidth((double) 10);
        double double24 = rectangleInsets11.calculateTopOutset((double) (byte) 10);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 12.0d + "'", double22 == 12.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(Double.NaN, (double) (byte) 1, 2.0d, (double) 10.0f);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        java.util.List list8 = categoryPlot4.getCategories();
        org.junit.Assert.assertNull(list8);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Layer.FOREGROUND");
        categoryAxis1.setAxisLineVisible(false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) '4');
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Paint paint6 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        boolean boolean9 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge8);
        try {
            double double10 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer0.setBaseCreateEntities(false);
        java.awt.Paint paint8 = barRenderer0.getItemLabelPaint((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryPlot14.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection19 = categoryPlot14.getRangeMarkers(layer18);
        try {
            categoryPlot4.addDomainMarker(0, categoryMarker9, layer18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            blockContainer0.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        double double4 = range3.getLength();
        boolean boolean6 = range3.contains((double) 1L);
        double double7 = range3.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 2, range3);
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) (-16727872));
        double double12 = range11.getLength();
        boolean boolean14 = range11.contains((double) 1L);
        double double15 = range11.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint8.toRangeWidth(range11);
        org.jfree.data.Range range17 = rectangleConstraint8.getHeightRange();
        double double18 = rectangleConstraint8.getWidth();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets8.calculateRightInset((double) 2);
        categoryPlot4.setInsets(rectangleInsets8, true);
        categoryPlot4.clearDomainMarkers();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer15.setSeriesFillPaint(0, (java.awt.Paint) color17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = statisticalBarRenderer15.getPositiveItemLabelPosition((int) (byte) 100, (int) 'a');
        java.awt.Stroke stroke23 = statisticalBarRenderer15.lookupSeriesOutlineStroke((int) (byte) 1);
        categoryPlot4.setRenderer((int) (byte) 100, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (short) 100);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("SortOrder.ASCENDING", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft((double) 10L);
        axisState0.setCursor(10.0d);
        java.util.List list5 = axisState0.getTicks();
        java.util.List list6 = axisState0.getTicks();
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray8 = legendTitle6.getSources();
        boolean boolean9 = legendTitle6.getNotify();
        legendTitle6.setID("Size2D[width=1.0, height=0.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle6.getItemLabelPadding();
        double double14 = rectangleInsets12.calculateBottomInset((double) (byte) 100);
        double double16 = rectangleInsets12.trimWidth((double) 255);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(legendItemSourceArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 251.0d + "'", double16 == 251.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        java.awt.Image image8 = categoryPlot4.getBackgroundImage();
        categoryPlot4.configureDomainAxes();
        categoryPlot4.setRangeCrosshairValue((double) 1, false);
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        float float8 = categoryPlot4.getBackgroundAlpha();
        categoryPlot4.clearDomainMarkers((-1));
        boolean boolean11 = categoryPlot4.isRangeZoomable();
        categoryPlot4.setAnchorValue((double) 255);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setAxisLineVisible(true);
        categoryAxis14.setLabelAngle((double) (-123));
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        boolean boolean20 = categoryAxis14.equals((java.lang.Object) color19);
        categoryPlot4.setDomainAxis(categoryAxis14);
        org.jfree.chart.util.ObjectList objectList23 = new org.jfree.chart.util.ObjectList(0);
        objectList23.clear();
        int int25 = objectList23.size();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        double double27 = categoryAxis26.getLabelAngle();
        double double28 = categoryAxis26.getCategoryMargin();
        java.lang.String str29 = categoryAxis26.getLabelToolTip();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis26.setAxisLinePaint((java.awt.Paint) color30);
        int int32 = objectList23.indexOf((java.lang.Object) categoryAxis26);
        categoryAxis26.setTickLabelsVisible(true);
        categoryAxis26.setTickMarkOutsideLength((float) 1L);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity42 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis26, shape39, "CategoryAnchor.MIDDLE", "{0}");
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, valueAxis45, categoryItemRenderer46);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        categoryPlot47.setDomainAxis(categoryAxis48);
        java.lang.Comparable[] comparableArray50 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray51 = new java.lang.Comparable[] {};
        double[][] doubleArray52 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray50, comparableArray51, doubleArray52);
        org.jfree.data.general.PieDataset pieDataset55 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset53, (int) (short) 100);
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset53, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = categoryPlot47.getRendererForDataset(categoryDataset53);
        java.awt.Paint paint59 = categoryPlot47.getNoDataMessagePaint();
        categoryPlot47.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot62 = categoryPlot47.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray64 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer63 };
        categoryPlot47.setRenderers(categoryItemRendererArray64);
        java.awt.Stroke stroke66 = categoryPlot47.getRangeGridlineStroke();
        categoryAxis26.setAxisLineStroke(stroke66);
        categoryPlot4.setDomainGridlineStroke(stroke66);
        boolean boolean69 = categoryPlot4.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.2d + "'", double28 == 0.2d);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(comparableArray50);
        org.junit.Assert.assertNotNull(comparableArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNotNull(pieDataset55);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertNull(categoryItemRenderer58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNull(plot62);
        org.junit.Assert.assertNotNull(categoryItemRendererArray64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.data.RangeType rangeType4 = numberAxis1.getRangeType();
        java.awt.Shape shape5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list9 = defaultStatisticalCategoryDataset8.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity12 = new org.jfree.chart.entity.CategoryItemEntity(shape5, "", "TextBlockAnchor.BOTTOM_CENTER", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset8, (java.lang.Comparable) "TextBlockAnchor.BOTTOM_CENTER", (java.lang.Comparable) (-123));
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryItemEntity12.getDataset();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color17 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color17);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color22 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic23 = new org.jfree.chart.title.LegendGraphic(shape21, (java.awt.Paint) color22);
        java.awt.Stroke stroke24 = legendGraphic23.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = legendGraphic23.getShapeLocation();
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape16, rectangleAnchor25, (double) (short) 10, (double) 0L);
        java.awt.Paint paint29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic30 = new org.jfree.chart.title.LegendGraphic(shape28, paint29);
        categoryItemEntity12.setArea(shape28);
        numberAxis1.setRightArrow(shape28);
        try {
            numberAxis1.setAutoRangeMinimumSize((-10.0d), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str2 = numberTickUnit0.valueToString(0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
        labelBlock1.setWidth(14.0d);
        java.lang.String str4 = labelBlock1.getURLText();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray8 = legendTitle6.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle6.getLegendItemGraphicLocation();
        java.lang.Object obj10 = legendTitle6.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle6.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(legendItemSourceArray8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isTickLabelsVisible();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) "UnitType.RELATIVE", "CategoryAnchor.MIDDLE");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = categoryLabelPositions7.getLabelPosition(rectangleEdge8);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions7);
        int int11 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNull(categoryLabelPosition9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets();
        double double10 = rectangleInsets8.calculateRightInset((double) 2);
        categoryPlot4.setInsets(rectangleInsets8, true);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer15.setSeriesFillPaint(0, (java.awt.Paint) color17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = statisticalBarRenderer15.getBasePositiveItemLabelPosition();
        categoryPlot4.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer15, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = null;
        statisticalBarRenderer15.setGradientPaintTransformer(gradientPaintTransformer22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            statisticalBarRenderer15.drawOutline(graphics2D24, categoryPlot25, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        textTitle1.draw(graphics2D2, rectangle2D3);
        java.awt.Paint paint5 = textTitle1.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = textTitle1.getMargin();
        java.lang.Object obj7 = textTitle1.clone();
        java.lang.String str8 = textTitle1.getToolTipText();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("AxisLocation.BOTTOM_OR_RIGHT", "{0}", "", image3, "ThreadContext", "", "Layer.BACKGROUND");
        java.lang.String str8 = projectInfo7.getLicenceText();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Layer.BACKGROUND" + "'", str8.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        java.lang.String str3 = categoryAxis0.getLabelToolTip();
        double double4 = categoryAxis0.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis0.getTickLabelInsets();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) (-16727872));
        double double3 = range2.getLength();
        double double4 = range2.getUpperBound();
        double double6 = range2.constrain((double) (short) 10);
        boolean boolean8 = range2.contains(0.05d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.6727872E7d) + "'", double4 == (-1.6727872E7d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.6727872E7d) + "'", double6 == (-1.6727872E7d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets2.getUnitType();
        java.awt.Font font5 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot10.setDomainAxis(categoryAxis11);
        categoryPlot10.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot10.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation17, plotOrientation18);
        categoryPlot10.setDomainAxisLocation((int) (short) 10, axisLocation17);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font5, (org.jfree.chart.plot.Plot) categoryPlot10, true);
        jFreeChart22.setTitle("Layer.BACKGROUND");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer25.setSeriesFillPaint(0, (java.awt.Paint) color27);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator30 = null;
        statisticalBarRenderer25.setSeriesURLGenerator(255, categoryURLGenerator30);
        statisticalBarRenderer25.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer25.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color37);
        jFreeChart22.setBorderPaint((java.awt.Paint) color37);
        java.awt.RenderingHints renderingHints40 = jFreeChart22.getRenderingHints();
        java.awt.Color color41 = java.awt.Color.WHITE;
        jFreeChart22.setBackgroundPaint((java.awt.Paint) color41);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) unitType3, jFreeChart22);
        java.lang.Object obj44 = jFreeChart22.getTextAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) list1, jFreeChart22);
        int int46 = jFreeChart22.getSubtitleCount();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(renderingHints40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list4 = defaultStatisticalCategoryDataset3.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity7 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "", "TextBlockAnchor.BOTTOM_CENTER", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) "TextBlockAnchor.BOTTOM_CENTER", (java.lang.Comparable) (-123));
        categoryItemEntity7.setColumnKey((java.lang.Comparable) "java.awt.Color[r=0,g=0,b=192]");
        categoryItemEntity7.setRowKey((java.lang.Comparable) 0.5f);
        java.lang.Comparable comparable12 = categoryItemEntity7.getRowKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 0.5f + "'", comparable12.equals(0.5f));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.data.RangeType rangeType4 = numberAxis1.getRangeType();
        double double5 = numberAxis1.getFixedDimension();
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable1 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer2.setSeriesFillPaint(0, (java.awt.Paint) color4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        statisticalBarRenderer2.setSeriesURLGenerator(255, categoryURLGenerator7);
        statisticalBarRenderer2.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer2.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color14);
        int int16 = statisticalBarRenderer2.getColumnCount();
        keyedObjects0.setObject(comparable1, (java.lang.Object) int16);
        java.lang.Object obj19 = keyedObjects0.getObject((int) (byte) -1);
        try {
            keyedObjects0.removeValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(obj19);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = categoryPlot4.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(categoryAnchor5);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot8);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int12 = defaultStatisticalCategoryDataset0.getRowCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot17.setDomainAxis(categoryAxis18);
        java.lang.Comparable[] comparableArray20 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray21 = new java.lang.Comparable[] {};
        double[][] doubleArray22 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray20, comparableArray21, doubleArray22);
        org.jfree.data.general.PieDataset pieDataset25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset23, (int) (short) 100);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset23, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot17.getRendererForDataset(categoryDataset23);
        java.awt.Paint paint29 = categoryPlot17.getNoDataMessagePaint();
        categoryPlot17.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot32 = categoryPlot17.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        categoryPlot17.setRenderer(1, categoryItemRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot17.getDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup37 = categoryPlot17.getDatasetGroup();
        int int38 = categoryPlot17.getRangeAxisCount();
        defaultStatisticalCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot17);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertEquals((double) number11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(comparableArray20);
        org.junit.Assert.assertNotNull(comparableArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(pieDataset25);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNull(categoryItemRenderer28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertNull(datasetGroup37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 'a', (-1.6727872E7d));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        boolean boolean21 = categoryPlot4.render(graphics2D17, rectangle2D18, (-123), plotRenderingInfo20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        categoryPlot26.setDomainAxis(categoryAxis27);
        java.lang.Comparable[] comparableArray29 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray30 = new java.lang.Comparable[] {};
        double[][] doubleArray31 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray29, comparableArray30, doubleArray31);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset32, (int) (short) 100);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset32, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot26.getRendererForDataset(categoryDataset32);
        java.awt.Paint paint38 = categoryPlot26.getNoDataMessagePaint();
        categoryPlot26.setBackgroundImageAlpha(0.0f);
        categoryPlot26.setRangeGridlinesVisible(true);
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.data.KeyedObject keyedObject45 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100.0f, (java.lang.Object) color44);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, valueAxis48, categoryItemRenderer49);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        categoryPlot50.setDomainAxis(categoryAxis51);
        org.jfree.chart.util.Layer layer54 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection55 = categoryPlot50.getRangeMarkers(0, layer54);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray56 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot50.setDomainAxes(categoryAxisArray56);
        boolean boolean58 = keyedObject45.equals((java.lang.Object) categoryAxisArray56);
        categoryPlot26.setDomainAxes(categoryAxisArray56);
        categoryPlot4.setDomainAxes(categoryAxisArray56);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(comparableArray29);
        org.junit.Assert.assertNotNull(comparableArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(layer54);
        org.junit.Assert.assertNotNull(collection55);
        org.junit.Assert.assertNotNull(categoryAxisArray56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.data.RangeType rangeType4 = numberAxis1.getRangeType();
        java.awt.Shape shape5 = numberAxis1.getUpArrow();
        org.jfree.data.Range range6 = numberAxis1.getRange();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        numberAxis1.setTickUnit(numberTickUnit8);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.SortOrder sortOrder5 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot4.setRowRenderingOrder(sortOrder5);
        float float7 = categoryPlot4.getBackgroundImageAlpha();
        java.awt.Image image8 = null;
        categoryPlot4.setBackgroundImage(image8);
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.lightGray;
        org.jfree.chart.text.TextBlock textBlock4 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, (java.awt.Paint) color3);
        java.util.List list5 = textBlock4.getLines();
        org.jfree.chart.text.TextLine textLine6 = textBlock4.getLastLine();
        textBlock0.addLine(textLine6);
        org.jfree.chart.text.TextFragment textFragment8 = textLine6.getFirstTextFragment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textBlock4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(textLine6);
        org.junit.Assert.assertNotNull(textFragment8);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.getItemStroke((int) 'a', (int) (byte) 10);
        try {
            statisticalBarRenderer0.setSeriesItemLabelsVisible((int) (byte) -1, (java.lang.Boolean) false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer11.setSeriesFillPaint(0, (java.awt.Paint) color13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = statisticalBarRenderer11.getBasePositiveItemLabelPosition();
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition15, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot4.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer19.setSeriesFillPaint(0, (java.awt.Paint) color21);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = statisticalBarRenderer19.getBasePositiveItemLabelPosition();
        java.awt.Paint paint26 = statisticalBarRenderer19.getItemFillPaint((int) (short) 100, 1);
        statisticalBarRenderer19.setAutoPopulateSeriesShape(false);
        boolean boolean29 = axisSpace17.equals((java.lang.Object) false);
        double double30 = axisSpace17.getRight();
        double double31 = axisSpace17.getBottom();
        org.jfree.chart.block.FlowArrangement flowArrangement32 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, categoryItemRenderer36);
        java.awt.Paint paint38 = categoryPlot37.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot37);
        flowArrangement32.add((org.jfree.chart.block.Block) legendTitle39, (java.lang.Object) (-16727872));
        java.awt.Paint paint42 = legendTitle39.getItemPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets();
        double double45 = rectangleInsets43.trimWidth((double) 1);
        legendTitle39.setItemLabelPadding(rectangleInsets43);
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, valueAxis49, categoryItemRenderer50);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        categoryPlot51.setDomainAxis(categoryAxis52);
        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = null;
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset54, categoryAxis55, valueAxis56, categoryItemRenderer57);
        categoryPlot58.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = new org.jfree.chart.util.RectangleInsets();
        double double64 = rectangleInsets62.calculateRightInset((double) 2);
        categoryPlot58.setInsets(rectangleInsets62, true);
        org.jfree.chart.util.UnitType unitType67 = rectangleInsets62.getUnitType();
        categoryPlot51.setAxisOffset(rectangleInsets62);
        double double69 = rectangleInsets62.getBottom();
        legendTitle39.setMargin(rectangleInsets62);
        boolean boolean71 = axisSpace17.equals((java.lang.Object) rectangleInsets62);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-1.0d) + "'", double45 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertNotNull(unitType67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0d + "'", double69 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.getItemStroke((int) 'a', (int) (byte) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = statisticalBarRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(drawingSupplier11);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list4 = defaultStatisticalCategoryDataset3.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity7 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "", "TextBlockAnchor.BOTTOM_CENTER", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) "TextBlockAnchor.BOTTOM_CENTER", (java.lang.Comparable) (-123));
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryItemEntity7.getDataset();
        categoryItemEntity7.setToolTipText("Range[-1.6727872E7,-1.6727872E7]");
        categoryItemEntity7.setRowKey((java.lang.Comparable) "ItemLabelAnchor.OUTSIDE9");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(categoryDataset8);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, 4.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Paint paint12 = statisticalBarRenderer0.getSeriesFillPaint((-123));
        statisticalBarRenderer0.setAutoPopulateSeriesPaint(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = statisticalBarRenderer0.getSeriesItemLabelGenerator(15);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = categoryLabelPositions2.getLabelPosition(rectangleEdge3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        java.awt.Paint paint12 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = legendTitle13.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = categoryLabelPositions6.getLabelPosition(rectangleEdge14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = categoryLabelPosition15.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType17 = categoryLabelPosition15.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = categoryLabelPosition15.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions2, categoryLabelPosition15);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = categoryLabelPosition15.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType23 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str24 = categoryLabelWidthType23.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor20, textAnchor21, (double) (byte) 0, categoryLabelWidthType23, 100.0f);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor27 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.JFreeChart jFreeChart28 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent31 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor27, jFreeChart28, 255, (int) (short) 1);
        boolean boolean32 = categoryLabelWidthType23.equals((java.lang.Object) textBlockAnchor27);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNull(categoryLabelPosition4);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(categoryLabelPosition15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(categoryLabelWidthType17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(categoryLabelWidthType23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str24.equals("CategoryLabelWidthType.CATEGORY"));
        org.junit.Assert.assertNotNull(textBlockAnchor27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        blockContainer2.clear();
        blockContainer2.setPadding((-1.0d), 100.0d, (double) (short) 100, (double) 10);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) 255, (double) 10);
        org.jfree.chart.util.Size2D size2D13 = borderArrangement0.arrange(blockContainer2, graphics2D9, rectangleConstraint12);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color17 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color17);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color22 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic23 = new org.jfree.chart.title.LegendGraphic(shape21, (java.awt.Paint) color22);
        legendGraphic18.setShape(shape21);
        legendGraphic18.setHeight(0.0d);
        java.awt.Shape shape27 = legendGraphic18.getShape();
        legendGraphic18.setID("ChartChangeEventType.GENERAL");
        java.lang.Object obj30 = legendGraphic18.clone();
        java.lang.Object obj31 = null;
        borderArrangement0.add((org.jfree.chart.block.Block) legendGraphic18, obj31);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.data.RangeType rangeType4 = numberAxis1.getRangeType();
        java.awt.Shape shape5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list9 = defaultStatisticalCategoryDataset8.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity12 = new org.jfree.chart.entity.CategoryItemEntity(shape5, "", "TextBlockAnchor.BOTTOM_CENTER", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset8, (java.lang.Comparable) "TextBlockAnchor.BOTTOM_CENTER", (java.lang.Comparable) (-123));
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryItemEntity12.getDataset();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color17 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color17);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color22 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic23 = new org.jfree.chart.title.LegendGraphic(shape21, (java.awt.Paint) color22);
        java.awt.Stroke stroke24 = legendGraphic23.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = legendGraphic23.getShapeLocation();
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape16, rectangleAnchor25, (double) (short) 10, (double) 0L);
        java.awt.Paint paint29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic30 = new org.jfree.chart.title.LegendGraphic(shape28, paint29);
        categoryItemEntity12.setArea(shape28);
        numberAxis1.setRightArrow(shape28);
        boolean boolean33 = numberAxis1.isAutoRange();
        org.jfree.chart.block.BlockContainer blockContainer34 = new org.jfree.chart.block.BlockContainer();
        blockContainer34.clear();
        blockContainer34.setPadding((-1.0d), 100.0d, (double) (short) 100, (double) 10);
        boolean boolean41 = blockContainer34.isEmpty();
        boolean boolean42 = numberAxis1.equals((java.lang.Object) blockContainer34);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer6 = new org.jfree.chart.text.G2TextMeasurer(graphics2D5);
        try {
            org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("Size2D[width=0.0, height=0.0]", font1, (java.awt.Paint) color2, (float) (-4145152), 0, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer3.setSeriesFillPaint(0, (java.awt.Paint) color5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer3.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 255, "ItemLabelAnchor.OUTSIDE9", textAnchor8, textAnchor9, (double) (byte) 100);
        double double12 = numberTick11.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor13 = numberTick11.getRotationAnchor();
        java.lang.String str14 = numberTick11.toString();
        java.lang.String str15 = numberTick11.getText();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ItemLabelAnchor.OUTSIDE9" + "'", str14.equals("ItemLabelAnchor.OUTSIDE9"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ItemLabelAnchor.OUTSIDE9" + "'", str15.equals("ItemLabelAnchor.OUTSIDE9"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        boolean boolean11 = legendGraphic4.isShapeVisible();
        java.awt.Paint paint12 = legendGraphic4.getOutlinePaint();
        legendGraphic4.setID("AxisLocation.BOTTOM_OR_RIGHT");
        boolean boolean15 = legendGraphic4.isShapeFilled();
        java.awt.Paint paint16 = legendGraphic4.getLinePaint();
        java.awt.Stroke stroke17 = legendGraphic4.getLineStroke();
        legendGraphic4.setShapeVisible(false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNull(stroke17);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle8.getItemLabelPadding();
        double double11 = rectangleInsets9.trimWidth((double) 0L);
        boolean boolean12 = numberAxis1.equals((java.lang.Object) double11);
        boolean boolean13 = numberAxis1.isAutoRange();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color21 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic22 = new org.jfree.chart.title.LegendGraphic(shape20, (java.awt.Paint) color21);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color26 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic27 = new org.jfree.chart.title.LegendGraphic(shape25, (java.awt.Paint) color26);
        legendGraphic22.setShape(shape25);
        java.awt.Color color29 = java.awt.Color.lightGray;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color31 = java.awt.Color.MAGENTA;
        int int32 = color31.getRed();
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape25, (java.awt.Paint) color29, stroke30, (java.awt.Paint) color31);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color37 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic38 = new org.jfree.chart.title.LegendGraphic(shape36, (java.awt.Paint) color37);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color42 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic43 = new org.jfree.chart.title.LegendGraphic(shape41, (java.awt.Paint) color42);
        legendGraphic38.setShape(shape41);
        java.lang.Object obj45 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) shape41);
        boolean boolean46 = org.jfree.chart.util.ShapeUtilities.equal(shape25, shape41);
        numberAxis1.setRightArrow(shape41);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-4.0d) + "'", double11 == (-4.0d));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 255 + "'", int32 == 255);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle8.getItemLabelPadding();
        double double11 = rectangleInsets9.trimWidth((double) 0L);
        boolean boolean12 = numberAxis1.equals((java.lang.Object) double11);
        boolean boolean13 = numberAxis1.isAutoRange();
        numberAxis1.setAutoRangeIncludesZero(false);
        numberAxis1.setInverted(false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-4.0d) + "'", double11 == (-4.0d));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getBase();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        statisticalBarRenderer0.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator3);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) '4', (int) '#');
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape14, 4.0d, (double) '4');
        try {
            statisticalBarRenderer0.setSeriesShape((int) (byte) -1, shape14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Font font2 = barRenderer0.getSeriesItemLabelFont(100);
        boolean boolean5 = barRenderer0.getItemVisible(100, 255);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("Size2D[width=1.0, height=0.0]");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        labelBlock1.setPaint((java.awt.Paint) color2);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            labelBlock1.setBounds(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        java.awt.Stroke stroke3 = strokeList0.getStroke(0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(stroke3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        boolean boolean11 = legendGraphic4.isShapeVisible();
        java.awt.Paint paint12 = legendGraphic4.getOutlinePaint();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color16 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color16);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color21 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic22 = new org.jfree.chart.title.LegendGraphic(shape20, (java.awt.Paint) color21);
        legendGraphic17.setShape(shape20);
        legendGraphic4.setShape(shape20);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = statisticalBarRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint7 = statisticalBarRenderer0.getSeriesFillPaint(10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        try {
            statisticalBarRenderer0.setSeriesToolTipGenerator((-1), categoryToolTipGenerator9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Stroke stroke12 = statisticalBarRenderer0.getSeriesOutlineStroke((int) '4');
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer13.setSeriesFillPaint(0, (java.awt.Paint) color15);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        statisticalBarRenderer13.setSeriesURLGenerator(255, categoryURLGenerator18);
        statisticalBarRenderer13.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer13.setErrorIndicatorStroke(stroke23);
        statisticalBarRenderer0.setBaseStroke(stroke23);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) 100, 14.0d, 2.0d, (double) 4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator8);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot16.setDomainAxis(categoryAxis17);
        java.lang.Comparable[] comparableArray19 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray20 = new java.lang.Comparable[] {};
        double[][] doubleArray21 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray19, comparableArray20, doubleArray21);
        org.jfree.data.general.PieDataset pieDataset24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset22, (int) (short) 100);
        org.jfree.data.Range range26 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset22, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = categoryPlot16.getRendererForDataset(categoryDataset22);
        java.awt.Paint paint28 = categoryPlot16.getNoDataMessagePaint();
        statisticalBarRenderer0.setBasePaint(paint28, false);
        java.awt.Stroke stroke31 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(comparableArray19);
        org.junit.Assert.assertNotNull(comparableArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(categoryDataset22);
        org.junit.Assert.assertNotNull(pieDataset24);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNull(categoryItemRenderer27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        boolean boolean11 = legendGraphic4.isShapeVisible();
        boolean boolean12 = legendGraphic4.isLineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation14 = axisLocation13.getOpposite();
        boolean boolean15 = legendGraphic4.equals((java.lang.Object) axisLocation14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendGraphic4.getMargin();
        double double17 = rectangleInsets16.getTop();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double10 = statisticalBarRenderer9.getBase();
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot4.getRangeAxis();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        try {
            org.jfree.chart.plot.XYPlot xYPlot14 = jFreeChart13.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer1.getBasePositiveItemLabelPosition();
        java.awt.Paint paint8 = statisticalBarRenderer1.getItemFillPaint((int) (short) 100, 1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        statisticalBarRenderer1.setBaseToolTipGenerator(categoryToolTipGenerator9);
        statisticalBarRenderer1.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot17.setDomainAxis(categoryAxis18);
        java.lang.Comparable[] comparableArray20 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray21 = new java.lang.Comparable[] {};
        double[][] doubleArray22 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray20, comparableArray21, doubleArray22);
        org.jfree.data.general.PieDataset pieDataset25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset23, (int) (short) 100);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset23, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot17.getRendererForDataset(categoryDataset23);
        java.awt.Paint paint29 = categoryPlot17.getNoDataMessagePaint();
        statisticalBarRenderer1.setBasePaint(paint29, false);
        org.jfree.data.KeyedObject keyedObject32 = new org.jfree.data.KeyedObject(comparable0, (java.lang.Object) paint29);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(comparableArray20);
        org.junit.Assert.assertNotNull(comparableArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(pieDataset25);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNull(categoryItemRenderer28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint((int) '4');
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot6.setDomainAxis(categoryAxis7);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot6.setDomainAxisLocation((int) (short) 10, axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        jFreeChart18.setTitle("Layer.BACKGROUND");
        jFreeChart18.setBackgroundImageAlignment((int) (byte) 10);
        boolean boolean23 = jFreeChart18.isNotify();
        jFreeChart18.setBorderVisible(false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.lang.Object obj2 = blockContainer0.clone();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) (-16727872));
        double double8 = range7.getLength();
        boolean boolean10 = range7.contains((double) 1L);
        double double11 = range7.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) 2, range7);
        org.jfree.data.Range range13 = null;
        org.jfree.data.Range range15 = org.jfree.data.Range.expandToInclude(range13, (double) (-16727872));
        double double16 = range15.getLength();
        boolean boolean18 = range15.contains((double) 1L);
        double double19 = range15.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint12.toRangeWidth(range15);
        org.jfree.data.Range range21 = rectangleConstraint12.getHeightRange();
        org.jfree.chart.util.Size2D size2D22 = blockContainer0.arrange(graphics2D3, rectangleConstraint12);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(size2D22);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        categoryPlot9.setAnchorValue(0.0d, true);
        java.awt.Image image13 = categoryPlot9.getBackgroundImage();
        categoryPlot9.configureDomainAxes();
        boolean boolean15 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot9);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        double double17 = categoryAxis16.getLabelAngle();
        double double18 = categoryAxis16.getCategoryMargin();
        java.lang.String str19 = categoryAxis16.getLabelToolTip();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setAxisLinePaint((java.awt.Paint) color20);
        categoryAxis16.setFixedDimension((double) 10L);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        categoryPlot28.setDomainAxis(categoryAxis29);
        java.lang.Comparable[] comparableArray31 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray32 = new java.lang.Comparable[] {};
        double[][] doubleArray33 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray31, comparableArray32, doubleArray33);
        org.jfree.data.general.PieDataset pieDataset36 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset34, (int) (short) 100);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset34, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = categoryPlot28.getRendererForDataset(categoryDataset34);
        java.awt.Paint paint40 = categoryPlot28.getNoDataMessagePaint();
        categoryAxis16.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot28);
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean45 = barRenderer42.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer42.setSeriesVisible(0, (java.lang.Boolean) true, true);
        categoryPlot28.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer42);
        org.jfree.data.category.CategoryDataset categoryDataset52 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset52, categoryAxis53, valueAxis54, categoryItemRenderer55);
        java.awt.Paint paint57 = categoryPlot56.getRangeGridlinePaint();
        categoryPlot56.clearAnnotations();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer59 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color61 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer59.setSeriesFillPaint(0, (java.awt.Paint) color61);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition63 = statisticalBarRenderer59.getBasePositiveItemLabelPosition();
        java.awt.Paint paint66 = statisticalBarRenderer59.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke69 = statisticalBarRenderer59.getItemStroke((int) 'a', (int) (byte) 10);
        categoryPlot56.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer59, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition73 = statisticalBarRenderer59.getSeriesNegativeItemLabelPosition(2);
        java.awt.Color color74 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color75 = color74.darker();
        statisticalBarRenderer59.setBaseItemLabelPaint((java.awt.Paint) color74);
        barRenderer42.setSeriesPaint(10, (java.awt.Paint) color74);
        categoryPlot9.setRangeGridlinePaint((java.awt.Paint) color74);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(image13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.2d + "'", double18 == 0.2d);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(comparableArray31);
        org.junit.Assert.assertNotNull(comparableArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(pieDataset36);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNull(categoryItemRenderer39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(itemLabelPosition63);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(itemLabelPosition73);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(color75);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        double double4 = range3.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) (-16727872));
        double double10 = range9.getLength();
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range9, (double) 100L);
        double double14 = range12.constrain((double) (-1));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) 128, range3, lengthConstraintType5, 255.0d, range12, lengthConstraintType15);
        java.lang.Comparable[] comparableArray17 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray18 = new java.lang.Comparable[] {};
        double[][] doubleArray19 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray17, comparableArray18, doubleArray19);
        org.jfree.data.general.PieDataset pieDataset22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset20, (int) (short) 100);
        org.jfree.data.general.PieDataset pieDataset26 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset22, (java.lang.Comparable) false, 0.0d, (int) (byte) 1);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) lengthConstraintType15, (org.jfree.data.general.Dataset) pieDataset26);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(comparableArray17);
        org.junit.Assert.assertNotNull(comparableArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(pieDataset22);
        org.junit.Assert.assertNotNull(pieDataset26);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        objectList1.clear();
        int int3 = objectList1.size();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        double double5 = categoryAxis4.getLabelAngle();
        double double6 = categoryAxis4.getCategoryMargin();
        java.lang.String str7 = categoryAxis4.getLabelToolTip();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis4.setAxisLinePaint((java.awt.Paint) color8);
        int int10 = objectList1.indexOf((java.lang.Object) categoryAxis4);
        double double11 = categoryAxis4.getUpperMargin();
        categoryAxis4.removeCategoryLabelToolTip((java.lang.Comparable) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Color color15 = java.awt.Color.lightGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        int int18 = color17.getRed();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape11, (java.awt.Paint) color15, stroke16, (java.awt.Paint) color17);
        int int20 = color15.getRGB();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-4144960) + "'", int20 == (-4144960));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot19 = categoryPlot4.getParent();
        categoryPlot4.setAnchorValue(0.0d, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer24.setSeriesFillPaint(0, (java.awt.Paint) color26);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator29 = null;
        statisticalBarRenderer24.setSeriesURLGenerator(255, categoryURLGenerator29);
        statisticalBarRenderer24.setSeriesVisible(100, (java.lang.Boolean) false, true);
        categoryPlot4.setRenderer(128, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer24);
        java.awt.Paint paint37 = statisticalBarRenderer24.getSeriesFillPaint(1);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        categoryPlot42.setAnchorValue(0.0d, true);
        categoryPlot42.clearAnnotations();
        float float47 = categoryPlot42.getBackgroundAlpha();
        java.awt.Image image48 = null;
        categoryPlot42.setBackgroundImage(image48);
        categoryPlot42.setAnchorValue((double) (-4145152), true);
        statisticalBarRenderer24.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot42);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 1.0f + "'", float47 == 1.0f);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisSpace axisSpace17 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot4.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer19.setSeriesFillPaint(0, (java.awt.Paint) color21);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = statisticalBarRenderer19.getBasePositiveItemLabelPosition();
        java.awt.Paint paint26 = statisticalBarRenderer19.getItemFillPaint((int) (short) 100, 1);
        statisticalBarRenderer19.setAutoPopulateSeriesShape(false);
        boolean boolean29 = axisSpace17.equals((java.lang.Object) false);
        double double30 = axisSpace17.getRight();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, categoryItemRenderer35);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        categoryPlot36.setDomainAxis(categoryAxis37);
        java.lang.Comparable[] comparableArray39 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray40 = new java.lang.Comparable[] {};
        double[][] doubleArray41 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray39, comparableArray40, doubleArray41);
        org.jfree.data.general.PieDataset pieDataset44 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset42, (int) (short) 100);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset42, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = categoryPlot36.getRendererForDataset(categoryDataset42);
        java.awt.Paint paint48 = categoryPlot36.getNoDataMessagePaint();
        categoryPlot36.setBackgroundImageAlpha(0.0f);
        categoryPlot36.setRangeGridlinesVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset53, categoryAxis54, valueAxis55, categoryItemRenderer56);
        categoryPlot57.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = new org.jfree.chart.util.RectangleInsets();
        double double63 = rectangleInsets61.calculateRightInset((double) 2);
        categoryPlot57.setInsets(rectangleInsets61, true);
        org.jfree.chart.util.UnitType unitType66 = rectangleInsets61.getUnitType();
        categoryPlot36.setAxisOffset(rectangleInsets61);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = categoryPlot36.getRangeAxisEdge();
        axisSpace17.add((double) (-16727872), rectangleEdge68);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(comparableArray39);
        org.junit.Assert.assertNotNull(comparableArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(pieDataset44);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertNull(categoryItemRenderer47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertNotNull(unitType66);
        org.junit.Assert.assertNotNull(rectangleEdge68);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        double double4 = range3.getLength();
        boolean boolean6 = range3.contains((double) 1L);
        double double7 = range3.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 2, range3);
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) (-16727872));
        double double12 = range11.getLength();
        boolean boolean14 = range11.contains((double) 1L);
        double double15 = range11.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint8.toRangeWidth(range11);
        double double17 = range11.getLowerBound();
        boolean boolean20 = range11.intersects((-10.0d), (double) (-4144960));
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.6727872E7d) + "'", double17 == (-1.6727872E7d));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        categoryPlot4.clearAnnotations();
        java.awt.Paint paint9 = categoryPlot4.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor0, jFreeChart1, 255, (int) (short) 1);
        java.awt.Font font6 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot11.setDomainAxis(categoryAxis12);
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot11.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation18, plotOrientation19);
        categoryPlot11.setDomainAxisLocation((int) (short) 10, axisLocation18);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font6, (org.jfree.chart.plot.Plot) categoryPlot11, true);
        jFreeChart23.setTitle("Layer.BACKGROUND");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer26.setSeriesFillPaint(0, (java.awt.Paint) color28);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator31 = null;
        statisticalBarRenderer26.setSeriesURLGenerator(255, categoryURLGenerator31);
        statisticalBarRenderer26.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer26.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color38);
        jFreeChart23.setBorderPaint((java.awt.Paint) color38);
        chartProgressEvent4.setChart(jFreeChart23);
        java.awt.Image image42 = jFreeChart23.getBackgroundImage();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        boolean boolean44 = jFreeChart23.equals((java.lang.Object) rectangleAnchor43);
        java.awt.RenderingHints renderingHints45 = jFreeChart23.getRenderingHints();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNull(image42);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(renderingHints45);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot8);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int12 = defaultStatisticalCategoryDataset0.getRowCount();
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 0.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextOutlinePaint();
        java.awt.Paint paint19 = defaultDrawingSupplier17.getNextPaint();
        int int20 = numberTickUnit16.compareTo((java.lang.Object) paint19);
        java.lang.Number number21 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) "SortOrder.DESCENDING", (java.lang.Comparable) numberTickUnit16);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertEquals((double) number11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNull(number21);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot8.setDomainAxis(categoryAxis9);
        categoryPlot8.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot8.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation15, plotOrientation16);
        categoryPlot8.setDomainAxisLocation((int) (short) 10, axisLocation15);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font3, (org.jfree.chart.plot.Plot) categoryPlot8, true);
        jFreeChart20.setTitle("Layer.BACKGROUND");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer23.setSeriesFillPaint(0, (java.awt.Paint) color25);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = null;
        statisticalBarRenderer23.setSeriesURLGenerator(255, categoryURLGenerator28);
        statisticalBarRenderer23.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer23.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color35);
        jFreeChart20.setBorderPaint((java.awt.Paint) color35);
        java.awt.RenderingHints renderingHints38 = jFreeChart20.getRenderingHints();
        java.awt.Color color39 = java.awt.Color.WHITE;
        jFreeChart20.setBackgroundPaint((java.awt.Paint) color39);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) unitType1, jFreeChart20);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        textTitle43.draw(graphics2D44, rectangle2D45);
        jFreeChart20.setTitle(textTitle43);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset48 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset48);
        int int51 = defaultStatisticalCategoryDataset48.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        defaultStatisticalCategoryDataset48.add((java.lang.Number) (short) 0, (java.lang.Number) 3.0d, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) 1L);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent57 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) jFreeChart20, (org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset48);
        defaultStatisticalCategoryDataset48.validateObject();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(renderingHints38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setRangeAboutValue((double) (-1L), (double) 0L);
        numberAxis1.setRangeAboutValue((double) 100L, (double) (byte) 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot4.setDomainAxis((int) (byte) 1, categoryAxis18);
        int int20 = categoryPlot4.getDomainAxisCount();
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection9 = categoryPlot4.getRangeMarkers(0, layer8);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot4.setDomainAxes(categoryAxisArray10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot16.setRowRenderingOrder(sortOrder17);
        java.lang.String str19 = sortOrder17.toString();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color23 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic24 = new org.jfree.chart.title.LegendGraphic(shape22, (java.awt.Paint) color23);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color28 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic29 = new org.jfree.chart.title.LegendGraphic(shape27, (java.awt.Paint) color28);
        legendGraphic24.setShape(shape27);
        legendGraphic24.setHeight(0.0d);
        java.lang.String str33 = legendGraphic24.getID();
        boolean boolean34 = sortOrder17.equals((java.lang.Object) str33);
        categoryPlot4.setRowRenderingOrder(sortOrder17);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = categoryPlot4.getLegendItems();
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "SortOrder.DESCENDING" + "'", str19.equals("SortOrder.DESCENDING"));
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(legendItemCollection36);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        double double4 = range3.getLength();
        boolean boolean6 = range3.contains((double) 1L);
        double double7 = range3.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 2, range3);
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) (-16727872));
        double double12 = range11.getLength();
        boolean boolean14 = range11.contains((double) 1L);
        double double15 = range11.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint8.toRangeWidth(range11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint16.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double10 = statisticalBarRenderer9.getBase();
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer9);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis13.setAutoRangeStickyZero(false);
        numberAxis13.setRangeAboutValue((double) (-1L), (double) 0L);
        int int19 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.awt.Paint paint7 = categoryPlot4.getRangeGridlinePaint();
        boolean boolean8 = categoryPlot4.isRangeZoomable();
        categoryPlot4.setRangeCrosshairValue((double) (byte) 10, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot17.setDomainAxis(categoryAxis18);
        categoryPlot17.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace22 = categoryPlot17.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation24, plotOrientation25);
        categoryPlot17.setDomainAxisLocation((int) (short) 10, axisLocation24);
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation24, plotOrientation28);
        categoryPlot4.setRangeAxisLocation((int) (short) 100, axisLocation24);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        categoryPlot5.setAnchorValue(0.0d, true);
        java.awt.Font font9 = categoryPlot5.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!", font9);
        java.lang.String str11 = labelBlock10.getToolTipText();
        java.awt.Paint paint12 = labelBlock10.getPaint();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer13.setSeriesFillPaint(0, (java.awt.Paint) color15);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        statisticalBarRenderer13.setSeriesURLGenerator(255, categoryURLGenerator18);
        statisticalBarRenderer13.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer13.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color25);
        int int27 = statisticalBarRenderer13.getColumnCount();
        boolean boolean28 = labelBlock10.equals((java.lang.Object) statisticalBarRenderer13);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        categoryPlot4.clearAnnotations();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        categoryPlot4.setDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setDomainAxisLocation(0, axisLocation12, true);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer1.getBasePositiveItemLabelPosition();
        java.awt.Paint paint8 = statisticalBarRenderer1.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke11 = statisticalBarRenderer1.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Paint paint13 = statisticalBarRenderer1.getSeriesPaint(10);
        java.awt.Color color14 = java.awt.Color.cyan;
        statisticalBarRenderer1.setBasePaint((java.awt.Paint) color14);
        java.awt.Paint paint17 = null;
        statisticalBarRenderer1.setSeriesFillPaint((int) (byte) 10, paint17, false);
        double double20 = statisticalBarRenderer1.getItemLabelAnchorOffset();
        boolean boolean23 = statisticalBarRenderer1.getItemCreateEntity(0, 0);
        boolean boolean24 = tickUnits0.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color3 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic4.setShape(shape7);
        legendGraphic4.setHeight(0.0d);
        java.awt.Shape shape13 = legendGraphic4.getShape();
        java.awt.Paint paint14 = legendGraphic4.getLinePaint();
        java.lang.Object obj15 = legendGraphic4.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getLegendItemGraphicEdge();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder();
        legendTitle6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder8);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.util.Locale locale1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Class<?> wildcardClass5 = textAnchor4.getClass();
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass5);
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("{0}", (java.lang.Class) wildcardClass5);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
        try {
            java.util.ResourceBundle resourceBundle9 = java.util.ResourceBundle.getBundle("Layer.FOREGROUND", locale1, classLoader8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(uRL6);
        org.junit.Assert.assertNull(inputStream7);
        org.junit.Assert.assertNotNull(classLoader8);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle8.getItemLabelPadding();
        double double11 = rectangleInsets9.trimWidth((double) 0L);
        boolean boolean12 = numberAxis1.equals((java.lang.Object) double11);
        boolean boolean13 = numberAxis1.isPositiveArrowVisible();
        double[] doubleArray19 = new double[] { 0.5f, (byte) -1, (-1) };
        double[] doubleArray23 = new double[] { 0.5f, (byte) -1, (-1) };
        double[] doubleArray27 = new double[] { 0.5f, (byte) -1, (-1) };
        double[] doubleArray31 = new double[] { 0.5f, (byte) -1, (-1) };
        double[] doubleArray35 = new double[] { 0.5f, (byte) -1, (-1) };
        double[] doubleArray39 = new double[] { 0.5f, (byte) -1, (-1) };
        double[][] doubleArray40 = new double[][] { doubleArray19, doubleArray23, doubleArray27, doubleArray31, doubleArray35, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[-1.6727872E7,-1.6727872E7]", "TextBlockAnchor.BOTTOM_CENTER", doubleArray40);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset41, false);
        numberAxis1.setRangeWithMargins(range43, true, true);
        org.jfree.data.Range range47 = null;
        try {
            numberAxis1.setRange(range47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-4.0d) + "'", double11 == (-4.0d));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot6.setDomainAxis(categoryAxis7);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot6.setDomainAxisLocation((int) (short) 10, axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        jFreeChart18.setTitle("Layer.BACKGROUND");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer21.setSeriesFillPaint(0, (java.awt.Paint) color23);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = null;
        statisticalBarRenderer21.setSeriesURLGenerator(255, categoryURLGenerator26);
        statisticalBarRenderer21.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer21.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color33);
        jFreeChart18.setBorderPaint((java.awt.Paint) color33);
        java.awt.RenderingHints renderingHints36 = jFreeChart18.getRenderingHints();
        java.awt.Color color37 = java.awt.Color.WHITE;
        jFreeChart18.setBackgroundPaint((java.awt.Paint) color37);
        java.awt.Stroke stroke39 = jFreeChart18.getBorderStroke();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(renderingHints36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.data.Range range4 = null;
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range4, (double) (-16727872));
        double double7 = range6.getLength();
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range6, (double) 100L);
        numberAxis1.setRangeWithMargins(range9);
        double double11 = range9.getUpperBound();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.TickType tickType3 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer6.setSeriesFillPaint(0, (java.awt.Paint) color8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalBarRenderer6.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor11 = itemLabelPosition10.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick14 = new org.jfree.chart.axis.NumberTick(tickType3, (double) 255, "ItemLabelAnchor.OUTSIDE9", textAnchor11, textAnchor12, (double) (byte) 100);
        org.jfree.chart.axis.NumberTick numberTick16 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "", textAnchor2, textAnchor11, 100.0d);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color4 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape3, (java.awt.Paint) color4);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic(shape8, (java.awt.Paint) color9);
        java.awt.Stroke stroke11 = legendGraphic10.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendGraphic10.getShapeLocation();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor12, (double) (short) 10, (double) 0L);
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape15, paint16);
        boolean boolean18 = projectInfo0.equals((java.lang.Object) shape15);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20);
        org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20, 15);
        legendItemEntity19.setDataset((org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset20);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(pieDataset23);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot8);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int12 = defaultStatisticalCategoryDataset0.getRowCount();
        java.lang.Number number13 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number17 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) 0, (java.lang.Comparable) (-10.0d));
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertEquals((double) number11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0d + "'", number13.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setAutoRangeStickyZero(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit4);
        java.lang.String str7 = numberTickUnit4.valueToString((double) 10);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Color color15 = java.awt.Color.lightGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        int int18 = color17.getRed();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape11, (java.awt.Paint) color15, stroke16, (java.awt.Paint) color17);
        java.awt.Shape shape20 = legendItem19.getShape();
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape20);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str3 = projectInfo2.getInfo();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo2.getOptionalLibraries();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.awt.Paint paint1 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer2.setSeriesFillPaint(0, (java.awt.Paint) color4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        statisticalBarRenderer2.setSeriesURLGenerator(255, categoryURLGenerator7);
        statisticalBarRenderer2.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer2.setErrorIndicatorStroke(stroke12);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 2, paint1, stroke12);
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor(0, 100, (int) 'a');
        int int19 = chartColor18.getRGB();
        valueMarker14.setLabelPaint((java.awt.Paint) chartColor18);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-16751519) + "'", int19 == (-16751519));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.data.RangeType rangeType4 = numberAxis1.getRangeType();
        java.lang.Object obj5 = numberAxis1.clone();
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        java.awt.Color color4 = color2.brighter();
        int int5 = color4.getRGB();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-41985) + "'", int5 == (-41985));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic(shape8, (java.awt.Paint) color9);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color14 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape13, (java.awt.Paint) color14);
        legendGraphic10.setShape(shape13);
        java.awt.Color color17 = java.awt.Color.lightGray;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = java.awt.Color.MAGENTA;
        int int20 = color19.getRed();
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape13, (java.awt.Paint) color17, stroke18, (java.awt.Paint) color19);
        java.lang.String str22 = legendItem21.getLabel();
        java.awt.Shape shape23 = legendItem21.getLine();
        boolean boolean24 = legendItemCollection1.equals((java.lang.Object) shape23);
        legendItemCollection0.addAll(legendItemCollection1);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) (-16727872));
        double double4 = range3.getLength();
        boolean boolean6 = range3.contains((double) 1L);
        double double7 = range3.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 2, range3);
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) (-16727872));
        double double12 = range11.getLength();
        boolean boolean14 = range11.contains((double) 1L);
        double double15 = range11.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = rectangleConstraint8.toRangeWidth(range11);
        org.jfree.data.Range range17 = rectangleConstraint8.getHeightRange();
        org.jfree.data.Range range19 = null;
        org.jfree.data.Range range21 = org.jfree.data.Range.expandToInclude(range19, (double) (-16727872));
        double double22 = range21.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType23 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range25 = null;
        org.jfree.data.Range range27 = org.jfree.data.Range.expandToInclude(range25, (double) (-16727872));
        double double28 = range27.getLength();
        org.jfree.data.Range range30 = org.jfree.data.Range.expandToInclude(range27, (double) 100L);
        double double32 = range30.constrain((double) (-1));
        org.jfree.chart.block.LengthConstraintType lengthConstraintType33 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint((double) 128, range21, lengthConstraintType23, 255.0d, range30, lengthConstraintType33);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = rectangleConstraint8.toRangeWidth(range30);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType36 = rectangleConstraint35.getHeightConstraintType();
        java.lang.String str37 = lengthConstraintType36.toString();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType23);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32 == (-1.0d));
        org.junit.Assert.assertNotNull(lengthConstraintType33);
        org.junit.Assert.assertNotNull(rectangleConstraint35);
        org.junit.Assert.assertNotNull(lengthConstraintType36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "RectangleConstraintType.RANGE" + "'", str37.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        objectList1.clear();
        int int3 = objectList1.size();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        double double5 = categoryAxis4.getLabelAngle();
        double double6 = categoryAxis4.getCategoryMargin();
        java.lang.String str7 = categoryAxis4.getLabelToolTip();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis4.setAxisLinePaint((java.awt.Paint) color8);
        int int10 = objectList1.indexOf((java.lang.Object) categoryAxis4);
        categoryAxis4.setTickLabelsVisible(true);
        categoryAxis4.setTickMarkOutsideLength((float) 1L);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity20 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis4, shape17, "CategoryAnchor.MIDDLE", "{0}");
        java.lang.String str21 = axisLabelEntity20.toString();
        axisLabelEntity20.setToolTipText("97");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "AxisLabelEntity: label = null" + "'", str21.equals("AxisLabelEntity: label = null"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double[] doubleArray5 = new double[] { (-1.6727872E7d) };
        double[] doubleArray7 = new double[] { (-1.6727872E7d) };
        double[] doubleArray9 = new double[] { (-1.6727872E7d) };
        double[] doubleArray11 = new double[] { (-1.6727872E7d) };
        double[] doubleArray13 = new double[] { (-1.6727872E7d) };
        double[] doubleArray15 = new double[] { (-1.6727872E7d) };
        double[][] doubleArray16 = new double[][] { doubleArray5, doubleArray7, doubleArray9, doubleArray11, doubleArray13, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("{0}", "", doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("0", "", doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Color color15 = java.awt.Color.lightGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        int int18 = color17.getRed();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape11, (java.awt.Paint) color15, stroke16, (java.awt.Paint) color17);
        java.awt.Stroke stroke20 = legendItem19.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = categoryPlot25.getRangeMarkers(layer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        int int32 = categoryPlot25.getIndexOf(categoryItemRenderer31);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier33 = categoryPlot25.getDrawingSupplier();
        boolean boolean34 = legendItem19.equals((java.lang.Object) categoryPlot25);
        java.lang.String str35 = legendItem19.getURLText();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(drawingSupplier33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "VerticalAlignment.CENTER" + "'", str35.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.util.SortOrder sortOrder5 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot4.setRowRenderingOrder(sortOrder5);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color14 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape13, (java.awt.Paint) color14);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color19 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color19);
        legendGraphic15.setShape(shape18);
        java.awt.Color color22 = java.awt.Color.lightGray;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color24 = java.awt.Color.MAGENTA;
        int int25 = color24.getRed();
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape18, (java.awt.Paint) color22, stroke23, (java.awt.Paint) color24);
        java.awt.Stroke stroke27 = legendItem26.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        categoryPlot32.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection37 = categoryPlot32.getRangeMarkers(layer36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        int int39 = categoryPlot32.getIndexOf(categoryItemRenderer38);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier40 = categoryPlot32.getDrawingSupplier();
        boolean boolean41 = legendItem26.equals((java.lang.Object) categoryPlot32);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray42 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot32.setRangeAxes(valueAxisArray42);
        categoryPlot4.setRangeAxes(valueAxisArray42);
        java.lang.String str45 = categoryPlot4.getNoDataMessage();
        org.junit.Assert.assertNotNull(sortOrder5);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(drawingSupplier40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(valueAxisArray42);
        org.junit.Assert.assertNull(str45);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection2 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        categoryPlot5.setAnchorValue(0.0d, true);
        java.awt.Font font9 = categoryPlot5.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!", font9);
        java.lang.String str11 = labelBlock10.getToolTipText();
        java.awt.Font font12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        labelBlock10.setFont(font12);
        org.jfree.data.KeyedObjects keyedObjects14 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable15 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer16.setSeriesFillPaint(0, (java.awt.Paint) color18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = null;
        statisticalBarRenderer16.setSeriesURLGenerator(255, categoryURLGenerator21);
        statisticalBarRenderer16.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer16.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color28);
        int int30 = statisticalBarRenderer16.getColumnCount();
        keyedObjects14.setObject(comparable15, (java.lang.Object) int30);
        java.lang.Object obj33 = keyedObjects14.getObject((int) (byte) -1);
        java.util.List list34 = keyedObjects14.getKeys();
        boolean boolean35 = labelBlock10.equals((java.lang.Object) list34);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNull(obj33);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        double double2 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        java.lang.Class<?> wildcardClass4 = axisChangeEvent3.getClass();
        org.jfree.chart.JFreeChart jFreeChart5 = axisChangeEvent3.getChart();
        org.jfree.chart.JFreeChart jFreeChart6 = axisChangeEvent3.getChart();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(jFreeChart5);
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.Shape shape4 = numberAxis1.getLeftArrow();
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list4 = defaultStatisticalCategoryDataset3.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity7 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "", "TextBlockAnchor.BOTTOM_CENTER", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) "TextBlockAnchor.BOTTOM_CENTER", (java.lang.Comparable) (-123));
        java.lang.Number number10 = defaultStatisticalCategoryDataset3.getStdDevValue((java.lang.Comparable) 192, (java.lang.Comparable) 'a');
        int int12 = defaultStatisticalCategoryDataset3.getColumnIndex((java.lang.Comparable) 3.0d);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setPositiveArrowVisible(true);
        java.awt.Font font4 = numberAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        textBlock0.draw(graphics2D3, 0.0f, (float) (-1), textBlockAnchor6);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        java.lang.Boolean boolean8 = statisticalBarRenderer0.getSeriesCreateEntities((int) (short) -1);
        java.awt.Paint paint11 = statisticalBarRenderer0.getItemPaint(15, (int) (short) 1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.data.RangeType rangeType4 = numberAxis1.getRangeType();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryAxis5.setAxisLinePaint((java.awt.Paint) color6);
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color6 };
        java.awt.Paint[] paintArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray11 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray8, paintArray9, strokeArray10, strokeArray11, shapeArray12);
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        java.awt.Paint paint20 = categoryPlot19.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot19);
        flowArrangement14.add((org.jfree.chart.block.Block) legendTitle21, (java.lang.Object) (-16727872));
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle25.setURLText("VerticalAlignment.CENTER");
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = textTitle25.getMargin();
        legendTitle21.setPadding(rectangleInsets28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = legendTitle21.getItemLabelPadding();
        boolean boolean31 = defaultDrawingSupplier13.equals((java.lang.Object) rectangleInsets30);
        java.awt.Paint paint32 = defaultDrawingSupplier13.getNextOutlinePaint();
        numberAxis1.setAxisLinePaint(paint32);
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(shapeArray12);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("AxisLocation.BOTTOM_OR_RIGHT");
        numberAxis1.setPositiveArrowVisible(true);
        org.jfree.data.RangeType rangeType4 = numberAxis1.getRangeType();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        boolean boolean6 = numberAxis1.isNegativeArrowVisible();
        java.lang.Object obj7 = numberAxis1.clone();
        org.junit.Assert.assertNotNull(rangeType4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int3 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "Layer.BACKGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot8.getRangeGridlinePaint();
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot8);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        int int12 = defaultStatisticalCategoryDataset0.getRowCount();
        java.lang.Number number13 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) (-16727872));
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertEquals((double) number11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0d + "'", number13.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = legendTitle8.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = categoryLabelPositions1.getLabelPosition(rectangleEdge9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = categoryLabelPosition10.getCategoryAnchor();
        org.jfree.chart.text.TextAnchor textAnchor12 = categoryLabelPosition10.getRotationAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(categoryLabelPosition10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Stroke stroke12 = statisticalBarRenderer0.getSeriesOutlineStroke((int) '4');
        statisticalBarRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = statisticalBarRenderer0.getGradientPaintTransformer();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine18 = new org.jfree.chart.text.TextLine("AxisLocation.BOTTOM_OR_RIGHT", font17);
        statisticalBarRenderer0.setBaseItemLabelFont(font17);
        java.awt.Stroke stroke21 = null;
        try {
            statisticalBarRenderer0.setSeriesOutlineStroke((int) (short) -1, stroke21, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Paint paint7 = statisticalBarRenderer0.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke10 = statisticalBarRenderer0.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Paint paint12 = statisticalBarRenderer0.getSeriesPaint(10);
        java.awt.Color color13 = java.awt.Color.cyan;
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color13);
        java.awt.Paint paint16 = null;
        statisticalBarRenderer0.setSeriesFillPaint((int) (byte) 10, paint16, false);
        double double19 = statisticalBarRenderer0.getUpperClip();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        categoryPlot4.clearAnnotations();
        float float9 = categoryPlot4.getBackgroundAlpha();
        java.awt.Image image10 = null;
        categoryPlot4.setBackgroundImage(image10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = null;
        try {
            categoryPlot4.setInsets(rectangleInsets13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNull(axisSpace12);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Comparable comparable5 = null;
        defaultStatisticalCategoryDataset0.add((double) (short) 0, (double) ' ', (java.lang.Comparable) false, comparable5);
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLabelAngle();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 0L);
        java.awt.Paint paint4 = null;
        try {
            categoryAxis0.setAxisLinePaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        boolean boolean2 = blockContainer0.isEmpty();
        org.junit.Assert.assertNotNull(arrangement1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        categoryPlot5.setAnchorValue(0.0d, true);
        java.awt.Font font9 = categoryPlot5.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("hi!", font9);
        labelBlock10.setToolTipText("PlotOrientation.HORIZONTAL");
        java.awt.Font font13 = labelBlock10.getFont();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getBase();
        java.awt.Font font3 = statisticalBarRenderer0.getSeriesItemLabelFont((int) (short) 1);
        boolean boolean4 = statisticalBarRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = statisticalBarRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = statisticalBarRenderer0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertNull(drawingSupplier6);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot19 = categoryPlot4.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot4.setRenderer(1, categoryItemRenderer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot4.getDomainAxis();
        org.jfree.data.general.DatasetGroup datasetGroup24 = categoryPlot4.getDatasetGroup();
        int int25 = categoryPlot4.getRangeAxisCount();
        categoryPlot4.clearDomainMarkers(255);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = null;
        java.awt.geom.Point2D point2D32 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D30, rectangleAnchor31);
        categoryPlot4.zoomDomainAxes((double) 1, plotRenderingInfo29, point2D32);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNull(datasetGroup24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(point2D32);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator11, false);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color16 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape11, stroke15, (java.awt.Paint) color16);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = categoryLabelPositions19.getLabelPosition(rectangleEdge20);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        java.awt.Paint paint29 = categoryPlot28.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = legendTitle30.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition32 = categoryLabelPositions23.getLabelPosition(rectangleEdge31);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions33 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions19, categoryLabelPosition32);
        boolean boolean34 = legendItem17.equals((java.lang.Object) categoryLabelPositions19);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
        org.junit.Assert.assertNull(categoryLabelPosition21);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(categoryLabelPosition32);
        org.junit.Assert.assertNotNull(categoryLabelPositions33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("VerticalAlignment.CENTER");
        java.lang.String str2 = datasetGroup1.getID();
        java.lang.Object obj3 = datasetGroup1.clone();
        java.lang.String str4 = datasetGroup1.getID();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VerticalAlignment.CENTER" + "'", str2.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "VerticalAlignment.CENTER" + "'", str4.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", graphics2D1, (double) 10, (float) (-4144960), 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean3 = barRenderer0.isItemLabelVisible((int) (short) 100, (-123));
        barRenderer0.setSeriesVisible(0, (java.lang.Boolean) true, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = barRenderer0.getSeriesToolTipGenerator(2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 3.0d);
        java.lang.Comparable comparable3 = null;
        java.lang.Object obj5 = keyedObjects2D0.getObject(comparable3, (java.lang.Comparable) (byte) -1);
        java.lang.Comparable comparable7 = null;
        keyedObjects2D0.removeObject((java.lang.Comparable) '4', comparable7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) (-1L), (double) (short) 0);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        java.awt.Paint paint12 = categoryPlot11.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot11);
        flowArrangement6.add((org.jfree.chart.block.Block) legendTitle13, (java.lang.Object) (-16727872));
        java.awt.Paint paint16 = legendTitle13.getItemPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets();
        double double19 = rectangleInsets17.trimWidth((double) 1);
        legendTitle13.setItemLabelPadding(rectangleInsets17);
        java.awt.Font font21 = legendTitle13.getItemFont();
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color29 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic30 = new org.jfree.chart.title.LegendGraphic(shape28, (java.awt.Paint) color29);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color34 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic35 = new org.jfree.chart.title.LegendGraphic(shape33, (java.awt.Paint) color34);
        legendGraphic30.setShape(shape33);
        java.awt.Stroke stroke37 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color38 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape33, stroke37, (java.awt.Paint) color38);
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape33, (double) (short) 1, (float) 100L, (float) 128);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity44 = new org.jfree.chart.entity.LegendItemEntity(shape43);
        java.awt.Shape shape45 = legendItemEntity44.getArea();
        java.awt.Shape shape46 = legendItemEntity44.getArea();
        java.lang.String str47 = legendItemEntity44.getShapeCoords();
        columnArrangement5.add((org.jfree.chart.block.Block) legendTitle13, (java.lang.Object) str47);
        org.jfree.data.KeyedObject keyedObject49 = new org.jfree.data.KeyedObject((java.lang.Comparable) "ItemLabelAnchor.OUTSIDE1", (java.lang.Object) str47);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "154,-24,153,-25,154,-25,154,-25,153,-25,153,-26,153,-26,153,-25,152,-24,152,-24,153,-25,154,-24,154,-24" + "'", str47.equals("154,-24,153,-25,154,-25,154,-25,153,-25,153,-26,153,-26,153,-25,152,-24,152,-24,153,-25,154,-24,154,-24"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        boolean boolean5 = categoryPlot4.getDrawSharedDomainAxis();
        java.awt.Stroke stroke6 = categoryPlot4.getOutlineStroke();
        categoryPlot4.mapDatasetToDomainAxis((int) (short) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        categoryPlot11.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double17 = rectangleInsets15.calculateRightInset((double) 2);
        categoryPlot11.setInsets(rectangleInsets15, true);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets15.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets15);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection25 = categoryPlot4.getDomainMarkers((int) 'a', layer24);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer26.setSeriesFillPaint(0, (java.awt.Paint) color28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = statisticalBarRenderer26.getBasePositiveItemLabelPosition();
        java.awt.Paint paint33 = statisticalBarRenderer26.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke36 = statisticalBarRenderer26.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Paint paint38 = statisticalBarRenderer26.getSeriesPaint(10);
        java.awt.Color color39 = java.awt.Color.cyan;
        statisticalBarRenderer26.setBasePaint((java.awt.Paint) color39);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer26, false);
        statisticalBarRenderer26.setSeriesItemLabelsVisible(2, false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(color39);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.setAnchorValue(0.0d, true);
        java.awt.Font font11 = categoryPlot7.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("hi!", font11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.GENERAL", font11);
        java.awt.Color color14 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("Layer.FOREGROUND", font11, (java.awt.Paint) color14, (float) (short) 0);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalBarRenderer1.getBasePositiveItemLabelPosition();
        java.awt.Paint paint8 = statisticalBarRenderer1.getItemFillPaint((int) (short) 100, 1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        statisticalBarRenderer1.setBaseToolTipGenerator(categoryToolTipGenerator9);
        statisticalBarRenderer1.setAutoPopulateSeriesOutlineStroke(true);
        boolean boolean13 = textAnchor0.equals((java.lang.Object) statisticalBarRenderer1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray1, doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (int) (short) 100);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset5, (java.lang.Comparable) 0.2d, (double) (-123));
        org.jfree.data.general.PieDataset pieDataset11 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset8, (java.lang.Comparable) (byte) 100, 0.0d);
        double double12 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset8);
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNotNull(pieDataset11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot4.getDataset();
        categoryPlot4.setOutlineVisible(true);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list12 = defaultStatisticalCategoryDataset11.getColumnKeys();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot4.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11);
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11);
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color26 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic27 = new org.jfree.chart.title.LegendGraphic(shape25, (java.awt.Paint) color26);
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color31 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic32 = new org.jfree.chart.title.LegendGraphic(shape30, (java.awt.Paint) color31);
        legendGraphic27.setShape(shape30);
        java.awt.Color color34 = java.awt.Color.lightGray;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color36 = java.awt.Color.MAGENTA;
        int int37 = color36.getRed();
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape30, (java.awt.Paint) color34, stroke35, (java.awt.Paint) color36);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color42 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic43 = new org.jfree.chart.title.LegendGraphic(shape41, (java.awt.Paint) color42);
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color47 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic48 = new org.jfree.chart.title.LegendGraphic(shape46, (java.awt.Paint) color47);
        legendGraphic43.setShape(shape46);
        java.lang.Object obj50 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) shape46);
        boolean boolean51 = org.jfree.chart.util.ShapeUtilities.equal(shape30, shape46);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color54 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer52.setSeriesFillPaint(0, (java.awt.Paint) color54);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = statisticalBarRenderer52.getBasePositiveItemLabelPosition();
        java.awt.Paint paint59 = statisticalBarRenderer52.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke62 = statisticalBarRenderer52.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Paint paint64 = statisticalBarRenderer52.getSeriesPaint(10);
        java.awt.Paint paint66 = statisticalBarRenderer52.lookupSeriesOutlinePaint((int) (short) 10);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer67 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color69 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer67.setSeriesFillPaint(0, (java.awt.Paint) color69);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator72 = null;
        statisticalBarRenderer67.setSeriesURLGenerator(255, categoryURLGenerator72);
        statisticalBarRenderer67.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color79 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer67.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color79);
        double double81 = statisticalBarRenderer67.getMinimumBarLength();
        java.awt.Stroke stroke82 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer67.setBaseStroke(stroke82);
        java.awt.Color color85 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.data.KeyedObject keyedObject86 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100.0f, (java.lang.Object) color85);
        org.jfree.chart.LegendItem legendItem87 = new org.jfree.chart.LegendItem("hi!", "{0}", "ItemLabelAnchor.OUTSIDE9", "UnitType.RELATIVE", shape46, paint66, stroke82, (java.awt.Paint) color85);
        boolean boolean88 = defaultStatisticalCategoryDataset11.equals((java.lang.Object) "ItemLabelAnchor.OUTSIDE9");
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 255 + "'", int37 == 255);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(itemLabelPosition56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNull(paint64);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertNotNull(color85);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer0.setSeriesFillPaint(0, (java.awt.Paint) color2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalBarRenderer0.setSeriesURLGenerator(255, categoryURLGenerator5);
        statisticalBarRenderer0.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer0.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color12);
        double double14 = statisticalBarRenderer0.getMinimumBarLength();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer0.setBaseStroke(stroke15);
        double double17 = statisticalBarRenderer0.getItemMargin();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        blockResult0.setEntityCollection(entityCollection2);
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color13 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape12, (java.awt.Paint) color13);
        java.awt.Paint paint15 = legendGraphic14.getOutlinePaint();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.Size2D size2D17 = legendGraphic14.arrange(graphics2D16);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition23 = categoryLabelPositions21.getLabelPosition(rectangleEdge22);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions25 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        java.awt.Paint paint31 = categoryPlot30.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot30);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = legendTitle32.getLegendItemGraphicEdge();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition34 = categoryLabelPositions25.getLabelPosition(rectangleEdge33);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = categoryLabelPosition34.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType36 = categoryLabelPosition34.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = categoryLabelPosition34.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions38 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions21, categoryLabelPosition34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = categoryLabelPosition34.getCategoryAnchor();
        java.awt.geom.Rectangle2D rectangle2D40 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 4.0d, (-4.0d), rectangleAnchor39);
        try {
            categoryPlot4.drawBackground(graphics2D9, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertNull(categoryLabelPosition23);
        org.junit.Assert.assertNotNull(categoryLabelPositions25);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(categoryLabelPosition34);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(categoryLabelWidthType36);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(categoryLabelPositions38);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setAnchorValue(0.0d, true);
        java.awt.Font font10 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("hi!", font10);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.GENERAL", font10);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent13 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle12);
        textTitle12.setText("Range[-1.6727872E7,-1.6727872E7]");
        java.lang.String str16 = textTitle12.getText();
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Range[-1.6727872E7,-1.6727872E7]" + "'", str16.equals("Range[-1.6727872E7,-1.6727872E7]"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue(0.0d, true);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot4.getRangeAxisLocation(255);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation13 = axisLocation12.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        java.lang.String str17 = plotOrientation15.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation15);
        categoryPlot4.setOrientation(plotOrientation15);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer20.setSeriesFillPaint(0, (java.awt.Paint) color22);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = statisticalBarRenderer20.getPositiveItemLabelPosition((int) (byte) 100, (int) 'a');
        java.awt.Stroke stroke28 = statisticalBarRenderer20.lookupSeriesOutlineStroke((int) (byte) 1);
        categoryPlot4.setRangeGridlineStroke(stroke28);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str17.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot8.setDomainAxis(categoryAxis9);
        categoryPlot8.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot8.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation15, plotOrientation16);
        categoryPlot8.setDomainAxisLocation((int) (short) 10, axisLocation15);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font3, (org.jfree.chart.plot.Plot) categoryPlot8, true);
        jFreeChart20.setTitle("Layer.BACKGROUND");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer23.setSeriesFillPaint(0, (java.awt.Paint) color25);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = null;
        statisticalBarRenderer23.setSeriesURLGenerator(255, categoryURLGenerator28);
        statisticalBarRenderer23.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer23.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color35);
        jFreeChart20.setBorderPaint((java.awt.Paint) color35);
        java.awt.RenderingHints renderingHints38 = jFreeChart20.getRenderingHints();
        java.awt.Color color39 = java.awt.Color.WHITE;
        jFreeChart20.setBackgroundPaint((java.awt.Paint) color39);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) unitType1, jFreeChart20);
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("hi!");
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        textTitle43.draw(graphics2D44, rectangle2D45);
        jFreeChart20.setTitle(textTitle43);
        java.awt.Stroke stroke48 = jFreeChart20.getBorderStroke();
        boolean boolean49 = jFreeChart20.isNotify();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(renderingHints38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.lightGray;
        org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, (java.awt.Paint) color2);
        java.util.List list4 = textBlock3.getLines();
        org.jfree.chart.text.TextLine textLine5 = textBlock3.getLastLine();
        org.jfree.chart.text.TextLine textLine6 = textBlock3.getLastLine();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textBlock3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(textLine5);
        org.junit.Assert.assertNotNull(textLine6);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color9 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic(shape8, (java.awt.Paint) color9);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color14 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape13, (java.awt.Paint) color14);
        legendGraphic10.setShape(shape13);
        java.awt.Color color17 = java.awt.Color.lightGray;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color19 = java.awt.Color.MAGENTA;
        int int20 = color19.getRed();
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape13, (java.awt.Paint) color17, stroke18, (java.awt.Paint) color19);
        java.lang.String str22 = legendItem21.getLabel();
        java.awt.Shape shape23 = legendItem21.getLine();
        boolean boolean24 = legendItemCollection1.equals((java.lang.Object) shape23);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity27 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) false, shape23, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "SortOrder.DESCENDING");
        java.lang.Comparable comparable28 = categoryLabelEntity27.getKey();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + false + "'", comparable28.equals(false));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color16 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape11, stroke15, (java.awt.Paint) color16);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, (double) (short) 1, (float) 100L, (float) 128);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity22 = new org.jfree.chart.entity.LegendItemEntity(shape21);
        java.lang.Object obj23 = legendItemEntity22.clone();
        java.lang.Object obj24 = legendItemEntity22.clone();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 100.0d, (java.lang.Number) (byte) 10);
        org.jfree.chart.axis.TickType tickType3 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer6.setSeriesFillPaint(0, (java.awt.Paint) color8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalBarRenderer6.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor11 = itemLabelPosition10.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick14 = new org.jfree.chart.axis.NumberTick(tickType3, (double) 255, "ItemLabelAnchor.OUTSIDE9", textAnchor11, textAnchor12, (double) (byte) 100);
        double double15 = numberTick14.getAngle();
        java.lang.String str16 = numberTick14.toString();
        org.jfree.chart.text.TextAnchor textAnchor17 = numberTick14.getTextAnchor();
        boolean boolean18 = meanAndStandardDeviation2.equals((java.lang.Object) numberTick14);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ItemLabelAnchor.OUTSIDE9" + "'", str16.equals("ItemLabelAnchor.OUTSIDE9"));
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot6.setDomainAxis(categoryAxis7);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot6.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
        categoryPlot6.setDomainAxisLocation((int) (short) 10, axisLocation13);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        jFreeChart18.setTitle("Layer.BACKGROUND");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer21 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer21.setSeriesFillPaint(0, (java.awt.Paint) color23);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = null;
        statisticalBarRenderer21.setSeriesURLGenerator(255, categoryURLGenerator26);
        statisticalBarRenderer21.setSeriesVisible(100, (java.lang.Boolean) false, true);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        statisticalBarRenderer21.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color33);
        jFreeChart18.setBorderPaint((java.awt.Paint) color33);
        java.awt.RenderingHints renderingHints36 = jFreeChart18.getRenderingHints();
        java.awt.Color color37 = java.awt.Color.WHITE;
        jFreeChart18.setBackgroundPaint((java.awt.Paint) color37);
        java.lang.String str39 = color37.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(renderingHints36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "java.awt.Color[r=255,g=255,b=255]" + "'", str39.equals("java.awt.Color[r=255,g=255,b=255]"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Paint paint5 = categoryPlot4.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getLegendItemGraphicEdge();
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = legendTitle6.getVerticalAlignment();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle6.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color12 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic8.setShape(shape11);
        java.awt.Color color15 = java.awt.Color.lightGray;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        int int18 = color17.getRed();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape11, (java.awt.Paint) color15, stroke16, (java.awt.Paint) color17);
        java.awt.Stroke stroke20 = legendItem19.getOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue(0.0d, true);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection30 = categoryPlot25.getRangeMarkers(layer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        int int32 = categoryPlot25.getIndexOf(categoryItemRenderer31);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier33 = categoryPlot25.getDrawingSupplier();
        boolean boolean34 = legendItem19.equals((java.lang.Object) categoryPlot25);
        legendItem19.setSeriesKey((java.lang.Comparable) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder37 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean38 = legendItem19.equals((java.lang.Object) blockBorder37);
        java.awt.Paint paint39 = legendItem19.getOutlinePaint();
        java.awt.Paint paint40 = legendItem19.getFillPaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(drawingSupplier33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(blockBorder37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] {};
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray7, comparableArray8, doubleArray9);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset10, (int) (short) 100);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset10, (double) (-1L));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot4.getRendererForDataset(categoryDataset10);
        java.awt.Paint paint16 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot19 = categoryPlot4.getParent();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot4.setRenderer(1, categoryItemRenderer21);
        boolean boolean23 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = null;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        categoryPlot4.zoomDomainAxes((double) ' ', plotRenderingInfo25, point2D28);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(point2D28);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        java.util.Locale locale1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        java.lang.Class<?> wildcardClass5 = textAnchor4.getClass();
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass5);
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("{0}", (java.lang.Class) wildcardClass5);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
        java.util.ResourceBundle.clearCache(classLoader8);
        try {
            java.util.ResourceBundle resourceBundle10 = java.util.ResourceBundle.getBundle("Size2D[width=255.0, height=10.0]", locale1, classLoader8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(uRL6);
        org.junit.Assert.assertNull(inputStream7);
        org.junit.Assert.assertNotNull(classLoader8);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer3.setSeriesFillPaint(0, (java.awt.Paint) color5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer3.getBasePositiveItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 255, "ItemLabelAnchor.OUTSIDE9", textAnchor8, textAnchor9, (double) (byte) 100);
        double double12 = numberTick11.getAngle();
        java.lang.String str13 = numberTick11.toString();
        org.jfree.chart.text.TextAnchor textAnchor14 = numberTick11.getRotationAnchor();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ItemLabelAnchor.OUTSIDE9" + "'", str13.equals("ItemLabelAnchor.OUTSIDE9"));
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        categoryPlot4.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation11, plotOrientation12);
        categoryPlot4.setDomainAxisLocation(15, axisLocation11);
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot20);
        flowArrangement15.add((org.jfree.chart.block.Block) legendTitle22, (java.lang.Object) (-16727872));
        java.awt.Paint paint25 = legendTitle22.getItemPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets();
        double double28 = rectangleInsets26.trimWidth((double) 1);
        legendTitle22.setItemLabelPadding(rectangleInsets26);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets();
        double double32 = rectangleInsets30.trimWidth((double) 1);
        boolean boolean33 = rectangleInsets26.equals((java.lang.Object) rectangleInsets30);
        categoryPlot4.setInsets(rectangleInsets26);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent35);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-1.0d) + "'", double28 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isTickLabelsVisible();
        double double3 = categoryAxis0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        categoryPlot11.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double17 = rectangleInsets15.calculateRightInset((double) 2);
        categoryPlot11.setInsets(rectangleInsets15, true);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets15.getUnitType();
        categoryPlot4.setAxisOffset(rectangleInsets15);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection25 = categoryPlot4.getDomainMarkers((int) 'a', layer24);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer26.setSeriesFillPaint(0, (java.awt.Paint) color28);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = statisticalBarRenderer26.getBasePositiveItemLabelPosition();
        java.awt.Paint paint33 = statisticalBarRenderer26.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke36 = statisticalBarRenderer26.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Paint paint38 = statisticalBarRenderer26.getSeriesPaint(10);
        java.awt.Color color39 = java.awt.Color.cyan;
        statisticalBarRenderer26.setBasePaint((java.awt.Paint) color39);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer26, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = statisticalBarRenderer26.getSeriesPositiveItemLabelPosition((int) '4');
        java.awt.Stroke stroke46 = statisticalBarRenderer26.getSeriesOutlineStroke((int) ' ');
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(itemLabelPosition44);
        org.junit.Assert.assertNull(stroke46);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str4 = verticalAlignment3.toString();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) rectangleAnchor2, (java.lang.Object) verticalAlignment3);
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment3, 0.0d, (double) 1);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement8);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color13 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic14 = new org.jfree.chart.title.LegendGraphic(shape12, (java.awt.Paint) color13);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color18 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape17, (java.awt.Paint) color18);
        legendGraphic14.setShape(shape17);
        boolean boolean21 = legendGraphic14.isShapeVisible();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer22.setSeriesFillPaint(0, (java.awt.Paint) color24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = statisticalBarRenderer22.getBasePositiveItemLabelPosition();
        java.awt.Paint paint29 = statisticalBarRenderer22.getItemFillPaint((int) (short) 100, 1);
        java.awt.Stroke stroke32 = statisticalBarRenderer22.getItemStroke((int) 'a', (int) (byte) 10);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color40 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic41 = new org.jfree.chart.title.LegendGraphic(shape39, (java.awt.Paint) color40);
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color45 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic46 = new org.jfree.chart.title.LegendGraphic(shape44, (java.awt.Paint) color45);
        legendGraphic41.setShape(shape44);
        java.awt.Stroke stroke48 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color49 = java.awt.Color.WHITE;
        org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem("Size2D[width=1.0, height=0.0]", "Layer.BACKGROUND", "ChartChangeEventType.GENERAL", "Size2D[width=1.0, height=0.0]", shape44, stroke48, (java.awt.Paint) color49);
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape44, (double) (short) 1, (float) 100L, (float) 128);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity55 = new org.jfree.chart.entity.LegendItemEntity(shape54);
        java.awt.Shape shape56 = legendItemEntity55.getArea();
        statisticalBarRenderer22.setBaseShape(shape56);
        java.awt.Paint paint59 = statisticalBarRenderer22.lookupSeriesFillPaint(10);
        columnArrangement8.add((org.jfree.chart.block.Block) legendGraphic14, (java.lang.Object) paint59);
        java.awt.Shape shape63 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color64 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic65 = new org.jfree.chart.title.LegendGraphic(shape63, (java.awt.Paint) color64);
        java.awt.Shape shape68 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color69 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic70 = new org.jfree.chart.title.LegendGraphic(shape68, (java.awt.Paint) color69);
        legendGraphic65.setShape(shape68);
        java.awt.Shape shape78 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color79 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic80 = new org.jfree.chart.title.LegendGraphic(shape78, (java.awt.Paint) color79);
        java.awt.Shape shape83 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) -1, 0.0f);
        java.awt.Color color84 = java.awt.Color.BLUE;
        org.jfree.chart.title.LegendGraphic legendGraphic85 = new org.jfree.chart.title.LegendGraphic(shape83, (java.awt.Paint) color84);
        legendGraphic80.setShape(shape83);
        java.awt.Color color87 = java.awt.Color.lightGray;
        java.awt.Stroke stroke88 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color89 = java.awt.Color.MAGENTA;
        int int90 = color89.getRed();
        org.jfree.chart.LegendItem legendItem91 = new org.jfree.chart.LegendItem("hi!", "VerticalAlignment.CENTER", "", "VerticalAlignment.CENTER", shape83, (java.awt.Paint) color87, stroke88, (java.awt.Paint) color89);
        java.awt.Stroke stroke92 = legendItem91.getOutlineStroke();
        legendGraphic65.setOutlineStroke(stroke92);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer94 = legendGraphic65.getFillPaintTransformer();
        legendGraphic14.setFillPaintTransformer(gradientPaintTransformer94);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "VerticalAlignment.CENTER" + "'", str4.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(shape78);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertNotNull(shape83);
        org.junit.Assert.assertNotNull(color84);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertNotNull(stroke88);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 255 + "'", int90 == 255);
        org.junit.Assert.assertNotNull(stroke92);
        org.junit.Assert.assertNotNull(gradientPaintTransformer94);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.awt.Paint paint1 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        statisticalBarRenderer2.setSeriesFillPaint(0, (java.awt.Paint) color4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        statisticalBarRenderer2.setSeriesURLGenerator(255, categoryURLGenerator7);
        statisticalBarRenderer2.setBaseSeriesVisible(true, false);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        statisticalBarRenderer2.setErrorIndicatorStroke(stroke12);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 2, paint1, stroke12);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot19.setDomainAxis(categoryAxis20);
        java.awt.Paint paint22 = categoryPlot19.getRangeGridlinePaint();
        boolean boolean23 = categoryPlot19.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        double double26 = categoryAxis25.getLabelAngle();
        double double27 = categoryAxis25.getCategoryMargin();
        java.lang.String str28 = categoryAxis25.getLabelToolTip();
        categoryAxis25.setVisible(false);
        categoryPlot19.setDomainAxis((int) (short) 100, categoryAxis25);
        valueMarker14.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot19);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = valueMarker14.getLabelOffsetType();
        org.jfree.data.KeyedObjects2D keyedObjects2D34 = new org.jfree.data.KeyedObjects2D();
        int int36 = keyedObjects2D34.getColumnIndex((java.lang.Comparable) 3.0d);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType37 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean38 = keyedObjects2D34.equals((java.lang.Object) chartChangeEventType37);
        boolean boolean39 = lengthAdjustmentType33.equals((java.lang.Object) keyedObjects2D34);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(lengthAdjustmentType33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(chartChangeEventType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) 1);
        double double3 = blockParams0.getTranslateX();
        double double4 = blockParams0.getTranslateX();
        blockParams0.setGenerateEntities(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        try {
            java.lang.String[] strArray5 = jFreeChartResources0.getStringArray("LegendItemEntity: seriesKey=null, dataset=null");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key LegendItemEntity: seriesKey=null, dataset=null");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Paint paint6 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot5);
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle7, (java.lang.Object) (-16727872));
        java.awt.Paint paint10 = legendTitle7.getItemPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.trimWidth((double) 1);
        legendTitle7.setItemLabelPadding(rectangleInsets11);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot19.setDomainAxis(categoryAxis20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        categoryPlot26.setAnchorValue(0.0d, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets();
        double double32 = rectangleInsets30.calculateRightInset((double) 2);
        categoryPlot26.setInsets(rectangleInsets30, true);
        org.jfree.chart.util.UnitType unitType35 = rectangleInsets30.getUnitType();
        categoryPlot19.setAxisOffset(rectangleInsets30);
        double double37 = rectangleInsets30.getBottom();
        legendTitle7.setMargin(rectangleInsets30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = legendTitle7.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(unitType35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setAnchorValue(0.0d, true);
        java.awt.Font font10 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("hi!", font10);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.GENERAL", font10);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent13 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle12);
        textTitle12.setText("ThreadContext");
        java.lang.String str16 = textTitle12.getID();
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(str16);
    }
}

