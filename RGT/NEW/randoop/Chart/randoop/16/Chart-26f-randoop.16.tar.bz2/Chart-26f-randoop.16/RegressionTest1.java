import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        boolean boolean2 = categoryAxis0.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues0.sortByKeys(sortOrder1);
        java.lang.Number number4 = null;
        defaultKeyedValues0.setValue((java.lang.Comparable) ' ', number4);
        java.lang.Object obj6 = defaultKeyedValues0.clone();
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Stroke stroke3 = stackedBarRenderer3D2.getBaseOutlineStroke();
        stackedBarRenderer3D2.setAutoPopulateSeriesShape(false);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D2.getLegendItem(0, (-1));
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(legendItem8);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.lang.Boolean boolean7 = stackedBarRenderer3D2.getSeriesCreateEntities(500);
        stackedBarRenderer3D2.setBaseSeriesVisible(true);
        boolean boolean11 = stackedBarRenderer3D2.isSeriesVisibleInLegend(11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.geom.Point2D point2D5 = null;
        xYPlot1.zoomRangeAxes(0.0d, plotRenderingInfo4, point2D5);
        java.awt.Stroke stroke7 = xYPlot1.getRangeCrosshairStroke();
        barRenderer0.setBaseStroke(stroke7);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) (-1));
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(1, false);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer15 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer15.setBaseCreateEntities(true, false);
        java.awt.Paint paint19 = ganttRenderer15.getCompletePaint();
        statisticalLineAndShapeRenderer2.setBaseFillPaint(paint19);
        int int21 = statisticalLineAndShapeRenderer2.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline3 = dateAxis1.getTimeline();
        dateAxis1.setAutoTickUnitSelection(false);
        double double6 = dateAxis1.getLabelAngle();
        dateAxis1.configure();
        dateAxis1.setUpperMargin((double) 3);
        boolean boolean10 = categoryAnchor0.equals((java.lang.Object) dateAxis1);
        java.lang.String str11 = categoryAnchor0.toString();
        boolean boolean13 = categoryAnchor0.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(timeline3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "CategoryAnchor.START" + "'", str11.equals("CategoryAnchor.START"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint6 = stackedBarRenderer3D4.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle7.setPosition(rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle7.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo12.getDataArea();
        rectangleInsets10.trim(rectangle2D13);
        plotRenderingInfo1.setPlotArea(rectangle2D13);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        dateAxis3.setStandardTickUnits(tickUnitSource7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean12 = stackedBarRenderer3D11.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke15 = stackedBarRenderer3D11.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis3.setAxisLineStroke(stroke15);
        stackedAreaRenderer0.setBaseStroke(stroke15);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font20 = dateAxis19.getTickLabelFont();
        stackedAreaRenderer0.setSeriesItemLabelFont((int) '4', font20);
        java.lang.Object obj22 = stackedAreaRenderer0.clone();
        java.awt.Paint paint24 = stackedAreaRenderer0.lookupSeriesOutlinePaint(9999);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = stackedAreaRenderer0.getLegendItems();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(legendItemCollection25);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("ThreadContext", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(9999, axisLocation7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline11 = dateAxis9.getTimeline();
        dateAxis9.setAutoTickUnitSelection(false);
        double double14 = dateAxis9.getLabelAngle();
        org.jfree.data.Range range15 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        xYPlot0.setOutlineVisible(false);
        java.awt.Stroke stroke18 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot0.getDomainAxisForDataset((int) (byte) 0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = xYPlot0.getRenderer();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeline11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNull(xYItemRenderer21);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        dateAxis0.setAutoTickUnitSelection(false);
        double double5 = dateAxis0.getLabelAngle();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = axisChangeEvent6.getType();
        java.lang.Object obj8 = axisChangeEvent6.getSource();
        org.jfree.chart.JFreeChart jFreeChart9 = axisChangeEvent6.getChart();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(jFreeChart9);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        try {
            java.lang.Comparable comparable4 = defaultCategoryDataset1.getRowKey((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("CategoryAnchor.START", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        boolean boolean1 = outlierListCollection0.isLowFarOut();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.Object obj1 = null;
        int int2 = numberTickUnit0.compareTo(obj1);
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        categoryMarker4.notifyListeners(markerChangeEvent5);
        java.lang.Object obj7 = categoryMarker4.clone();
        java.lang.Class<?> wildcardClass8 = categoryMarker4.getClass();
        boolean boolean9 = numberTickUnit0.equals((java.lang.Object) categoryMarker4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = categoryMarker4.getLabelOffsetType();
        java.awt.Paint paint11 = categoryMarker4.getLabelPaint();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        int int28 = defaultIntervalCategoryDataset27.getSeriesCount();
        try {
            int int30 = defaultIntervalCategoryDataset27.getCategoryIndex((java.lang.Comparable) "CategoryAnchor.START");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5 + "'", int28 == 5);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D2.getLegendItem((int) (short) -1, 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedBarRenderer3D2.getSeriesItemLabelGenerator(2);
        java.awt.Paint paint12 = stackedBarRenderer3D2.lookupSeriesOutlinePaint((-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = stackedBarRenderer3D2.getBaseURLGenerator();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Stroke stroke18 = stackedBarRenderer3D17.getBaseOutlineStroke();
        stackedBarRenderer3D2.setSeriesOutlineStroke((int) (byte) 1, stroke18);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryURLGenerator13);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 0.95f, (java.lang.Comparable) "ClassContext");
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) (-1));
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        double double7 = ringPlot6.getInnerSeparatorExtension();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        boolean boolean2 = categoryLabelWidthType0.equals((java.lang.Object) 'a');
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.data.Range range4 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        stackedBarRenderer3D7.setSeriesURLGenerator(10, categoryURLGenerator9);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset12);
        org.jfree.data.Range range14 = stackedBarRenderer3D7.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12);
        boolean boolean15 = range4.equals((java.lang.Object) range14);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer16.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint20 = dateAxis19.getLabelPaint();
        dateAxis19.setAutoTickUnitSelection(false);
        org.jfree.data.Range range23 = dateAxis19.getDefaultAutoRange();
        boolean boolean24 = intervalBarRenderer16.equals((java.lang.Object) range23);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange(range23);
        java.util.Date date26 = dateRange25.getUpperDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint(range4, (org.jfree.data.Range) dateRange25);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType28 = rectangleConstraint27.getHeightConstraintType();
        java.lang.String str29 = lengthConstraintType28.toString();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(lengthConstraintType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "RectangleConstraintType.RANGE" + "'", str29.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        int int28 = defaultIntervalCategoryDataset27.getSeriesCount();
        try {
            int int29 = defaultIntervalCategoryDataset27.getColumnCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5 + "'", int28 == 5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle5.setPosition(rectangleEdge6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Point2D point2D12 = null;
        xYPlot8.zoomRangeAxes(0.0d, plotRenderingInfo11, point2D12);
        java.awt.Paint paint14 = xYPlot8.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot8.getAxisOffset();
        double double17 = rectangleInsets15.calculateRightInset((double) 3600000L);
        legendTitle5.setMargin(rectangleInsets15);
        double double20 = rectangleInsets15.calculateRightOutset((double) (byte) 1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setUpperBound((double) 1L);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) (-1));
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(1, false);
        int int13 = statisticalLineAndShapeRenderer2.getPassCount();
        statisticalLineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        polarPlot6.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = polarPlot6.getOrientation();
        polarPlot6.removeCornerTextItem("hi!");
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(plotOrientation9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D9 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D7, rectangleAnchor8);
        xYPlot0.zoomRangeAxes((double) 500, plotRenderingInfo4, point2D9);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        stackedBarRenderer3D13.setSeriesURLGenerator(10, categoryURLGenerator15);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset18 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset18);
        org.jfree.data.Range range20 = stackedBarRenderer3D13.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset18);
        java.awt.Stroke stroke21 = stackedBarRenderer3D13.getBaseOutlineStroke();
        java.awt.Paint paint23 = stackedBarRenderer3D13.lookupSeriesFillPaint((int) (short) 0);
        xYPlot0.setBackgroundPaint(paint23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(point2D9);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = axisState0.getTicks();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        stackedBarRenderer3D4.setSeriesURLGenerator(10, categoryURLGenerator6);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset9);
        org.jfree.data.Range range11 = stackedBarRenderer3D4.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        java.util.List list12 = defaultCategoryDataset9.getRowKeys();
        axisState0.setTicks(list12);
        axisState0.cursorLeft((double) (short) 0);
        axisState0.cursorDown((double) (-1.0f));
        axisState0.setCursor((double) '4');
        axisState0.setCursor((double) 0.5f);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.lang.Boolean boolean7 = stackedBarRenderer3D2.getSeriesCreateEntities(500);
        stackedBarRenderer3D2.setBaseSeriesVisible(true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.geom.Point2D point2D16 = null;
        xYPlot12.zoomRangeAxes(0.0d, plotRenderingInfo15, point2D16);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState18 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj20 = numberAxis3D19.clone();
        numberAxis3D19.setAutoTickUnitSelection(false);
        numberAxis3D19.configure();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint27 = dateAxis26.getLabelPaint();
        dateAxis26.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer30 = null;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis26, polarItemRenderer30);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo34);
        java.awt.geom.Rectangle2D rectangle2D36 = plotRenderingInfo35.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D36, rectangleAnchor37);
        java.awt.Point point39 = polarPlot31.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D36);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double41 = numberAxis3D19.java2DToValue(4.0d, rectangle2D36, rectangleEdge40);
        plotRenderingInfo15.setPlotArea(rectangle2D36);
        try {
            stackedBarRenderer3D2.drawDomainGridline(graphics2D10, categoryPlot11, rectangle2D36, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertNotNull(point39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + Double.POSITIVE_INFINITY + "'", double41 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint7 = stackedBarRenderer3D5.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D5);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle8.setPosition(rectangleEdge9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle8.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo13.getDataArea();
        rectangleInsets11.trim(rectangle2D14);
        int int16 = numberTickUnit2.compareTo((java.lang.Object) rectangle2D14);
        try {
            xYPlot0.drawOutline(graphics2D1, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape10, "hi!", "");
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean19 = stackedBarRenderer3D18.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke22 = stackedBarRenderer3D18.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke26 = categoryMarker25.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint15, stroke22, (java.awt.Paint) color23, stroke26, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint30 = dateAxis29.getLabelPaint();
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape10, stroke22, paint30);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint40 = stackedBarRenderer3D38.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D38);
        java.awt.Shape shape44 = stackedBarRenderer3D38.getItemShape((int) '#', (int) ' ');
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent47 = null;
        categoryMarker46.notifyListeners(markerChangeEvent47);
        java.lang.Object obj49 = categoryMarker46.clone();
        java.awt.Paint paint50 = categoryMarker46.getPaint();
        java.awt.Paint paint51 = categoryMarker46.getLabelPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D54 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint56 = stackedBarRenderer3D54.lookupSeriesPaint((int) '4');
        categoryMarker46.setOutlinePaint(paint56);
        org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", "RectangleEdge.LEFT", "", "Size2D[width=0.0, height=0.0]", shape44, paint56);
        java.awt.Color color60 = java.awt.Color.CYAN;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo63 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo63);
        java.awt.geom.Point2D point2D65 = null;
        xYPlot61.zoomRangeAxes(0.0d, plotRenderingInfo64, point2D65);
        java.awt.Stroke stroke67 = xYPlot61.getRangeCrosshairStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker68 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 0, (java.awt.Paint) color60, stroke67);
        org.jfree.data.xy.XYDataset xYDataset69 = null;
        org.jfree.chart.axis.DateAxis dateAxis70 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint71 = dateAxis70.getLabelPaint();
        dateAxis70.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer74 = null;
        org.jfree.chart.plot.PolarPlot polarPlot75 = new org.jfree.chart.plot.PolarPlot(xYDataset69, (org.jfree.chart.axis.ValueAxis) dateAxis70, polarItemRenderer74);
        java.awt.Paint paint76 = polarPlot75.getAngleLabelPaint();
        try {
            org.jfree.chart.LegendItem legendItem77 = new org.jfree.chart.LegendItem(attributedString0, "RectangleConstraintType.RANGE", "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", "", shape10, paint56, stroke67, paint76);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(paint76);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = segmentedTimeline0.getBaseTimeline();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer2 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer2.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint6 = dateAxis5.getLabelPaint();
        dateAxis5.setAutoTickUnitSelection(false);
        org.jfree.data.Range range9 = dateAxis5.getDefaultAutoRange();
        boolean boolean10 = intervalBarRenderer2.equals((java.lang.Object) range9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(range9);
        java.util.Date date12 = dateRange11.getUpperDate();
        java.util.Date date13 = null;
        try {
            boolean boolean14 = segmentedTimeline1.containsDomainRange(date12, date13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNull(segmentedTimeline1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset1.removeColumn((java.lang.Comparable) 500);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        int int6 = defaultCategoryDataset1.getRowIndex((java.lang.Comparable) "hi!");
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 2.0d, (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        labelBlock2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder3);
        labelBlock2.setURLText("ItemLabelAnchor.OUTSIDE2");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Stroke stroke6 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation7 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("ChartChangeEventType.NEW_DATASET");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ChartChangeEventType.NEW_DATASET");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 0.95f, (java.lang.Comparable) "ClassContext");
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) (-1));
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        ringPlot6.setLabelOutlinePaint(paint7);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "hi!", "");
        java.awt.Shape shape6 = tickLabelEntity5.getArea();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint6 = stackedBarRenderer3D4.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getPosition();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint13 = stackedBarRenderer3D11.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D11);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle14.setPosition(rectangleEdge15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle14.getLegendItemGraphicPadding();
        double double18 = legendTitle14.getContentYOffset();
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("", font20);
        legendTitle14.setItemFont(font20);
        legendTitle7.setItemFont(font20);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.geom.Point2D point2D28 = null;
        xYPlot24.zoomRangeAxes(0.0d, plotRenderingInfo27, point2D28);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset31);
        xYPlot24.datasetChanged(datasetChangeEvent32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot24.getDomainAxisEdge();
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("RectangleEdge.LEFT", font20, (org.jfree.chart.plot.Plot) xYPlot24, false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor0, jFreeChart36);
        jFreeChart36.removeLegend();
        jFreeChart36.setBackgroundImageAlignment((int) (byte) -1);
        boolean boolean41 = jFreeChart36.getAntiAlias();
        java.awt.RenderingHints renderingHints42 = null;
        try {
            jFreeChart36.setRenderingHints(renderingHints42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        stackedBarRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator3);
        stackedBarRenderer3D2.setSeriesVisibleInLegend(4, (java.lang.Boolean) false, true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = defaultKeyedValues0.clone();
        defaultKeyedValues0.removeValue((java.lang.Comparable) 900000L);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        xYPlot0.setWeight(128);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint6 = dateAxis5.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis5.getTimeline();
        java.text.DateFormat dateFormat8 = null;
        dateAxis5.setDateFormatOverride(dateFormat8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        dateAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot10);
        org.jfree.data.Range range12 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = axisChangeEvent13.getType();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer4 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer4.setBaseCreateEntities(true, false);
        java.awt.Paint paint8 = ganttRenderer4.getCompletePaint();
        double double9 = ganttRenderer4.getStartPercent();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = intervalBarRenderer10.getSeriesNegativeItemLabelPosition(2);
        ganttRenderer4.setNegativeItemLabelPositionFallback(itemLabelPosition12);
        lineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(9999, itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.35d + "'", double9 == 0.35d);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator0 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity6 = new org.jfree.chart.entity.TickLabelEntity(shape3, "hi!", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset10);
        java.util.List list12 = defaultCategoryDataset10.getRowKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "hi!", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, (java.lang.Comparable) 0L, (java.lang.Comparable) "");
        java.lang.String str16 = categoryItemEntity15.getShapeType();
        java.lang.String str17 = categoryItemEntity15.getShapeCoords();
        categoryItemEntity15.setRowKey((java.lang.Comparable) 5);
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryItemEntity15.getDataset();
        try {
            java.lang.String str23 = standardCategoryURLGenerator0.generateURL(categoryDataset20, (int) 'a', 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "poly" + "'", str16.equals("poly"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0" + "'", str17.equals("-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0"));
        org.junit.Assert.assertNotNull(categoryDataset20);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(5);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint6 = stackedBarRenderer3D4.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getPosition();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint13 = stackedBarRenderer3D11.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D11);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle14.setPosition(rectangleEdge15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle14.getLegendItemGraphicPadding();
        double double18 = legendTitle14.getContentYOffset();
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("", font20);
        legendTitle14.setItemFont(font20);
        legendTitle7.setItemFont(font20);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.geom.Point2D point2D28 = null;
        xYPlot24.zoomRangeAxes(0.0d, plotRenderingInfo27, point2D28);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset31);
        xYPlot24.datasetChanged(datasetChangeEvent32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot24.getDomainAxisEdge();
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("RectangleEdge.LEFT", font20, (org.jfree.chart.plot.Plot) xYPlot24, false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor0, jFreeChart36);
        jFreeChart36.setAntiAlias(true);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        try {
            java.lang.Comparable comparable29 = defaultIntervalCategoryDataset27.getColumnKey(8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.Range range2 = new org.jfree.data.Range(10.0d, (double) 10);
        double double3 = range2.getCentralValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) blockBorder0, jFreeChart1, (int) (short) 10, (int) ' ');
        chartProgressEvent4.setPercent((int) (byte) -1);
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", "CategoryAnchor.START", "WMAP_Plot", "WMAP_Plot");
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        boolean boolean4 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlinePaint();
        stackedBarRenderer3D2.setMaximumBarWidth(0.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint11 = stackedBarRenderer3D9.lookupSeriesPaint((int) '4');
        stackedBarRenderer3D2.setBasePaint(paint11, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = null;
        try {
            stackedBarRenderer3D2.setBasePositiveItemLabelPosition(itemLabelPosition14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Color color1 = java.awt.Color.BLACK;
        java.awt.Color color2 = java.awt.Color.getColor("ChartChangeEventType.NEW_DATASET", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 3600000L, 12.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        boolean boolean6 = blockContainer5.isEmpty();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint11 = stackedBarRenderer3D9.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D9);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle12.setPosition(rectangleEdge13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle12.getLegendItemGraphicEdge();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo16 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray17 = basicProjectInfo16.getOptionalLibraries();
        blockContainer5.add((org.jfree.chart.block.Block) legendTitle12, (java.lang.Object) basicProjectInfo16);
        basicProjectInfo16.setInfo("");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(libraryArray17);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2019);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getPreviousDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint5 = dateAxis4.getLabelPaint();
        dateAxis4.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = null;
        dateAxis4.setStandardTickUnits(tickUnitSource8);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean13 = stackedBarRenderer3D12.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke16 = stackedBarRenderer3D12.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis4.setAxisLineStroke(stroke16);
        stackedAreaRenderer1.setBaseStroke(stroke16);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font21 = dateAxis20.getTickLabelFont();
        stackedAreaRenderer1.setSeriesItemLabelFont((int) '4', font21);
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("poly", font21);
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean29 = stackedBarRenderer3D28.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke32 = stackedBarRenderer3D28.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke36 = categoryMarker35.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint25, stroke32, (java.awt.Paint) color33, stroke36, 0.0f);
        labelBlock23.setPaint((java.awt.Paint) color33);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX((double) 1L);
        blockParams0.setGenerateEntities(false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(9999, axisLocation7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot0.getRenderer();
        boolean boolean10 = xYPlot0.isDomainZoomable();
        java.awt.Stroke stroke11 = xYPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) 10.0f, 0.0d);
        boolean boolean4 = gradientPaintTransformType0.equals((java.lang.Object) 10.0f);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        try {
            java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMinRegularValue(1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) 10.0f, 0.0d);
        org.jfree.chart.util.Size2D size2D10 = legendTitle5.arrange(graphics2D6, rectangleConstraint9);
        java.lang.String str11 = size2D10.toString();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, (double) (byte) 10, (double) 10, rectangleAnchor14);
        java.lang.String str16 = size2D10.toString();
        size2D10.width = (-2208960000000L);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str11.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str16.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) ' ', 0, (int) 'a');
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey(2019);
        org.junit.Assert.assertNull(comparable2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) '#', false);
        boolean boolean11 = xYPlot0.equals((java.lang.Object) 1.0d);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = xYPlot0.getLegendItems();
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(legendItemCollection12);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        ringPlot0.setShadowXOffset((double) 0);
        ringPlot0.setInnerSeparatorExtension(0.35d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D2.getLegendItem((int) (short) -1, 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedBarRenderer3D2.getSeriesItemLabelGenerator(2);
        stackedBarRenderer3D2.setIncludeBaseInRange(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.lang.Object[][] objArray1 = dataPackageResources0.getContents();
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean2 = standardCategoryToolTipGenerator0.equals((java.lang.Object) 100.0f);
        java.text.DateFormat dateFormat3 = standardCategoryToolTipGenerator0.getDateFormat();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset5);
        java.util.List list7 = defaultCategoryDataset5.getRowKeys();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5);
        try {
            java.lang.String str10 = standardCategoryToolTipGenerator0.generateRowLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(dateFormat3);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0d + "'", number8.equals(0.0d));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "hi!", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset9);
        java.util.List list11 = defaultCategoryDataset9.getRowKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity14 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "hi!", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, (java.lang.Comparable) 0L, (java.lang.Comparable) "");
        java.lang.String str15 = categoryItemEntity14.getShapeType();
        java.lang.String str16 = categoryItemEntity14.getShapeCoords();
        categoryItemEntity14.setRowKey((java.lang.Comparable) 5);
        java.lang.String str19 = categoryItemEntity14.getURLText();
        java.lang.String str20 = categoryItemEntity14.getShapeType();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "poly" + "'", str15.equals("poly"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0" + "'", str16.equals("-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ThreadContext" + "'", str19.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "poly" + "'", str20.equals("poly"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        int int28 = defaultIntervalCategoryDataset27.getSeriesCount();
        try {
            java.lang.Comparable comparable30 = defaultIntervalCategoryDataset27.getSeriesKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No such series : -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5 + "'", int28 == 5);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("org.jfree.data.time.TimePeriodFormatException: ClassContext", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        boolean boolean4 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlinePaint();
        stackedBarRenderer3D2.setMaximumBarWidth(0.0d);
        boolean boolean7 = stackedBarRenderer3D2.getIncludeBaseInRange();
        int int8 = stackedBarRenderer3D2.getColumnCount();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = stackedBarRenderer3D2.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = null;
        try {
            legendItemCollection9.addAll(legendItemCollection10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity6 = new org.jfree.chart.entity.TickLabelEntity(shape3, "hi!", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset10);
        java.util.List list12 = defaultCategoryDataset10.getRowKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "hi!", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, (java.lang.Comparable) 0L, (java.lang.Comparable) "");
        boolean boolean16 = basicProjectInfo0.equals((java.lang.Object) defaultCategoryDataset10);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 3600000L, 12.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        boolean boolean6 = blockContainer5.isEmpty();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint11 = stackedBarRenderer3D9.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D9);
        java.lang.Object obj13 = legendTitle12.clone();
        blockContainer5.add((org.jfree.chart.block.Block) legendTitle12);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint19 = stackedBarRenderer3D17.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = legendTitle20.getPosition();
        blockContainer5.add((org.jfree.chart.block.Block) legendTitle20);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        org.jfree.data.gantt.Task task4 = new org.jfree.data.gantt.Task("", (org.jfree.data.time.TimePeriod) simpleTimePeriod3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.lang.Object obj4 = categoryMarker1.clone();
        java.awt.Paint paint5 = categoryMarker1.getOutlinePaint();
        java.lang.Comparable comparable6 = categoryMarker1.getKey();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 10L + "'", comparable6.equals(10L));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        java.lang.String str2 = textBlockAnchor1.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str2.equals("TextBlockAnchor.TOP_CENTER"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setName("");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray4 = basicProjectInfo3.getOptionalLibraries();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
        org.jfree.chart.ui.Library[] libraryArray6 = projectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray4);
        org.junit.Assert.assertNotNull(libraryArray6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, 0, 128);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo6);
        java.awt.geom.Point2D point2D8 = null;
        xYPlot4.zoomRangeAxes(0.0d, plotRenderingInfo7, point2D8);
        int int10 = xYPlot4.getSeriesCount();
        java.awt.Font font11 = xYPlot4.getNoDataMessageFont();
        int int12 = xYPlot4.getRangeAxisCount();
        boolean boolean13 = segmentedTimeline3.equals((java.lang.Object) int12);
        try {
            boolean boolean15 = segmentedTimeline3.containsDomainValue((long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint5 = stackedBarRenderer3D3.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        java.lang.Object obj7 = legendTitle6.clone();
        java.awt.Color color10 = java.awt.Color.getColor("TextBlockAnchor.TOP_CENTER", (int) (byte) 0);
        centerArrangement0.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) "TextBlockAnchor.TOP_CENTER");
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.lang.String str2 = ringPlot0.getPlotType();
        ringPlot0.setLabelLinksVisible(false);
        ringPlot0.setSeparatorsVisible(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0", graphics2D1, (float) (-460), (float) (-457), textAnchor4, (double) 500, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(9999, axisLocation7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline11 = dateAxis9.getTimeline();
        dateAxis9.setAutoTickUnitSelection(false);
        double double14 = dateAxis9.getLabelAngle();
        org.jfree.data.Range range15 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        xYPlot0.setOutlineVisible(false);
        java.awt.Stroke stroke18 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint20 = dateAxis19.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline21 = dateAxis19.getTimeline();
        dateAxis19.setAutoTickUnitSelection(false);
        double double24 = dateAxis19.getLabelAngle();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis19);
        xYPlot0.axisChanged(axisChangeEvent25);
        org.jfree.chart.plot.Marker marker27 = null;
        try {
            xYPlot0.addRangeMarker(marker27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeline11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(timeline21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        boolean boolean6 = stackedBarRenderer3D2.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues0.sortByKeys(sortOrder1);
        java.lang.Number number4 = null;
        defaultKeyedValues0.setValue((java.lang.Comparable) ' ', number4);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues6 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder7 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues6.sortByKeys(sortOrder7);
        defaultKeyedValues0.sortByKeys(sortOrder7);
        java.util.List list10 = defaultKeyedValues0.getKeys();
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendTitle5.getLegendItemGraphicLocation();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font8);
        java.lang.String str10 = labelBlock9.getToolTipText();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer12.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint16 = dateAxis15.getLabelPaint();
        dateAxis15.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = null;
        dateAxis15.setStandardTickUnits(tickUnitSource19);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean24 = stackedBarRenderer3D23.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke27 = stackedBarRenderer3D23.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis15.setAxisLineStroke(stroke27);
        stackedAreaRenderer12.setBaseStroke(stroke27);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font32 = dateAxis31.getTickLabelFont();
        stackedAreaRenderer12.setSeriesItemLabelFont((int) '4', font32);
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("poly", font32);
        labelBlock34.setURLText("TextBlockAnchor.TOP_CENTER");
        org.jfree.chart.block.BlockBorder blockBorder37 = org.jfree.chart.block.BlockBorder.NONE;
        labelBlock34.setFrame((org.jfree.chart.block.BlockFrame) blockBorder37);
        labelBlock9.setFrame((org.jfree.chart.block.BlockFrame) blockBorder37);
        legendTitle5.setFrame((org.jfree.chart.block.BlockFrame) blockBorder37);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(blockBorder37);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D2.getLegendItem((int) (short) -1, 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedBarRenderer3D2.getSeriesItemLabelGenerator(2);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator12 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        stackedBarRenderer3D2.setSeriesURLGenerator(500, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues0.sortByKeys(sortOrder1);
        java.lang.Number number4 = null;
        defaultKeyedValues0.setValue((java.lang.Comparable) ' ', number4);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer6.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        dateAxis9.setAutoTickUnitSelection(false);
        org.jfree.data.Range range13 = dateAxis9.getDefaultAutoRange();
        boolean boolean14 = intervalBarRenderer6.equals((java.lang.Object) range13);
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange(range13);
        java.util.Date date16 = dateRange15.getLowerDate();
        defaultKeyedValues0.removeValue((java.lang.Comparable) date16);
        java.lang.Comparable comparable18 = null;
        try {
            java.lang.Number number19 = defaultKeyedValues0.getValue(comparable18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            java.lang.Number number4 = defaultKeyedValues2D1.getValue((java.lang.Comparable) "RangeType.FULL", (java.lang.Comparable) 2);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 2");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 3600000L, 12.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        boolean boolean6 = blockContainer5.isEmpty();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        stackedBarRenderer3D10.setSeriesURLGenerator(10, categoryURLGenerator12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D10.getBaseNegativeItemLabelPosition();
        stackedBarRenderer3D10.setBaseSeriesVisibleInLegend(false);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint20 = dateAxis19.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline21 = dateAxis19.getTimeline();
        dateAxis19.setAutoTickUnitSelection(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        categoryMarker25.notifyListeners(markerChangeEvent26);
        java.lang.Object obj28 = categoryMarker25.clone();
        java.awt.Paint paint29 = categoryMarker25.getOutlinePaint();
        java.awt.Font font31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("", font31);
        org.jfree.chart.block.BlockBorder blockBorder33 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = blockBorder33.getInsets();
        labelBlock32.setFrame((org.jfree.chart.block.BlockFrame) blockBorder33);
        labelBlock32.setPadding(0.0d, 0.0d, 0.0d, (double) 5);
        double double41 = labelBlock32.getWidth();
        java.awt.geom.Rectangle2D rectangle2D42 = labelBlock32.getBounds();
        stackedBarRenderer3D10.drawRangeMarker(graphics2D17, categoryPlot18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.plot.Marker) categoryMarker25, rectangle2D42);
        try {
            blockContainer5.draw(graphics2D7, rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(timeline21);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(blockBorder33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D42);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer2 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.LegendItem legendItem5 = areaRenderer2.getLegendItem(1, 3);
        java.awt.Paint paint6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        areaRenderer2.setBaseFillPaint(paint6, false);
        levelRenderer0.setSeriesItemLabelPaint((int) (byte) 10, paint6, false);
        org.junit.Assert.assertNull(legendItem5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setBaseCreateEntities(true, false);
        java.awt.Paint paint4 = ganttRenderer0.getCompletePaint();
        double double5 = ganttRenderer0.getStartPercent();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = intervalBarRenderer6.getSeriesNegativeItemLabelPosition(2);
        ganttRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition8);
        java.awt.Paint paint12 = ganttRenderer0.getItemOutlinePaint((-1), 10);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.35d + "'", double5 == 0.35d);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable1 = null;
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getValue(comparable1, (java.lang.Comparable) 9999);
        java.lang.Object obj4 = null;
        boolean boolean5 = defaultStatisticalCategoryDataset0.equals(obj4);
        java.util.List list6 = defaultStatisticalCategoryDataset0.getRowKeys();
        int int8 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.time.TimePeriodFormatException: ClassContext", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        int int1 = ganttRenderer0.getRowCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        java.lang.Comparable comparable3 = null;
        defaultCategoryDataset1.removeColumn(comparable3);
        java.lang.Object obj5 = defaultCategoryDataset1.clone();
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2019);
        java.lang.String str2 = serialDate1.getDescription();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        ringPlot0.setLabelBackgroundPaint(paint1);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType3 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        boolean boolean4 = ringPlot0.equals((java.lang.Object) gradientPaintTransformType3);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity7 = new org.jfree.chart.entity.TickLabelEntity(shape4, "hi!", "");
        dateAxis0.setLeftArrow(shape4);
        dateAxis0.configure();
        dateAxis0.configure();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("poly");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = plotRenderingInfo16.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D17, rectangleAnchor18);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint25 = stackedBarRenderer3D23.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D23);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle26.setPosition(rectangleEdge27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle26.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo31.getDataArea();
        rectangleInsets29.trim(rectangle2D32);
        int int34 = numberTickUnit20.compareTo((java.lang.Object) rectangle2D32);
        boolean boolean35 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D17, rectangle2D32);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis13.valueToJava2D((double) 10.0f, rectangle2D17, rectangleEdge36);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint42 = stackedBarRenderer3D40.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D40);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle43.setPosition(rectangleEdge44);
        double double46 = dateAxis0.lengthToJava2D((double) 0L, rectangle2D17, rectangleEdge44);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition47 = dateAxis0.getTickMarkPosition();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition47);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(4, (int) (short) -1);
        int int3 = dateTickUnit2.getRollUnit();
        java.lang.String str4 = dateTickUnit2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DateTickUnit[MINUTE, -1]" + "'", str4.equals("DateTickUnit[MINUTE, -1]"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle5.setPosition(rectangleEdge6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle5.getLegendItemGraphicPadding();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        legendTitle5.setBackgroundPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition3);
        boolean boolean5 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) true, false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset11);
        java.lang.Comparable comparable13 = null;
        defaultCategoryDataset11.removeColumn(comparable13);
        org.jfree.data.Range range15 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        stackedBarRenderer3D2.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(9999, axisLocation7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline11 = dateAxis9.getTimeline();
        dateAxis9.setAutoTickUnitSelection(false);
        double double14 = dateAxis9.getLabelAngle();
        org.jfree.data.Range range15 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot0.getInsets();
        double double18 = rectangleInsets16.calculateBottomOutset((double) (short) 0);
        double double20 = rectangleInsets16.calculateBottomOutset((double) 0.5f);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeline11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        dateAxis0.setAutoTickUnitSelection(false);
        double double5 = dateAxis0.getLabelAngle();
        dateAxis0.configure();
        dateAxis0.setTickMarkInsideLength((float) (short) -1);
        double double9 = dateAxis0.getUpperMargin();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer10.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint14 = dateAxis13.getLabelPaint();
        dateAxis13.setAutoTickUnitSelection(false);
        org.jfree.data.Range range17 = dateAxis13.getDefaultAutoRange();
        boolean boolean18 = intervalBarRenderer10.equals((java.lang.Object) range17);
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange(range17);
        java.util.Date date20 = dateRange19.getLowerDate();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isAutoTickUnitSelection();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity28 = new org.jfree.chart.entity.TickLabelEntity(shape25, "hi!", "");
        dateAxis21.setLeftArrow(shape25);
        dateAxis21.configure();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date34 = simpleTimePeriod33.getEnd();
        dateAxis21.setMinimumDate(date34);
        try {
            dateAxis0.setRange(date20, date34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        ringPlot0.setLabelBackgroundPaint(paint1);
        double double3 = ringPlot0.getShadowXOffset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        int int6 = xYPlot0.getSeriesCount();
        java.awt.Font font7 = xYPlot0.getNoDataMessageFont();
        int int8 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot0.setDrawingSupplier(drawingSupplier9);
        xYPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        int int7 = xYPlot0.getWeight();
        java.awt.Paint paint8 = xYPlot0.getBackgroundPaint();
        xYPlot0.setForegroundAlpha(0.0f);
        double double11 = xYPlot0.getRangeCrosshairValue();
        boolean boolean12 = xYPlot0.isRangeGridlinesVisible();
        java.util.List list13 = xYPlot0.getAnnotations();
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 128);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.data.Range range7 = dateAxis3.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint2.toRangeHeight(range7);
        double double9 = rectangleConstraint2.getWidth();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        org.jfree.data.Range range9 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        java.awt.Stroke stroke10 = stackedBarRenderer3D2.getBaseOutlineStroke();
        java.awt.Paint paint12 = stackedBarRenderer3D2.lookupSeriesFillPaint((int) (short) 0);
        double double13 = stackedBarRenderer3D2.getLowerClip();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("", font16);
        org.jfree.chart.block.BlockBorder blockBorder18 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        labelBlock17.setFrame((org.jfree.chart.block.BlockFrame) blockBorder18);
        labelBlock17.setPadding(0.0d, 0.0d, 0.0d, (double) 5);
        double double26 = labelBlock17.getWidth();
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock17.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState31 = stackedBarRenderer3D2.initialise(graphics2D14, rectangle2D27, categoryPlot28, (int) (byte) 1, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(blockBorder18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer0.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.data.Range range7 = dateAxis3.getDefaultAutoRange();
        boolean boolean8 = intervalBarRenderer0.equals((java.lang.Object) range7);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(range7);
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range10, (double) 128);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint14 = dateAxis13.getLabelPaint();
        dateAxis13.setAutoTickUnitSelection(false);
        org.jfree.data.Range range17 = dateAxis13.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint12.toRangeHeight(range17);
        org.jfree.data.Range range19 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange9, range17);
        double double20 = dateRange9.getCentralValue();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5d + "'", double20 == 0.5d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        dateAxis0.setAutoTickUnitSelection(false);
        double double5 = dateAxis0.getLabelAngle();
        dateAxis0.configure();
        dateAxis0.setVerticalTickLabels(true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = axisState0.getTicks();
        double double2 = axisState0.getCursor();
        axisState0.setCursor((double) (-2208960000000L));
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer0.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.data.Range range7 = dateAxis3.getDefaultAutoRange();
        boolean boolean8 = intervalBarRenderer0.equals((java.lang.Object) range7);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(range7);
        java.util.Date date10 = dateRange9.getLowerDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange9, (double) 900000L);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Third", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.data.general.Dataset dataset2 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) numberAxis1, dataset2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = numberAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(numberTickUnit4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        java.text.DateFormat dateFormat3 = null;
        dateAxis0.setDateFormatOverride(dateFormat3);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo6.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D9 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D7, rectangleAnchor8);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint15 = stackedBarRenderer3D13.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D13);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle16.setPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = legendTitle16.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo21.getDataArea();
        rectangleInsets19.trim(rectangle2D22);
        int int24 = numberTickUnit10.compareTo((java.lang.Object) rectangle2D22);
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D7, rectangle2D22);
        boolean boolean26 = dateAxis0.equals((java.lang.Object) boolean25);
        dateAxis0.setLowerMargin(0.65d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(point2D9);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint8 = stackedBarRenderer3D6.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D6);
        java.awt.Shape shape12 = stackedBarRenderer3D6.getItemShape((int) '#', (int) ' ');
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        categoryMarker14.notifyListeners(markerChangeEvent15);
        java.lang.Object obj17 = categoryMarker14.clone();
        java.awt.Paint paint18 = categoryMarker14.getPaint();
        java.awt.Paint paint19 = categoryMarker14.getLabelPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint24 = stackedBarRenderer3D22.lookupSeriesPaint((int) '4');
        categoryMarker14.setOutlinePaint(paint24);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", "RectangleEdge.LEFT", "", "Size2D[width=0.0, height=0.0]", shape12, paint24);
        java.awt.Stroke stroke27 = legendItem26.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        double double2 = layeredBarRenderer0.getSeriesBarWidth((int) (byte) 100);
        double double4 = layeredBarRenderer0.getSeriesBarWidth(0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) (-1));
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(1, false);
        java.lang.Boolean boolean14 = statisticalLineAndShapeRenderer2.getSeriesVisibleInLegend(15);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean14);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 0.95f, (java.lang.Comparable) "ClassContext");
        java.util.List list4 = defaultStatisticalCategoryDataset0.getRowKeys();
        java.util.List list5 = defaultStatisticalCategoryDataset0.getRowKeys();
        try {
            java.lang.Number number8 = defaultStatisticalCategoryDataset0.getMeanValue(128, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Point2D point2D11 = null;
        xYPlot7.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11);
        java.awt.Paint paint13 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke16 = categoryMarker15.getOutlineStroke();
        xYPlot7.setDomainCrosshairStroke(stroke16);
        boolean boolean18 = xYPlot7.isRangeZeroBaselineVisible();
        xYPlot7.setDomainCrosshairValue((double) (short) -1);
        java.awt.geom.Point2D point2D21 = xYPlot7.getQuadrantOrigin();
        java.awt.Paint paint22 = xYPlot7.getBackgroundPaint();
        polarPlot6.setRadiusGridlinePaint(paint22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.data.general.Dataset dataset26 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) numberAxis25, dataset26);
        polarPlot6.datasetChanged(datasetChangeEvent27);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.Object obj1 = null;
        int int2 = numberTickUnit0.compareTo(obj1);
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        categoryMarker4.notifyListeners(markerChangeEvent5);
        java.lang.Object obj7 = categoryMarker4.clone();
        java.lang.Class<?> wildcardClass8 = categoryMarker4.getClass();
        boolean boolean9 = numberTickUnit0.equals((java.lang.Object) categoryMarker4);
        java.awt.Stroke stroke10 = categoryMarker4.getStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker4);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        boolean boolean4 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition();
        stackedBarRenderer3D2.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition6, false);
        double double9 = stackedBarRenderer3D2.getBase();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        stackedBarRenderer3D2.setBaseStroke(stroke10);
        boolean boolean12 = stackedBarRenderer3D2.getBaseItemLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem(attributedString0, "ClassContext", "", "ThreadContext", shape4, paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        dateAxis0.zoomRange(4.0d, 100.0d);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setBaseCreateEntities(true, false);
        java.awt.Paint paint4 = ganttRenderer0.getCompletePaint();
        double double5 = ganttRenderer0.getStartPercent();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer6 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = intervalBarRenderer6.getSeriesNegativeItemLabelPosition(2);
        ganttRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = ganttRenderer0.getNegativeItemLabelPosition(15, 0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.35d + "'", double5 == 0.35d);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 12.0d, (java.lang.Number) Double.POSITIVE_INFINITY);
        defaultKeyedValue2.setValue((java.lang.Number) 6);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        xYPlot0.setDomainCrosshairValue((double) 3600000L);
        java.awt.Paint paint8 = xYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        legendItem27.setSeriesKey((java.lang.Comparable) 1.0E-5d);
        java.awt.Stroke stroke30 = legendItem27.getLineStroke();
        java.awt.Paint paint31 = legendItem27.getLinePaint();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj1 = numberAxis3D0.clone();
        numberAxis3D0.setAutoTickUnitSelection(false);
        numberAxis3D0.configure();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint11 = dateAxis10.getLabelPaint();
        dateAxis10.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, polarItemRenderer14);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo19.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D22 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor21);
        java.awt.Point point23 = polarPlot15.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D20);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0f);
        java.awt.Font font26 = categoryMarker25.getLabelFont();
        polarPlot15.setNoDataMessageFont(font26);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) '4', 0.0d, 0.0d, (double) 3, font26);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertNotNull(point23);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint5 = dateAxis4.getLabelPaint();
        dateAxis4.setFixedDimension((double) (short) 10);
        double double8 = dateAxis4.getFixedDimension();
        dateAxis4.setTickMarkOutsideLength((float) 60000L);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(9999, axisLocation7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline11 = dateAxis9.getTimeline();
        dateAxis9.setAutoTickUnitSelection(false);
        double double14 = dateAxis9.getLabelAngle();
        org.jfree.data.Range range15 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot0.getInsets();
        double double18 = rectangleInsets16.calculateBottomOutset((double) (short) 0);
        double double19 = rectangleInsets16.getBottom();
        double double21 = rectangleInsets16.calculateTopOutset((double) 10);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeline11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis3, polarItemRenderer7);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo12.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D15 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D13, rectangleAnchor14);
        java.awt.Point point16 = polarPlot8.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D13);
        int int17 = polarPlot8.getBackgroundImageAlignment();
        boolean boolean18 = verticalAlignment1.equals((java.lang.Object) int17);
        org.jfree.chart.block.ColumnArrangement columnArrangement21 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 10L, (double) 0);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNotNull(point16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        int int3 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        dateAxis0.setAutoTickUnitSelection(false);
        double double5 = dateAxis0.getLabelAngle();
        dateAxis0.configure();
        double double7 = dateAxis0.getFixedAutoRange();
        java.awt.Shape shape8 = dateAxis0.getDownArrow();
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        polarPlot6.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = polarPlot6.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        polarPlot6.setDataset(xYDataset10);
        double double12 = polarPlot6.getMaxRadius();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        xYPlot13.zoomRangeAxes(0.0d, plotRenderingInfo16, point2D17);
        java.awt.Stroke stroke19 = xYPlot13.getRangeCrosshairStroke();
        boolean boolean20 = polarPlot6.equals((java.lang.Object) stroke19);
        int int21 = polarPlot6.getBackgroundImageAlignment();
        polarPlot6.setAngleLabelsVisible(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        int int1 = defaultBoxAndWhiskerCategoryDataset0.getColumnCount();
        try {
            java.lang.Number number4 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value(500, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke9);
        boolean boolean11 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setDomainCrosshairValue((double) (short) -1);
        org.jfree.chart.plot.Plot plot14 = xYPlot0.getRootPlot();
        int int15 = xYPlot0.getWeight();
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setSeriesVisible(100, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem6 = stackedAreaRenderer0.getLegendItem((int) (byte) 1, 0);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.0d, (double) '#');
        java.lang.Number number3 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 35.0d + "'", number3.equals(35.0d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font2 = dateAxis1.getTickLabelFont();
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean10 = chartColor6.equals((java.lang.Object) 'a');
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) chartColor6);
        float[] floatArray12 = new float[] {};
        try {
            float[] floatArray13 = chartColor6.getRGBColorComponents(floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        int int8 = stackedBarRenderer3D2.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = stackedBarRenderer3D2.getSeriesPositiveItemLabelPosition((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "hi!", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset9);
        java.util.List list11 = defaultCategoryDataset9.getRowKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity14 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "hi!", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, (java.lang.Comparable) 0L, (java.lang.Comparable) "");
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, true);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, (java.lang.Comparable) year17);
        double double21 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset20);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(pieDataset20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop(Double.NaN);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo6);
        java.awt.geom.Point2D point2D8 = null;
        xYPlot4.zoomRangeAxes(0.0d, plotRenderingInfo7, point2D8);
        java.awt.Paint paint10 = xYPlot4.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke13 = categoryMarker12.getOutlineStroke();
        xYPlot4.setDomainCrosshairStroke(stroke13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot4.getDomainAxisEdge();
        axisSpace0.ensureAtLeast((double) 900000L, rectangleEdge15);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = stackedBarRenderer3D2.getLegendItemURLGenerator();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryMarker11.notifyListeners(markerChangeEvent12);
        org.jfree.chart.text.TextAnchor textAnchor14 = categoryMarker11.getLabelTextAnchor();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer16.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint20 = dateAxis19.getLabelPaint();
        dateAxis19.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = null;
        dateAxis19.setStandardTickUnits(tickUnitSource23);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean28 = stackedBarRenderer3D27.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke31 = stackedBarRenderer3D27.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis19.setAxisLineStroke(stroke31);
        stackedAreaRenderer16.setBaseStroke(stroke31);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font36 = dateAxis35.getTickLabelFont();
        stackedAreaRenderer16.setSeriesItemLabelFont((int) '4', font36);
        org.jfree.chart.block.LabelBlock labelBlock38 = new org.jfree.chart.block.LabelBlock("poly", font36);
        labelBlock38.setURLText("TextBlockAnchor.TOP_CENTER");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj42 = numberAxis3D41.clone();
        numberAxis3D41.setAutoTickUnitSelection(false);
        numberAxis3D41.configure();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo47);
        java.awt.geom.Rectangle2D rectangle2D49 = plotRenderingInfo48.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double51 = numberAxis3D41.lengthToJava2D((double) 9999, rectangle2D49, rectangleEdge50);
        labelBlock38.setBounds(rectangle2D49);
        try {
            stackedBarRenderer3D2.drawDomainMarker(graphics2D7, categoryPlot8, categoryAxis9, categoryMarker11, rectangle2D49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Stroke stroke6 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        java.awt.Stroke stroke8 = null;
        try {
            xYPlot0.setRangeGridlineStroke(stroke8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        java.awt.Shape shape8 = stackedBarRenderer3D2.getItemShape((int) '#', (int) ' ');
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape8, 12.0d, 0.2d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(4);
        java.lang.Object obj3 = objectList1.get((-457));
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = axisState0.getTicks();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        stackedBarRenderer3D4.setSeriesURLGenerator(10, categoryURLGenerator6);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset9);
        org.jfree.data.Range range11 = stackedBarRenderer3D4.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        java.util.List list12 = defaultCategoryDataset9.getRowKeys();
        axisState0.setTicks(list12);
        java.util.List list14 = axisState0.getTicks();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.lang.Object obj4 = categoryMarker1.clone();
        java.awt.Paint paint5 = categoryMarker1.getPaint();
        java.lang.Comparable comparable6 = categoryMarker1.getKey();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 10L + "'", comparable6.equals(10L));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        ringPlot0.setShadowXOffset((double) 0);
        int int4 = ringPlot0.getPieIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) (-1));
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(1, false);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.LegendItem legendItem17 = statisticalLineAndShapeRenderer2.getLegendItem((int) '#', 1);
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        statisticalLineAndShapeRenderer2.setBaseOutlinePaint(paint18, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(legendItem17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        java.awt.Color color3 = java.awt.Color.green;
        statisticalLineAndShapeRenderer2.setBaseFillPaint((java.awt.Paint) color3, false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        statisticalLineAndShapeRenderer2.setErrorIndicatorPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("ThreadContext");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = dateAxis1.getStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        xYPlot0.setRangeCrosshairValue((double) (byte) 100);
        xYPlot0.clearDomainMarkers();
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(xYDataset6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setName("");
        java.lang.String str3 = projectInfo0.getVersion();
        java.lang.String str4 = projectInfo0.getLicenceName();
        projectInfo0.setLicenceName("ThreadContext");
        projectInfo0.setCopyright("Size2D[width=0.0, height=0.0]");
        java.lang.String str9 = projectInfo0.getName();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (-1.0d), (double) 0.95f, 10.0d, (double) 10.0f, font5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        stackedBarRenderer3D9.setSeriesURLGenerator(10, categoryURLGenerator11);
        java.awt.Stroke stroke15 = stackedBarRenderer3D9.getItemOutlineStroke((int) (byte) -1, 2019);
        boolean boolean16 = markerAxisBand6.equals((java.lang.Object) 2019);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0");
        numberAxis1.setTickLabelsVisible(true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem3 = defaultBoxAndWhiskerCategoryDataset0.getItem(6, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        org.jfree.data.Range range9 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) 9999);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, (java.lang.Comparable) "Third");
        java.lang.Comparable comparable16 = null;
        try {
            defaultCategoryDataset7.addValue((java.lang.Number) 5, (java.lang.Comparable) 0.35d, comparable16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(pieDataset13);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint6 = dateAxis5.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis5.getTimeline();
        dateAxis5.setAutoTickUnitSelection(false);
        double double10 = dateAxis5.getLabelAngle();
        dateAxis5.configure();
        dateAxis5.setUpperMargin((double) 3);
        boolean boolean14 = categoryAnchor4.equals((java.lang.Object) dateAxis5);
        boolean boolean15 = simpleTimePeriod2.equals((java.lang.Object) categoryAnchor4);
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray35 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray40 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray41 = new java.lang.Number[][] { numberArray20, numberArray25, numberArray30, numberArray35, numberArray40 };
        java.lang.Number[][] numberArray42 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset43 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray41, numberArray42);
        int int44 = defaultIntervalCategoryDataset43.getSeriesCount();
        try {
            int int45 = simpleTimePeriod2.compareTo((java.lang.Object) defaultIntervalCategoryDataset43);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.category.DefaultIntervalCategoryDataset cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(categoryAnchor4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray35);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(numberArray41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 5 + "'", int44 == 5);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesFillPaint(1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint6 = stackedBarRenderer3D4.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getPosition();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint13 = stackedBarRenderer3D11.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D11);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle14.setPosition(rectangleEdge15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle14.getLegendItemGraphicPadding();
        double double18 = legendTitle14.getContentYOffset();
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("", font20);
        legendTitle14.setItemFont(font20);
        legendTitle7.setItemFont(font20);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.geom.Point2D point2D28 = null;
        xYPlot24.zoomRangeAxes(0.0d, plotRenderingInfo27, point2D28);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset31);
        xYPlot24.datasetChanged(datasetChangeEvent32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot24.getDomainAxisEdge();
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("RectangleEdge.LEFT", font20, (org.jfree.chart.plot.Plot) xYPlot24, false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor0, jFreeChart36);
        java.util.List list38 = jFreeChart36.getSubtitles();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(list38);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        xYPlot0.setRangeCrosshairValue((double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = xYPlot0.getInsets();
        java.awt.Color color6 = java.awt.Color.CYAN;
        int int7 = color6.getTransparency();
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = year3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.next();
        long long6 = year3.getLastMillisecond();
        java.lang.Number number8 = defaultBoxAndWhiskerCategoryDataset0.getMinOutlier((java.lang.Comparable) long6, (java.lang.Comparable) 0.2d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        boolean boolean8 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlineStroke();
        stackedBarRenderer3D2.setItemMargin((double) (byte) 0);
        stackedBarRenderer3D2.setMinimumBarLength((double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = stackedBarRenderer3D2.getURLGenerator((int) (short) 0, 6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryURLGenerator15);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight((double) 'a');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        dateAxis3.setStandardTickUnits(tickUnitSource7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean12 = stackedBarRenderer3D11.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke15 = stackedBarRenderer3D11.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis3.setAxisLineStroke(stroke15);
        stackedAreaRenderer0.setBaseStroke(stroke15);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font20 = dateAxis19.getTickLabelFont();
        stackedAreaRenderer0.setSeriesItemLabelFont((int) '4', font20);
        org.jfree.chart.LegendItem legendItem24 = stackedAreaRenderer0.getLegendItem(0, (int) (short) 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator25 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean27 = standardCategoryToolTipGenerator25.equals((java.lang.Object) 100.0f);
        stackedAreaRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator25);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = null;
        stackedBarRenderer3D31.setSeriesURLGenerator(10, categoryURLGenerator33);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset36 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset36);
        org.jfree.data.Range range38 = stackedBarRenderer3D31.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset36);
        java.util.List list39 = defaultCategoryDataset36.getRowKeys();
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity49 = new org.jfree.chart.entity.TickLabelEntity(shape46, "hi!", "");
        java.awt.Paint paint51 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D54 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean55 = stackedBarRenderer3D54.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke58 = stackedBarRenderer3D54.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke62 = categoryMarker61.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker64 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint51, stroke58, (java.awt.Paint) color59, stroke62, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint66 = dateAxis65.getLabelPaint();
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape46, stroke58, paint66);
        boolean boolean68 = defaultCategoryDataset36.equals((java.lang.Object) "ThreadContext");
        int int70 = defaultCategoryDataset36.getRowIndex((java.lang.Comparable) (-1.0f));
        try {
            java.lang.String str72 = standardCategoryToolTipGenerator25.generateRowLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset36, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) "12/31/69");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.data.Range range6 = dateAxis2.getDefaultAutoRange();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        stackedBarRenderer3D9.setSeriesURLGenerator(10, categoryURLGenerator11);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset14 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset14);
        org.jfree.data.Range range16 = stackedBarRenderer3D9.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset14);
        boolean boolean17 = range6.equals((java.lang.Object) range16);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer18 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer18.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint22 = dateAxis21.getLabelPaint();
        dateAxis21.setAutoTickUnitSelection(false);
        org.jfree.data.Range range25 = dateAxis21.getDefaultAutoRange();
        boolean boolean26 = intervalBarRenderer18.equals((java.lang.Object) range25);
        org.jfree.data.time.DateRange dateRange27 = new org.jfree.data.time.DateRange(range25);
        java.util.Date date28 = dateRange27.getUpperDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range6, (org.jfree.data.Range) dateRange27);
        java.util.Date date30 = dateRange27.getLowerDate();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        boolean boolean32 = dateAxis31.isAutoTickUnitSelection();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity38 = new org.jfree.chart.entity.TickLabelEntity(shape35, "hi!", "");
        dateAxis31.setLeftArrow(shape35);
        dateAxis31.configure();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date44 = simpleTimePeriod43.getEnd();
        dateAxis31.setMinimumDate(date44);
        org.jfree.data.gantt.Task task46 = new org.jfree.data.gantt.Task("WMAP_Plot", date30, date44);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) date30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(date44);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Point2D point2D11 = null;
        xYPlot7.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11);
        java.awt.Paint paint13 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke16 = categoryMarker15.getOutlineStroke();
        xYPlot7.setDomainCrosshairStroke(stroke16);
        boolean boolean18 = xYPlot7.isRangeZeroBaselineVisible();
        xYPlot7.setDomainCrosshairValue((double) (short) -1);
        java.awt.geom.Point2D point2D21 = xYPlot7.getQuadrantOrigin();
        java.awt.Paint paint22 = xYPlot7.getBackgroundPaint();
        polarPlot6.setRadiusGridlinePaint(paint22);
        polarPlot6.removeCornerTextItem("hi!");
        double double26 = polarPlot6.getMaxRadius();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        int int7 = xYPlot0.getWeight();
        java.awt.Paint paint8 = xYPlot0.getBackgroundPaint();
        xYPlot0.setForegroundAlpha(0.0f);
        double double11 = xYPlot0.getRangeCrosshairValue();
        boolean boolean12 = xYPlot0.isRangeGridlinesVisible();
        java.awt.Paint paint13 = null;
        try {
            xYPlot0.setDomainCrosshairPaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        dateAxis3.setStandardTickUnits(tickUnitSource7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean12 = stackedBarRenderer3D11.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke15 = stackedBarRenderer3D11.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis3.setAxisLineStroke(stroke15);
        stackedAreaRenderer0.setBaseStroke(stroke15);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font20 = dateAxis19.getTickLabelFont();
        stackedAreaRenderer0.setSeriesItemLabelFont((int) '4', font20);
        org.jfree.chart.LegendItem legendItem24 = stackedAreaRenderer0.getLegendItem(0, (int) (short) 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator25 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean27 = standardCategoryToolTipGenerator25.equals((java.lang.Object) 100.0f);
        stackedAreaRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator25);
        java.text.NumberFormat numberFormat29 = standardCategoryToolTipGenerator25.getNumberFormat();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(numberFormat29);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        labelBlock2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder3);
        labelBlock2.setPadding(0.0d, 0.0d, 0.0d, (double) 5);
        double double11 = labelBlock2.getWidth();
        java.awt.geom.Rectangle2D rectangle2D12 = labelBlock2.getBounds();
        java.lang.Object obj13 = labelBlock2.clone();
        labelBlock2.setWidth((double) (byte) 1);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        ringPlot0.setShadowXOffset((double) 0);
        double double4 = ringPlot0.getInnerSeparatorExtension();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj1 = numberAxis3D0.clone();
        numberAxis3D0.setAutoTickUnitSelection(false);
        double double4 = numberAxis3D0.getFixedDimension();
        double double5 = numberAxis3D0.getUpperBound();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        double double7 = categoryItemRendererState6.getSeriesRunningTotal();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) (-1));
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(1, false);
        int int13 = statisticalLineAndShapeRenderer2.getPassCount();
        boolean boolean14 = statisticalLineAndShapeRenderer2.getBaseShapesVisible();
        statisticalLineAndShapeRenderer2.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 3600000L, 12.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range7, (double) 128);
        org.jfree.data.Range range10 = rectangleConstraint9.getHeightRange();
        org.jfree.data.Range range13 = new org.jfree.data.Range(10.0d, (double) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint9.toRangeWidth(range13);
        try {
            org.jfree.chart.util.Size2D size2D15 = blockContainer5.arrange(graphics2D6, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("ThreadContext");
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = axisState0.getTicks();
        double double2 = axisState0.getCursor();
        axisState0.setCursor(0.0d);
        double double5 = axisState0.getCursor();
        axisState0.cursorUp((double) (-460));
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10, (int) 'a', 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio(0.0f);
        java.lang.String str4 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "hi!");
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        xYPlot0.setRangeCrosshairValue((double) (byte) 100);
        xYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint8 = dateAxis7.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline9 = dateAxis7.getTimeline();
        dateAxis7.setAutoTickUnitSelection(false);
        double double12 = dateAxis7.getLabelAngle();
        dateAxis7.configure();
        dateAxis7.setLabel("ThreadContext");
        xYPlot0.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) dateAxis7, true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(timeline9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str8 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ClassContext" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: ClassContext"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.Axis axis0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, (float) 100L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity6 = new org.jfree.chart.entity.AxisLabelEntity(axis0, shape3, "hi!", "ClassContext");
        java.lang.String str7 = axisLabelEntity6.getShapeType();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "poly" + "'", str7.equals("poly"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, (double) 1546329600000L);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        polarPlot6.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = polarPlot6.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        polarPlot6.setDataset(xYDataset10);
        double double12 = polarPlot6.getMaxRadius();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        xYPlot13.zoomRangeAxes(0.0d, plotRenderingInfo16, point2D17);
        java.awt.Stroke stroke19 = xYPlot13.getRangeCrosshairStroke();
        boolean boolean20 = polarPlot6.equals((java.lang.Object) stroke19);
        int int21 = polarPlot6.getBackgroundImageAlignment();
        java.lang.String str22 = polarPlot6.getPlotType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Polar Plot" + "'", str22.equals("Polar Plot"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D2.getLegendItem((int) (short) -1, 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedBarRenderer3D2.getSeriesItemLabelGenerator(2);
        java.awt.Paint paint12 = stackedBarRenderer3D2.lookupSeriesOutlinePaint((-1));
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor13 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor13, textAnchor14);
        stackedBarRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(itemLabelAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        legendItem27.setSeriesKey((java.lang.Comparable) 1.0E-5d);
        java.awt.Paint paint30 = legendItem27.getLinePaint();
        java.lang.String str31 = legendItem27.getDescription();
        int int32 = legendItem27.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str31.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle5.setPosition(rectangleEdge6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Point2D point2D12 = null;
        xYPlot8.zoomRangeAxes(0.0d, plotRenderingInfo11, point2D12);
        java.awt.Paint paint14 = xYPlot8.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot8.getAxisOffset();
        double double17 = rectangleInsets15.calculateRightInset((double) 3600000L);
        legendTitle5.setMargin(rectangleInsets15);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint23 = stackedBarRenderer3D21.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D21);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = legendTitle24.getPosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge25);
        legendTitle5.setLegendItemGraphicEdge(rectangleEdge25);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeColumn((java.lang.Comparable) 500);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) 0L);
        org.junit.Assert.assertNotNull(pieDataset6);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.Object obj1 = null;
        boolean boolean2 = unitType0.equals(obj1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = stackedBarRenderer3D2.getBaseURLGenerator();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("", font9);
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        labelBlock10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        labelBlock10.setPadding(0.0d, 0.0d, 0.0d, (double) 5);
        double double19 = labelBlock10.getWidth();
        java.awt.geom.Rectangle2D rectangle2D20 = labelBlock10.getBounds();
        try {
            stackedBarRenderer3D2.drawBackground(graphics2D6, categoryPlot7, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ThreadContext");
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition3);
        boolean boolean5 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) true, false);
        int int10 = stackedBarRenderer3D2.getColumnCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "hi!", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset9);
        java.util.List list11 = defaultCategoryDataset9.getRowKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity14 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "hi!", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, (java.lang.Comparable) 0L, (java.lang.Comparable) "");
        categoryItemEntity14.setURLText("RectangleConstraintType.RANGE");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke6 = stackedBarRenderer3D2.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = stackedBarRenderer3D2.getDrawingSupplier();
        stackedBarRenderer3D2.setMaximumBarWidth((double) 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(drawingSupplier7);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.lang.Object obj4 = categoryMarker1.clone();
        java.lang.Class<?> wildcardClass5 = categoryMarker1.getClass();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint7 = dateAxis6.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline8 = dateAxis6.getTimeline();
        java.text.DateFormat dateFormat9 = null;
        dateAxis6.setDateFormatOverride(dateFormat9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo12.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D15 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D13, rectangleAnchor14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint21 = stackedBarRenderer3D19.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D19);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle22.setPosition(rectangleEdge23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendTitle22.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.geom.Rectangle2D rectangle2D28 = plotRenderingInfo27.getDataArea();
        rectangleInsets25.trim(rectangle2D28);
        int int30 = numberTickUnit16.compareTo((java.lang.Object) rectangle2D28);
        boolean boolean31 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D13, rectangle2D28);
        boolean boolean32 = dateAxis6.equals((java.lang.Object) boolean31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = dateAxis6.getLabelInsets();
        categoryMarker1.setLabelOffset(rectangleInsets33);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(timeline8);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleInsets33);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) (-1));
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(1, false);
        int int13 = statisticalLineAndShapeRenderer2.getPassCount();
        boolean boolean14 = statisticalLineAndShapeRenderer2.getBaseShapesVisible();
        statisticalLineAndShapeRenderer2.setSeriesItemLabelsVisible(15, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 0.95f, (java.lang.Comparable) "ClassContext");
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) (-1));
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        ringPlot6.setLabelLinksVisible(false);
        boolean boolean9 = ringPlot6.getIgnoreNullValues();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        int int7 = xYPlot0.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline10 = dateAxis8.getTimeline();
        dateAxis8.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj14 = numberAxis3D13.clone();
        numberAxis3D13.setAutoTickUnitSelection(false);
        java.text.NumberFormat numberFormat17 = null;
        numberAxis3D13.setNumberFormatOverride(numberFormat17);
        numberAxis3D13.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font22 = dateAxis21.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint24 = dateAxis23.getLabelPaint();
        dateAxis23.setAutoTickUnitSelection(false);
        boolean boolean27 = dateAxis23.isVerticalTickLabels();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { dateAxis8, numberAxis3D13, dateAxis21, dateAxis23 };
        xYPlot0.setDomainAxes(valueAxisArray28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot0.getDomainAxisLocation();
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection32 = xYPlot0.getDomainMarkers(layer31);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(timeline10);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNull(collection32);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        boolean boolean8 = statisticalLineAndShapeRenderer2.getItemShapeFilled(100, (int) 'a');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = statisticalLineAndShapeRenderer2.getSeriesItemLabelGenerator(6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 2, (double) (byte) 100, (double) (short) 100, (double) 2019L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        boolean boolean8 = stackedBarRenderer3D2.getAutoPopulateSeriesFillPaint();
        double double9 = stackedBarRenderer3D2.getLowerClip();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer0.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.data.Range range7 = dateAxis3.getDefaultAutoRange();
        boolean boolean8 = intervalBarRenderer0.equals((java.lang.Object) range7);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(range7);
        org.jfree.data.Range range12 = new org.jfree.data.Range(10.0d, (double) 10);
        org.jfree.data.Range range13 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange9, range12);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 3600000L, 12.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        dateAxis8.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis8, polarItemRenderer12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = plotRenderingInfo17.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D20 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D18, rectangleAnchor19);
        java.awt.Point point21 = polarPlot13.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D18);
        try {
            blockContainer5.draw(graphics2D6, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(point2D20);
        org.junit.Assert.assertNotNull(point21);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("poly");
        double double2 = categoryAxis1.getCategoryMargin();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 100.0d);
        java.awt.Stroke stroke5 = categoryAxis1.getTickMarkStroke();
        double double6 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "hi!", "");
        tickLabelEntity5.setToolTipText("Polar Plot");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = legendTitle5.arrange(graphics2D6);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(size2D7);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Color color2 = java.awt.Color.magenta;
        org.jfree.chart.axis.Axis axis7 = null;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, (float) 100L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity(axis7, shape10, "hi!", "ClassContext");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, rectangleAnchor14, 10.0d, (double) 10.0f);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint19 = dateAxis18.getLabelPaint();
        dateAxis18.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = null;
        dateAxis18.setStandardTickUnits(tickUnitSource22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean27 = stackedBarRenderer3D26.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke30 = stackedBarRenderer3D26.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis18.setAxisLineStroke(stroke30);
        java.awt.Paint paint32 = null;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("poly", "", "TextBlockAnchor.TOP_CENTER", "", shape17, stroke30, paint32);
        java.awt.Paint paint34 = null;
        java.awt.Paint paint36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean40 = stackedBarRenderer3D39.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke43 = stackedBarRenderer3D39.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke47 = categoryMarker46.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint36, stroke43, (java.awt.Paint) color44, stroke47, 0.0f);
        org.jfree.chart.plot.IntervalMarker intervalMarker51 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 0, 1.0E-5d, (java.awt.Paint) color2, stroke30, paint34, stroke47, 1.0f);
        java.lang.Object obj52 = null;
        boolean boolean53 = intervalMarker51.equals(obj52);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        java.lang.String str3 = labelBlock2.getToolTipText();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer5.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        dateAxis8.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = null;
        dateAxis8.setStandardTickUnits(tickUnitSource12);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean17 = stackedBarRenderer3D16.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke20 = stackedBarRenderer3D16.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis8.setAxisLineStroke(stroke20);
        stackedAreaRenderer5.setBaseStroke(stroke20);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font25 = dateAxis24.getTickLabelFont();
        stackedAreaRenderer5.setSeriesItemLabelFont((int) '4', font25);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("poly", font25);
        labelBlock27.setURLText("TextBlockAnchor.TOP_CENTER");
        org.jfree.chart.block.BlockBorder blockBorder30 = org.jfree.chart.block.BlockBorder.NONE;
        labelBlock27.setFrame((org.jfree.chart.block.BlockFrame) blockBorder30);
        labelBlock2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder30);
        labelBlock2.setToolTipText("RectangleConstraintType.RANGE");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(blockBorder30);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        axisState2.setMax(100.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions6, categoryLabelPosition7);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = categoryLabelPositions6.getLabelPosition(rectangleEdge9);
        axisState2.moveCursor(0.0d, rectangleEdge9);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("poly");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = plotRenderingInfo16.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D17, rectangleAnchor18);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint25 = stackedBarRenderer3D23.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D23);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle26.setPosition(rectangleEdge27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle26.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo31.getDataArea();
        rectangleInsets29.trim(rectangle2D32);
        int int34 = numberTickUnit20.compareTo((java.lang.Object) rectangle2D32);
        boolean boolean35 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D17, rectangle2D32);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis13.valueToJava2D((double) 10.0f, rectangle2D17, rectangleEdge36);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint42 = stackedBarRenderer3D40.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D40);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = legendTitle43.getPosition();
        try {
            java.util.List list45 = numberAxis3D0.refreshTicks(graphics2D1, axisState2, rectangle2D17, rectangleEdge44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(categoryLabelPosition10);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) blockBorder0, jFreeChart1, (int) (short) 10, (int) ' ');
        chartProgressEvent4.setPercent(0);
        chartProgressEvent4.setPercent(0);
        chartProgressEvent4.setType(9999);
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        org.jfree.data.Range range9 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        java.util.List list10 = defaultCategoryDataset7.getRowKeys();
        java.lang.Object obj11 = defaultCategoryDataset7.clone();
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, 100);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(pieDataset13);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        legendItem27.setSeriesKey((java.lang.Comparable) (byte) 1);
        legendItem27.setSeriesKey((java.lang.Comparable) (short) 1);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = defaultKeyedValues0.clone();
        try {
            defaultKeyedValues0.insertValue((int) (byte) 1, (java.lang.Comparable) "ThreadContext", (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 3600000L, 12.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        boolean boolean6 = blockContainer5.isEmpty();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint11 = stackedBarRenderer3D9.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D9);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle12.setPosition(rectangleEdge13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle12.getLegendItemGraphicEdge();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo16 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray17 = basicProjectInfo16.getOptionalLibraries();
        blockContainer5.add((org.jfree.chart.block.Block) legendTitle12, (java.lang.Object) basicProjectInfo16);
        java.lang.Object obj19 = legendTitle12.clone();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.data.Range range21 = null;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint23 = dateAxis22.getLabelPaint();
        dateAxis22.setAutoTickUnitSelection(false);
        org.jfree.data.Range range26 = dateAxis22.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint(range21, range26);
        org.jfree.chart.util.Size2D size2D28 = legendTitle12.arrange(graphics2D20, rectangleConstraint27);
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = legendTitle12.getVerticalAlignment();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(libraryArray17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(verticalAlignment29);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        polarPlot6.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = polarPlot6.getOrientation();
        java.lang.String str10 = plotOrientation9.toString();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str10.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions1, categoryLabelPosition2);
        double double4 = categoryLabelPosition2.getAngle();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = categoryLabelPosition2.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions6, categoryLabelPosition7);
        double double9 = categoryLabelPosition7.getAngle();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = categoryLabelPosition7.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions11, categoryLabelPosition12);
        double double14 = categoryLabelPosition12.getAngle();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition2, categoryLabelPosition7, categoryLabelPosition12);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop(Double.NaN);
        double double3 = axisSpace0.getBottom();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        xYPlot0.setWeight(128);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint6 = dateAxis5.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis5.getTimeline();
        java.text.DateFormat dateFormat8 = null;
        dateAxis5.setDateFormatOverride(dateFormat8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        dateAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot10);
        org.jfree.data.Range range12 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.lang.String str13 = dateAxis5.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        org.jfree.data.Range range9 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        java.awt.Stroke stroke10 = stackedBarRenderer3D2.getBaseOutlineStroke();
        stackedBarRenderer3D2.setAutoPopulateSeriesOutlinePaint(false);
        boolean boolean13 = stackedBarRenderer3D2.getBaseCreateEntities();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = stackedBarRenderer3D2.getGradientPaintTransformer();
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer14);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        java.util.List list2 = axisCollection0.getAxesAtBottom();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.LEFT;
        axisCollection0.add((org.jfree.chart.axis.Axis) categoryAxis3, rectangleEdge4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        xYPlot6.zoomRangeAxes(0.0d, plotRenderingInfo9, point2D10);
        int int12 = xYPlot6.getSeriesCount();
        java.awt.Color color15 = java.awt.Color.magenta;
        org.jfree.chart.axis.Axis axis20 = null;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, (float) 100L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity26 = new org.jfree.chart.entity.AxisLabelEntity(axis20, shape23, "hi!", "ClassContext");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape23, rectangleAnchor27, 10.0d, (double) 10.0f);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint32 = dateAxis31.getLabelPaint();
        dateAxis31.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource35 = null;
        dateAxis31.setStandardTickUnits(tickUnitSource35);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean40 = stackedBarRenderer3D39.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke43 = stackedBarRenderer3D39.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis31.setAxisLineStroke(stroke43);
        java.awt.Paint paint45 = null;
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("poly", "", "TextBlockAnchor.TOP_CENTER", "", shape30, stroke43, paint45);
        java.awt.Paint paint47 = null;
        java.awt.Paint paint49 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean53 = stackedBarRenderer3D52.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke56 = stackedBarRenderer3D52.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker59 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke60 = categoryMarker59.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint49, stroke56, (java.awt.Paint) color57, stroke60, 0.0f);
        org.jfree.chart.plot.IntervalMarker intervalMarker64 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 0, 1.0E-5d, (java.awt.Paint) color15, stroke43, paint47, stroke60, 1.0f);
        xYPlot6.setDomainCrosshairStroke(stroke43);
        java.awt.Stroke stroke66 = null;
        xYPlot6.setOutlineStroke(stroke66);
        boolean boolean68 = categoryAxis3.equals((java.lang.Object) stroke66);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean9 = stackedBarRenderer3D8.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke12 = stackedBarRenderer3D8.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis0.setAxisLineStroke(stroke12);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity23 = new org.jfree.chart.entity.TickLabelEntity(shape20, "hi!", "");
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean29 = stackedBarRenderer3D28.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke32 = stackedBarRenderer3D28.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke36 = categoryMarker35.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint25, stroke32, (java.awt.Paint) color33, stroke36, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint40 = dateAxis39.getLabelPaint();
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape20, stroke32, paint40);
        dateAxis0.setLabelPaint(paint40);
        java.lang.String str43 = dateAxis0.getLabelURL();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(str43);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable1 = null;
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getValue(comparable1, (java.lang.Comparable) 9999);
        int int5 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) 1.0E-5d);
        java.util.List list6 = defaultStatisticalCategoryDataset0.getRowKeys();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("poly");
        double double2 = categoryAxis1.getCategoryMargin();
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable1 = null;
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getValue(comparable1, (java.lang.Comparable) 9999);
        java.lang.Object obj4 = null;
        boolean boolean5 = defaultStatisticalCategoryDataset0.equals(obj4);
        int int7 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) 5);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Comparable comparable2 = null;
        java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getValue((java.lang.Comparable) 9999, comparable2);
        try {
            java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier(500, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = numberAxis1.getTickLabelPaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Point2D point2D11 = null;
        xYPlot7.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11);
        int int13 = xYPlot7.getSeriesCount();
        java.awt.Font font14 = xYPlot7.getNoDataMessageFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 10.0d, 1.0d, 0.0d, 0.0d, font14);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D2.getBaseNegativeItemLabelPosition();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(false);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint12 = dateAxis11.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline13 = dateAxis11.getTimeline();
        dateAxis11.setAutoTickUnitSelection(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        categoryMarker17.notifyListeners(markerChangeEvent18);
        java.lang.Object obj20 = categoryMarker17.clone();
        java.awt.Paint paint21 = categoryMarker17.getOutlinePaint();
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("", font23);
        org.jfree.chart.block.BlockBorder blockBorder25 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = blockBorder25.getInsets();
        labelBlock24.setFrame((org.jfree.chart.block.BlockFrame) blockBorder25);
        labelBlock24.setPadding(0.0d, 0.0d, 0.0d, (double) 5);
        double double33 = labelBlock24.getWidth();
        java.awt.geom.Rectangle2D rectangle2D34 = labelBlock24.getBounds();
        stackedBarRenderer3D2.drawRangeMarker(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.plot.Marker) categoryMarker17, rectangle2D34);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font38 = dateAxis37.getTickLabelFont();
        org.jfree.chart.ChartColor chartColor42 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D45 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean46 = chartColor42.equals((java.lang.Object) 'a');
        org.jfree.chart.text.TextFragment textFragment47 = new org.jfree.chart.text.TextFragment("", font38, (java.awt.Paint) chartColor42);
        categoryMarker17.setLabelFont(font38);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(timeline13);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(blockBorder25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.lang.Boolean boolean7 = stackedBarRenderer3D2.getSeriesCreateEntities(500);
        stackedBarRenderer3D2.setBaseSeriesVisible(true);
        boolean boolean10 = stackedBarRenderer3D2.isDrawBarOutline();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        java.util.List list3 = defaultCategoryDataset1.getRowKeys();
        defaultCategoryDataset1.validateObject();
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setName("");
        java.lang.String str3 = projectInfo0.getVersion();
        java.lang.String str4 = projectInfo0.getLicenceName();
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo5.setName("");
        projectInfo5.setName("ClassContext");
        projectInfo5.addOptionalLibrary("ThreadContext");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
        java.lang.String str13 = projectInfo5.getName();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ClassContext" + "'", str13.equals("ClassContext"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke9);
        boolean boolean11 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setDomainCrosshairValue((double) (short) -1);
        org.jfree.chart.plot.Plot plot14 = xYPlot0.getRootPlot();
        java.awt.Stroke stroke15 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        legendItem27.setSeriesKey((java.lang.Comparable) 1.0E-5d);
        java.awt.Paint paint30 = legendItem27.getLinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem27.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset31);
        int int33 = defaultCategoryDataset31.getRowCount();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        int int36 = xYPlot34.getIndexOf(xYItemRenderer35);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot34.getDomainMarkers(layer37);
        boolean boolean39 = defaultCategoryDataset31.hasListener((java.util.EventListener) xYPlot34);
        int int41 = defaultCategoryDataset31.getColumnIndex((java.lang.Comparable) (-457));
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = stackedBarRenderer3D2.getLegendItemURLGenerator();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            stackedBarRenderer3D2.setSeriesOutlineStroke((int) (byte) -1, stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        float float2 = ringPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getSerialIndex();
        java.util.Date date5 = year0.getEnd();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setAutoTickUnitSelection(false);
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor5 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint7 = dateAxis6.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline8 = dateAxis6.getTimeline();
        dateAxis6.setAutoTickUnitSelection(false);
        double double11 = dateAxis6.getLabelAngle();
        dateAxis6.configure();
        dateAxis6.setUpperMargin((double) 3);
        boolean boolean15 = categoryAnchor5.equals((java.lang.Object) dateAxis6);
        org.jfree.chart.axis.Timeline timeline16 = dateAxis6.getTimeline();
        dateAxis0.setTimeline(timeline16);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryAnchor5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(timeline8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeline16);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", "WMAP_Plot", "DateTickUnit[MINUTE, -1]", "CategoryAnchor.START");
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        legendItem27.setSeriesKey((java.lang.Comparable) 1.0E-5d);
        legendItem27.setSeriesKey((java.lang.Comparable) 3.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Font font5 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (-1.0d), (double) 0.95f, 10.0d, (double) 10.0f, font5);
        java.awt.Graphics2D graphics2D7 = null;
        double double8 = markerAxisBand6.getHeight(graphics2D7);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(false, true);
        stackedBarRenderer3D2.setBaseCreateEntities(false, true);
        stackedBarRenderer3D2.setIncludeBaseInRange(false);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot();
        int int13 = ringPlot12.getPieIndex();
        java.lang.String str14 = ringPlot12.getPlotType();
        ringPlot12.setLabelLinksVisible(false);
        ringPlot12.setStartAngle((double) (-2208960000000L));
        java.awt.Color color19 = java.awt.Color.CYAN;
        int int20 = color19.getTransparency();
        ringPlot12.setSeparatorPaint((java.awt.Paint) color19);
        stackedBarRenderer3D2.setSeriesItemLabelPaint((int) '#', (java.awt.Paint) color19, false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pie Plot" + "'", str14.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("org.jfree.data.time.TimePeriodFormatException: ClassContext");
        textTitle1.setText("Third");
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        org.jfree.data.Range range9 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        java.awt.Stroke stroke10 = stackedBarRenderer3D2.getBaseOutlineStroke();
        stackedBarRenderer3D2.setAutoPopulateSeriesOutlinePaint(false);
        boolean boolean13 = stackedBarRenderer3D2.getBaseCreateEntities();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator15 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        stackedBarRenderer3D2.setSeriesURLGenerator((int) ' ', (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator15);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setItemMargin((double) (byte) -1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeColumn((java.lang.Comparable) 500);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) 1L);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        dateAxis0.setAutoTickUnitSelection(false);
        double double5 = dateAxis0.getLabelAngle();
        dateAxis0.configure();
        double double7 = dateAxis0.getFixedAutoRange();
        java.awt.Shape shape8 = dateAxis0.getDownArrow();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = new org.jfree.chart.axis.AxisState();
        axisState10.setMax(100.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions14, categoryLabelPosition15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = categoryLabelPositions14.getLabelPosition(rectangleEdge17);
        axisState10.moveCursor(0.0d, rectangleEdge17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo21.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D22, rectangleAnchor23);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit25 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint30 = stackedBarRenderer3D28.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D28);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle31.setPosition(rectangleEdge32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendTitle31.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo35);
        java.awt.geom.Rectangle2D rectangle2D37 = plotRenderingInfo36.getDataArea();
        rectangleInsets34.trim(rectangle2D37);
        int int39 = numberTickUnit25.compareTo((java.lang.Object) rectangle2D37);
        boolean boolean40 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D22, rectangle2D37);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            java.util.List list42 = dateAxis0.refreshTicks(graphics2D9, axisState10, rectangle2D22, rectangleEdge41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(categoryLabelPosition18);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNotNull(numberTickUnit25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isAutoTickUnitSelection();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity14 = new org.jfree.chart.entity.TickLabelEntity(shape11, "hi!", "");
        dateAxis7.setLeftArrow(shape11);
        stackedBarRenderer3D2.setSeriesShape((int) (byte) 10, shape11, true);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape11, "poly");
        java.lang.String str20 = chartEntity19.getURLText();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        java.util.List list3 = defaultCategoryDataset1.getRowKeys();
        try {
            java.lang.Comparable comparable5 = defaultCategoryDataset1.getRowKey((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font2 = dateAxis1.getTickLabelFont();
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("Polar Plot", font2);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setFixedDimension((double) (short) 10);
        java.util.Date date4 = dateAxis0.getMinimumDate();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setFixedDimension((double) (short) 10);
        java.util.Date date4 = dateAxis0.getMinimumDate();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = null;
        stackedBarRenderer3D7.setPositiveItemLabelPositionFallback(itemLabelPosition8);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        stackedBarRenderer3D12.setSeriesURLGenerator(10, categoryURLGenerator14);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset17);
        org.jfree.data.Range range19 = stackedBarRenderer3D12.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset17);
        defaultCategoryDataset17.removeColumn((java.lang.Comparable) 9999);
        boolean boolean22 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultCategoryDataset17);
        org.jfree.data.Range range23 = stackedBarRenderer3D7.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset17);
        java.awt.Paint paint24 = stackedBarRenderer3D7.getBaseItemLabelPaint();
        dateAxis0.setLabelPaint(paint24);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getLicenceName();
        java.lang.String str2 = basicProjectInfo0.getCopyright();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint5 = stackedBarRenderer3D3.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getPosition();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint12 = stackedBarRenderer3D10.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D10);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle13.setPosition(rectangleEdge14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle13.getLegendItemGraphicPadding();
        double double17 = legendTitle13.getContentYOffset();
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("", font19);
        legendTitle13.setItemFont(font19);
        legendTitle6.setItemFont(font19);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo25);
        java.awt.geom.Point2D point2D27 = null;
        xYPlot23.zoomRangeAxes(0.0d, plotRenderingInfo26, point2D27);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset30);
        xYPlot23.datasetChanged(datasetChangeEvent31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot23.getDomainAxisEdge();
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("RectangleEdge.LEFT", font19, (org.jfree.chart.plot.Plot) xYPlot23, false);
        jFreeChart35.clearSubtitles();
        java.lang.Object obj37 = jFreeChart35.clone();
        java.lang.Object obj38 = jFreeChart35.getTextAntiAlias();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNull(obj38);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        try {
            java.lang.Number number30 = defaultIntervalCategoryDataset27.getValue(0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setAutoTickUnitSelection(false);
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint9 = stackedBarRenderer3D7.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D7);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle10.setPosition(rectangleEdge11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = legendTitle10.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        java.awt.geom.Rectangle2D rectangle2D16 = plotRenderingInfo15.getDataArea();
        rectangleInsets13.trim(rectangle2D16);
        java.lang.String str18 = rectangleInsets13.toString();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo21);
        java.awt.geom.Point2D point2D23 = null;
        xYPlot19.zoomRangeAxes(0.0d, plotRenderingInfo22, point2D23);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState25 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo22);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj27 = numberAxis3D26.clone();
        numberAxis3D26.setAutoTickUnitSelection(false);
        numberAxis3D26.configure();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint34 = dateAxis33.getLabelPaint();
        dateAxis33.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer37 = null;
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis33, polarItemRenderer37);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo41);
        java.awt.geom.Rectangle2D rectangle2D43 = plotRenderingInfo42.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D45 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D43, rectangleAnchor44);
        java.awt.Point point46 = polarPlot38.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D43);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double48 = numberAxis3D26.java2DToValue(4.0d, rectangle2D43, rectangleEdge47);
        plotRenderingInfo22.setPlotArea(rectangle2D43);
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets13.createOutsetRectangle(rectangle2D43);
        dateAxis0.setUpArrow((java.awt.Shape) rectangle2D50);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]" + "'", str18.equals("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"));
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(point2D45);
        org.junit.Assert.assertNotNull(point46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + Double.POSITIVE_INFINITY + "'", double48 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangle2D50);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        boolean boolean1 = minMaxCategoryRenderer0.isDrawLines();
        java.awt.Paint paint3 = minMaxCategoryRenderer0.lookupSeriesOutlinePaint((int) 'a');
        java.awt.Stroke stroke4 = minMaxCategoryRenderer0.getGroupStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.lang.String[] strArray4 = new java.lang.String[] { "ItemLabelAnchor.OUTSIDE2", "ClassContext", "CategoryAnchor.START", "org.jfree.data.time.TimePeriodFormatException: ClassContext" };
        java.lang.Number[][] numberArray5 = new java.lang.Number[][] {};
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 0.0d, 0.0d, 2.0d, 0.5f, 0.0d, 0.25d };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray12 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset14 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray4, numberArray5, numberArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        org.jfree.data.Range range9 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator11 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
        java.lang.Object obj12 = standardCategorySeriesLabelGenerator11.clone();
        stackedBarRenderer3D2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator11);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint3 = dateAxis2.getLabelPaint();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.data.Range range6 = dateAxis2.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range1, range6);
        boolean boolean8 = rangeType0.equals((java.lang.Object) range1);
        java.lang.String str9 = rangeType0.toString();
        java.lang.String str10 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RangeType.FULL" + "'", str9.equals("RangeType.FULL"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RangeType.FULL" + "'", str10.equals("RangeType.FULL"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        ringPlot0.setLabelBackgroundPaint(paint1);
        double double3 = ringPlot0.getSectionDepth();
        java.awt.Stroke stroke4 = ringPlot0.getSeparatorStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        try {
            java.awt.Color color1 = java.awt.Color.decode("CategoryAnchor.START");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"CategoryAnchor.START\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) 3600000L, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle5.setPosition(rectangleEdge6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle5.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo10.getDataArea();
        rectangleInsets8.trim(rectangle2D11);
        java.lang.String str13 = rectangleInsets8.toString();
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        xYPlot14.zoomRangeAxes(0.0d, plotRenderingInfo17, point2D18);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState20 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo17);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj22 = numberAxis3D21.clone();
        numberAxis3D21.setAutoTickUnitSelection(false);
        numberAxis3D21.configure();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint29 = dateAxis28.getLabelPaint();
        dateAxis28.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer32 = null;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis28, polarItemRenderer32);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        java.awt.geom.Rectangle2D rectangle2D38 = plotRenderingInfo37.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D40 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D38, rectangleAnchor39);
        java.awt.Point point41 = polarPlot33.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D38);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double43 = numberAxis3D21.java2DToValue(4.0d, rectangle2D38, rectangleEdge42);
        plotRenderingInfo17.setPlotArea(rectangle2D38);
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets8.createOutsetRectangle(rectangle2D38);
        java.io.ObjectOutputStream objectOutputStream46 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape((java.awt.Shape) rectangle2D45, objectOutputStream46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]" + "'", str13.equals("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]"));
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(point2D40);
        org.junit.Assert.assertNotNull(point41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.POSITIVE_INFINITY + "'", double43 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(rectangle2D45);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        org.jfree.data.Range range9 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        java.awt.Stroke stroke10 = stackedBarRenderer3D2.getBaseOutlineStroke();
        java.io.ObjectOutputStream objectOutputStream11 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke10, objectOutputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 100);
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) 2);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint10 = stackedBarRenderer3D8.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D8);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) 10.0f, 0.0d);
        org.jfree.chart.util.Size2D size2D16 = legendTitle11.arrange(graphics2D12, rectangleConstraint15);
        java.lang.String str17 = size2D16.toString();
        try {
            org.jfree.chart.util.Size2D size2D18 = rectangleConstraint2.calculateConstrainedSize(size2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str17.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (double) 11, false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.lang.Object obj4 = categoryMarker1.clone();
        java.awt.Paint paint5 = categoryMarker1.getPaint();
        java.awt.Paint paint6 = categoryMarker1.getLabelPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint11 = stackedBarRenderer3D9.lookupSeriesPaint((int) '4');
        categoryMarker1.setOutlinePaint(paint11);
        java.awt.Paint paint13 = categoryMarker1.getOutlinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryMarker1.setLabelPaint((java.awt.Paint) color14);
        float float16 = categoryMarker1.getAlpha();
        java.lang.String str17 = categoryMarker1.getLabel();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        java.awt.Color color3 = java.awt.Color.green;
        statisticalLineAndShapeRenderer2.setBaseFillPaint((java.awt.Paint) color3, false);
        java.awt.Paint paint6 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        statisticalLineAndShapeRenderer2.notifyListeners(rendererChangeEvent7);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity7 = new org.jfree.chart.entity.TickLabelEntity(shape4, "hi!", "");
        dateAxis0.setLeftArrow(shape4);
        boolean boolean9 = dateAxis0.isVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) blockBorder0, jFreeChart1, (int) (short) 10, (int) ' ');
        chartProgressEvent4.setType((int) (byte) 1);
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        java.util.List list28 = defaultIntervalCategoryDataset27.getRowKeys();
        try {
            int int29 = defaultIntervalCategoryDataset27.getRowCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(9999, axisLocation7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline11 = dateAxis9.getTimeline();
        dateAxis9.setAutoTickUnitSelection(false);
        double double14 = dateAxis9.getLabelAngle();
        org.jfree.data.Range range15 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        xYPlot0.setOutlineVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        xYPlot0.handleClick(0, 6, plotRenderingInfo21);
        int int23 = plotRenderingInfo21.getSubplotCount();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeline11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Shape shape1 = numberAxis3D0.getRightArrow();
        double double2 = numberAxis3D0.getUpperBound();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.lang.Boolean boolean7 = stackedBarRenderer3D2.getSeriesCreateEntities(500);
        stackedBarRenderer3D2.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator((int) 'a', categoryURLGenerator11);
        stackedBarRenderer3D2.setDrawBarOutline(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = stackedBarRenderer3D2.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNull(categoryURLGenerator15);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        double double1 = levelRenderer0.getMaximumItemWidth();
        double double2 = levelRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        org.jfree.data.Range range9 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        org.jfree.chart.util.TableOrder tableOrder11 = multiplePiePlot10.getDataExtractOrder();
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(tableOrder11);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLowerMargin();
        categoryAxis0.clearCategoryLabelToolTips();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint5 = dateAxis4.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline6 = dateAxis4.getTimeline();
        dateAxis4.setAutoTickUnitSelection(false);
        double double9 = dateAxis4.getLabelAngle();
        dateAxis4.configure();
        dateAxis4.setUpperMargin((double) 3);
        boolean boolean13 = categoryAnchor3.equals((java.lang.Object) dateAxis4);
        java.lang.String str14 = categoryAnchor3.toString();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint19 = dateAxis18.getLabelPaint();
        dateAxis18.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, polarItemRenderer22);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.geom.Rectangle2D rectangle2D28 = plotRenderingInfo27.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D30 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D28, rectangleAnchor29);
        java.awt.Point point31 = polarPlot23.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D28);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor3, 0, (int) 'a', rectangle2D28, rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(timeline6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "CategoryAnchor.START" + "'", str14.equals("CategoryAnchor.START"));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(point2D30);
        org.junit.Assert.assertNotNull(point31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        boolean boolean4 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlinePaint();
        stackedBarRenderer3D2.setDrawBarOutline(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        java.awt.Color color3 = java.awt.Color.green;
        statisticalLineAndShapeRenderer2.setBaseFillPaint((java.awt.Paint) color3, false);
        java.awt.Paint paint6 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        boolean boolean7 = statisticalLineAndShapeRenderer2.getBaseShapesVisible();
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(8, true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.configure();
        numberAxis3D0.setRangeAboutValue((double) (byte) -1, (double) 4);
        numberAxis3D0.setLabelURL("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
        java.awt.Font font7 = numberAxis3D0.getTickLabelFont();
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        java.lang.String str3 = labelBlock2.getToolTipText();
        java.lang.Object obj4 = labelBlock2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D2.getLegendItem((int) (short) -1, 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedBarRenderer3D2.getSeriesItemLabelGenerator(2);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = null;
        stackedBarRenderer3D14.setSeriesURLGenerator(10, categoryURLGenerator16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = stackedBarRenderer3D14.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor19 = itemLabelPosition18.getRotationAnchor();
        stackedBarRenderer3D2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition18, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot0.getRenderer((int) (short) 1);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(xYItemRenderer12);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 15);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE4" + "'", str1.equals("ItemLabelAnchor.INSIDE4"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Shape shape1 = numberAxis3D0.getRightArrow();
        numberAxis3D0.setAutoRangeIncludesZero(true);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        java.util.List list2 = axisCollection0.getAxesAtLeft();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        stackedBarRenderer1.setRenderAsPercentages(true);
        int int4 = stackedBarRenderer1.getPassCount();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        stackedBarRenderer3D7.setSeriesURLGenerator(10, categoryURLGenerator9);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset12);
        org.jfree.data.Range range14 = stackedBarRenderer3D7.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12);
        java.util.List list15 = defaultCategoryDataset12.getRowKeys();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape22, "hi!", "");
        java.awt.Paint paint27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D30 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean31 = stackedBarRenderer3D30.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke34 = stackedBarRenderer3D30.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke38 = categoryMarker37.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint27, stroke34, (java.awt.Paint) color35, stroke38, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint42 = dateAxis41.getLabelPaint();
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape22, stroke34, paint42);
        boolean boolean44 = defaultCategoryDataset12.equals((java.lang.Object) "ThreadContext");
        int int46 = defaultCategoryDataset12.getRowIndex((java.lang.Comparable) (-1.0f));
        org.jfree.data.Range range47 = stackedBarRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(range47);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.data.Range range4 = dateAxis0.getDefaultAutoRange();
        dateAxis0.zoomRange((double) (-1), (double) (-1L));
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot();
        java.lang.String str9 = waferMapPlot8.getPlotType();
        dateAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) waferMapPlot8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        waferMapPlot8.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = null;
        waferMapPlot8.axisChanged(axisChangeEvent13);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "WMAP_Plot" + "'", str9.equals("WMAP_Plot"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setFixedDimension((double) (short) 10);
        double double5 = dateAxis1.getFixedDimension();
        java.lang.Class<?> wildcardClass6 = dateAxis1.getClass();
        java.net.URL uRL7 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("DateTickUnit[MINUTE, -1]", (java.lang.Class) wildcardClass6);
        java.lang.ClassLoader classLoader8 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
        java.util.ResourceBundle.clearCache(classLoader8);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(uRL7);
        org.junit.Assert.assertNotNull(classLoader8);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) '#', false);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer4 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer4.setBaseCreateEntities(true, false);
        java.awt.Paint paint8 = ganttRenderer4.getCompletePaint();
        boolean boolean9 = stackedBarRenderer3D3.equals((java.lang.Object) ganttRenderer4);
        stackedBarRenderer3D3.setDrawBarOutline(true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        ringPlot0.setShadowXOffset((double) 0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = null;
        try {
            ringPlot0.setLegendLabelGenerator(pieSectionLabelGenerator4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity11 = new org.jfree.chart.entity.TickLabelEntity(shape8, "hi!", "");
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean17 = stackedBarRenderer3D16.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke20 = stackedBarRenderer3D16.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke24 = categoryMarker23.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint13, stroke20, (java.awt.Paint) color21, stroke24, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint28 = dateAxis27.getLabelPaint();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape8, stroke20, paint28);
        java.awt.Paint paint30 = legendItem29.getFillPaint();
        java.awt.Stroke stroke31 = legendItem29.getLineStroke();
        strokeList0.setStroke(3, stroke31);
        java.lang.Object obj33 = null;
        boolean boolean34 = strokeList0.equals(obj33);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setName("");
        java.lang.String str3 = projectInfo0.getVersion();
        java.lang.String str4 = projectInfo0.getLicenceName();
        projectInfo0.setLicenceName("ThreadContext");
        projectInfo0.setCopyright("Size2D[width=0.0, height=0.0]");
        java.lang.String str9 = projectInfo0.toString();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + " version null.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nnull" + "'", str9.equals(" version null.\nSize2D[width=0.0, height=0.0].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\nnull"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) '#', false);
        boolean boolean11 = xYPlot0.equals((java.lang.Object) 1.0d);
        org.jfree.chart.axis.Axis axis16 = null;
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, (float) 100L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity22 = new org.jfree.chart.entity.AxisLabelEntity(axis16, shape19, "hi!", "ClassContext");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape19, rectangleAnchor23, 10.0d, (double) 10.0f);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint28 = dateAxis27.getLabelPaint();
        dateAxis27.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource31 = null;
        dateAxis27.setStandardTickUnits(tickUnitSource31);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean36 = stackedBarRenderer3D35.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke39 = stackedBarRenderer3D35.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis27.setAxisLineStroke(stroke39);
        java.awt.Paint paint41 = null;
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("poly", "", "TextBlockAnchor.TOP_CENTER", "", shape26, stroke39, paint41);
        xYPlot0.setRangeGridlineStroke(stroke39);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        dateAxis1.setLabelURL("({0}, {1}) = {3} - {4}");
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) (-1));
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(1, false);
        int int13 = statisticalLineAndShapeRenderer2.getPassCount();
        boolean boolean14 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator15 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean17 = standardCategoryToolTipGenerator15.equals((java.lang.Object) 100.0f);
        statisticalLineAndShapeRenderer2.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator15, false);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font21 = dateAxis20.getTickLabelFont();
        statisticalLineAndShapeRenderer2.setBaseItemLabelFont(font21);
        boolean boolean23 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint29 = stackedBarRenderer3D27.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D27);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle30.setPosition(rectangleEdge31);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo35);
        java.awt.geom.Point2D point2D37 = null;
        xYPlot33.zoomRangeAxes(0.0d, plotRenderingInfo36, point2D37);
        java.awt.Paint paint39 = xYPlot33.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = xYPlot33.getAxisOffset();
        double double42 = rectangleInsets40.calculateRightInset((double) 3600000L);
        legendTitle30.setMargin(rectangleInsets40);
        java.awt.Font font44 = legendTitle30.getItemFont();
        statisticalLineAndShapeRenderer2.setSeriesItemLabelFont(15, font44, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(font44);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        int int8 = stackedBarRenderer3D2.getRowCount();
        stackedBarRenderer3D2.setSeriesItemLabelsVisible(8, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        float[] floatArray10 = new float[] { 1900, (byte) -1, (-2208960000000L), 1577865599999L, 2019, (-2208960000000L) };
        float[] floatArray11 = color3.getRGBComponents(floatArray10);
        float[] floatArray12 = java.awt.Color.RGBtoHSB(2, 2019, 6, floatArray10);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Comparable comparable2 = null;
        java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getValue((java.lang.Comparable) 9999, comparable2);
        try {
            java.lang.Comparable comparable5 = defaultBoxAndWhiskerCategoryDataset0.getColumnKey(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        int int28 = defaultIntervalCategoryDataset27.getSeriesCount();
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer29 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer29.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint33 = dateAxis32.getLabelPaint();
        dateAxis32.setAutoTickUnitSelection(false);
        org.jfree.data.Range range36 = dateAxis32.getDefaultAutoRange();
        boolean boolean37 = intervalBarRenderer29.equals((java.lang.Object) range36);
        org.jfree.data.time.DateRange dateRange38 = new org.jfree.data.time.DateRange(range36);
        java.util.Date date39 = dateRange38.getLowerDate();
        try {
            int int40 = defaultIntervalCategoryDataset27.indexOf((java.lang.Comparable) date39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5 + "'", int28 == 5);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions1, categoryLabelPosition2);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition2);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions4, categoryLabelPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        org.jfree.data.Range range9 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        java.util.List list10 = defaultCategoryDataset7.getRowKeys();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity20 = new org.jfree.chart.entity.TickLabelEntity(shape17, "hi!", "");
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean26 = stackedBarRenderer3D25.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke29 = stackedBarRenderer3D25.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke33 = categoryMarker32.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint22, stroke29, (java.awt.Paint) color30, stroke33, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint37 = dateAxis36.getLabelPaint();
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape17, stroke29, paint37);
        boolean boolean39 = defaultCategoryDataset7.equals((java.lang.Object) "ThreadContext");
        try {
            java.lang.Comparable comparable41 = defaultCategoryDataset7.getRowKey(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        polarPlot6.rendererChanged(rendererChangeEvent7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = polarPlot6.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        polarPlot6.setDataset(xYDataset10);
        double double12 = polarPlot6.getMaxRadius();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint14 = dateAxis13.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline15 = dateAxis13.getTimeline();
        java.text.DateFormat dateFormat16 = null;
        dateAxis13.setDateFormatOverride(dateFormat16);
        polarPlot6.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        java.awt.Paint paint19 = polarPlot6.getAngleLabelPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(timeline15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "hi!", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset9);
        java.util.List list11 = defaultCategoryDataset9.getRowKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity14 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "hi!", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, (java.lang.Comparable) 0L, (java.lang.Comparable) "");
        java.lang.String str15 = categoryItemEntity14.getShapeType();
        java.lang.String str16 = categoryItemEntity14.getShapeCoords();
        categoryItemEntity14.setRowKey((java.lang.Comparable) 5);
        java.lang.String str19 = categoryItemEntity14.getURLText();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        try {
            categoryItemEntity14.setDataset(categoryDataset20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "poly" + "'", str15.equals("poly"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0" + "'", str16.equals("-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ThreadContext" + "'", str19.equals("ThreadContext"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.lang.Object obj4 = categoryMarker1.clone();
        java.awt.Paint paint5 = categoryMarker1.getPaint();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        xYPlot6.zoomRangeAxes(0.0d, plotRenderingInfo9, point2D10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot6.setRangeAxisLocation(9999, axisLocation13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint16 = dateAxis15.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline17 = dateAxis15.getTimeline();
        dateAxis15.setAutoTickUnitSelection(false);
        double double20 = dateAxis15.getLabelAngle();
        org.jfree.data.Range range21 = xYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = xYPlot6.getInsets();
        double double24 = rectangleInsets22.calculateBottomOutset((double) (short) 0);
        double double25 = rectangleInsets22.getBottom();
        categoryMarker1.setLabelOffset(rectangleInsets22);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(timeline17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "hi!", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset9);
        java.util.List list11 = defaultCategoryDataset9.getRowKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity14 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "hi!", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, (java.lang.Comparable) 0L, (java.lang.Comparable) "");
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, true);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        int int18 = year17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, (java.lang.Comparable) year17);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year17.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(pieDataset20);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        java.text.DateFormat dateFormat3 = null;
        dateAxis0.setDateFormatOverride(dateFormat3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0f);
        java.awt.Font font9 = categoryMarker8.getLabelFont();
        xYPlot5.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        try {
            java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMinRegularValue((int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLowerMargin();
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.configure();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D2.getBaseNegativeItemLabelPosition();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(false);
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean14 = stackedBarRenderer3D13.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke17 = stackedBarRenderer3D13.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke21 = categoryMarker20.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint10, stroke17, (java.awt.Paint) color18, stroke21, 0.0f);
        stackedBarRenderer3D2.setBaseOutlineStroke(stroke17, false);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.block.CenterArrangement centerArrangement1 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) centerArrangement1);
        boolean boolean3 = gradientPaintTransformType0.equals((java.lang.Object) blockContainer2);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setFixedDimension((double) (short) 10);
        java.util.Date date4 = dateAxis0.getMinimumDate();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date4);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) 10.0f, 0.0d);
        org.jfree.chart.util.Size2D size2D10 = legendTitle5.arrange(graphics2D6, rectangleConstraint9);
        java.lang.String str11 = size2D10.toString();
        size2D10.height = 100;
        size2D10.setHeight((double) 10);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str11.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        java.lang.String str2 = dateAxis0.getLabelToolTip();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D8 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D6, rectangleAnchor7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint14 = stackedBarRenderer3D12.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D12);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle15.setPosition(rectangleEdge16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle15.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo20.getDataArea();
        rectangleInsets18.trim(rectangle2D21);
        int int23 = numberTickUnit9.compareTo((java.lang.Object) rectangle2D21);
        boolean boolean24 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D6, rectangle2D21);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double26 = dateAxis0.valueToJava2D((double) 1577865599999L, rectangle2D6, rectangleEdge25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge25);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(point2D8);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(9999, axisLocation7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline11 = dateAxis9.getTimeline();
        dateAxis9.setAutoTickUnitSelection(false);
        double double14 = dateAxis9.getLabelAngle();
        org.jfree.data.Range range15 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot0.getInsets();
        java.awt.Paint paint17 = xYPlot0.getDomainZeroBaselinePaint();
        xYPlot0.clearAnnotations();
        boolean boolean19 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        int int21 = xYPlot0.getDomainAxisIndex(valueAxis20);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeline11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        java.util.List list28 = defaultIntervalCategoryDataset27.getRowKeys();
        java.util.List list29 = defaultIntervalCategoryDataset27.getColumnKeys();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.Object obj31 = null;
        int int32 = numberTickUnit30.compareTo(obj31);
        try {
            int int33 = defaultIntervalCategoryDataset27.getRowIndex((java.lang.Comparable) numberTickUnit30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(numberTickUnit30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.lang.String str2 = ringPlot0.getPlotType();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset3.removeColumn((java.lang.Comparable) 500);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3, (java.lang.Comparable) 1L);
        double double8 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset7);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset7, (java.lang.Comparable) 100.0d, (double) (byte) 0, (int) 'a');
        ringPlot0.setDataset(pieDataset12);
        java.awt.Paint paint14 = ringPlot0.getSeparatorPaint();
        double double15 = ringPlot0.getInteriorGap();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.25d + "'", double15 == 0.25d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity11 = new org.jfree.chart.entity.TickLabelEntity(shape8, "hi!", "");
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean17 = stackedBarRenderer3D16.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke20 = stackedBarRenderer3D16.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke24 = categoryMarker23.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint13, stroke20, (java.awt.Paint) color21, stroke24, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint28 = dateAxis27.getLabelPaint();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape8, stroke20, paint28);
        java.awt.Paint paint30 = legendItem29.getFillPaint();
        java.awt.Stroke stroke31 = legendItem29.getLineStroke();
        strokeList0.setStroke(3, stroke31);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean37 = stackedBarRenderer3D36.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D36.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean43 = stackedBarRenderer3D42.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke46 = stackedBarRenderer3D42.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        stackedBarRenderer3D36.setBaseOutlineStroke(stroke46, true);
        strokeList0.setStroke(15, stroke46);
        java.lang.Object obj50 = strokeList0.clone();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(obj50);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(9999, axisLocation7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline11 = dateAxis9.getTimeline();
        dateAxis9.setAutoTickUnitSelection(false);
        double double14 = dateAxis9.getLabelAngle();
        org.jfree.data.Range range15 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot0.getInsets();
        java.awt.Paint paint17 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = null;
        xYPlot0.notifyListeners(plotChangeEvent18);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray21 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer20 };
        xYPlot0.setRenderers(xYItemRendererArray21);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        xYPlot0.setRenderer(128, xYItemRenderer24, false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeline11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(xYItemRendererArray21);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        try {
            java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMinOutlier(11, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setName("");
        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("poly");
        double double2 = categoryAxis1.getCategoryMargin();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean6 = stackedBarRenderer3D5.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D5.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.LegendItem legendItem11 = stackedBarRenderer3D5.getLegendItem((int) (short) -1, 1);
        boolean boolean12 = categoryAxis1.equals((java.lang.Object) legendItem11);
        double double13 = categoryAxis1.getCategoryMargin();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint17 = dateAxis16.getLabelPaint();
        dateAxis16.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, polarItemRenderer20);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo25.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        java.awt.Point point29 = polarPlot21.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D26);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0f);
        java.awt.Font font32 = categoryMarker31.getLabelFont();
        polarPlot21.setNoDataMessageFont(font32);
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) -1, font32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertNotNull(point29);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        java.util.List list28 = defaultIntervalCategoryDataset27.getRowKeys();
        try {
            int int30 = defaultIntervalCategoryDataset27.getColumnIndex((java.lang.Comparable) "ItemLabelAnchor.INSIDE4");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        xYPlot0.setRangeCrosshairValue((double) (byte) 100);
        java.awt.Stroke stroke5 = xYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        legendItem27.setSeriesKey((java.lang.Comparable) (byte) 1);
        int int30 = legendItem27.getDatasetIndex();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = xYPlot0.getAxisOffset();
        double double9 = rectangleInsets7.calculateRightInset((double) 3600000L);
        java.lang.String str10 = rectangleInsets7.toString();
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str10.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        boolean boolean4 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlinePaint();
        stackedBarRenderer3D2.setMaximumBarWidth(0.0d);
        boolean boolean7 = stackedBarRenderer3D2.getIncludeBaseInRange();
        int int8 = stackedBarRenderer3D2.getColumnCount();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = stackedBarRenderer3D2.getLegendItems();
        java.awt.Shape shape12 = stackedBarRenderer3D2.getItemShape(3, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Point2D point2D11 = null;
        xYPlot7.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11);
        java.awt.Paint paint13 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke16 = categoryMarker15.getOutlineStroke();
        xYPlot7.setDomainCrosshairStroke(stroke16);
        boolean boolean18 = xYPlot7.isRangeZeroBaselineVisible();
        xYPlot7.setDomainCrosshairValue((double) (short) -1);
        java.awt.geom.Point2D point2D21 = xYPlot7.getQuadrantOrigin();
        java.awt.Paint paint22 = xYPlot7.getBackgroundPaint();
        polarPlot6.setRadiusGridlinePaint(paint22);
        polarPlot6.removeCornerTextItem("hi!");
        polarPlot6.removeCornerTextItem("Pie Plot");
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
        boolean boolean2 = stackedBarRenderer1.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.junit.Assert.assertNull(timeZone0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 0.95f, (java.lang.Comparable) "ClassContext");
        java.util.List list4 = defaultStatisticalCategoryDataset0.getRowKeys();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity14 = new org.jfree.chart.entity.TickLabelEntity(shape11, "hi!", "");
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean20 = stackedBarRenderer3D19.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke23 = stackedBarRenderer3D19.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke27 = categoryMarker26.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint16, stroke23, (java.awt.Paint) color24, stroke27, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint31 = dateAxis30.getLabelPaint();
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape11, stroke23, paint31);
        java.text.AttributedString attributedString33 = legendItem32.getAttributedLabel();
        boolean boolean34 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) attributedString33);
        try {
            java.lang.Number number37 = defaultStatisticalCategoryDataset0.getMeanValue(0, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(attributedString33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        int int7 = xYPlot0.getWeight();
        java.awt.Paint paint8 = xYPlot0.getBackgroundPaint();
        xYPlot0.setForegroundAlpha(0.0f);
        double double11 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint13 = dateAxis12.getLabelPaint();
        dateAxis12.setFixedDimension((double) (short) 10);
        java.util.Date date16 = dateAxis12.getMinimumDate();
        int int17 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(9999, axisLocation7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline11 = dateAxis9.getTimeline();
        dateAxis9.setAutoTickUnitSelection(false);
        double double14 = dateAxis9.getLabelAngle();
        org.jfree.data.Range range15 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot0.getInsets();
        double double18 = rectangleInsets16.calculateBottomOutset((double) (short) 0);
        double double19 = rectangleInsets16.getRight();
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets16.getUnitType();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeline11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNotNull(unitType20);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        boolean boolean6 = dateAxis0.isInverted();
        boolean boolean8 = dateAxis0.isHiddenValue(1577865599999L);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        boolean boolean8 = statisticalLineAndShapeRenderer2.getItemShapeFilled(100, (int) 'a');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = statisticalLineAndShapeRenderer2.getSeriesItemLabelGenerator((int) (byte) 10);
        statisticalLineAndShapeRenderer2.setItemLabelAnchorOffset((double) (-460));
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        xYPlot13.zoomRangeAxes(0.0d, plotRenderingInfo16, point2D17);
        java.awt.Paint paint19 = xYPlot13.getRangeTickBandPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) '#', false);
        boolean boolean24 = xYPlot13.equals((java.lang.Object) 1.0d);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = xYPlot13.getRenderer();
        boolean boolean26 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) xYPlot13);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(xYItemRenderer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint6 = stackedBarRenderer3D4.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getPosition();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint13 = stackedBarRenderer3D11.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D11);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle14.setPosition(rectangleEdge15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle14.getLegendItemGraphicPadding();
        double double18 = legendTitle14.getContentYOffset();
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("", font20);
        legendTitle14.setItemFont(font20);
        legendTitle7.setItemFont(font20);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.geom.Point2D point2D28 = null;
        xYPlot24.zoomRangeAxes(0.0d, plotRenderingInfo27, point2D28);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset31);
        xYPlot24.datasetChanged(datasetChangeEvent32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot24.getDomainAxisEdge();
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("RectangleEdge.LEFT", font20, (org.jfree.chart.plot.Plot) xYPlot24, false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor0, jFreeChart36);
        java.awt.Paint paint38 = jFreeChart36.getBorderPaint();
        org.jfree.chart.title.LegendTitle legendTitle40 = jFreeChart36.getLegend(0);
        java.awt.Paint paint41 = jFreeChart36.getBackgroundPaint();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(legendTitle40);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) 3600000L, 12.0d);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment7, verticalAlignment8, (double) 3600000L, 12.0d);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement11);
        boolean boolean13 = blockContainer12.isEmpty();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint18 = stackedBarRenderer3D16.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D16);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle19.setPosition(rectangleEdge20);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = legendTitle19.getLegendItemGraphicEdge();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo23 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray24 = basicProjectInfo23.getOptionalLibraries();
        blockContainer12.add((org.jfree.chart.block.Block) legendTitle19, (java.lang.Object) basicProjectInfo23);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint28 = dateAxis27.getLabelPaint();
        dateAxis27.setAutoTickUnitSelection(false);
        org.jfree.data.Range range31 = dateAxis27.getDefaultAutoRange();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator36 = null;
        stackedBarRenderer3D34.setSeriesURLGenerator(10, categoryURLGenerator36);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset39);
        org.jfree.data.Range range41 = stackedBarRenderer3D34.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset39);
        boolean boolean42 = range31.equals((java.lang.Object) range41);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer43 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer43.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint47 = dateAxis46.getLabelPaint();
        dateAxis46.setAutoTickUnitSelection(false);
        org.jfree.data.Range range50 = dateAxis46.getDefaultAutoRange();
        boolean boolean51 = intervalBarRenderer43.equals((java.lang.Object) range50);
        org.jfree.data.time.DateRange dateRange52 = new org.jfree.data.time.DateRange(range50);
        java.util.Date date53 = dateRange52.getUpperDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = new org.jfree.chart.block.RectangleConstraint(range31, (org.jfree.data.Range) dateRange52);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType55 = rectangleConstraint54.getHeightConstraintType();
        org.jfree.chart.util.Size2D size2D56 = columnArrangement5.arrange(blockContainer12, graphics2D26, rectangleConstraint54);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.data.Range range58 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = new org.jfree.chart.block.RectangleConstraint(range58, (double) 128);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint62 = dateAxis61.getLabelPaint();
        dateAxis61.setAutoTickUnitSelection(false);
        org.jfree.data.Range range65 = dateAxis61.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint66 = rectangleConstraint60.toRangeHeight(range65);
        try {
            org.jfree.chart.util.Size2D size2D67 = flowArrangement0.arrange(blockContainer12, graphics2D57, rectangleConstraint66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(libraryArray24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(lengthConstraintType55);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(range65);
        org.junit.Assert.assertNotNull(rectangleConstraint66);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = categoryLabelPositions0.getLabelPosition(rectangleEdge3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions5, categoryLabelPosition6);
        double double8 = categoryLabelPosition6.getAngle();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = categoryLabelPosition6.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition6);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = categoryLabelPosition6.getWidthType();
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(categoryLabelPosition4);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(categoryLabelWidthType11);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("poly");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Point2D point2D6 = null;
        xYPlot2.zoomRangeAxes(0.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot2.setRangeAxisLocation(9999, axisLocation9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot2.getRenderer();
        boolean boolean12 = xYPlot2.isDomainZoomable();
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot2);
        categoryAxis1.setLabelAngle(Double.NaN);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        int int7 = xYPlot0.getWeight();
        java.awt.Paint paint8 = xYPlot0.getBackgroundPaint();
        xYPlot0.setForegroundAlpha(0.0f);
        double double11 = xYPlot0.getRangeCrosshairValue();
        int int12 = xYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D13.configure();
        numberAxis3D13.setRangeAboutValue((double) (byte) -1, (double) 4);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D13);
        float float19 = numberAxis3D13.getTickMarkOutsideLength();
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D3 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.lang.Object obj4 = defaultKeyedValues2D3.clone();
        defaultKeyedValues2D3.clear();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        defaultKeyedValues2D3.removeValue((java.lang.Comparable) "Size2D[width=0.0, height=0.0]", (java.lang.Comparable) date10);
        java.lang.String str12 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) "Size2D[width=0.0, height=0.0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        boolean boolean4 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlinePaint();
        stackedBarRenderer3D2.setMaximumBarWidth(0.0d);
        boolean boolean7 = stackedBarRenderer3D2.getIncludeBaseInRange();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(100.0f, (-1.0f));
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape10, "Size2D[width=0.0, height=0.0]", "org.jfree.data.time.TimePeriodFormatException: ClassContext");
        stackedBarRenderer3D2.setBaseShape(shape10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (short) -1);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions2, categoryLabelPosition3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = categoryLabelPositions2.getLabelPosition(rectangleEdge5);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions7, categoryLabelPosition8);
        double double10 = categoryLabelPosition8.getAngle();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = categoryLabelPosition8.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions2, categoryLabelPosition8);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions1, categoryLabelPosition8);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(categoryLabelPosition6);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("WMAP_Plot");
        dateAxis1.setAutoRangeMinimumSize((double) 4, false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 3600000L, 12.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        boolean boolean6 = blockContainer5.isEmpty();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint11 = stackedBarRenderer3D9.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D9);
        java.lang.Object obj13 = legendTitle12.clone();
        blockContainer5.add((org.jfree.chart.block.Block) legendTitle12);
        java.awt.Font font15 = legendTitle12.getItemFont();
        legendTitle12.setNotify(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        polarPlot6.rendererChanged(rendererChangeEvent7);
        polarPlot6.setRadiusGridlinesVisible(true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("org.jfree.data.time.TimePeriodFormatException: ClassContext");
        java.lang.String str2 = textTitle1.getURLText();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("RectangleConstraintType.RANGE", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke9);
        int int11 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot0.getRangeAxis(2);
        java.awt.Paint paint14 = null;
        try {
            xYPlot0.setDomainCrosshairPaint(paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(valueAxis13);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = year3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        long long6 = year3.getFirstMillisecond();
        java.lang.Number number8 = defaultBoxAndWhiskerCategoryDataset0.getQ1Value((java.lang.Comparable) long6, (java.lang.Comparable) (byte) 100);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = year9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.next();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = new org.jfree.chart.axis.DateTickUnit(4, (int) (short) -1);
        int int15 = dateTickUnit14.getRollUnit();
        java.lang.Number number16 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue((java.lang.Comparable) year9, (java.lang.Comparable) int15);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        int int6 = xYPlot0.getSeriesCount();
        java.awt.Font font7 = xYPlot0.getNoDataMessageFont();
        int int8 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = null;
        xYPlot0.setDrawingSupplier(drawingSupplier9);
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = null;
        keyedObjects0.addObject((java.lang.Comparable) 60000L, obj2);
        int int4 = keyedObjects0.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        java.text.DateFormat dateFormat3 = null;
        dateAxis0.setDateFormatOverride(dateFormat3);
        dateAxis0.setAutoTickUnitSelection(false, true);
        dateAxis0.setRangeAboutValue((double) (short) -1, 0.2d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        legendItem27.setSeriesKey((java.lang.Comparable) (byte) 1);
        java.lang.String str30 = legendItem27.getURLText();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = stackedBarRenderer3D2.getBaseURLGenerator();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        stackedBarRenderer3D8.setSeriesURLGenerator(10, categoryURLGenerator10);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        org.jfree.data.Range range15 = stackedBarRenderer3D8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13);
        java.util.List list16 = defaultCategoryDataset13.getRowKeys();
        org.jfree.data.Range range17 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator18 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean20 = standardCategoryToolTipGenerator18.equals((java.lang.Object) 100.0f);
        stackedBarRenderer3D2.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator18);
        java.text.DateFormat dateFormat22 = standardCategoryToolTipGenerator18.getDateFormat();
        java.text.NumberFormat numberFormat23 = standardCategoryToolTipGenerator18.getNumberFormat();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(dateFormat22);
        org.junit.Assert.assertNotNull(numberFormat23);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean2 = standardCategoryToolTipGenerator0.equals((java.lang.Object) 100.0f);
        java.text.DateFormat dateFormat3 = standardCategoryToolTipGenerator0.getDateFormat();
        java.text.DateFormat dateFormat4 = standardCategoryToolTipGenerator0.getDateFormat();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(dateFormat3);
        org.junit.Assert.assertNull(dateFormat4);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) 10.0f, 0.0d);
        org.jfree.chart.util.Size2D size2D10 = legendTitle5.arrange(graphics2D6, rectangleConstraint9);
        java.lang.String str11 = size2D10.toString();
        size2D10.setWidth((double) (short) 1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str11.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint6 = stackedBarRenderer3D4.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D4);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) 10.0f, 0.0d);
        org.jfree.chart.util.Size2D size2D12 = legendTitle7.arrange(graphics2D8, rectangleConstraint11);
        java.lang.String str13 = size2D12.toString();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D12, (double) (byte) 10, (double) 10, rectangleAnchor16);
        lineBorder0.draw(graphics2D1, rectangle2D17);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str13.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        int int7 = xYPlot0.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline10 = dateAxis8.getTimeline();
        dateAxis8.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj14 = numberAxis3D13.clone();
        numberAxis3D13.setAutoTickUnitSelection(false);
        java.text.NumberFormat numberFormat17 = null;
        numberAxis3D13.setNumberFormatOverride(numberFormat17);
        numberAxis3D13.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font22 = dateAxis21.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint24 = dateAxis23.getLabelPaint();
        dateAxis23.setAutoTickUnitSelection(false);
        boolean boolean27 = dateAxis23.isVerticalTickLabels();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { dateAxis8, numberAxis3D13, dateAxis21, dateAxis23 };
        xYPlot0.setDomainAxes(valueAxisArray28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(timeline10);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertNull(axisSpace30);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.LEFT" + "'", str1.equals("HorizontalAlignment.LEFT"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Comparable comparable2 = null;
        java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getValue((java.lang.Comparable) 9999, comparable2);
        double double5 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(true);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getRowCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getColorComponents(floatArray1);
        java.awt.color.ColorSpace colorSpace3 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(colorSpace3);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        dateAxis0.setAutoTickUnitSelection(false);
        double double5 = dateAxis0.getLabelAngle();
        dateAxis0.configure();
        dateAxis0.setTickMarkInsideLength((float) (short) -1);
        java.awt.Paint paint9 = dateAxis0.getTickMarkPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        int int1 = ringPlot0.getPieIndex();
        java.lang.String str2 = ringPlot0.getPlotType();
        ringPlot0.setLabelLinksVisible(false);
        ringPlot0.setStartAngle((double) (-2208960000000L));
        java.awt.Color color7 = java.awt.Color.CYAN;
        int int8 = color7.getTransparency();
        ringPlot0.setSeparatorPaint((java.awt.Paint) color7);
        int int10 = color7.getTransparency();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = xYPlot0.getAxisOffset();
        java.awt.Paint paint9 = xYPlot0.getQuadrantPaint(0);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        xYPlot0.setDomainAxis(4, valueAxis11);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        statisticalLineAndShapeRenderer2.setSeriesVisible((int) (byte) 0, (java.lang.Boolean) true, true);
        java.lang.Object obj14 = statisticalLineAndShapeRenderer2.clone();
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        java.awt.Color color18 = java.awt.Color.YELLOW;
        statisticalLineAndShapeRenderer2.setSeriesOutlinePaint(0, (java.awt.Paint) color18, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) 10.0f, 0.0d);
        org.jfree.chart.util.Size2D size2D10 = legendTitle5.arrange(graphics2D6, rectangleConstraint9);
        size2D10.setWidth((double) '4');
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(size2D10);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        java.util.List list28 = defaultIntervalCategoryDataset27.getRowKeys();
        java.util.List list29 = defaultIntervalCategoryDataset27.getColumnKeys();
        java.util.List list30 = defaultIntervalCategoryDataset27.getRowKeys();
        try {
            int int32 = defaultIntervalCategoryDataset27.indexOf((java.lang.Comparable) Double.POSITIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.lang.Object obj4 = categoryMarker1.clone();
        java.lang.Class<?> wildcardClass5 = categoryMarker1.getClass();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryMarker1.getLabelOffset();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = null;
        dateAxis1.setStandardTickUnits(tickUnitSource5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean10 = stackedBarRenderer3D9.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke13 = stackedBarRenderer3D9.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis1.setAxisLineStroke(stroke13);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, (float) 100L);
        dateAxis1.setRightArrow(shape17);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        boolean boolean20 = dateAxis19.isAutoTickUnitSelection();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity26 = new org.jfree.chart.entity.TickLabelEntity(shape23, "hi!", "");
        dateAxis19.setLeftArrow(shape23);
        dateAxis19.configure();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer29);
        dateAxis1.centerRange(12.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeLowerBound(true);
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getValue((java.lang.Comparable) 1546329600000L, (java.lang.Comparable) 900000L);
        java.lang.Number number8 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((java.lang.Comparable) 1546329600000L, (java.lang.Comparable) 128);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) '#', false);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer4 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer4.setBaseCreateEntities(true, false);
        java.awt.Paint paint8 = ganttRenderer4.getCompletePaint();
        boolean boolean9 = stackedBarRenderer3D3.equals((java.lang.Object) ganttRenderer4);
        java.awt.Paint paint10 = ganttRenderer4.getIncompletePaint();
        java.awt.Paint paint11 = ganttRenderer4.getIncompletePaint();
        ganttRenderer4.setEndPercent((double) (short) -1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) '#', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) (-1));
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(1, false);
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        boolean boolean17 = statisticalLineAndShapeRenderer2.getItemLineVisible((int) ' ', 15);
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 3600000L, 12.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        boolean boolean6 = blockContainer5.isEmpty();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint11 = stackedBarRenderer3D9.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D9);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle12.setPosition(rectangleEdge13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle12.getLegendItemGraphicEdge();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo16 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray17 = basicProjectInfo16.getOptionalLibraries();
        blockContainer5.add((org.jfree.chart.block.Block) legendTitle12, (java.lang.Object) basicProjectInfo16);
        org.jfree.chart.block.Arrangement arrangement19 = blockContainer5.getArrangement();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(libraryArray17);
        org.junit.Assert.assertNotNull(arrangement19);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint5 = stackedBarRenderer3D3.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getPosition();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint12 = stackedBarRenderer3D10.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D10);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle13.setPosition(rectangleEdge14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle13.getLegendItemGraphicPadding();
        double double17 = legendTitle13.getContentYOffset();
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("", font19);
        legendTitle13.setItemFont(font19);
        legendTitle6.setItemFont(font19);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo25);
        java.awt.geom.Point2D point2D27 = null;
        xYPlot23.zoomRangeAxes(0.0d, plotRenderingInfo26, point2D27);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset30);
        xYPlot23.datasetChanged(datasetChangeEvent31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot23.getDomainAxisEdge();
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("RectangleEdge.LEFT", font19, (org.jfree.chart.plot.Plot) xYPlot23, false);
        org.jfree.chart.plot.Plot plot36 = jFreeChart35.getPlot();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(plot36);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        labelBlock2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder3);
        java.awt.Font font6 = labelBlock2.getFont();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        int int6 = xYPlot0.getSeriesCount();
        java.awt.Color color9 = java.awt.Color.magenta;
        org.jfree.chart.axis.Axis axis14 = null;
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, (float) 100L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity20 = new org.jfree.chart.entity.AxisLabelEntity(axis14, shape17, "hi!", "ClassContext");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape17, rectangleAnchor21, 10.0d, (double) 10.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        dateAxis25.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = null;
        dateAxis25.setStandardTickUnits(tickUnitSource29);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean34 = stackedBarRenderer3D33.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke37 = stackedBarRenderer3D33.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis25.setAxisLineStroke(stroke37);
        java.awt.Paint paint39 = null;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("poly", "", "TextBlockAnchor.TOP_CENTER", "", shape24, stroke37, paint39);
        java.awt.Paint paint41 = null;
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D46 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean47 = stackedBarRenderer3D46.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke50 = stackedBarRenderer3D46.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke54 = categoryMarker53.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint43, stroke50, (java.awt.Paint) color51, stroke54, 0.0f);
        org.jfree.chart.plot.IntervalMarker intervalMarker58 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 0, 1.0E-5d, (java.awt.Paint) color9, stroke37, paint41, stroke54, 1.0f);
        xYPlot0.setDomainCrosshairStroke(stroke37);
        java.awt.Stroke stroke60 = null;
        xYPlot0.setOutlineStroke(stroke60);
        java.awt.Color color65 = java.awt.Color.getHSBColor((float) 100, (float) (byte) 1, (float) (-460));
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color65);
        org.jfree.data.xy.XYDataset xYDataset68 = null;
        xYPlot0.setDataset((int) ' ', xYDataset68);
        java.util.List list70 = xYPlot0.getAnnotations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(list70);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.data.Range range5 = dateAxis1.getDefaultAutoRange();
        numberAxis0.setRangeWithMargins(range5, true, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(numberTickUnit9);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D2.getBaseNegativeItemLabelPosition();
        java.awt.Color color8 = java.awt.Color.lightGray;
        stackedBarRenderer3D2.setSeriesOutlinePaint(100, (java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 900000L);
        double double3 = intervalMarker2.getStartValue();
        double double4 = intervalMarker2.getEndValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 900000.0d + "'", double4 == 900000.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getRightArrow();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable1 = null;
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getValue(comparable1, (java.lang.Comparable) 9999);
        int int5 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) 1.0E-5d);
        defaultStatisticalCategoryDataset0.add((double) 11, (double) 0.0f, (java.lang.Comparable) 1577865599999L, (java.lang.Comparable) Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getLowerMargin();
        categoryAxis0.clearCategoryLabelToolTips();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        dateAxis3.setStandardTickUnits(tickUnitSource7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean12 = stackedBarRenderer3D11.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke15 = stackedBarRenderer3D11.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis3.setAxisLineStroke(stroke15);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity26 = new org.jfree.chart.entity.TickLabelEntity(shape23, "hi!", "");
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean32 = stackedBarRenderer3D31.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke35 = stackedBarRenderer3D31.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke39 = categoryMarker38.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint28, stroke35, (java.awt.Paint) color36, stroke39, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint43 = dateAxis42.getLabelPaint();
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape23, stroke35, paint43);
        dateAxis3.setLabelPaint(paint43);
        categoryAxis0.setTickMarkPaint(paint43);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.lang.Object obj4 = categoryMarker1.clone();
        java.lang.Comparable comparable5 = categoryMarker1.getKey();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        stackedBarRenderer3D8.setPositiveItemLabelPositionFallback(itemLabelPosition9);
        boolean boolean11 = stackedBarRenderer3D8.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D8.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) true, false);
        boolean boolean16 = categoryMarker1.equals((java.lang.Object) stackedBarRenderer3D8);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 10L + "'", comparable5.equals(10L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        org.jfree.chart.renderer.RendererState rendererState3 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo2);
        int int4 = plotRenderingInfo2.getSubplotCount();
        java.awt.geom.Rectangle2D rectangle2D5 = plotRenderingInfo2.getDataArea();
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(rectangle2D5);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Point2D point2D6 = null;
        xYPlot2.zoomRangeAxes(0.0d, plotRenderingInfo5, point2D6);
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo5);
        boolean boolean10 = plotRenderingInfo5.equals((java.lang.Object) 11);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(8);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        java.lang.String str2 = waferMapPlot1.getPlotType();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot1.getDataset();
        boolean boolean4 = keyedObjects0.equals((java.lang.Object) waferMapPlot1);
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot1.setDataset(waferMapDataset5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WMAP_Plot" + "'", str2.equals("WMAP_Plot"));
        org.junit.Assert.assertNull(waferMapDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.lang.Boolean boolean7 = stackedBarRenderer3D2.getSeriesCreateEntities(500);
        stackedBarRenderer3D2.setBaseSeriesVisible(true);
        boolean boolean10 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlineStroke();
        int int11 = stackedBarRenderer3D2.getRowCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        xYPlot0.setRangeCrosshairValue((double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = xYPlot0.getInsets();
        double double7 = rectangleInsets5.calculateTopOutset((double) 1.0f);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ItemLabelAnchor.INSIDE4");
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        boolean boolean8 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlineStroke();
        stackedBarRenderer3D2.setSeriesCreateEntities(2019, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D2.getSeriesNegativeItemLabelPosition(100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint5 = stackedBarRenderer3D3.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getPosition();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint12 = stackedBarRenderer3D10.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D10);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle13.setPosition(rectangleEdge14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle13.getLegendItemGraphicPadding();
        double double17 = legendTitle13.getContentYOffset();
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("", font19);
        legendTitle13.setItemFont(font19);
        legendTitle6.setItemFont(font19);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo25);
        java.awt.geom.Point2D point2D27 = null;
        xYPlot23.zoomRangeAxes(0.0d, plotRenderingInfo26, point2D27);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset30);
        xYPlot23.datasetChanged(datasetChangeEvent31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot23.getDomainAxisEdge();
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("RectangleEdge.LEFT", font19, (org.jfree.chart.plot.Plot) xYPlot23, false);
        float float36 = jFreeChart35.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisCollection axisCollection37 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list38 = axisCollection37.getAxesAtTop();
        jFreeChart35.setSubtitles(list38);
        java.awt.Image image40 = jFreeChart35.getBackgroundImage();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.5f + "'", float36 == 0.5f);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNull(image40);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor2 = categoryLabelPosition1.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition1);
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Third", "Third", numberArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryLabelPositions3, (org.jfree.data.general.Dataset) categoryDataset7);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj1 = numberAxis3D0.clone();
        numberAxis3D0.setAutoTickUnitSelection(false);
        double double4 = numberAxis3D0.getFixedDimension();
        org.jfree.data.RangeType rangeType5 = numberAxis3D0.getRangeType();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rangeType5);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        dateAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        boolean boolean1 = minMaxCategoryRenderer0.isDrawLines();
        javax.swing.Icon icon2 = minMaxCategoryRenderer0.getMinIcon();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(icon2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo6);
        java.awt.geom.Point2D point2D8 = null;
        xYPlot4.zoomRangeAxes(0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj12 = numberAxis3D11.clone();
        numberAxis3D11.setAutoTickUnitSelection(false);
        numberAxis3D11.configure();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint19 = dateAxis18.getLabelPaint();
        dateAxis18.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, polarItemRenderer22);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.geom.Rectangle2D rectangle2D28 = plotRenderingInfo27.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D30 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D28, rectangleAnchor29);
        java.awt.Point point31 = polarPlot23.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D28);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double33 = numberAxis3D11.java2DToValue(4.0d, rectangle2D28, rectangleEdge32);
        plotRenderingInfo7.setPlotArea(rectangle2D28);
        java.awt.Color color36 = java.awt.Color.CYAN;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo39);
        java.awt.geom.Point2D point2D41 = null;
        xYPlot37.zoomRangeAxes(0.0d, plotRenderingInfo40, point2D41);
        java.awt.Stroke stroke43 = xYPlot37.getRangeCrosshairStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 0, (java.awt.Paint) color36, stroke43);
        java.awt.Paint paint45 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem(attributedString0, "ItemLabelAnchor.OUTSIDE2", "ChartChangeEventType.NEW_DATASET", "RangeType.FULL", (java.awt.Shape) rectangle2D28, stroke43, paint45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(point2D30);
        org.junit.Assert.assertNotNull(point31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + Double.POSITIVE_INFINITY + "'", double33 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("ThreadContext");
        categoryAxis1.setUpperMargin(35.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint6 = stackedBarRenderer3D4.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getPosition();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint13 = stackedBarRenderer3D11.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D11);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle14.setPosition(rectangleEdge15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle14.getLegendItemGraphicPadding();
        double double18 = legendTitle14.getContentYOffset();
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("", font20);
        legendTitle14.setItemFont(font20);
        legendTitle7.setItemFont(font20);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.geom.Point2D point2D28 = null;
        xYPlot24.zoomRangeAxes(0.0d, plotRenderingInfo27, point2D28);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset31);
        xYPlot24.datasetChanged(datasetChangeEvent32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot24.getDomainAxisEdge();
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("RectangleEdge.LEFT", font20, (org.jfree.chart.plot.Plot) xYPlot24, false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textAnchor0, jFreeChart36);
        jFreeChart36.removeLegend();
        java.awt.Image image39 = jFreeChart36.getBackgroundImage();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNull(image39);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        boolean boolean7 = stackedBarRenderer3D2.isSeriesItemLabelsVisible(0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        xYPlot0.setRangeCrosshairValue((double) (byte) 100);
        java.awt.geom.Point2D point2D5 = xYPlot0.getQuadrantOrigin();
        java.io.ObjectOutputStream objectOutputStream6 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D5, objectOutputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(point2D5);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setName("");
        projectInfo0.setName("ClassContext");
        java.util.List list5 = projectInfo0.getContributors();
        org.junit.Assert.assertNull(list5);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        xYPlot0.setRangeCrosshairValue((double) (byte) 100);
        xYPlot0.clearDomainMarkers();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYPlot0.rendererChanged(rendererChangeEvent6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxis((int) (short) 100);
        java.awt.Paint paint10 = xYPlot0.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        ringPlot0.setLabelBackgroundPaint(paint1);
        double double3 = ringPlot0.getSectionDepth();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = null;
        ringPlot0.setDrawingSupplier(drawingSupplier4);
        double double6 = ringPlot0.getLabelGap();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Stroke stroke1 = ringPlot0.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str1.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.lang.Object obj2 = defaultKeyedValues2D1.clone();
        defaultKeyedValues2D1.clear();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) "Size2D[width=0.0, height=0.0]", (java.lang.Comparable) date8);
        try {
            defaultKeyedValues2D1.removeColumn(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Paint paint2 = numberAxis1.getTickLabelPaint();
        numberAxis1.setLabelToolTip("-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0");
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        org.jfree.data.Range range9 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        java.awt.Stroke stroke10 = stackedBarRenderer3D2.getBaseOutlineStroke();
        java.awt.Paint paint12 = stackedBarRenderer3D2.lookupSeriesFillPaint((int) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = stackedBarRenderer3D2.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(itemLabelPosition13);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.Range range2 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = year3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        long long6 = year3.getFirstMillisecond();
        java.lang.Number number8 = defaultBoxAndWhiskerCategoryDataset0.getQ1Value((java.lang.Comparable) long6, (java.lang.Comparable) (byte) 100);
        double double10 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = new org.jfree.chart.axis.DateTickUnit(4, (int) (short) -1);
        int int14 = dateTickUnit13.getRollUnit();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint16 = dateAxis15.getLabelPaint();
        dateAxis15.setAutoTickUnitSelection(false);
        org.jfree.data.Range range19 = dateAxis15.getDefaultAutoRange();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        stackedBarRenderer3D22.setSeriesURLGenerator(10, categoryURLGenerator24);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset27 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset27);
        org.jfree.data.Range range29 = stackedBarRenderer3D22.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset27);
        boolean boolean30 = range19.equals((java.lang.Object) range29);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer31 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer31.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint35 = dateAxis34.getLabelPaint();
        dateAxis34.setAutoTickUnitSelection(false);
        org.jfree.data.Range range38 = dateAxis34.getDefaultAutoRange();
        boolean boolean39 = intervalBarRenderer31.equals((java.lang.Object) range38);
        org.jfree.data.time.DateRange dateRange40 = new org.jfree.data.time.DateRange(range38);
        java.util.Date date41 = dateRange40.getUpperDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint(range19, (org.jfree.data.Range) dateRange40);
        java.util.Date date43 = dateRange40.getLowerDate();
        java.lang.String str44 = dateTickUnit13.dateToString(date43);
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = new org.jfree.chart.axis.DateTickUnit(4, (int) (short) -1);
        int int48 = dateTickUnit47.getRollUnit();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint50 = dateAxis49.getLabelPaint();
        dateAxis49.setAutoTickUnitSelection(false);
        org.jfree.data.Range range53 = dateAxis49.getDefaultAutoRange();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D56 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator58 = null;
        stackedBarRenderer3D56.setSeriesURLGenerator(10, categoryURLGenerator58);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset61 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent62 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset61);
        org.jfree.data.Range range63 = stackedBarRenderer3D56.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset61);
        boolean boolean64 = range53.equals((java.lang.Object) range63);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer65 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer65.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint69 = dateAxis68.getLabelPaint();
        dateAxis68.setAutoTickUnitSelection(false);
        org.jfree.data.Range range72 = dateAxis68.getDefaultAutoRange();
        boolean boolean73 = intervalBarRenderer65.equals((java.lang.Object) range72);
        org.jfree.data.time.DateRange dateRange74 = new org.jfree.data.time.DateRange(range72);
        java.util.Date date75 = dateRange74.getUpperDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint76 = new org.jfree.chart.block.RectangleConstraint(range53, (org.jfree.data.Range) dateRange74);
        java.util.Date date77 = dateRange74.getLowerDate();
        java.lang.String str78 = dateTickUnit47.dateToString(date77);
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Date date80 = dateTickUnit13.rollDate(date77, timeZone79);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues81 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder82 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues81.sortByKeys(sortOrder82);
        java.lang.Number number85 = null;
        defaultKeyedValues81.setValue((java.lang.Comparable) ' ', number85);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer87 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer87.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis90 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint91 = dateAxis90.getLabelPaint();
        dateAxis90.setAutoTickUnitSelection(false);
        org.jfree.data.Range range94 = dateAxis90.getDefaultAutoRange();
        boolean boolean95 = intervalBarRenderer87.equals((java.lang.Object) range94);
        org.jfree.data.time.DateRange dateRange96 = new org.jfree.data.time.DateRange(range94);
        java.util.Date date97 = dateRange96.getLowerDate();
        defaultKeyedValues81.removeValue((java.lang.Comparable) date97);
        java.lang.Number number99 = defaultBoxAndWhiskerCategoryDataset0.getMaxRegularValue((java.lang.Comparable) date77, (java.lang.Comparable) date97);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "12/31/69" + "'", str44.equals("12/31/69"));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "12/31/69" + "'", str78.equals("12/31/69"));
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(sortOrder82);
        org.junit.Assert.assertNotNull(paint91);
        org.junit.Assert.assertNotNull(range94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(date97);
        org.junit.Assert.assertNull(number99);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = dateAxis4.isAutoTickUnitSelection();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity11 = new org.jfree.chart.entity.TickLabelEntity(shape8, "hi!", "");
        dateAxis4.setLeftArrow(shape8);
        dateAxis4.configure();
        dateAxis4.configure();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("poly");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo20.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D23 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor22);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint29 = stackedBarRenderer3D27.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D27);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle30.setPosition(rectangleEdge31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle30.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo34);
        java.awt.geom.Rectangle2D rectangle2D36 = plotRenderingInfo35.getDataArea();
        rectangleInsets33.trim(rectangle2D36);
        int int38 = numberTickUnit24.compareTo((java.lang.Object) rectangle2D36);
        boolean boolean39 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D21, rectangle2D36);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = numberAxis17.valueToJava2D((double) 10.0f, rectangle2D21, rectangleEdge40);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint46 = stackedBarRenderer3D44.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D44);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle47.setPosition(rectangleEdge48);
        double double50 = dateAxis4.lengthToJava2D((double) 0L, rectangle2D21, rectangleEdge48);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer53 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        java.awt.Color color54 = java.awt.Color.green;
        statisticalLineAndShapeRenderer53.setBaseFillPaint((java.awt.Paint) color54, false);
        org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem("RectangleEdge.LEFT", "", "", "ItemLabelAnchor.INSIDE4", (java.awt.Shape) rectangle2D21, (java.awt.Paint) color54);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertNotNull(numberTickUnit24);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(color54);
    }
}

