import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Shape shape0 = null;
        try {
            java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, (double) (short) 10, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Paint paint0 = null;
        java.awt.Paint paint1 = null;
        java.awt.Paint paint2 = null;
        java.awt.Paint paint3 = null;
        try {
            org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(paint0, paint1, paint2, paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'firstBarPaint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape1, (double) 100.0f, (float) (-1L), (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Stroke stroke0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = null;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem(attributedString0, "", "hi!", "", shape4, paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 10, 0.0d);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 10.0d + "'", number3.equals(10.0d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = null;
        try {
            stackedBarRenderer3D2.setLegendItemLabelGenerator(categorySeriesLabelGenerator3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categoryAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("hi!", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) true, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        try {
            stackedBarRenderer3D2.setSeriesShape((int) (byte) -1, shape6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0f, (float) (short) 0, textAnchor4, (double) (short) -1, textAnchor6);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            defaultKeyedValues0.insertValue((int) ' ', (java.lang.Comparable) (short) -1, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        try {
            stackedBarRenderer3D2.setBasePositiveItemLabelPosition(itemLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener3 = null;
        try {
            stackedBarRenderer3D2.removeChangeListener(rendererChangeListener3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition1, categoryLabelPosition2, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        try {
            stackedBarRenderer3D2.drawItem(graphics2D6, categoryItemRendererState7, rectangle2D8, categoryPlot9, categoryAxis10, valueAxis11, categoryDataset12, 0, (int) (byte) 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = stackedBarRenderer3D2.getSeriesToolTipGenerator((int) (short) 100);
        org.junit.Assert.assertNull(categoryToolTipGenerator4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue(2, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke6 = stackedBarRenderer3D2.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint13 = dateAxis12.getLabelPaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset14 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            stackedBarRenderer3D2.drawItem(graphics2D7, categoryItemRendererState8, rectangle2D9, categoryPlot10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset14, 0, 0, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setNegativeArrowVisible(true);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        java.lang.Class class1 = null;
//        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", class1);
//        org.junit.Assert.assertNull(inputStream2);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 100);
        org.jfree.data.Range range3 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toRangeWidth(range3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1), (double) '4', (double) 2, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Comparable comparable2 = null;
        try {
            defaultKeyedValues0.insertValue((int) (short) 0, comparable2, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        boolean boolean8 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        stackedBarRenderer3D2.setBaseToolTipGenerator(categoryToolTipGenerator9);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        java.lang.Comparable comparable3 = null;
        try {
            java.lang.Number number5 = defaultCategoryDataset1.getValue(comparable3, (java.lang.Comparable) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener4 = null;
        categoryMarker1.removeChangeListener(markerChangeListener4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        try {
            categoryMarker1.setLabelOffsetType(lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.jfree.chart.axis.DateTickUnit.SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        java.util.Date date3 = null;
        try {
            dateAxis0.setMinimumDate(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'date' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        java.lang.Comparable comparable3 = null;
        defaultCategoryDataset1.removeColumn(comparable3);
        try {
            java.lang.Number number7 = defaultCategoryDataset1.getValue((java.lang.Comparable) 5, (java.lang.Comparable) 0.25d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 0.25");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (short) -1);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Color color2 = java.awt.Color.getColor("ClassContext", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(0.25d, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation3 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 10, 0.0d);
        boolean boolean4 = categoryLabelPositions0.equals((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Comparable comparable2 = defaultKeyedValues0.getKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean9 = stackedBarRenderer3D8.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke12 = stackedBarRenderer3D8.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis0.setAxisLineStroke(stroke12);
        java.io.ObjectOutputStream objectOutputStream14 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke12, objectOutputStream14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        java.text.DateFormat dateFormat3 = null;
        dateAxis0.setDateFormatOverride(dateFormat3);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double8 = dateAxis0.java2DToValue((double) 100L, rectangle2D6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D2.getLegendItem((int) (short) -1, 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedBarRenderer3D2.getSeriesItemLabelGenerator(2);
        java.awt.Paint paint12 = stackedBarRenderer3D2.lookupSeriesOutlinePaint((-1));
        stackedBarRenderer3D2.setIncludeBaseInRange(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setSeriesVisible(100, (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline11 = dateAxis9.getTimeline();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        java.lang.Comparable comparable15 = null;
        defaultCategoryDataset13.removeColumn(comparable15);
        try {
            stackedAreaRenderer0.drawItem(graphics2D4, categoryItemRendererState5, rectangle2D6, categoryPlot7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset13, (int) (short) -1, 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeline11);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = null;
        try {
            numberAxis3D0.setTickUnit(numberTickUnit1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj1 = datasetGroup0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        java.util.List list3 = axisState2.getTicks();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            java.util.List list6 = numberAxis3D0.refreshTicks(graphics2D1, axisState2, rectangle2D4, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) 'a', (float) (-1));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            stackedBarRenderer3D2.drawBackground(graphics2D5, categoryPlot6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toRangeWidth(range1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D2.getLegendItem((int) (short) -1, 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        try {
            stackedBarRenderer3D2.setPlot(categoryPlot9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItem8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        try {
            ganttRenderer0.setSeriesFillPaint((-1), paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryMarker8.notifyListeners(markerChangeEvent9);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener11 = null;
        categoryMarker8.removeChangeListener(markerChangeListener11);
        org.jfree.chart.util.Layer layer13 = null;
        try {
            xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke6 = stackedBarRenderer3D2.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        int int7 = stackedBarRenderer3D2.getRowCount();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint14 = dateAxis13.getLabelPaint();
        dateAxis13.setAutoTickUnitSelection(false);
        java.lang.String str17 = dateAxis13.getLabel();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset18 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            stackedBarRenderer3D2.drawItem(graphics2D8, categoryItemRendererState9, rectangle2D10, categoryPlot11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset18, 0, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("TextBlockAnchor.TOP_CENTER");
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setAutoTickUnitSelection(false);
        java.lang.String str4 = dateAxis0.getLabel();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = new org.jfree.chart.axis.AxisState();
        java.util.List list7 = axisState6.getTicks();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        stackedBarRenderer3D10.setSeriesURLGenerator(10, categoryURLGenerator12);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset15 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset15);
        org.jfree.data.Range range17 = stackedBarRenderer3D10.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset15);
        java.util.List list18 = defaultCategoryDataset15.getRowKeys();
        axisState6.setTicks(list18);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            java.util.List list22 = dateAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D20, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "hi!", "");
        tickLabelEntity5.setURLText("");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.Axis axis0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, (float) 100L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity6 = new org.jfree.chart.entity.AxisLabelEntity(axis0, shape3, "hi!", "ClassContext");
        java.io.ObjectOutputStream objectOutputStream7 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape3, objectOutputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            defaultKeyedValues0.removeValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        java.io.ObjectOutputStream objectOutputStream28 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke18, objectOutputStream28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX((double) 1L);
        blockParams0.setGenerateEntities(true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeColumn((java.lang.Comparable) 500);
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) 1L);
        boolean boolean5 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset4);
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        xYPlot0.setRangeCrosshairValue((double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = xYPlot0.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint7 = dateAxis6.getLabelPaint();
        dateAxis6.setNegativeArrowVisible(true);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] { dateAxis6 };
        xYPlot0.setDomainAxes(valueAxisArray10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(valueAxisArray10);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 60000L, (double) (-1.0f));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.Axis axis4 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, (float) 100L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity10 = new org.jfree.chart.entity.AxisLabelEntity(axis4, shape7, "hi!", "ClassContext");
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean16 = stackedBarRenderer3D15.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke19 = stackedBarRenderer3D15.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke23 = categoryMarker22.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint12, stroke19, (java.awt.Paint) color20, stroke23, 0.0f);
        java.awt.Color color26 = java.awt.Color.white;
        try {
            org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "ClassContext", "", shape7, stroke19, (java.awt.Paint) color26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) 'a', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.Number number3 = defaultStatisticalCategoryDataset0.getValue((int) 'a', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition3);
        boolean boolean5 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) true, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = null;
        try {
            stackedBarRenderer3D2.setLegendItemLabelGenerator(categorySeriesLabelGenerator10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke6 = stackedBarRenderer3D2.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        int int7 = stackedBarRenderer3D2.getRowCount();
        org.jfree.chart.axis.Axis axis8 = null;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, (float) 100L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity14 = new org.jfree.chart.entity.AxisLabelEntity(axis8, shape11, "hi!", "ClassContext");
        stackedBarRenderer3D2.setBaseShape(shape11, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition3);
        boolean boolean5 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisible(false, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Color color1 = java.awt.Color.getColor("TextBlockAnchor.TOP_CENTER");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        java.awt.geom.Point2D point2D7 = null;
        xYPlot3.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo11.getDataArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset17);
        try {
            stackedBarRenderer1.drawItem(graphics2D2, categoryItemRendererState9, rectangle2D12, categoryPlot13, categoryAxis14, valueAxis15, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset17, (int) (byte) 10, (int) (byte) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Color color10 = java.awt.Color.green;
        try {
            org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem(attributedString0, "ClassContext", "", "poly", shape6, (java.awt.Paint) color10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj1 = numberAxis3D0.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = null;
        try {
            numberAxis3D0.setTickUnit(numberTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType1 = null;
        try {
            stackedAreaRenderer0.setEndType(areaRendererEndType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 100, (double) '#', (double) (-1.0f), (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.axis.Axis axis0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, (float) 100L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity6 = new org.jfree.chart.entity.AxisLabelEntity(axis0, shape3, "hi!", "ClassContext");
        java.lang.String str7 = axisLabelEntity6.getToolTipText();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.awt.Font font4 = null;
        try {
            categoryMarker1.setLabelFont(font4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Third" + "'", str1.equals("Third"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        legendItem27.setSeriesKey((java.lang.Comparable) 1.0E-5d);
        java.awt.Paint paint30 = legendItem27.getLinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem27.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset31);
        java.lang.String str33 = legendItem27.getDescription();
        java.lang.String str34 = legendItem27.getToolTipText();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str33.equals("TextBlockAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        try {
            java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultIntervalCategoryDataset27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Stroke stroke3 = stackedBarRenderer3D2.getBaseOutlineStroke();
        stackedBarRenderer3D2.setAutoPopulateSeriesShape(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = plotRenderingInfo9.getDataArea();
        try {
            stackedBarRenderer3D2.drawOutline(graphics2D6, categoryPlot7, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangle2D10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        boolean boolean2 = dateAxis0.isAxisLineVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo6);
        java.awt.geom.Point2D point2D8 = null;
        xYPlot4.zoomRangeAxes(0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo7);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo12.getDataArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj17 = numberAxis3D16.clone();
        numberAxis3D16.setAutoTickUnitSelection(false);
        java.text.NumberFormat numberFormat20 = null;
        numberAxis3D16.setNumberFormatOverride(numberFormat20);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset23);
        java.util.List list25 = defaultCategoryDataset23.getRowKeys();
        try {
            stackedAreaRenderer0.drawItem(graphics2D3, categoryItemRendererState10, rectangle2D13, categoryPlot14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis3D16, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset23, (int) (short) 0, 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) labelBlock2);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(false, true);
        stackedBarRenderer3D2.setAutoPopulateSeriesStroke(true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        float float1 = categoryLabelPosition0.getWidthRatio();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.95f + "'", float1 == 0.95f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library library1 = null;
        try {
            projectInfo0.addOptionalLibrary(library1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Library must be given.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        stackedAreaRenderer0.setBaseURLGenerator(categoryURLGenerator3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setAutoTickUnitSelection(false);
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.data.Range range5 = null;
        try {
            dateAxis0.setRange(range5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo10.getDataArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        xYPlot14.zoomRangeAxes(0.0d, plotRenderingInfo17, point2D18);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState20 = stackedBarRenderer3D2.initialise(graphics2D8, rectangle2D11, categoryPlot12, (int) (short) 100, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(range1, (double) 128);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint5 = dateAxis4.getLabelPaint();
        dateAxis4.setAutoTickUnitSelection(false);
        org.jfree.data.Range range8 = dateAxis4.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint3.toRangeHeight(range8);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = null;
        org.jfree.data.Range range12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint14 = dateAxis13.getLabelPaint();
        dateAxis13.setAutoTickUnitSelection(false);
        org.jfree.data.Range range17 = dateAxis13.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(range12, range17);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) 500, range8, lengthConstraintType10, 10.0d, range17, lengthConstraintType19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        int int6 = xYPlot0.getSeriesCount();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        categoryMarker8.notifyListeners(markerChangeEvent9);
        java.lang.Object obj11 = categoryMarker8.clone();
        java.awt.Paint paint12 = categoryMarker8.getPaint();
        java.awt.Paint paint13 = categoryMarker8.getLabelPaint();
        org.jfree.chart.util.Layer layer14 = null;
        try {
            xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity10 = new org.jfree.chart.entity.TickLabelEntity(shape7, "hi!", "");
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean16 = stackedBarRenderer3D15.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke19 = stackedBarRenderer3D15.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke23 = categoryMarker22.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint12, stroke19, (java.awt.Paint) color20, stroke23, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint27 = dateAxis26.getLabelPaint();
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape7, stroke19, paint27);
        legendItem28.setSeriesKey((java.lang.Comparable) 1.0E-5d);
        java.awt.Paint paint31 = legendItem28.getLinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset32 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem28.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset32);
        try {
            java.lang.String str35 = standardCategoryToolTipGenerator0.generateColumnLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset32, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int0 = org.jfree.chart.axis.DateTickUnit.DAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) 0, (float) (byte) 100);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getColorComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        dateAxis3.setStandardTickUnits(tickUnitSource7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean12 = stackedBarRenderer3D11.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke15 = stackedBarRenderer3D11.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis3.setAxisLineStroke(stroke15);
        stackedAreaRenderer0.setBaseStroke(stroke15);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font20 = dateAxis19.getTickLabelFont();
        stackedAreaRenderer0.setSeriesItemLabelFont((int) '4', font20);
        org.jfree.chart.LegendItem legendItem24 = stackedAreaRenderer0.getLegendItem(0, (int) (short) 0);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator25 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean27 = standardCategoryToolTipGenerator25.equals((java.lang.Object) 100.0f);
        stackedAreaRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator25);
        boolean boolean29 = stackedAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        legendItem27.setSeriesKey((java.lang.Comparable) 1.0E-5d);
        java.awt.Shape shape30 = legendItem27.getLine();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setFixedDimension((double) (short) 10);
        java.util.TimeZone timeZone4 = null;
        try {
            dateAxis0.setTimeZone(timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ThreadContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 0L);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        org.jfree.data.Range range9 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) 9999);
        org.jfree.data.KeyToGroupMap keyToGroupMap12 = null;
        try {
            org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7, keyToGroupMap12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D2.getLegendItem((int) (short) -1, 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedBarRenderer3D2.getSeriesItemLabelGenerator(2);
        boolean boolean11 = stackedBarRenderer3D2.getBaseSeriesVisibleInLegend();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint18 = stackedBarRenderer3D16.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D16);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle19.setPosition(rectangleEdge20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendTitle19.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        java.awt.geom.Rectangle2D rectangle2D25 = plotRenderingInfo24.getDataArea();
        rectangleInsets22.trim(rectangle2D25);
        try {
            stackedBarRenderer3D2.drawOutline(graphics2D12, categoryPlot13, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangle2D25);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean9 = stackedBarRenderer3D8.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke12 = stackedBarRenderer3D8.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis0.setAxisLineStroke(stroke12);
        boolean boolean14 = dateAxis0.isVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("ThreadContext");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = null;
        try {
            textFragment1.draw(graphics2D2, (float) (-1L), (float) 100, textAnchor5, 0.5f, 0.95f, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setName("");
        projectInfo0.setName("ClassContext");
        projectInfo0.addOptionalLibrary("ThreadContext");
        java.lang.String str7 = projectInfo0.getLicenceText();
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        categoryMarker5.notifyListeners(markerChangeEvent6);
        org.jfree.chart.text.TextAnchor textAnchor8 = categoryMarker5.getLabelTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor10 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 1, (float) (short) 1, textAnchor8, (double) 100.0f, textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = null;
        boolean boolean2 = strokeList0.equals(obj1);
        java.lang.Object obj3 = strokeList0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        boolean boolean8 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlineStroke();
        double double9 = stackedBarRenderer3D2.getMinimumBarLength();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.lang.Object obj4 = categoryMarker1.clone();
        java.awt.Paint paint5 = categoryMarker1.getOutlinePaint();
        java.lang.Object obj6 = null;
        boolean boolean7 = categoryMarker1.equals(obj6);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.lang.Object obj4 = categoryMarker1.clone();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer5 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer5.setBaseCreateEntities(true, false);
        java.awt.Paint paint9 = ganttRenderer5.getCompletePaint();
        categoryMarker1.setOutlinePaint(paint9);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.Object obj1 = null;
        boolean boolean2 = sortOrder0.equals(obj1);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int3 = java.awt.Color.HSBtoRGB((float) 2, (float) (-2208960000000L), (float) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) blockBorder0, jFreeChart1, (int) (short) 10, (int) ' ');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        stackedBarRenderer3D7.setSeriesURLGenerator(10, categoryURLGenerator9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = stackedBarRenderer3D7.getBaseNegativeItemLabelPosition();
        stackedBarRenderer3D7.setBaseSeriesVisibleInLegend(false);
        boolean boolean14 = blockBorder0.equals((java.lang.Object) stackedBarRenderer3D7);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity7 = new org.jfree.chart.entity.TickLabelEntity(shape4, "hi!", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset11);
        java.util.List list13 = defaultCategoryDataset11.getRowKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape4, "hi!", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, (java.lang.Comparable) 0L, (java.lang.Comparable) "");
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, true);
        try {
            java.lang.String str20 = standardCategorySeriesLabelGenerator1.generateLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor7 = categoryLabelPosition6.getRotationAnchor();
        try {
            textLine1.draw(graphics2D3, 0.95f, (float) 9999, textAnchor7, (float) 0L, (float) 10L, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26 };
        java.lang.Number[][] numberArray28 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset29 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray27, numberArray28);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "poly", numberArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        try {
            defaultIntervalCategoryDataset27.setStartValue(100, (java.lang.Comparable) "Third", (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("TextBlockAnchor.TOP_CENTER");
        java.lang.Object obj2 = null;
        boolean boolean3 = textLine1.equals(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 10L, (float) 60000L, textAnchor4, (double) (short) 100, (float) 3600000L, (float) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D2.getBaseNegativeItemLabelPosition();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Point2D point2D12 = null;
        xYPlot8.zoomRangeAxes(0.0d, plotRenderingInfo11, point2D12);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState14 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo11);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint19 = stackedBarRenderer3D17.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle20.setPosition(rectangleEdge21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = legendTitle20.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo25.getDataArea();
        rectangleInsets23.trim(rectangle2D26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        int int30 = categoryAxis29.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint32 = dateAxis31.getLabelPaint();
        dateAxis31.setAutoTickUnitSelection(false);
        java.lang.String str35 = dateAxis31.getLabel();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator40 = null;
        stackedBarRenderer3D38.setSeriesURLGenerator(10, categoryURLGenerator40);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset43 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset43);
        org.jfree.data.Range range45 = stackedBarRenderer3D38.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset43);
        defaultCategoryDataset43.removeColumn((java.lang.Comparable) 9999);
        try {
            stackedBarRenderer3D2.drawItem(graphics2D7, categoryItemRendererState14, rectangle2D26, categoryPlot28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset43, 6, (int) ' ', 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNull(range45);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) -1, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Stroke stroke3 = stackedBarRenderer3D2.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        try {
            stackedBarRenderer3D2.setSeriesItemLabelGenerator((int) (short) -1, categoryItemLabelGenerator5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font1 = dateAxis0.getTickLabelFont();
        boolean boolean2 = dateAxis0.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.LegendItem legendItem8 = stackedBarRenderer3D2.getLegendItem((int) (short) -1, 1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedBarRenderer3D2.getSeriesItemLabelGenerator(2);
        java.awt.Stroke stroke12 = stackedBarRenderer3D2.getSeriesStroke(10);
        stackedBarRenderer3D2.setItemLabelAnchorOffset((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
        org.junit.Assert.assertNull(stroke12);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.axis.Axis axis4 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, (float) 100L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity10 = new org.jfree.chart.entity.AxisLabelEntity(axis4, shape7, "hi!", "ClassContext");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor11, 10.0d, (double) 10.0f);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint16 = dateAxis15.getLabelPaint();
        dateAxis15.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = null;
        dateAxis15.setStandardTickUnits(tickUnitSource19);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean24 = stackedBarRenderer3D23.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke27 = stackedBarRenderer3D23.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis15.setAxisLineStroke(stroke27);
        java.awt.Paint paint29 = null;
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("poly", "", "TextBlockAnchor.TOP_CENTER", "", shape14, stroke27, paint29);
        int int31 = legendItem30.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        float[] floatArray5 = new float[] { 1L, 3600000L };
        try {
            float[] floatArray6 = color0.getColorComponents(colorSpace2, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = stackedBarRenderer3D2.getPlot();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo10.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D13 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D11, rectangleAnchor12);
        try {
            stackedBarRenderer3D2.drawOutline(graphics2D7, categoryPlot8, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(point2D13);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        java.awt.Font font7 = null;
        statisticalLineAndShapeRenderer2.setSeriesItemLabelFont(0, font7, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false, true);
        stackedBarRenderer3D2.setIncludeBaseInRange(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.Object obj1 = null;
        boolean boolean2 = datasetRenderingOrder0.equals(obj1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(9999, axisLocation7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline11 = dateAxis9.getTimeline();
        dateAxis9.setAutoTickUnitSelection(false);
        double double14 = dateAxis9.getLabelAngle();
        org.jfree.data.Range range15 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        xYPlot0.setOutlineVisible(false);
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeline11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendTitle5.getLegendItemGraphicLocation();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        try {
            legendTitle5.setHorizontalAlignment(horizontalAlignment7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        int int28 = defaultIntervalCategoryDataset27.getSeriesCount();
        try {
            int int29 = defaultIntervalCategoryDataset27.getRowCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5 + "'", int28 == 5);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = statisticalLineAndShapeRenderer2.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = defaultKeyedValues0.clone();
        int int2 = defaultKeyedValues0.getItemCount();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.Object obj1 = null;
        int int2 = numberTickUnit0.compareTo(obj1);
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        categoryMarker4.notifyListeners(markerChangeEvent5);
        java.lang.Object obj7 = categoryMarker4.clone();
        java.lang.Class<?> wildcardClass8 = categoryMarker4.getClass();
        boolean boolean9 = numberTickUnit0.equals((java.lang.Object) categoryMarker4);
        java.awt.Paint paint10 = categoryMarker4.getPaint();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        java.awt.Paint paint6 = legendTitle5.getBackgroundPaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = null;
        dateAxis3.setStandardTickUnits(tickUnitSource7);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean12 = stackedBarRenderer3D11.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke15 = stackedBarRenderer3D11.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis3.setAxisLineStroke(stroke15);
        stackedAreaRenderer0.setBaseStroke(stroke15);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font20 = dateAxis19.getTickLabelFont();
        stackedAreaRenderer0.setSeriesItemLabelFont((int) '4', font20);
        java.awt.Paint paint22 = null;
        try {
            stackedAreaRenderer0.setBaseOutlinePaint(paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        int int7 = xYPlot0.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline10 = dateAxis8.getTimeline();
        dateAxis8.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj14 = numberAxis3D13.clone();
        numberAxis3D13.setAutoTickUnitSelection(false);
        java.text.NumberFormat numberFormat17 = null;
        numberAxis3D13.setNumberFormatOverride(numberFormat17);
        numberAxis3D13.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font22 = dateAxis21.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint24 = dateAxis23.getLabelPaint();
        dateAxis23.setAutoTickUnitSelection(false);
        boolean boolean27 = dateAxis23.isVerticalTickLabels();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { dateAxis8, numberAxis3D13, dateAxis21, dateAxis23 };
        xYPlot0.setDomainAxes(valueAxisArray28);
        java.awt.Color color31 = java.awt.Color.white;
        try {
            xYPlot0.setQuadrantPaint((int) (short) 100, (java.awt.Paint) color31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(timeline10);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        boolean boolean6 = stackedBarRenderer3D2.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object[][] objArray1 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) 128);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { "Third", 10.0f, (short) 10, "TextBlockAnchor.TOP_CENTER", numberTickUnit4 };
        java.lang.String[] strArray6 = org.jfree.data.time.SerialDate.getMonths();
        double[] doubleArray12 = new double[] { 1.0d, (-1), 0.0f, 1.0d, 1577865599999L };
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray5, (java.lang.Comparable[]) strArray6, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.lang.Comparable[] comparableArray0 = null;
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = year3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.next();
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] { 0.0f, 2, regularTimePeriod5, 8.0d, (short) 0, 2019 };
        double[] doubleArray10 = new double[] {};
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray9, doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.lang.Number[][] numberArray0 = new java.lang.Number[][] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray20 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray5, numberArray10, numberArray15, numberArray20, numberArray25 };
        java.lang.Number[][] numberArray27 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset28 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray26, numberArray27);
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset29 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray0, numberArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray0);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.lang.Object obj4 = categoryMarker1.clone();
        java.awt.Paint paint5 = categoryMarker1.getPaint();
        java.awt.Paint paint6 = categoryMarker1.getLabelPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint11 = stackedBarRenderer3D9.lookupSeriesPaint((int) '4');
        categoryMarker1.setOutlinePaint(paint11);
        java.awt.Paint paint13 = categoryMarker1.getOutlinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryMarker1.setLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        stackedBarRenderer3D18.setSeriesURLGenerator(10, categoryURLGenerator20);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset23);
        org.jfree.data.Range range25 = stackedBarRenderer3D18.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23);
        java.awt.Stroke stroke26 = stackedBarRenderer3D18.getBaseOutlineStroke();
        categoryMarker1.setOutlineStroke(stroke26);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(5, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        double double1 = numberAxis3D0.getUpperBound();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint8 = stackedBarRenderer3D6.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D6);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle9.setPosition(rectangleEdge10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle9.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo14.getDataArea();
        rectangleInsets12.trim(rectangle2D15);
        java.awt.Paint paint17 = null;
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean24 = stackedBarRenderer3D23.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke27 = stackedBarRenderer3D23.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke31 = categoryMarker30.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint20, stroke27, (java.awt.Paint) color28, stroke31, 0.0f);
        java.awt.Paint paint34 = valueMarker33.getLabelPaint();
        try {
            org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "Third", "", (java.awt.Shape) rectangle2D15, paint17, stroke18, paint34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues0.sortByKeys(sortOrder1);
        java.lang.Number number4 = null;
        defaultKeyedValues0.setValue((java.lang.Comparable) ' ', number4);
        java.lang.Number number7 = null;
        defaultKeyedValues0.setValue((java.lang.Comparable) 1.0d, number7);
        org.junit.Assert.assertNotNull(sortOrder1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer0.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.data.Range range7 = dateAxis3.getDefaultAutoRange();
        boolean boolean8 = intervalBarRenderer0.equals((java.lang.Object) range7);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(range7);
        java.util.Date date10 = dateRange9.getLowerDate();
        double double11 = dateRange9.getUpperBound();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeColumn((java.lang.Comparable) 500);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.lang.Comparable comparable4 = null;
        java.lang.Comparable comparable5 = null;
        try {
            defaultCategoryDataset0.removeValue(comparable4, comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Color color1 = java.awt.Color.getColor("Third");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = stackedBarRenderer3D2.getBaseURLGenerator();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        stackedBarRenderer3D8.setSeriesURLGenerator(10, categoryURLGenerator10);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        org.jfree.data.Range range15 = stackedBarRenderer3D8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13);
        java.util.List list16 = defaultCategoryDataset13.getRowKeys();
        org.jfree.data.Range range17 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = null;
        stackedBarRenderer3D2.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator19);
        double double21 = stackedBarRenderer3D2.getUpperClip();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint27 = stackedBarRenderer3D25.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D25);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle28.setPosition(rectangleEdge29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendTitle28.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        java.awt.geom.Rectangle2D rectangle2D34 = plotRenderingInfo33.getDataArea();
        rectangleInsets31.trim(rectangle2D34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo42);
        java.awt.geom.Point2D point2D44 = null;
        xYPlot40.zoomRangeAxes(0.0d, plotRenderingInfo43, point2D44);
        plotRenderingInfo39.addSubplotInfo(plotRenderingInfo43);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState47 = stackedBarRenderer3D2.initialise(graphics2D22, rectangle2D34, categoryPlot36, 3, plotRenderingInfo39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangle2D34);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        stackedBarRenderer3D2.setBaseItemLabelsVisible(false, true);
        boolean boolean12 = stackedBarRenderer3D2.isSeriesItemLabelsVisible((-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange(range0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = stackedBarRenderer3D2.getBaseURLGenerator();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        stackedBarRenderer3D8.setSeriesURLGenerator(10, categoryURLGenerator10);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        org.jfree.data.Range range15 = stackedBarRenderer3D8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13);
        java.util.List list16 = defaultCategoryDataset13.getRowKeys();
        org.jfree.data.Range range17 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13);
        java.lang.Comparable comparable18 = null;
        try {
            java.lang.Number number20 = defaultCategoryDataset13.getValue(comparable18, (java.lang.Comparable) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) 10.0f, 0.0d);
        org.jfree.chart.util.Size2D size2D10 = legendTitle5.arrange(graphics2D6, rectangleConstraint9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint9.toFixedHeight((double) (-1L));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        int int28 = defaultIntervalCategoryDataset27.getSeriesCount();
        try {
            defaultIntervalCategoryDataset27.setStartValue(0, (java.lang.Comparable) (byte) 10, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5 + "'", int28 == 5);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(11, categoryURLGenerator4, true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 3600000L, 12.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        blockContainer5.clear();
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        java.lang.Object obj3 = null;
        boolean boolean4 = textLine1.equals(obj3);
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        try {
            int int29 = defaultIntervalCategoryDataset27.getSeriesIndex((java.lang.Comparable) 0.35d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        try {
            xYPlot0.setDomainAxis((int) (byte) -1, valueAxis14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) '#', false);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer4 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer4.setBaseCreateEntities(true, false);
        java.awt.Paint paint8 = ganttRenderer4.getCompletePaint();
        boolean boolean9 = stackedBarRenderer3D3.equals((java.lang.Object) ganttRenderer4);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = ganttRenderer4.getSeriesItemLabelGenerator((-460));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("poly");
        categoryAxis1.setCategoryMargin((double) 1L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(2019);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 100, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        legendItem27.setSeriesKey((java.lang.Comparable) 1.0E-5d);
        java.awt.Paint paint30 = legendItem27.getLinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem27.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset31);
        int int33 = defaultCategoryDataset31.getRowCount();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        int int35 = year34.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.next();
        long long37 = year34.getLastMillisecond();
        int int38 = defaultCategoryDataset31.getRowIndex((java.lang.Comparable) long37);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "hi!", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset9);
        java.util.List list11 = defaultCategoryDataset9.getRowKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity14 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "hi!", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, (java.lang.Comparable) 0L, (java.lang.Comparable) "");
        java.lang.String str15 = categoryItemEntity14.getShapeType();
        java.lang.String str16 = categoryItemEntity14.getShapeCoords();
        categoryItemEntity14.setRowKey((java.lang.Comparable) 5);
        java.awt.Shape shape19 = categoryItemEntity14.getArea();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "poly" + "'", str15.equals("poly"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0" + "'", str16.equals("-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0"));
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE2" + "'", str1.equals("ItemLabelAnchor.OUTSIDE2"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        dateAxis0.setAutoTickUnitSelection(false);
        double double5 = dateAxis0.getLabelAngle();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        axisChangeEvent6.setChart(jFreeChart7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        java.awt.Paint paint7 = stackedBarRenderer3D2.getSeriesFillPaint(11);
        boolean boolean8 = stackedBarRenderer3D2.isDrawBarOutline();
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        boolean boolean8 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlineStroke();
        stackedBarRenderer3D2.setItemMargin((double) (byte) 0);
        stackedBarRenderer3D2.setAutoPopulateSeriesFillPaint(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity7 = new org.jfree.chart.entity.TickLabelEntity(shape4, "hi!", "");
        dateAxis0.setLeftArrow(shape4);
        dateAxis0.configure();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint14 = dateAxis13.getLabelPaint();
        dateAxis13.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer17 = null;
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis13, polarItemRenderer17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo21);
        java.awt.geom.Rectangle2D rectangle2D23 = plotRenderingInfo22.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D23, rectangleAnchor24);
        java.awt.Point point26 = polarPlot18.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D23);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        java.awt.geom.Point2D point2D32 = null;
        xYPlot28.zoomRangeAxes(0.0d, plotRenderingInfo31, point2D32);
        java.awt.Paint paint34 = xYPlot28.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke37 = categoryMarker36.getOutlineStroke();
        xYPlot28.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot28.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot28.getRangeAxisEdge();
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo43);
        java.awt.geom.Point2D point2D45 = null;
        xYPlot41.zoomRangeAxes(0.0d, plotRenderingInfo44, point2D45);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState47 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo44);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D48 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj49 = numberAxis3D48.clone();
        numberAxis3D48.setAutoTickUnitSelection(false);
        numberAxis3D48.configure();
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint56 = dateAxis55.getLabelPaint();
        dateAxis55.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer59 = null;
        org.jfree.chart.plot.PolarPlot polarPlot60 = new org.jfree.chart.plot.PolarPlot(xYDataset54, (org.jfree.chart.axis.ValueAxis) dateAxis55, polarItemRenderer59);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo63 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo63);
        java.awt.geom.Rectangle2D rectangle2D65 = plotRenderingInfo64.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor66 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D67 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D65, rectangleAnchor66);
        java.awt.Point point68 = polarPlot60.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D65);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double70 = numberAxis3D48.java2DToValue(4.0d, rectangle2D65, rectangleEdge69);
        plotRenderingInfo44.setPlotArea(rectangle2D65);
        try {
            org.jfree.chart.axis.AxisState axisState72 = dateAxis0.draw(graphics2D10, (double) 2019, rectangle2D23, rectangle2D27, rectangleEdge40, plotRenderingInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertNotNull(point26);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(rectangleAnchor66);
        org.junit.Assert.assertNotNull(point2D67);
        org.junit.Assert.assertNotNull(point68);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + Double.POSITIVE_INFINITY + "'", double70 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 9999, 0.0f, (double) 100.0f, (float) (-1L), (float) (-460));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setBaseCreateEntities(true, false);
        java.awt.Paint paint4 = ganttRenderer0.getCompletePaint();
        double double5 = ganttRenderer0.getEndPercent();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.65d + "'", double5 == 0.65d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2019, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean5 = stackedBarRenderer3D4.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke8 = stackedBarRenderer3D4.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke12 = categoryMarker11.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint1, stroke8, (java.awt.Paint) color9, stroke12, 0.0f);
        double double15 = valueMarker14.getValue();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.LegendItem legendItem3 = areaRenderer0.getLegendItem(1, 3);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType4 = null;
        try {
            areaRenderer0.setEndType(areaRendererEndType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Third", graphics2D1, (double) 6, (float) (byte) 0, (float) 900000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        java.awt.Shape shape9 = stackedBarRenderer3D2.lookupSeriesShape(1);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int12 = color11.getBlue();
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = plotRenderingInfo16.getDataArea();
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color11.createContext(colorModel13, rectangle14, rectangle2D17, affineTransform18, renderingHints19);
        stackedBarRenderer3D2.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 128 + "'", int12 == 128);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(paintContext20);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition3);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        stackedBarRenderer3D7.setSeriesURLGenerator(10, categoryURLGenerator9);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset12);
        org.jfree.data.Range range14 = stackedBarRenderer3D7.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12);
        defaultCategoryDataset12.removeColumn((java.lang.Comparable) 9999);
        boolean boolean17 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12);
        org.jfree.data.Range range18 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12);
        java.util.List list19 = defaultCategoryDataset12.getRowKeys();
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.lang.Object obj4 = categoryMarker1.clone();
        java.awt.Paint paint5 = categoryMarker1.getPaint();
        java.awt.Paint paint6 = categoryMarker1.getLabelPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint11 = stackedBarRenderer3D9.lookupSeriesPaint((int) '4');
        categoryMarker1.setOutlinePaint(paint11);
        java.lang.Comparable comparable13 = categoryMarker1.getKey();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 10L + "'", comparable13.equals(10L));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        xYPlot0.setRangeCrosshairValue((double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = xYPlot0.getInsets();
        boolean boolean6 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline10 = dateAxis8.getTimeline();
        dateAxis8.setAutoTickUnitSelection(false);
        xYPlot0.setDomainAxis(2019, (org.jfree.chart.axis.ValueAxis) dateAxis8);
        double double14 = dateAxis8.getUpperMargin();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(timeline10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint5 = stackedBarRenderer3D3.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle6.setPosition(rectangleEdge7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle6.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo11.getDataArea();
        rectangleInsets9.trim(rectangle2D12);
        int int14 = numberTickUnit0.compareTo((java.lang.Object) rectangle2D12);
        java.io.ObjectOutputStream objectOutputStream15 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape((java.awt.Shape) rectangle2D12, objectOutputStream15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.lang.Comparable[] comparableArray0 = null;
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (byte) -1, 1.0d };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (byte) -1, 1.0d };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { (byte) -1, 1.0d };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { (byte) -1, 1.0d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (byte) -1, 1.0d };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (byte) -1, 1.0d };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10, numberArray13, numberArray16, numberArray19 };
        java.lang.Number[][] numberArray23 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Third", "Third", numberArray23);
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset25 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray0, (java.lang.Comparable[]) strArray1, numberArray20, numberArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        labelBlock2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder3);
        labelBlock2.setWidth((double) (byte) 10);
        java.lang.Object obj8 = labelBlock2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        labelBlock2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder3);
        labelBlock2.setPadding(100.0d, (double) 0.0f, (double) 3, (double) 0L);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setName("");
        projectInfo0.setName("ClassContext");
        java.lang.String str5 = projectInfo0.getCopyright();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline3 = dateAxis1.getTimeline();
        dateAxis1.setAutoTickUnitSelection(false);
        double double6 = dateAxis1.getLabelAngle();
        dateAxis1.configure();
        dateAxis1.setUpperMargin((double) 3);
        boolean boolean10 = categoryAnchor0.equals((java.lang.Object) dateAxis1);
        dateAxis1.setAutoRangeMinimumSize((double) (short) 10);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(timeline3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("poly");
        double double2 = categoryAxis1.getCategoryMargin();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean6 = stackedBarRenderer3D5.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D5.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.LegendItem legendItem11 = stackedBarRenderer3D5.getLegendItem((int) (short) -1, 1);
        boolean boolean12 = categoryAxis1.equals((java.lang.Object) legendItem11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint19 = stackedBarRenderer3D17.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D17);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint((double) 10.0f, 0.0d);
        org.jfree.chart.util.Size2D size2D25 = legendTitle20.arrange(graphics2D21, rectangleConstraint24);
        java.lang.String str26 = size2D25.toString();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D30 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D25, (double) (byte) 10, (double) 10, rectangleAnchor29);
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint36 = stackedBarRenderer3D34.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D34);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = legendTitle37.getPosition();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo39);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo43);
        java.awt.geom.Point2D point2D45 = null;
        xYPlot41.zoomRangeAxes(0.0d, plotRenderingInfo44, point2D45);
        plotRenderingInfo40.addSubplotInfo(plotRenderingInfo44);
        try {
            org.jfree.chart.axis.AxisState axisState48 = categoryAxis1.draw(graphics2D13, (double) (short) 10, rectangle2D30, rectangle2D31, rectangleEdge38, plotRenderingInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str26.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.Axis axis4 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, (float) 100L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity10 = new org.jfree.chart.entity.AxisLabelEntity(axis4, shape7, "hi!", "ClassContext");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor11, 10.0d, (double) 10.0f);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint16 = dateAxis15.getLabelPaint();
        dateAxis15.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = null;
        dateAxis15.setStandardTickUnits(tickUnitSource19);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean24 = stackedBarRenderer3D23.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke27 = stackedBarRenderer3D23.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis15.setAxisLineStroke(stroke27);
        java.awt.Paint paint29 = null;
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("poly", "", "TextBlockAnchor.TOP_CENTER", "", shape14, stroke27, paint29);
        java.awt.Stroke stroke31 = legendItem30.getLineStroke();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        org.jfree.chart.util.Layer layer3 = null;
        java.util.Collection collection4 = xYPlot0.getDomainMarkers(layer3);
        java.awt.Paint paint5 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(collection4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = null;
        textLine1.removeFragment(textFragment2);
        org.jfree.chart.text.TextFragment textFragment4 = textLine1.getFirstTextFragment();
        org.junit.Assert.assertNotNull(textFragment4);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment2 = textLine1.getLastTextFragment();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            float float5 = textFragment2.calculateBaselineOffset(graphics2D3, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textFragment2);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getDomainTickBandPaint();
        int int7 = xYPlot0.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint9 = dateAxis8.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline10 = dateAxis8.getTimeline();
        dateAxis8.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj14 = numberAxis3D13.clone();
        numberAxis3D13.setAutoTickUnitSelection(false);
        java.text.NumberFormat numberFormat17 = null;
        numberAxis3D13.setNumberFormatOverride(numberFormat17);
        numberAxis3D13.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font22 = dateAxis21.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint24 = dateAxis23.getLabelPaint();
        dateAxis23.setAutoTickUnitSelection(false);
        boolean boolean27 = dateAxis23.isVerticalTickLabels();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { dateAxis8, numberAxis3D13, dateAxis21, dateAxis23 };
        xYPlot0.setDomainAxes(valueAxisArray28);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = null;
        xYPlot0.setDrawingSupplier(drawingSupplier30);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(timeline10);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(valueAxisArray28);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(9999, axisLocation7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline11 = dateAxis9.getTimeline();
        dateAxis9.setAutoTickUnitSelection(false);
        double double14 = dateAxis9.getLabelAngle();
        org.jfree.data.Range range15 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot0.getInsets();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            xYPlot0.drawBackground(graphics2D17, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeline11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.lang.Object obj4 = categoryMarker1.clone();
        java.lang.Class<?> wildcardClass5 = categoryMarker1.getClass();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        try {
            categoryMarker1.setLabelOffsetType(lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        waferMapPlot0.setDataset(waferMapDataset1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Object obj1 = defaultKeyedValues0.clone();
        org.jfree.data.DefaultKeyedValues defaultKeyedValues2 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder3 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues2.sortByKeys(sortOrder3);
        defaultKeyedValues0.sortByKeys(sortOrder3);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(sortOrder3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Third");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        try {
            java.util.Date date6 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            java.awt.Shape shape9 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", graphics2D1, 0.0f, (float) (-460), textAnchor5, (double) 6, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(9999, axisLocation7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline11 = dateAxis9.getTimeline();
        dateAxis9.setAutoTickUnitSelection(false);
        double double14 = dateAxis9.getLabelAngle();
        org.jfree.data.Range range15 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot0.getInsets();
        double double18 = rectangleInsets16.calculateBottomOutset((double) (short) 0);
        double double19 = rectangleInsets16.getRight();
        double double21 = rectangleInsets16.extendHeight((double) (byte) 0);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeline11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 8.0d + "'", double21 == 8.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.data.Range range5 = dateAxis1.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range0, range5);
        double double7 = range5.getLowerBound();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 3600000L, 12.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        boolean boolean6 = blockContainer5.isEmpty();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = plotRenderingInfo9.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D12 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D10, rectangleAnchor11);
        java.awt.Color color13 = java.awt.Color.CYAN;
        try {
            java.lang.Object obj14 = blockContainer5.draw(graphics2D7, rectangle2D10, (java.lang.Object) color13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        org.jfree.chart.LegendItem legendItem6 = stackedBarRenderer3D2.getLegendItem(5, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        boolean boolean4 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlinePaint();
        stackedBarRenderer3D2.setMaximumBarWidth(0.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint11 = stackedBarRenderer3D9.lookupSeriesPaint((int) '4');
        stackedBarRenderer3D2.setBasePaint(paint11, false);
        double double14 = stackedBarRenderer3D2.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("poly");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = plotRenderingInfo4.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint13 = stackedBarRenderer3D11.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D11);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle14.setPosition(rectangleEdge15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle14.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo19.getDataArea();
        rectangleInsets17.trim(rectangle2D20);
        int int22 = numberTickUnit8.compareTo((java.lang.Object) rectangle2D20);
        boolean boolean23 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D5, rectangle2D20);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = numberAxis1.valueToJava2D((double) 10.0f, rectangle2D5, rectangleEdge24);
        numberAxis1.setAutoRangeStickyZero(true);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj1 = numberAxis3D0.clone();
        org.jfree.data.RangeType rangeType2 = numberAxis3D0.getRangeType();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rangeType2);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font1 = dateAxis0.getTickLabelFont();
        boolean boolean2 = dateAxis0.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        boolean boolean4 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlinePaint();
        stackedBarRenderer3D2.setMaximumBarWidth(0.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Stroke stroke10 = stackedBarRenderer3D9.getBaseOutlineStroke();
        stackedBarRenderer3D2.setBaseStroke(stroke10, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "hi!", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset9);
        java.util.List list11 = defaultCategoryDataset9.getRowKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity14 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "hi!", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, (java.lang.Comparable) 0L, (java.lang.Comparable) "");
        java.lang.String str15 = categoryItemEntity14.getShapeType();
        java.lang.String str16 = categoryItemEntity14.getShapeCoords();
        java.lang.Comparable comparable17 = categoryItemEntity14.getColumnKey();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "poly" + "'", str15.equals("poly"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0" + "'", str16.equals("-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0"));
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + "" + "'", comparable17.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = null;
        categoryMarker1.notifyListeners(markerChangeEvent2);
        java.lang.Object obj4 = categoryMarker1.clone();
        java.awt.Paint paint5 = categoryMarker1.getPaint();
        java.awt.Paint paint6 = categoryMarker1.getLabelPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint11 = stackedBarRenderer3D9.lookupSeriesPaint((int) '4');
        categoryMarker1.setOutlinePaint(paint11);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryMarker1.setLabelFont(font13);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = dateAxis7.isAutoTickUnitSelection();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity14 = new org.jfree.chart.entity.TickLabelEntity(shape11, "hi!", "");
        dateAxis7.setLeftArrow(shape11);
        stackedBarRenderer3D2.setSeriesShape((int) (byte) 10, shape11, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape11, rectangleAnchor18, (double) (-1L), (double) 1L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D2.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor7 = itemLabelPosition6.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor8 = itemLabelPosition6.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(itemLabelAnchor8);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.awt.Color color1 = java.awt.Color.CYAN;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Point2D point2D6 = null;
        xYPlot2.zoomRangeAxes(0.0d, plotRenderingInfo5, point2D6);
        java.awt.Stroke stroke8 = xYPlot2.getRangeCrosshairStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 0, (java.awt.Paint) color1, stroke8);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean13 = stackedBarRenderer3D12.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke16 = stackedBarRenderer3D12.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        categoryMarker9.setStroke(stroke16);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState();
        java.util.List list5 = axisState4.getTicks();
        axisState4.setMax((double) 0.5f);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint12 = stackedBarRenderer3D10.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D10);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle13.setPosition(rectangleEdge14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle13.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = plotRenderingInfo18.getDataArea();
        rectangleInsets16.trim(rectangle2D19);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        java.awt.geom.Point2D point2D25 = null;
        xYPlot21.zoomRangeAxes(0.0d, plotRenderingInfo24, point2D25);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset28 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent29 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset28);
        xYPlot21.datasetChanged(datasetChangeEvent29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot21.getDomainAxisEdge();
        try {
            java.util.List list32 = dateAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D19, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("poly", "ClassContext");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "poly" + "'", str4.equals("poly"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str1.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) 3600000L, 12.0d);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = borderArrangement0.arrange(blockContainer6, graphics2D7, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setName("");
        java.lang.String str3 = projectInfo0.getVersion();
        java.lang.String str4 = projectInfo0.getLicenceName();
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo5.setName("");
        projectInfo5.setName("ClassContext");
        projectInfo5.addOptionalLibrary("ThreadContext");
        org.jfree.chart.axis.AxisState axisState12 = new org.jfree.chart.axis.AxisState();
        java.util.List list13 = axisState12.getTicks();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        stackedBarRenderer3D16.setSeriesURLGenerator(10, categoryURLGenerator18);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset21);
        org.jfree.data.Range range23 = stackedBarRenderer3D16.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        java.util.List list24 = defaultCategoryDataset21.getRowKeys();
        axisState12.setTicks(list24);
        projectInfo5.setContributors(list24);
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(list24);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        try {
            java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.String str1 = numberAxis3D0.getLabelURL();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) 10.0f, 0.0d);
        org.jfree.chart.util.Size2D size2D10 = legendTitle5.arrange(graphics2D6, rectangleConstraint9);
        java.lang.String str11 = size2D10.toString();
        double double12 = size2D10.getWidth();
        double double13 = size2D10.getWidth();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str11.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        xYPlot0.setRangeCrosshairValue((double) (byte) 100);
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = null;
        categoryMarker6.notifyListeners(markerChangeEvent7);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener9 = null;
        categoryMarker6.removeChangeListener(markerChangeListener9);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke13 = categoryMarker12.getOutlineStroke();
        categoryMarker6.setStroke(stroke13);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        legendItem27.setSeriesKey((java.lang.Comparable) 1.0E-5d);
        java.awt.Paint paint30 = legendItem27.getLinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem27.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset31);
        java.lang.String str33 = legendItem27.getDescription();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer34 = null;
        try {
            legendItem27.setFillPaintTransformer(gradientPaintTransformer34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str33.equals("TextBlockAnchor.TOP_CENTER"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot0.getRangeAxisEdge();
        java.lang.String str12 = rectangleEdge11.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleEdge.LEFT" + "'", str12.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj1 = numberAxis3D0.clone();
        numberAxis3D0.setAutoTickUnitSelection(false);
        numberAxis3D0.setLabelURL("RectangleEdge.LEFT");
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint1 = ganttRenderer0.getCompletePaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0", "ThreadContext", "Third", "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]");
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(9999, axisLocation7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot0.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.Axis axis4 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, (float) 100L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity10 = new org.jfree.chart.entity.AxisLabelEntity(axis4, shape7, "hi!", "ClassContext");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor11, 10.0d, (double) 10.0f);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint16 = dateAxis15.getLabelPaint();
        dateAxis15.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = null;
        dateAxis15.setStandardTickUnits(tickUnitSource19);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean24 = stackedBarRenderer3D23.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke27 = stackedBarRenderer3D23.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        dateAxis15.setAxisLineStroke(stroke27);
        java.awt.Paint paint29 = null;
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("poly", "", "TextBlockAnchor.TOP_CENTER", "", shape14, stroke27, paint29);
        boolean boolean31 = legendItem30.isLineVisible();
        int int32 = legendItem30.getDatasetIndex();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("", font2);
        org.jfree.chart.block.BlockBorder blockBorder4 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        labelBlock3.setFrame((org.jfree.chart.block.BlockFrame) blockBorder4);
        labelBlock3.setWidth((double) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_CENTER");
        double double11 = dateAxis10.getLowerBound();
        try {
            borderArrangement0.add((org.jfree.chart.block.Block) labelBlock3, (java.lang.Object) dateAxis10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.axis.DateAxis cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(blockBorder4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        dateAxis0.setAutoTickUnitSelection(false);
        boolean boolean5 = dateAxis0.isTickMarksVisible();
        double double6 = dateAxis0.getLowerBound();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.data.Range range4 = dateAxis0.getDefaultAutoRange();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        stackedBarRenderer3D7.setSeriesURLGenerator(10, categoryURLGenerator9);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset12);
        org.jfree.data.Range range14 = stackedBarRenderer3D7.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12);
        boolean boolean15 = range4.equals((java.lang.Object) range14);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer16 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer16.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint20 = dateAxis19.getLabelPaint();
        dateAxis19.setAutoTickUnitSelection(false);
        org.jfree.data.Range range23 = dateAxis19.getDefaultAutoRange();
        boolean boolean24 = intervalBarRenderer16.equals((java.lang.Object) range23);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange(range23);
        java.util.Date date26 = dateRange25.getUpperDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint(range4, (org.jfree.data.Range) dateRange25);
        java.util.Date date28 = dateRange25.getLowerDate();
        double double29 = dateRange25.getLength();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setBaseCreateEntities(true, false);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint11 = stackedBarRenderer3D9.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D9);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle12.setPosition(rectangleEdge13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle12.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = plotRenderingInfo17.getDataArea();
        rectangleInsets15.trim(rectangle2D18);
        int int20 = numberTickUnit6.compareTo((java.lang.Object) rectangle2D18);
        try {
            ganttRenderer0.drawOutline(graphics2D4, categoryPlot5, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = axisState0.getTicks();
        axisState0.setMax((double) 0.5f);
        axisState0.setCursor(100.0d);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint5 = stackedBarRenderer3D3.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D3);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle6.getPosition();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint12 = stackedBarRenderer3D10.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D10);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle13.setPosition(rectangleEdge14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle13.getLegendItemGraphicPadding();
        double double17 = legendTitle13.getContentYOffset();
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("", font19);
        legendTitle13.setItemFont(font19);
        legendTitle6.setItemFont(font19);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("hi!", font19);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setName("");
        projectInfo0.setName("ClassContext");
        projectInfo0.addOptionalLibrary("ThreadContext");
        java.lang.String str7 = projectInfo0.getInfo();
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        long long3 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        boolean boolean1 = layeredBarRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition3);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        stackedBarRenderer3D7.setSeriesURLGenerator(10, categoryURLGenerator9);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset12);
        org.jfree.data.Range range14 = stackedBarRenderer3D7.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12);
        defaultCategoryDataset12.removeColumn((java.lang.Comparable) 9999);
        boolean boolean17 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12);
        org.jfree.data.Range range18 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = stackedBarRenderer3D2.getToolTipGenerator((-460), 11);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = segmentedTimeline0.getBaseTimeline();
        try {
            long long4 = segmentedTimeline1.getExceptionSegmentCount((long) (short) 0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNull(segmentedTimeline1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        labelBlock2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder3);
        java.awt.Font font6 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        labelBlock2.setFont(font6);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        org.jfree.data.Range range9 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) 9999);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        int int14 = defaultCategoryDataset7.getRowIndex((java.lang.Comparable) (byte) 0);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        labelBlock2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder3);
        labelBlock2.setWidth((double) (byte) 10);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Point2D point2D12 = null;
        xYPlot8.zoomRangeAxes(0.0d, plotRenderingInfo11, point2D12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot8.setRangeAxisLocation(9999, axisLocation15);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint18 = dateAxis17.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline19 = dateAxis17.getTimeline();
        dateAxis17.setAutoTickUnitSelection(false);
        double double22 = dateAxis17.getLabelAngle();
        org.jfree.data.Range range23 = xYPlot8.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis17);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = xYPlot8.getInsets();
        double double26 = rectangleInsets24.calculateBottomOutset((double) (short) 0);
        double double27 = rectangleInsets24.getRight();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int29 = color28.getBlue();
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        java.awt.geom.Rectangle2D rectangle2D34 = plotRenderingInfo33.getDataArea();
        java.awt.geom.AffineTransform affineTransform35 = null;
        java.awt.RenderingHints renderingHints36 = null;
        java.awt.PaintContext paintContext37 = color28.createContext(colorModel30, rectangle31, rectangle2D34, affineTransform35, renderingHints36);
        rectangleInsets24.trim(rectangle2D34);
        labelBlock2.setPadding(rectangleInsets24);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(timeline19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 4.0d + "'", double26 == 4.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 8.0d + "'", double27 == 8.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 128 + "'", int29 == 128);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(paintContext37);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(9999);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = stackedBarRenderer3D2.getBaseURLGenerator();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        stackedBarRenderer3D8.setSeriesURLGenerator(10, categoryURLGenerator10);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        org.jfree.data.Range range15 = stackedBarRenderer3D8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13);
        java.util.List list16 = defaultCategoryDataset13.getRowKeys();
        org.jfree.data.Range range17 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator18 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean20 = standardCategoryToolTipGenerator18.equals((java.lang.Object) 100.0f);
        stackedBarRenderer3D2.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator18);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity27 = new org.jfree.chart.entity.TickLabelEntity(shape24, "hi!", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset31);
        java.util.List list33 = defaultCategoryDataset31.getRowKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity36 = new org.jfree.chart.entity.CategoryItemEntity(shape24, "hi!", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset31, (java.lang.Comparable) 0L, (java.lang.Comparable) "");
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent39 = null;
        categoryMarker38.notifyListeners(markerChangeEvent39);
        org.jfree.chart.text.TextAnchor textAnchor41 = categoryMarker38.getLabelTextAnchor();
        boolean boolean42 = categoryItemEntity36.equals((java.lang.Object) textAnchor41);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D45 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = null;
        stackedBarRenderer3D45.setSeriesURLGenerator(10, categoryURLGenerator47);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset50 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent51 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset50);
        org.jfree.data.Range range52 = stackedBarRenderer3D45.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset50);
        java.util.List list53 = defaultCategoryDataset50.getRowKeys();
        categoryItemEntity36.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset50);
        org.jfree.data.general.DatasetGroup datasetGroup55 = defaultCategoryDataset50.getGroup();
        try {
            java.lang.String str57 = standardCategoryToolTipGenerator18.generateRowLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset50, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(range52);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertNotNull(datasetGroup55);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 0.5f, (double) (byte) 0, 0, (java.lang.Comparable) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 0.95f, (java.lang.Comparable) "ClassContext");
        java.util.List list4 = defaultStatisticalCategoryDataset0.getRowKeys();
        try {
            java.util.Collection collection5 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list4);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) 10.0f, 0.0d);
        org.jfree.chart.util.Size2D size2D10 = legendTitle5.arrange(graphics2D6, rectangleConstraint9);
        java.lang.String str11 = size2D10.toString();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, (double) (byte) 10, (double) 10, rectangleAnchor14);
        size2D10.width = 5;
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str11.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) (-1));
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(1, false);
        int int13 = statisticalLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = statisticalLineAndShapeRenderer2.getNegativeItemLabelPosition(9999, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        int int2 = xYPlot0.getIndexOf(xYItemRenderer1);
        xYPlot0.setRangeCrosshairValue((double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = xYPlot0.getInsets();
        int int6 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) 10.0f, 0.0d);
        org.jfree.chart.util.Size2D size2D10 = legendTitle5.arrange(graphics2D6, rectangleConstraint9);
        java.lang.String str11 = size2D10.toString();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D10, (double) (byte) 10, (double) 10, rectangleAnchor14);
        double double16 = size2D10.width;
        java.lang.String str17 = size2D10.toString();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str11.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str17.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = intervalBarRenderer0.getSeriesNegativeItemLabelPosition(2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = intervalBarRenderer0.getSeriesPositiveItemLabelPosition(128);
        java.awt.Paint paint6 = null;
        intervalBarRenderer0.setSeriesOutlinePaint((int) (byte) 1, paint6, false);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        java.util.List list15 = defaultCategoryDataset13.getRowKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape6, "hi!", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset13, (java.lang.Comparable) 0L, (java.lang.Comparable) "");
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo21);
        java.awt.geom.Point2D point2D23 = null;
        xYPlot19.zoomRangeAxes(0.0d, plotRenderingInfo22, point2D23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot19.setRangeAxisLocation(9999, axisLocation26);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint29 = dateAxis28.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline30 = dateAxis28.getTimeline();
        dateAxis28.setAutoTickUnitSelection(false);
        double double33 = dateAxis28.getLabelAngle();
        org.jfree.data.Range range34 = xYPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis28);
        xYPlot19.setOutlineVisible(false);
        java.awt.Stroke stroke37 = xYPlot19.getRangeZeroBaselineStroke();
        java.awt.Color color38 = java.awt.Color.green;
        try {
            org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem(attributedString0, "", "", "", shape6, stroke37, (java.awt.Paint) color38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(timeline30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        int int28 = defaultIntervalCategoryDataset27.getSeriesCount();
        try {
            int int30 = defaultIntervalCategoryDataset27.getSeriesIndex((java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5 + "'", int28 == 5);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        boolean boolean28 = legendItem27.isShapeVisible();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { (short) -1, 60000L, 1.0d, 0 };
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] { numberArray4, numberArray9, numberArray14, numberArray19, numberArray24 };
        java.lang.Number[][] numberArray26 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray25, numberArray26);
        int int28 = defaultIntervalCategoryDataset27.getSeriesCount();
        try {
            java.lang.Comparable comparable30 = defaultIntervalCategoryDataset27.getColumnKey((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5 + "'", int28 == 5);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        java.text.DateFormat dateFormat3 = null;
        dateAxis0.setDateFormatOverride(dateFormat3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot5);
        org.jfree.chart.axis.Axis axis7 = null;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 10, (float) 100L);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity13 = new org.jfree.chart.entity.AxisLabelEntity(axis7, shape10, "hi!", "ClassContext");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, rectangleAnchor14, 10.0d, (double) 10.0f);
        dateAxis0.setRightArrow(shape10);
        dateAxis0.setTickMarkInsideLength(0.5f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj1 = numberAxis3D0.clone();
        numberAxis3D0.setAutoTickUnitSelection(false);
        numberAxis3D0.configure();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint8 = dateAxis7.getLabelPaint();
        dateAxis7.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, polarItemRenderer11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = plotRenderingInfo16.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D17, rectangleAnchor18);
        java.awt.Point point20 = polarPlot12.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double22 = numberAxis3D0.java2DToValue(4.0d, rectangle2D17, rectangleEdge21);
        numberAxis3D0.setAutoRangeIncludesZero(true);
        numberAxis3D0.setUpperBound(0.0d);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(point20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + Double.POSITIVE_INFINITY + "'", double22 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(1.0d, (double) '#', false);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer4 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer4.setBaseCreateEntities(true, false);
        java.awt.Paint paint8 = ganttRenderer4.getCompletePaint();
        boolean boolean9 = stackedBarRenderer3D3.equals((java.lang.Object) ganttRenderer4);
        java.awt.Paint paint12 = stackedBarRenderer3D3.getItemPaint((int) (byte) 100, (-1));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 3600000L, 12.0d);
        org.jfree.chart.entity.EntityCollection entityCollection5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo(entityCollection5);
        boolean boolean7 = columnArrangement4.equals((java.lang.Object) chartRenderingInfo6);
        org.jfree.chart.block.Block block8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot9.getIndexOf(xYItemRenderer10);
        xYPlot9.setRangeCrosshairValue((double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = xYPlot9.getInsets();
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot9.getRangeAxisLocation((int) '4');
        columnArrangement4.add(block8, (java.lang.Object) axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        int int0 = org.jfree.chart.axis.DateTickUnit.MILLISECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer0.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.data.Range range7 = dateAxis3.getDefaultAutoRange();
        boolean boolean8 = intervalBarRenderer0.equals((java.lang.Object) range7);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(range7);
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range10, (double) 128);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint14 = dateAxis13.getLabelPaint();
        dateAxis13.setAutoTickUnitSelection(false);
        org.jfree.data.Range range17 = dateAxis13.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint12.toRangeHeight(range17);
        org.jfree.data.Range range19 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange9, range17);
        org.jfree.data.Range range21 = org.jfree.data.Range.shift(range17, (double) 4);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Point2D point2D12 = null;
        xYPlot8.zoomRangeAxes(0.0d, plotRenderingInfo11, point2D12);
        java.awt.Paint paint14 = xYPlot8.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot8.getAxisOffset();
        boolean boolean16 = stackedBarRenderer3D2.equals((java.lang.Object) rectangleInsets15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        java.awt.geom.Point2D point2D22 = null;
        xYPlot18.zoomRangeAxes(0.0d, plotRenderingInfo21, point2D22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot18.setRangeAxisLocation(9999, axisLocation25);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint28 = dateAxis27.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline29 = dateAxis27.getTimeline();
        dateAxis27.setAutoTickUnitSelection(false);
        double double32 = dateAxis27.getLabelAngle();
        org.jfree.data.Range range33 = xYPlot18.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot18.getInsets();
        double double36 = rectangleInsets34.calculateBottomOutset((double) (short) 0);
        double double37 = rectangleInsets34.getRight();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int39 = color38.getBlue();
        java.awt.image.ColorModel colorModel40 = null;
        java.awt.Rectangle rectangle41 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo42);
        java.awt.geom.Rectangle2D rectangle2D44 = plotRenderingInfo43.getDataArea();
        java.awt.geom.AffineTransform affineTransform45 = null;
        java.awt.RenderingHints renderingHints46 = null;
        java.awt.PaintContext paintContext47 = color38.createContext(colorModel40, rectangle41, rectangle2D44, affineTransform45, renderingHints46);
        rectangleInsets34.trim(rectangle2D44);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo53 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo53);
        java.awt.geom.Point2D point2D55 = null;
        xYPlot51.zoomRangeAxes(0.0d, plotRenderingInfo54, point2D55);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState57 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo54);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D58 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj59 = numberAxis3D58.clone();
        numberAxis3D58.setAutoTickUnitSelection(false);
        numberAxis3D58.configure();
        org.jfree.data.xy.XYDataset xYDataset64 = null;
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint66 = dateAxis65.getLabelPaint();
        dateAxis65.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer69 = null;
        org.jfree.chart.plot.PolarPlot polarPlot70 = new org.jfree.chart.plot.PolarPlot(xYDataset64, (org.jfree.chart.axis.ValueAxis) dateAxis65, polarItemRenderer69);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo73 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo73);
        java.awt.geom.Rectangle2D rectangle2D75 = plotRenderingInfo74.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor76 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D77 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D75, rectangleAnchor76);
        java.awt.Point point78 = polarPlot70.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D75);
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double80 = numberAxis3D58.java2DToValue(4.0d, rectangle2D75, rectangleEdge79);
        plotRenderingInfo54.setPlotArea(rectangle2D75);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState82 = stackedBarRenderer3D2.initialise(graphics2D17, rectangle2D44, categoryPlot49, (int) (byte) 100, plotRenderingInfo54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(timeline29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 8.0d + "'", double37 == 8.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 128 + "'", int39 == 128);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(paintContext47);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(rectangleAnchor76);
        org.junit.Assert.assertNotNull(point2D77);
        org.junit.Assert.assertNotNull(point78);
        org.junit.Assert.assertNotNull(rectangleEdge79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + Double.POSITIVE_INFINITY + "'", double80 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        java.awt.geom.Point2D point2D7 = null;
        xYPlot3.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo6);
        categoryItemRendererState9.setBarWidth((double) 1L);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo13.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D16 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D14, rectangleAnchor15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.setMaximumCategoryLabelWidthRatio(0.0f);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = dateAxis21.isAutoTickUnitSelection();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo23 = new org.jfree.chart.ui.BasicProjectInfo();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity29 = new org.jfree.chart.entity.TickLabelEntity(shape26, "hi!", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset33 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent34 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset33);
        java.util.List list35 = defaultCategoryDataset33.getRowKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity38 = new org.jfree.chart.entity.CategoryItemEntity(shape26, "hi!", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset33, (java.lang.Comparable) 0L, (java.lang.Comparable) "");
        boolean boolean39 = basicProjectInfo23.equals((java.lang.Object) defaultCategoryDataset33);
        try {
            stackedBarRenderer1.drawItem(graphics2D2, categoryItemRendererState9, rectangle2D14, categoryPlot17, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset33, (int) (short) 100, 9999, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(point2D16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("ThreadContext");
        textLine1.addFragment(textFragment3);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        stackedBarRenderer3D2.setBaseURLGenerator(categoryURLGenerator8);
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer10 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = intervalBarRenderer10.getSeriesNegativeItemLabelPosition(2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = intervalBarRenderer10.getSeriesPositiveItemLabelPosition(128);
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        dateAxis0.setAutoTickUnitSelection(false);
        double double5 = dateAxis0.getLabelAngle();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = axisChangeEvent6.getType();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = axisChangeEvent6.getType();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(timeline2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = null;
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity16 = new org.jfree.chart.entity.TickLabelEntity(shape13, "hi!", "");
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean22 = stackedBarRenderer3D21.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke25 = stackedBarRenderer3D21.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke29 = categoryMarker28.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint18, stroke25, (java.awt.Paint) color26, stroke29, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint33 = dateAxis32.getLabelPaint();
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape13, stroke25, paint33);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer36 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.LegendItem legendItem39 = areaRenderer36.getLegendItem(1, 3);
        java.awt.Paint paint40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        areaRenderer36.setBaseFillPaint(paint40, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.Object obj44 = null;
        int int45 = numberTickUnit43.compareTo(obj44);
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent48 = null;
        categoryMarker47.notifyListeners(markerChangeEvent48);
        java.lang.Object obj50 = categoryMarker47.clone();
        java.lang.Class<?> wildcardClass51 = categoryMarker47.getClass();
        boolean boolean52 = numberTickUnit43.equals((java.lang.Object) categoryMarker47);
        java.awt.Stroke stroke53 = categoryMarker47.getStroke();
        java.awt.Shape shape55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo58);
        java.awt.geom.Point2D point2D60 = null;
        xYPlot56.zoomRangeAxes(0.0d, plotRenderingInfo59, point2D60);
        java.awt.Paint paint62 = xYPlot56.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker64 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke65 = categoryMarker64.getOutlineStroke();
        xYPlot56.setDomainCrosshairStroke(stroke65);
        java.awt.Color color67 = java.awt.Color.magenta;
        try {
            org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem(attributedString0, "TextBlockAnchor.TOP_CENTER", "RectangleEdge.LEFT", "poly", false, shape5, true, paint33, false, paint40, stroke53, false, shape55, stroke65, (java.awt.Paint) color67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(legendItem39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(numberTickUnit43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNull(paint62);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color67);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) statisticalLineAndShapeRenderer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        legendItem27.setSeriesKey((java.lang.Comparable) 1.0E-5d);
        java.awt.Paint paint30 = legendItem27.getLinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem27.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset31);
        java.text.AttributedString attributedString33 = legendItem27.getAttributedLabel();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(attributedString33);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Point2D point2D11 = null;
        xYPlot7.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11);
        java.awt.Paint paint13 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke16 = categoryMarker15.getOutlineStroke();
        xYPlot7.setDomainCrosshairStroke(stroke16);
        boolean boolean18 = xYPlot7.isRangeZeroBaselineVisible();
        xYPlot7.setDomainCrosshairValue((double) (short) -1);
        java.awt.geom.Point2D point2D21 = xYPlot7.getQuadrantOrigin();
        java.awt.Paint paint22 = xYPlot7.getBackgroundPaint();
        polarPlot6.setRadiusGridlinePaint(paint22);
        java.awt.Paint paint24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        polarPlot6.setRadiusGridlinePaint(paint24);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = stackedBarRenderer3D2.getItemLabelGenerator(8, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultBoxAndWhiskerCategoryDataset0.getColumnKey(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        java.awt.Paint paint7 = stackedBarRenderer3D2.getSeriesFillPaint(11);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D2.getSeriesToolTipGenerator((int) (short) 0);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "hi!", "");
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean15 = stackedBarRenderer3D14.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke18 = stackedBarRenderer3D14.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke22 = categoryMarker21.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint11, stroke18, (java.awt.Paint) color19, stroke22, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("ThreadContext", "TextBlockAnchor.TOP_CENTER", "", "", shape6, stroke18, paint26);
        legendItem27.setSeriesKey((java.lang.Comparable) 1.0E-5d);
        java.awt.Paint paint30 = legendItem27.getLinePaint();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        legendItem27.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset31);
        int int33 = defaultCategoryDataset31.getRowCount();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        int int36 = xYPlot34.getIndexOf(xYItemRenderer35);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot34.getDomainMarkers(layer37);
        boolean boolean39 = defaultCategoryDataset31.hasListener((java.util.EventListener) xYPlot34);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        int int41 = xYPlot34.getIndexOf(xYItemRenderer40);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setLowFarOut(false);
        boolean boolean3 = outlierListCollection0.isLowFarOut();
        org.jfree.chart.renderer.Outlier outlier4 = null;
        boolean boolean5 = outlierListCollection0.add(outlier4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D2.getBaseNegativeItemLabelPosition();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor10);
        stackedBarRenderer3D2.setBasePositiveItemLabelPosition(itemLabelPosition11, false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        java.awt.geom.Point2D point2D20 = null;
        xYPlot16.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot16.setRangeAxisLocation(9999, axisLocation23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint26 = dateAxis25.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline27 = dateAxis25.getTimeline();
        dateAxis25.setAutoTickUnitSelection(false);
        double double30 = dateAxis25.getLabelAngle();
        org.jfree.data.Range range31 = xYPlot16.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint34 = dateAxis33.getLabelPaint();
        dateAxis33.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer37 = null;
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis33, polarItemRenderer37);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo41);
        java.awt.geom.Rectangle2D rectangle2D43 = plotRenderingInfo42.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D45 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D43, rectangleAnchor44);
        java.awt.Point point46 = polarPlot38.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D43);
        try {
            stackedBarRenderer3D2.drawRangeGridline(graphics2D14, categoryPlot15, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D43, (double) 0.95f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(timeline27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(point2D45);
        org.junit.Assert.assertNotNull(point46);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean((int) (byte) 0);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean3 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setBaseSeriesVisibleInLegend(true);
        java.awt.Stroke stroke7 = stackedBarRenderer3D2.getSeriesStroke((int) (short) -1);
        int int8 = stackedBarRenderer3D2.getRowCount();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint14 = dateAxis13.getLabelPaint();
        categoryAxis11.setTickLabelPaint((java.lang.Comparable) 8.0d, paint14);
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        categoryMarker17.notifyListeners(markerChangeEvent18);
        java.lang.Object obj20 = categoryMarker17.clone();
        java.awt.Paint paint21 = categoryMarker17.getPaint();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint24 = dateAxis23.getLabelPaint();
        dateAxis23.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer27 = null;
        org.jfree.chart.plot.PolarPlot polarPlot28 = new org.jfree.chart.plot.PolarPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) dateAxis23, polarItemRenderer27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        java.awt.geom.Rectangle2D rectangle2D33 = plotRenderingInfo32.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        java.awt.Point point36 = polarPlot28.translateValueThetaRadiusToJava2D(2.0d, (double) 2, rectangle2D33);
        try {
            stackedBarRenderer3D2.drawDomainMarker(graphics2D9, categoryPlot10, categoryAxis11, categoryMarker17, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(point36);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        dateAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, polarItemRenderer5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        polarPlot6.rendererChanged(rendererChangeEvent7);
        polarPlot6.setRadiusGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        java.awt.Paint paint6 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke9);
        boolean boolean11 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setDomainCrosshairValue((double) (short) -1);
        java.awt.geom.Point2D point2D14 = xYPlot0.getQuadrantOrigin();
        java.awt.Paint paint15 = xYPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(point2D14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        java.awt.Shape shape8 = stackedBarRenderer3D2.getItemShape((int) '#', (int) ' ');
        boolean boolean11 = stackedBarRenderer3D2.getItemCreateEntity(4, 10);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = stackedBarRenderer3D2.getBaseURLGenerator();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        stackedBarRenderer3D8.setSeriesURLGenerator(10, categoryURLGenerator10);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset13);
        org.jfree.data.Range range15 = stackedBarRenderer3D8.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13);
        java.util.List list16 = defaultCategoryDataset13.getRowKeys();
        org.jfree.data.Range range17 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator18 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean20 = standardCategoryToolTipGenerator18.equals((java.lang.Object) 100.0f);
        stackedBarRenderer3D2.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator18);
        java.lang.Object obj22 = standardCategoryToolTipGenerator18.clone();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            chartRenderingInfo0.setChartArea(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint2 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("-1,-1,-1,-1,0,0,1,-1,1,-1,0,0,1,1,1,1,0,0,-1,1,-1,1,0,0,0,0", font1, paint2);
        java.awt.Graphics2D graphics2D4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = textLine3.calculateDimensions(graphics2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        xYPlot0.datasetChanged(datasetChangeEvent8);
        xYPlot0.setRangeCrosshairLockedOnData(false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 900000L, 100.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity6 = new org.jfree.chart.entity.TickLabelEntity(shape3, "hi!", "");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset10);
        java.util.List list12 = defaultCategoryDataset10.getRowKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity(shape3, "hi!", "ThreadContext", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, (java.lang.Comparable) 0L, (java.lang.Comparable) "");
        boolean boolean16 = basicProjectInfo0.equals((java.lang.Object) defaultCategoryDataset10);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, true);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        double double3 = rectangleInsets1.calculateLeftInset(2.0d);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        stackedBarRenderer3D2.setBaseItemLabelGenerator(categoryItemLabelGenerator6, true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setName("");
        java.lang.String str3 = projectInfo0.getVersion();
        java.lang.String str4 = projectInfo0.getLicenceName();
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo5.setName("");
        projectInfo5.setName("ClassContext");
        projectInfo5.addOptionalLibrary("ThreadContext");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
        java.lang.String str13 = projectInfo5.getCopyright();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 3600000L, 12.0d);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        boolean boolean6 = blockContainer5.isEmpty();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint11 = stackedBarRenderer3D9.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D9);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle12.setPosition(rectangleEdge13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle12.getLegendItemGraphicEdge();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo16 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray17 = basicProjectInfo16.getOptionalLibraries();
        blockContainer5.add((org.jfree.chart.block.Block) legendTitle12, (java.lang.Object) basicProjectInfo16);
        blockContainer5.clear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(libraryArray17);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = null;
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition3);
        boolean boolean5 = stackedBarRenderer3D2.getAutoPopulateSeriesStroke();
        stackedBarRenderer3D2.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) true, false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset11);
        java.lang.Comparable comparable13 = null;
        defaultCategoryDataset11.removeColumn(comparable13);
        org.jfree.data.Range range15 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        try {
            defaultCategoryDataset11.removeColumn((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("TextBlockAnchor.TOP_CENTER");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        try {
            textLine1.draw(graphics2D2, (float) 11, (float) 'a', textAnchor5, (float) (byte) -1, (float) 900000L, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, 0, 128);
        try {
            long long5 = segmentedTimeline3.toMillisecond(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj1 = numberAxis3D0.clone();
        numberAxis3D0.setAutoTickUnitSelection(false);
        java.text.NumberFormat numberFormat4 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat4);
        numberAxis3D0.setAutoRangeIncludesZero(true);
        double double8 = numberAxis3D0.getLowerBound();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = dateAxis0.getLabelPaint();
        dateAxis0.setFixedDimension((double) (short) 10);
        float float4 = dateAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer0.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.data.Range range7 = dateAxis3.getDefaultAutoRange();
        boolean boolean8 = intervalBarRenderer0.equals((java.lang.Object) range7);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange(range7);
        org.jfree.data.Range range11 = org.jfree.data.Range.shift(range7, (double) (byte) 10);
        double double12 = range7.getLength();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        xYPlot0.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot0.getDomainAxisEdge();
        xYPlot0.setDomainCrosshairVisible(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot0.setRenderer(xYItemRenderer13);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isAutoTickUnitSelection();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 1L, 0.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity7 = new org.jfree.chart.entity.TickLabelEntity(shape4, "hi!", "");
        dateAxis0.setLeftArrow(shape4);
        dateAxis0.configure();
        boolean boolean11 = dateAxis0.equals((java.lang.Object) (-460));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setBaseCreateEntities(true, false);
        java.awt.Paint paint4 = ganttRenderer0.getCompletePaint();
        double double5 = ganttRenderer0.getStartPercent();
        java.awt.Shape shape7 = ganttRenderer0.getSeriesShape((int) (short) 10);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.35d + "'", double5 == 0.35d);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        intervalBarRenderer0.setBase((double) 1);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint4 = dateAxis3.getLabelPaint();
        dateAxis3.setAutoTickUnitSelection(false);
        org.jfree.data.Range range7 = dateAxis3.getDefaultAutoRange();
        boolean boolean8 = intervalBarRenderer0.equals((java.lang.Object) range7);
        java.awt.Paint paint10 = intervalBarRenderer0.getSeriesFillPaint(5);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = year12.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.next();
        long long15 = year12.getLastMillisecond();
        java.awt.Paint paint16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean22 = stackedBarRenderer3D21.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke25 = stackedBarRenderer3D21.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke29 = categoryMarker28.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint18, stroke25, (java.awt.Paint) color26, stroke29, 0.0f);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) long15, paint16, stroke25);
        intervalBarRenderer0.setSeriesStroke((int) (short) 1, stroke25);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes(0.0d, plotRenderingInfo3, point2D4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setRangeAxisLocation(9999, axisLocation7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint10 = dateAxis9.getLabelPaint();
        org.jfree.chart.axis.Timeline timeline11 = dateAxis9.getTimeline();
        dateAxis9.setAutoTickUnitSelection(false);
        double double14 = dateAxis9.getLabelAngle();
        org.jfree.data.Range range15 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis9);
        xYPlot0.setOutlineVisible(false);
        java.awt.Stroke stroke18 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot0.setDataset(0, xYDataset20);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(timeline11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Third");
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean5 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) 'a', (int) ' ');
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) (-1));
        statisticalLineAndShapeRenderer2.setSeriesShapesFilled(1, false);
        int int13 = statisticalLineAndShapeRenderer2.getPassCount();
        boolean boolean14 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator15 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        boolean boolean17 = standardCategoryToolTipGenerator15.equals((java.lang.Object) 100.0f);
        statisticalLineAndShapeRenderer2.setBaseToolTipGenerator((org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator15, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        stackedBarRenderer3D22.setSeriesURLGenerator(10, categoryURLGenerator24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = stackedBarRenderer3D22.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor27 = itemLabelPosition26.getRotationAnchor();
        statisticalLineAndShapeRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition26);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(textAnchor27);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getLastMillisecond();
        java.awt.Paint paint4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        boolean boolean10 = stackedBarRenderer3D9.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke13 = stackedBarRenderer3D9.getItemOutlineStroke((int) (short) -1, (int) (byte) 0);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke17 = categoryMarker16.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 0, paint6, stroke13, (java.awt.Paint) color14, stroke17, 0.0f);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) long3, paint4, stroke13);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions21, categoryLabelPosition22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = categoryLabelPosition22.getCategoryAnchor();
        categoryMarker20.setLabelAnchor(rectangleAnchor24);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double[] doubleArray4 = new double[] { 0.65d, 8.0d, (byte) 0, 100 };
        double[][] doubleArray5 = new double[][] { doubleArray4 };
        double[] doubleArray10 = new double[] { 2019L, 9999, 3, (byte) 100 };
        double[] doubleArray15 = new double[] { 2019L, 9999, 3, (byte) 100 };
        double[] doubleArray20 = new double[] { 2019L, 9999, 3, (byte) 100 };
        double[][] doubleArray21 = new double[][] { doubleArray10, doubleArray15, doubleArray20 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset22 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray5, doubleArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        chartRenderingInfo1.clear();
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint4 = stackedBarRenderer3D2.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D2);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Point2D point2D10 = null;
        xYPlot6.zoomRangeAxes(0.0d, plotRenderingInfo9, point2D10);
        java.awt.Paint paint12 = xYPlot6.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L);
        java.awt.Stroke stroke15 = categoryMarker14.getOutlineStroke();
        xYPlot6.setDomainCrosshairStroke(stroke15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot6.getDomainAxisEdge();
        legendTitle5.setLegendItemGraphicEdge(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, false);
        boolean boolean3 = statisticalLineAndShapeRenderer2.getUseOutlinePaint();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 60000L);
        statisticalLineAndShapeRenderer2.setBaseShape(shape5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = segmentedTimeline0.getBaseTimeline();
        try {
            boolean boolean4 = segmentedTimeline1.containsDomainRange(2019L, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNull(segmentedTimeline1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = axisState0.getTicks();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        stackedBarRenderer3D4.setSeriesURLGenerator(10, categoryURLGenerator6);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset9);
        org.jfree.data.Range range11 = stackedBarRenderer3D4.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        java.util.List list12 = defaultCategoryDataset9.getRowKeys();
        axisState0.setTicks(list12);
        axisState0.cursorDown(12.0d);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setBaseCreateEntities(true, false);
        java.awt.Paint paint4 = ganttRenderer0.getCompletePaint();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("poly");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo10.getDataArea();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.geom.Point2D point2D13 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D11, rectangleAnchor12);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 'a', (double) 1L);
        java.awt.Paint paint19 = stackedBarRenderer3D17.lookupSeriesPaint((int) '4');
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) stackedBarRenderer3D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle20.setPosition(rectangleEdge21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = legendTitle20.getLegendItemGraphicPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo25.getDataArea();
        rectangleInsets23.trim(rectangle2D26);
        int int28 = numberTickUnit14.compareTo((java.lang.Object) rectangle2D26);
        boolean boolean29 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D11, rectangle2D26);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = numberAxis7.valueToJava2D((double) 10.0f, rectangle2D11, rectangleEdge30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo34);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState36 = ganttRenderer0.initialise(graphics2D5, rectangle2D11, categoryPlot32, (int) (byte) 100, plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(point2D13);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) -1, (double) (-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        stackedBarRenderer3D2.setSeriesURLGenerator(10, categoryURLGenerator4);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) '4', (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        org.jfree.data.Range range9 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        defaultCategoryDataset7.removeColumn((java.lang.Comparable) 9999);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        defaultCategoryDataset7.setValue((java.lang.Number) 0, (java.lang.Comparable) 60000L, (java.lang.Comparable) 0);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }
}

