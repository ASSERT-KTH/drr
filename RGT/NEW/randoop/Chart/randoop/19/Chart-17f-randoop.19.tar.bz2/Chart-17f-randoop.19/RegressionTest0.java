import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) 'a', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = null;
        try {
            timeSeries3.add(timeSeriesDataItem6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, (int) (short) 1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getSerialIndex();
        long long4 = year0.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getFollowingDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = month0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod5, 10.0d);
        try {
            timeSeries3.add(timeSeriesDataItem9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, (int) (short) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(regularTimePeriod7, (double) 1.0f);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11, class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate(regularTimePeriod17, (double) 1.0f);
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate(regularTimePeriod17, number20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod23, class24);
        timeSeries25.setMaximumItemCount((int) '4');
        timeSeries25.removeAgedItems(false);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod31, class32);
        timeSeries33.setMaximumItemCount((int) '4');
        timeSeries33.removeAgedItems(false);
        timeSeries33.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries25.addAndOrUpdate(timeSeries33);
        int int41 = timeSeriesDataItem21.compareTo((java.lang.Object) timeSeries25);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        long long4 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(regularTimePeriod7, (double) 1.0f);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11, class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate(regularTimePeriod17, (double) 1.0f);
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate(regularTimePeriod17, number20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21);
        boolean boolean24 = timeSeries22.equals((java.lang.Object) 1900);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = month0.equals(obj2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(regularTimePeriod7, (double) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries10 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.addAndOrUpdate(timeSeries10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        try {
            timeSeries3.delete(1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str7 = seriesChangeEvent6.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate3 = null;
        try {
            boolean boolean4 = spreadsheetDate1.isOn(serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        timeSeries4.setKey((java.lang.Comparable) spreadsheetDate6);
        java.lang.Object obj18 = timeSeries4.clone();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 1, (java.lang.Object) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        boolean boolean8 = timeSeries3.getNotify();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries3.addAndOrUpdate(timeSeries13);
        try {
            timeSeries14.removeAgedItems((long) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(timeSeries14);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ThreadContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        timeSeries3.setMaximumItemAge(0L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getMiddleMillisecond();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, year11);
        org.jfree.data.time.Year year15 = month14.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.removeChangeListener(seriesChangeListener19);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Time");
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod6, class7);
        timeSeries8.setMaximumItemCount((int) '4');
        timeSeries8.removeAgedItems(false);
        boolean boolean13 = timeSeries8.getNotify();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries8.addAndOrUpdate(timeSeries18);
        boolean boolean20 = timeSeries4.equals((java.lang.Object) timeSeries8);
        try {
            timeSeries4.update((int) (short) 100, (java.lang.Number) 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year1);
        java.lang.String str5 = year1.toString();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(4, year1);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        long long25 = year23.getMiddleMillisecond();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 1, year23);
        try {
            timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month26, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1562097599999L + "'", long25 == 1562097599999L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("June 2019", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        try {
            org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        timeSeries3.setMaximumItemCount((int) (short) 0);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = year19.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date13 = spreadsheetDate2.toDate();
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date13, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        long long6 = month5.getFirstMillisecond();
        long long7 = month5.getSerialIndex();
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1559372400000L + "'", long6 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24234L + "'", long7 == 24234L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (byte) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        timeSeries3.setRangeDescription("");
        timeSeries3.setDescription("ThreadContext");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getMiddleMillisecond();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, year11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (byte) 100);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        long long6 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Time" + "'", str0.equals("Time"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(1, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jan" + "'", str2.equals("Jan"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Jan");
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) '4', 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("2-January-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = day23.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Comparable comparable0 = null;
        java.lang.Class class3 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries(comparable0, "2019", "", class3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(regularTimePeriod7, (double) 1.0f);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11, class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate(regularTimePeriod17, (double) 1.0f);
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate(regularTimePeriod17, number20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = null;
        try {
            timeSeries22.update(regularTimePeriod23, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("SerialDate.weekInMonthToString(): invalid code.", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int11 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-1), 9999, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("ThreadContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1900, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Date date2 = year0.getEnd();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "First" + "'", str1.equals("First"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
//        timeSeries3.setMaximumItemCount((int) '4');
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
//        timeSeries11.setMaximumItemCount((int) '4');
//        timeSeries11.removeAgedItems(false);
//        timeSeries11.setMaximumItemAge(10L);
//        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
//        java.lang.Comparable comparable22 = timeSeries18.getKey();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getSerialIndex();
//        java.lang.String str25 = day23.toString();
//        int int26 = day23.getDayOfMonth();
//        try {
//            timeSeries18.add((org.jfree.data.time.RegularTimePeriod) day23, 0.0d);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(timeSeries18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + "Overwritten values from: 2018" + "'", comparable22.equals("Overwritten values from: 2018"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43629L + "'", long24 == 43629L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 13 + "'", int26 == 13);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate24 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(3);
        int int27 = spreadsheetDate26.getMonth();
        int int28 = spreadsheetDate26.getDayOfWeek();
        try {
            boolean boolean29 = spreadsheetDate20.isInRange(serialDate24, (org.jfree.data.time.SerialDate) spreadsheetDate26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        org.jfree.data.time.Year year5 = month4.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        int int5 = year1.compareTo((java.lang.Object) "June 2019");
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#', 12, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ClassContext", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("2-January-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount(100);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7, class8);
        timeSeries9.setMaximumItemCount((int) '4');
        timeSeries9.removeAgedItems(false);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod15, class16);
        timeSeries17.setMaximumItemCount((int) '4');
        timeSeries17.removeAgedItems(false);
        timeSeries17.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries9.addAndOrUpdate(timeSeries17);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) year25);
        java.lang.Number number28 = null;
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year25, number28, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        try {
            java.util.Collection collection7 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list6);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        try {
            org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate1.getPreviousDayOfWeek(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1900, serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        timeSeries3.setRangeDescription("");
        timeSeries3.setDescription("ThreadContext");
        int int10 = timeSeries3.getItemCount();
        try {
            timeSeries3.update(1900, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        timeSeries18.setMaximumItemCount(0);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + "Overwritten values from: 2018" + "'", comparable22.equals("Overwritten values from: 2018"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("2-January-1900", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        timeSeries3.setMaximumItemAge(0L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getMiddleMillisecond();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, year11);
        org.jfree.data.time.Year year15 = month14.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long19 = month14.getSerialIndex();
        java.lang.Object obj20 = null;
        int int21 = month14.compareTo(obj20);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 24229L + "'", long19 == 24229L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("2-January-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=-1]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNull(class6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        boolean boolean8 = timeSeries3.getNotify();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries3.addAndOrUpdate(timeSeries13);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries14.getTimePeriod((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(timeSeries14);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        boolean boolean8 = month5.equals((java.lang.Object) "");
        boolean boolean9 = timeSeries4.equals((java.lang.Object) boolean8);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str7 = timeSeries3.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("Overwritten values from: 2018");
        try {
            timeSeries3.delete((-459), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int24 = spreadsheetDate20.getYYYY();
        org.jfree.data.time.SerialDate serialDate25 = null;
        try {
            boolean boolean26 = spreadsheetDate20.isOnOrBefore(serialDate25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears(9999, serialDate13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '4', (-1), (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year1);
        java.lang.String str5 = year1.toString();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(4, year1);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date14 = spreadsheetDate3.toDate();
        spreadsheetDate3.setDescription("June 2019");
        int int17 = spreadsheetDate3.getDayOfWeek();
        int int18 = spreadsheetDate3.getMonth();
        try {
            org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((-1), (org.jfree.data.time.SerialDate) spreadsheetDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.Calendar calendar5 = null;
        try {
            month4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        boolean boolean3 = year0.equals((java.lang.Object) 100);
        boolean boolean5 = year0.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        boolean boolean4 = timeSeries3.getNotify();
        timeSeries3.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        int int8 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate12.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean22 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(3);
        int int25 = spreadsheetDate24.toSerial();
        org.jfree.data.time.SerialDate serialDate26 = spreadsheetDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        java.lang.String str28 = day27.toString();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) 9999, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2-January-1900" + "'", str28.equals("2-January-1900"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("June 2019");
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        int int6 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod2, class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate(regularTimePeriod8, (double) 1.0f);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getMiddleMillisecond();
        int int14 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(12, year11);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month15.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-2) + "'", int14 == (-2));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) '4');
        int int3 = month2.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        try {
            org.jfree.data.time.TimeSeries timeSeries21 = timeSeries18.createCopy((-460), 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        org.jfree.data.time.Year year5 = month4.getYear();
        java.util.Calendar calendar6 = null;
        try {
            year5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(6);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 100, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (-1), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1, 7, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries3);
        timeSeries3.setDomainDescription("First");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int12 = day11.getMonth();
        java.lang.Object obj13 = null;
        boolean boolean14 = day11.equals(obj13);
        java.util.Date date15 = day11.getStart();
        int int16 = day11.getDayOfMonth();
        long long17 = day11.getFirstMillisecond();
        long long18 = day11.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208873600000L) + "'", long17 == (-2208873600000L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2208873600000L) + "'", long18 == (-2208873600000L));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate12.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        timeSeries10.setKey((java.lang.Comparable) spreadsheetDate12);
        java.util.Collection collection24 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(collection24);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) ' ', 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate13);
        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) strArray0, (java.lang.Object) timeSeries14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries14.getDataItem(regularTimePeriod16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year1);
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((-1), 4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-459), (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int23 = spreadsheetDate3.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#', 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.String str24 = day23.toString();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = day23.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2-January-1900" + "'", str24.equals("2-January-1900"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.Class class0 = null;
        java.lang.Class class1 = null;
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        java.util.Date date4 = year2.getEnd();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date4, timeZone6);
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone8);
        java.util.TimeZone timeZone10 = null;
        try {
            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date4, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        timeSeries3.setMaximumItemAge(0L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getMiddleMillisecond();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, year11);
        org.jfree.data.time.Year year15 = month14.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = month14.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(regularTimePeriod7, (double) 1.0f);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        long long12 = year10.getMiddleMillisecond();
        int int13 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        java.util.Date date16 = year14.getEnd();
        int int17 = year14.getYear();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) (short) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2) + "'", int13 == (-2));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date23 = spreadsheetDate3.toDate();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        long long28 = year26.getMiddleMillisecond();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (byte) 1, year26);
        long long30 = year26.getFirstMillisecond();
        java.lang.String str31 = year26.toString();
        int int32 = day24.compareTo((java.lang.Object) year26);
        long long33 = year26.getLastMillisecond();
        java.util.Calendar calendar34 = null;
        try {
            year26.peg(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1562097599999L + "'", long28 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        boolean boolean8 = timeSeries3.getNotify();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod10, class11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate(regularTimePeriod16, (double) 1.0f);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod20, class21);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries22.addOrUpdate(regularTimePeriod26, (double) 1.0f);
        java.lang.Number number29 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries12.addOrUpdate(regularTimePeriod26, number29);
        java.lang.Number number31 = timeSeriesDataItem30.getValue();
        java.lang.Object obj32 = null;
        boolean boolean33 = timeSeriesDataItem30.equals(obj32);
        try {
            timeSeries3.add(timeSeriesDataItem30, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 1.0d + "'", number31.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond1.equals(obj6);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 8, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7, class8);
        timeSeries9.setMaximumItemCount((int) '4');
        java.util.Collection collection12 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year13, (double) 0.0f, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        int int17 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate21.toSerial();
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int25 = spreadsheetDate21.getYYYY();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertNotNull(serialDate26);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        try {
            org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate6.getFollowingDayOfWeek((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        timeSeries1.setMaximumItemCount((int) 'a');
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str7 = timeSeries3.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        timeSeries3.setDomainDescription("Overwritten values from: 2018");
        try {
            timeSeries3.removeAgedItems(100L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        int int5 = year1.getYear();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getMiddleMillisecond();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year8);
        long long12 = year8.getFirstMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(8, year8);
        int int14 = year1.compareTo((java.lang.Object) 8);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.String str23 = spreadsheetDate3.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-1), 3, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        java.lang.Object obj7 = timeSeries3.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.lang.String str16 = spreadsheetDate12.toString();
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int18 = spreadsheetDate1.getDayOfWeek();
        int int19 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2-January-1900" + "'", str16.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        long long5 = month4.getFirstMillisecond();
        long long6 = month4.getSerialIndex();
        int int8 = month4.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        boolean boolean14 = month4.equals((java.lang.Object) timeSeries13);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 1.0f);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 43629L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        int int17 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate19);
        java.lang.Class class21 = timeSeries20.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date6, class21);
        java.util.TimeZone timeZone23 = null;
        try {
            org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date6, timeZone23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(class21);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(regularTimePeriod7, (double) 1.0f);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11, class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate(regularTimePeriod17, (double) 1.0f);
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate(regularTimePeriod17, number20);
        java.lang.Comparable comparable22 = timeSeries3.getKey();
        timeSeries3.removeAgedItems(true);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(comparable22);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        boolean boolean8 = timeSeries3.getNotify();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries3.addAndOrUpdate(timeSeries13);
        timeSeries14.setDescription("ERROR : Relative To String");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(timeSeries14);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
//        try {
//            java.lang.Number number4 = timeSeries2.getValue(regularTimePeriod3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod24, class25);
        timeSeries26.setMaximumItemCount((int) '4');
        timeSeries26.removeAgedItems(false);
        timeSeries26.setMaximumItemAge(0L);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        long long36 = year34.getMiddleMillisecond();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (byte) 1, year34);
        org.jfree.data.time.Year year38 = month37.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) month37, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long44 = fixedMillisecond43.getMiddleMillisecond();
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond43.getLastMillisecond(calendar45);
        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        java.lang.Number number48 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        timeSeries18.setDescription("2-January-1900");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + "Overwritten values from: 2018" + "'", comparable22.equals("Overwritten values from: 2018"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1562097599999L + "'", long36 == 1562097599999L);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-1L) + "'", long46 == (-1L));
        org.junit.Assert.assertNull(number48);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(1900, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        int int3 = month0.compareTo((java.lang.Object) 9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        int int3 = spreadsheetDate2.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod2, class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate(regularTimePeriod8, (double) 1.0f);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getMiddleMillisecond();
        int int14 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(12, year11);
        int int16 = month15.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-2) + "'", int14 == (-2));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod24, class25);
        timeSeries26.setMaximumItemCount((int) '4');
        timeSeries26.removeAgedItems(false);
        timeSeries26.setMaximumItemAge(0L);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        long long36 = year34.getMiddleMillisecond();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (byte) 1, year34);
        org.jfree.data.time.Year year38 = month37.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) month37, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long44 = fixedMillisecond43.getMiddleMillisecond();
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond43.getLastMillisecond(calendar45);
        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        java.lang.Number number48 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        long long49 = fixedMillisecond43.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + "Overwritten values from: 2018" + "'", comparable22.equals("Overwritten values from: 2018"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1562097599999L + "'", long36 == 1562097599999L);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-1L) + "'", long46 == (-1L));
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-1L) + "'", long49 == (-1L));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries4.removeAgedItems((long) (byte) 100, false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate(regularTimePeriod15, (double) 1.0f);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod19, class20);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries21.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.addOrUpdate(regularTimePeriod25, (double) 1.0f);
        java.lang.Number number28 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries11.addOrUpdate(regularTimePeriod25, number28);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.previous();
        int int33 = timeSeriesDataItem29.compareTo((java.lang.Object) year31);
        java.lang.Number number34 = timeSeriesDataItem29.getValue();
        try {
            timeSeries4.add(timeSeriesDataItem29, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 1.0d + "'", number34.equals(1.0d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        long long4 = year2.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, year2);
        long long6 = year2.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(8, year2);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.Object obj19 = timeSeries18.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.lang.String str16 = spreadsheetDate12.toString();
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int18 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod20, class21);
        timeSeries22.setMaximumItemCount((int) '4');
        timeSeries22.removeAgedItems(false);
        timeSeries22.setMaximumItemAge(0L);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        long long32 = year30.getMiddleMillisecond();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, year30);
        org.jfree.data.time.Year year34 = month33.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) month33, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
        java.lang.String str38 = timeSeries37.getDomainDescription();
        boolean boolean39 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) int18, (java.lang.Object) timeSeries37);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2-January-1900" + "'", str16.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1562097599999L + "'", long32 == 1562097599999L);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.Class class19 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNull(class19);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7, class8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate(regularTimePeriod13, (double) 1.0f);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod17, class18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries19.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries19.addOrUpdate(regularTimePeriod23, (double) 1.0f);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries9.addOrUpdate(regularTimePeriod23, number26);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem27);
        try {
            timeSeries3.add(timeSeriesDataItem27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date23 = spreadsheetDate3.toDate();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        long long28 = year26.getMiddleMillisecond();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (byte) 1, year26);
        long long30 = year26.getFirstMillisecond();
        java.lang.String str31 = year26.toString();
        int int32 = day24.compareTo((java.lang.Object) year26);
        long long33 = day24.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1562097599999L + "'", long28 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 3L + "'", long33 == 3L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate1.setDescription("2-January-1900");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate(regularTimePeriod11, (double) 1.0f);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod15, class16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate(regularTimePeriod21, (double) 1.0f);
        java.lang.Number number24 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries7.addOrUpdate(regularTimePeriod21, number24);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        int int29 = timeSeriesDataItem25.compareTo((java.lang.Object) year27);
        boolean boolean30 = spreadsheetDate1.equals((java.lang.Object) year27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 0L);
        long long33 = year27.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1562097599999L + "'", long33 == 1562097599999L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (9) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate1.setDescription("2-January-1900");
        try {
            org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(13, 2958465, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        long long25 = day23.getSerialIndex();
        java.lang.String str26 = day23.toString();
        java.util.Calendar calendar27 = null;
        try {
            long long28 = day23.getLastMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 3L + "'", long25 == 3L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2-January-1900" + "'", str26.equals("2-January-1900"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        timeSeries3.setMaximumItemAge(0L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getMiddleMillisecond();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, year11);
        org.jfree.data.time.Year year15 = month14.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long21 = fixedMillisecond20.getMiddleMillisecond();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond20.getLastMillisecond(calendar22);
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        try {
            timeSeries18.removeAgedItems((long) (-2), false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date13 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(3);
        int int23 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        int int28 = spreadsheetDate25.compare((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate20.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean32 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate20, (-460));
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.previous();
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod34, class35);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries36.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries36);
        java.lang.String str40 = timeSeries36.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries36.removeChangeListener(seriesChangeListener41);
        timeSeries36.setDomainDescription("Overwritten values from: 2018");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries36.addChangeListener(seriesChangeListener45);
        try {
            int int47 = spreadsheetDate17.compareTo((java.lang.Object) seriesChangeListener45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Time" + "'", str40.equals("Time"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        timeSeries3.setMaximumItemAge(0L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getMiddleMillisecond();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, year11);
        org.jfree.data.time.Year year15 = month14.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long19 = fixedMillisecond17.getLastMillisecond();
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond17.getFirstMillisecond(calendar20);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.fireSeriesChanged();
        try {
            timeSeries3.delete(2019, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        timeSeries3.setMaximumItemAge(0L);
        timeSeries3.setMaximumItemCount(7);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) -1);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) -1 + "'", obj3.equals((byte) -1));
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        int int4 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date13 = spreadsheetDate2.toDate();
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date13 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(3);
        int int25 = spreadsheetDate22.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate27);
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, class29);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date13, class29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date13);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(serialDate32);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        java.lang.Object obj4 = seriesChangeEvent3.getSource();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ClassContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getMiddleMillisecond();
        int int4 = year0.compareTo((java.lang.Object) "June 2019");
        java.util.Date date5 = year0.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) '4');
        int int3 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date14 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(3);
        int int19 = spreadsheetDate16.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(3);
        int int24 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        int int29 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean30 = spreadsheetDate21.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean33 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, (org.jfree.data.time.SerialDate) spreadsheetDate21, (-460));
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays((int) (short) -1, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(serialDate34);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getSerialIndex();
        int int4 = month0.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        boolean boolean10 = month0.equals((java.lang.Object) timeSeries9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = null;
        try {
            timeSeries9.add(timeSeriesDataItem11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getMiddleMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year6);
        java.lang.String str10 = year6.toString();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(4, year6);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 10.0d);
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        java.lang.Comparable comparable22 = timeSeries18.getKey();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod24, class25);
        timeSeries26.setMaximumItemCount((int) '4');
        timeSeries26.removeAgedItems(false);
        timeSeries26.setMaximumItemAge(0L);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        long long36 = year34.getMiddleMillisecond();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (byte) 1, year34);
        org.jfree.data.time.Year year38 = month37.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) month37, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long44 = fixedMillisecond43.getMiddleMillisecond();
        java.util.Calendar calendar45 = null;
        long long46 = fixedMillisecond43.getLastMillisecond(calendar45);
        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        java.lang.Number number48 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        java.util.Date date49 = fixedMillisecond43.getTime();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + "Overwritten values from: 2018" + "'", comparable22.equals("Overwritten values from: 2018"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1562097599999L + "'", long36 == 1562097599999L);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-1L) + "'", long46 == (-1L));
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertNotNull(date49);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        long long25 = day23.getSerialIndex();
        java.lang.String str26 = day23.toString();
        int int27 = day23.getMonth();
        boolean boolean29 = day23.equals((java.lang.Object) "Overwritten values from: 2018");
        long long30 = day23.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 3L + "'", long25 == 3L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2-January-1900" + "'", str26.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2208787200001L) + "'", long30 == (-2208787200001L));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getLastMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.util.Date date18 = spreadsheetDate7.toDate();
        spreadsheetDate7.setDescription("June 2019");
        int int21 = month3.compareTo((java.lang.Object) "June 2019");
        java.util.Calendar calendar22 = null;
        try {
            month3.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate1.setDescription("2-January-1900");
        int int4 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        int int17 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate21.toSerial();
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        try {
            org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(serialDate23);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        long long4 = year1.getSerialIndex();
        long long5 = year1.getSerialIndex();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(1900, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries3);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (double) 'a');
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond3.getMiddleMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond3.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(3);
        int int19 = spreadsheetDate16.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate21);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date8, class23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(3);
        int int31 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(3);
        int int36 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean37 = spreadsheetDate28.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate38);
        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
        java.io.InputStream inputStream41 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", class40);
        java.lang.Object obj42 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("First", class23, class40);
        java.lang.Object obj43 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Value", class23);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNull(inputStream41);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNull(obj43);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        timeSeries3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate12.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod25, class26);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries27.addPropertyChangeListener(propertyChangeListener28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries27.addOrUpdate(regularTimePeriod31, (double) 1.0f);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod35, class36);
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries37.addOrUpdate(regularTimePeriod41, (double) 1.0f);
        java.lang.Number number44 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries27.addOrUpdate(regularTimePeriod41, number44);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.previous();
        int int49 = timeSeriesDataItem45.compareTo((java.lang.Object) year47);
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) year47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (double) 'a');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond52.previous();
        boolean boolean56 = year47.equals((java.lang.Object) regularTimePeriod55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries58 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year47, regularTimePeriod57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(regularTimePeriod7, (double) 1.0f);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11, class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate(regularTimePeriod17, (double) 1.0f);
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate(regularTimePeriod17, number20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod23, class24);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries25.addPropertyChangeListener(propertyChangeListener26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate(regularTimePeriod29, (double) 1.0f);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod33, class34);
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.addOrUpdate(regularTimePeriod39, (double) 1.0f);
        java.lang.Number number42 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries25.addOrUpdate(regularTimePeriod39, number42);
        timeSeries3.setKey((java.lang.Comparable) regularTimePeriod39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(3);
        int int50 = spreadsheetDate47.compare((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(3);
        int int57 = spreadsheetDate54.compare((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(3);
        int int62 = spreadsheetDate59.compare((org.jfree.data.time.SerialDate) spreadsheetDate61);
        boolean boolean63 = spreadsheetDate54.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        boolean boolean64 = spreadsheetDate49.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate52, (org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(3);
        int int67 = spreadsheetDate66.toSerial();
        org.jfree.data.time.SerialDate serialDate68 = spreadsheetDate49.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, (org.jfree.data.time.SerialDate) spreadsheetDate66);
        int int71 = spreadsheetDate66.getYYYY();
        timeSeries3.setKey((java.lang.Comparable) int71);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1900 + "'", int71 == 1900);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        timeSeries3.setMaximumItemAge(0L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getMiddleMillisecond();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, year11);
        org.jfree.data.time.Year year15 = month14.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long19 = fixedMillisecond17.getLastMillisecond();
        long long20 = fixedMillisecond17.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        long long4 = year2.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, year2);
        int int6 = month0.compareTo((java.lang.Object) (byte) 1);
        java.lang.String str7 = month0.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getMiddleMillisecond();
        int int12 = year8.compareTo((java.lang.Object) "June 2019");
        int int13 = month0.compareTo((java.lang.Object) "June 2019");
        int int14 = month0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, 10.0d);
        int int7 = timeSeriesDataItem5.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        long long11 = year9.getMiddleMillisecond();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, year9);
        org.jfree.data.time.Year year13 = month12.getYear();
        boolean boolean14 = timeSeriesDataItem5.equals((java.lang.Object) year13);
        java.lang.Object obj15 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate1.setDescription("2-January-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        int int8 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int16 = day15.getMonth();
        java.lang.Object obj17 = null;
        boolean boolean18 = day15.equals(obj17);
        java.util.Date date19 = day15.getStart();
        try {
            int int20 = spreadsheetDate1.compareTo((java.lang.Object) day15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Day cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str7 = timeSeries3.getDomainDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((int) 'a', 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2-January-1900");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        timeSeries3.setMaximumItemCount((int) (short) 0);
        timeSeries3.setNotify(true);
        long long11 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-460) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) '4');
        int int3 = month2.getMonth();
        long long4 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-60521184000001L) + "'", long4 == (-60521184000001L));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        java.lang.String str6 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2-January-1900" + "'", str5.equals("2-January-1900"));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
        boolean boolean26 = day23.equals((java.lang.Object) regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        boolean boolean3 = month0.equals((java.lang.Object) "");
        java.lang.String str4 = month0.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        java.lang.Object obj3 = null;
        int int4 = day0.compareTo(obj3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        long long25 = day23.getSerialIndex();
        long long26 = day23.getFirstMillisecond();
        int int27 = day23.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 3L + "'", long25 == 3L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208873600000L) + "'", long26 == (-2208873600000L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        long long4 = year2.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, year2);
        int int6 = month0.compareTo((java.lang.Object) (byte) 1);
        java.lang.String str7 = month0.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getMiddleMillisecond();
        int int12 = year8.compareTo((java.lang.Object) "June 2019");
        int int13 = month0.compareTo((java.lang.Object) "June 2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month0.previous();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = month0.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date23 = spreadsheetDate3.toDate();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date23);
        int int27 = year26.getYear();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1900 + "'", int27 == 1900);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        long long25 = day23.getSerialIndex();
        java.lang.String str26 = day23.toString();
        int int27 = day23.getMonth();
        int int28 = day23.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 3L + "'", long25 == 3L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2-January-1900" + "'", str26.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year1);
        java.lang.String str5 = year1.toString();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(4, year1);
        java.lang.String str7 = year1.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        long long23 = year21.getMiddleMillisecond();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, year21);
        int int25 = month19.compareTo((java.lang.Object) (byte) 1);
        java.lang.String str26 = month19.toString();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        long long29 = year27.getMiddleMillisecond();
        int int31 = year27.compareTo((java.lang.Object) "June 2019");
        int int32 = month19.compareTo((java.lang.Object) "June 2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month19.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month19);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.previous();
        long long38 = year36.getMiddleMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year36);
        java.lang.String str40 = year36.toString();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(4, year36);
        long long42 = year36.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year36, (double) (-460));
        java.lang.String str45 = year36.toString();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year46.previous();
        java.lang.Class class48 = null;
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod47, class48);
        timeSeries49.setMaximumItemCount((int) '4');
        timeSeries49.removeAgedItems(false);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year54.previous();
        java.lang.Class class56 = null;
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod55, class56);
        timeSeries57.setMaximumItemCount((int) '4');
        timeSeries57.removeAgedItems(false);
        timeSeries57.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries49.addAndOrUpdate(timeSeries57);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year65.previous();
        java.lang.Class class67 = null;
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod66, class67);
        timeSeries68.setMaximumItemCount((int) '4');
        timeSeries68.removeAgedItems(false);
        boolean boolean73 = timeSeries68.getNotify();
        java.lang.Class class77 = null;
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class77);
        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries68.addAndOrUpdate(timeSeries78);
        java.util.Collection collection80 = timeSeries64.getTimePeriodsUniqueToOtherSeries(timeSeries78);
        boolean boolean81 = year36.equals((java.lang.Object) timeSeries78);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1562097599999L + "'", long23 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "June 2019" + "'", str26.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1562097599999L + "'", long29 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1562097599999L + "'", long38 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019" + "'", str40.equals("2019"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2019L + "'", long42 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(timeSeries64);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(timeSeries79);
        org.junit.Assert.assertNotNull(collection80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        long long6 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        int int17 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.String str18 = spreadsheetDate14.toString();
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(2958465, serialDate20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2-January-1900" + "'", str18.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod20, class21);
        timeSeries22.setMaximumItemCount((int) '4');
        timeSeries22.removeAgedItems(false);
        boolean boolean27 = timeSeries22.getNotify();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class31);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries22.addAndOrUpdate(timeSeries32);
        java.util.Collection collection34 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 'a');
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond36.getMiddleMillisecond(calendar39);
        java.util.Date date41 = fixedMillisecond36.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond36.next();
        try {
            timeSeries18.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 10.0f, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getMiddleMillisecond();
        int int4 = year0.compareTo((java.lang.Object) "June 2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        int int17 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate19.compare((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate14.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(3);
        int int27 = spreadsheetDate26.toSerial();
        org.jfree.data.time.SerialDate serialDate28 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean31 = year0.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        boolean boolean8 = timeSeries3.getNotify();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class12);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries3.addAndOrUpdate(timeSeries13);
        java.lang.Object obj15 = timeSeries14.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = null;
        try {
            timeSeries14.delete(regularTimePeriod16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(4, (int) (byte) 100, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 10.0d);
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
//        long long7 = year5.getMiddleMillisecond();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, year5);
//        org.jfree.data.time.Year year9 = month8.getYear();
//        boolean boolean10 = timeSeriesDataItem3.equals((java.lang.Object) year9);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1562097599999L + "'", long7 == 1562097599999L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        long long4 = year2.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, year2);
        int int6 = month0.compareTo((java.lang.Object) (byte) 1);
        java.lang.String str7 = month0.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getMiddleMillisecond();
        int int12 = year8.compareTo((java.lang.Object) "June 2019");
        int int13 = month0.compareTo((java.lang.Object) "June 2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month0.previous();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        long long16 = month15.getFirstMillisecond();
        long long17 = month15.getSerialIndex();
        int int19 = month15.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        boolean boolean25 = month15.equals((java.lang.Object) timeSeries24);
        boolean boolean26 = month0.equals((java.lang.Object) timeSeries24);
        java.util.Collection collection27 = timeSeries24.getTimePeriods();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries24.addOrUpdate(regularTimePeriod28, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 24234L + "'", long17 == 24234L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(collection27);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        int int8 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate15);
        java.lang.Class class17 = timeSeries16.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, class17);
        java.io.InputStream inputStream19 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("2-January-1900", class17);
        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResource("Value", class17);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNull(inputStream19);
        org.junit.Assert.assertNull(uRL20);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        long long25 = day23.getSerialIndex();
        java.lang.String str26 = day23.toString();
        java.lang.String str27 = day23.toString();
        int int28 = day23.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 3L + "'", long25 == 3L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2-January-1900" + "'", str26.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2-January-1900" + "'", str27.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(11, (int) ' ', 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        timeSeries3.setMaximumItemCount((int) (short) 0);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod10, class11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        java.lang.Comparable comparable15 = timeSeries12.getKey();
        java.util.List list16 = timeSeries12.getItems();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries12);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(comparable15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date23 = spreadsheetDate3.toDate();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23);
        int int26 = day25.getYear();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Tuesday" + "'", str1.equals("Tuesday"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Object obj6 = timeSeries3.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getSerialIndex();
        int int4 = month0.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        boolean boolean10 = month0.equals((java.lang.Object) timeSeries9);
        org.jfree.data.time.Year year11 = month0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(year11);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.addOrUpdate(regularTimePeriod11, (double) 0L);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        long long17 = year15.getMiddleMillisecond();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, year15);
        int int19 = year15.getYear();
        java.lang.String str20 = year15.toString();
        long long21 = year15.getLastMillisecond();
        long long22 = year15.getFirstMillisecond();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) (short) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019" + "'", str20.equals("2019"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2958465, 2019, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        timeSeries3.setMaximumItemAge(0L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getMiddleMillisecond();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, year11);
        org.jfree.data.time.Year year15 = month14.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long19 = month14.getSerialIndex();
        long long20 = month14.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 24229L + "'", long19 == 24229L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1549007999999L + "'", long20 == 1549007999999L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getLastMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.util.Date date18 = spreadsheetDate7.toDate();
        spreadsheetDate7.setDescription("June 2019");
        int int21 = month3.compareTo((java.lang.Object) "June 2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 13);
        java.util.Calendar calendar24 = null;
        try {
            month3.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) '4');
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem2);
        java.lang.Number number4 = timeSeriesDataItem2.getValue();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "July" + "'", str1.equals("July"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date13 = spreadsheetDate2.toDate();
        spreadsheetDate2.setDescription("June 2019");
        int int16 = spreadsheetDate2.getDayOfWeek();
        int int17 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate19.compare((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.String str23 = spreadsheetDate19.toString();
        int int24 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(3);
        int int30 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        int int35 = spreadsheetDate32.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean36 = spreadsheetDate27.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date38 = spreadsheetDate27.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(3);
        int int43 = spreadsheetDate40.compare((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(3);
        int int48 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(3);
        int int53 = spreadsheetDate50.compare((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean54 = spreadsheetDate45.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean57 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate45, (-460));
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(3);
        int int62 = spreadsheetDate59.compare((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(3);
        int int69 = spreadsheetDate66.compare((org.jfree.data.time.SerialDate) spreadsheetDate68);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(3);
        int int74 = spreadsheetDate71.compare((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean75 = spreadsheetDate66.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean76 = spreadsheetDate61.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate64, (org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(3);
        int int79 = spreadsheetDate78.toSerial();
        org.jfree.data.time.SerialDate serialDate80 = spreadsheetDate61.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate78);
        boolean boolean82 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate61, (int) '#');
        try {
            org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate19.getNearestDayOfWeek(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2-January-1900" + "'", str23.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 3 + "'", int79 == 3);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getSerialIndex();
        int int4 = month0.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        boolean boolean10 = month0.equals((java.lang.Object) timeSeries9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) 1.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 'a');
        java.lang.Number number17 = timeSeriesDataItem16.getValue();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(3);
        int int23 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        int int28 = spreadsheetDate25.compare((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate20.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod33, class34);
        timeSeries35.setMaximumItemCount((int) '4');
        long long38 = timeSeries35.getMaximumItemAge();
        timeSeries35.fireSeriesChanged();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.previous();
        long long42 = year40.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year40.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries35.addOrUpdate(regularTimePeriod43, (double) 0L);
        int int46 = timeSeries31.getIndex(regularTimePeriod43);
        int int47 = timeSeriesDataItem16.compareTo((java.lang.Object) regularTimePeriod43);
        int int48 = month0.compareTo((java.lang.Object) timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 97.0d + "'", number17.equals(97.0d));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 9223372036854775807L + "'", long38 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1562097599999L + "'", long42 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str7 = timeSeries3.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.removeChangeListener(seriesChangeListener10);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date13 = spreadsheetDate2.toDate();
        spreadsheetDate2.setDescription("June 2019");
        int int16 = spreadsheetDate2.getDayOfWeek();
        int int17 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate19.compare((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.String str23 = spreadsheetDate19.toString();
        int int24 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(3);
        int int30 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        int int35 = spreadsheetDate32.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean36 = spreadsheetDate27.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date38 = spreadsheetDate27.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(3);
        int int43 = spreadsheetDate40.compare((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(3);
        int int48 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(3);
        int int53 = spreadsheetDate50.compare((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean54 = spreadsheetDate45.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean57 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate45, (-460));
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(3);
        int int62 = spreadsheetDate59.compare((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(3);
        int int69 = spreadsheetDate66.compare((org.jfree.data.time.SerialDate) spreadsheetDate68);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(3);
        int int74 = spreadsheetDate71.compare((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean75 = spreadsheetDate66.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean76 = spreadsheetDate61.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate64, (org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(3);
        int int79 = spreadsheetDate78.toSerial();
        org.jfree.data.time.SerialDate serialDate80 = spreadsheetDate61.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate78);
        boolean boolean82 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate61, (int) '#');
        int int83 = spreadsheetDate42.getYYYY();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2-January-1900" + "'", str23.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 3 + "'", int79 == 3);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1900 + "'", int83 == 1900);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getSerialIndex();
        long long3 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date13 = spreadsheetDate2.toDate();
        spreadsheetDate2.setDescription("June 2019");
        int int16 = spreadsheetDate2.getDayOfWeek();
        int int17 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate19.compare((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.String str23 = spreadsheetDate19.toString();
        int int24 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(3);
        int int30 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        int int35 = spreadsheetDate32.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean36 = spreadsheetDate27.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date38 = spreadsheetDate27.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(3);
        int int43 = spreadsheetDate40.compare((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(3);
        int int48 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(3);
        int int53 = spreadsheetDate50.compare((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean54 = spreadsheetDate45.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean57 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate45, (-460));
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(3);
        int int62 = spreadsheetDate59.compare((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(3);
        int int69 = spreadsheetDate66.compare((org.jfree.data.time.SerialDate) spreadsheetDate68);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(3);
        int int74 = spreadsheetDate71.compare((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean75 = spreadsheetDate66.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean76 = spreadsheetDate61.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate64, (org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(3);
        int int79 = spreadsheetDate78.toSerial();
        org.jfree.data.time.SerialDate serialDate80 = spreadsheetDate61.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate78);
        boolean boolean82 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate61, (int) '#');
        try {
            org.jfree.data.time.SerialDate serialDate84 = spreadsheetDate42.getPreviousDayOfWeek((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2-January-1900" + "'", str23.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 3 + "'", int79 == 3);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate2.getDayOfMonth();
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(2958465, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod6, class7);
        timeSeries8.setMaximumItemCount((int) '4');
        timeSeries8.removeAgedItems(false);
        boolean boolean13 = timeSeries8.getNotify();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries8.addAndOrUpdate(timeSeries18);
        boolean boolean20 = timeSeries4.equals((java.lang.Object) timeSeries8);
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod24, class25);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries26.addPropertyChangeListener(propertyChangeListener27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries26.addOrUpdate(regularTimePeriod30, (double) 1.0f);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.previous();
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod34, class35);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries36.addPropertyChangeListener(propertyChangeListener37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries36.addOrUpdate(regularTimePeriod40, (double) 1.0f);
        java.lang.Number number43 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries26.addOrUpdate(regularTimePeriod40, number43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.previous();
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod46, class47);
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timeSeries48.addPropertyChangeListener(propertyChangeListener49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year51.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries48.addOrUpdate(regularTimePeriod52, (double) 1.0f);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year55.previous();
        java.lang.Class class57 = null;
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod56, class57);
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timeSeries58.addPropertyChangeListener(propertyChangeListener59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year61.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries58.addOrUpdate(regularTimePeriod62, (double) 1.0f);
        java.lang.Number number65 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries48.addOrUpdate(regularTimePeriod62, number65);
        timeSeries26.setKey((java.lang.Comparable) regularTimePeriod62);
        try {
            timeSeries8.update(regularTimePeriod62, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNull(timeSeriesDataItem64);
        org.junit.Assert.assertNotNull(timeSeriesDataItem66);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        long long4 = year2.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, year2);
        int int6 = month0.compareTo((java.lang.Object) (byte) 1);
        java.lang.String str7 = month0.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getMiddleMillisecond();
        int int12 = year8.compareTo((java.lang.Object) "June 2019");
        int int13 = month0.compareTo((java.lang.Object) "June 2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month0.previous();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        long long16 = month15.getFirstMillisecond();
        long long17 = month15.getSerialIndex();
        int int19 = month15.compareTo((java.lang.Object) 1.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        boolean boolean25 = month15.equals((java.lang.Object) timeSeries24);
        boolean boolean26 = month0.equals((java.lang.Object) timeSeries24);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        java.util.Date date29 = year27.getEnd();
        try {
            timeSeries24.add((org.jfree.data.time.RegularTimePeriod) year27, (double) 3L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 24234L + "'", long17 == 24234L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        long long6 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date23 = spreadsheetDate3.toDate();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23);
        int int26 = day25.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        boolean boolean8 = timeSeries3.getNotify();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        long long11 = year9.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.previous();
        timeSeries3.setKey((java.lang.Comparable) regularTimePeriod12);
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemCount(2019);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: ThreadContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount(100);
        java.lang.String str6 = timeSeries3.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener7);
        try {
            timeSeries3.update(7, (java.lang.Number) (-2177424000001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        int int5 = year1.getYear();
        java.lang.String str6 = year1.toString();
        long long7 = year1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.lang.String str4 = month2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "February 52" + "'", str4.equals("February 52"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        timeSeries4.setKey((java.lang.Comparable) spreadsheetDate6);
        try {
            timeSeries4.delete((-459), 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        java.lang.Object obj7 = timeSeries3.clone();
        timeSeries3.setNotify(false);
        timeSeries3.setRangeDescription("2-January-1900");
        java.lang.Comparable comparable12 = timeSeries3.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(comparable12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.Class class19 = timeSeries11.getTimePeriodClass();
        java.lang.String str20 = timeSeries11.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate18.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate13.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
        timeSeries11.setKey((java.lang.Comparable) spreadsheetDate13);
        spreadsheetDate13.setDescription("Time");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        int int29 = spreadsheetDate28.getMonth();
        int int30 = spreadsheetDate28.getDayOfWeek();
        boolean boolean31 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean32 = fixedMillisecond1.equals((java.lang.Object) spreadsheetDate13);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        timeSeries3.setMaximumItemAge(0L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        long long13 = year11.getMiddleMillisecond();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, year11);
        org.jfree.data.time.Year year15 = month14.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long21 = fixedMillisecond20.getMiddleMillisecond();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond20.getLastMillisecond(calendar22);
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        int int29 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(3);
        int int36 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
        int int41 = spreadsheetDate38.compare((org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean42 = spreadsheetDate33.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean43 = spreadsheetDate28.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(3);
        int int46 = spreadsheetDate45.toSerial();
        org.jfree.data.time.SerialDate serialDate47 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day48.next();
        long long50 = day48.getSerialIndex();
        java.lang.String str51 = day48.toString();
        int int52 = fixedMillisecond20.compareTo((java.lang.Object) str51);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 3 + "'", int46 == 3);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 3L + "'", long50 == 3L);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "2-January-1900" + "'", str51.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(regularTimePeriod7, (double) 1.0f);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        long long12 = year10.getMiddleMillisecond();
        int int13 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate15.setDescription("2-January-1900");
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod19, class20);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries21.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.addOrUpdate(regularTimePeriod25, (double) 1.0f);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod29, class30);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate(regularTimePeriod35, (double) 1.0f);
        java.lang.Number number38 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries21.addOrUpdate(regularTimePeriod35, number38);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year41.previous();
        int int43 = timeSeriesDataItem39.compareTo((java.lang.Object) year41);
        boolean boolean44 = spreadsheetDate15.equals((java.lang.Object) year41);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year41, (double) 2019L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2) + "'", int13 == (-2));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date13 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(3);
        int int25 = spreadsheetDate22.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate27);
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, class29);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date13, class29);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date13);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(class29);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(regularTimePeriod7, (double) 1.0f);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11, class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate(regularTimePeriod17, (double) 1.0f);
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate(regularTimePeriod17, number20);
        java.lang.Number number22 = timeSeriesDataItem21.getValue();
        java.lang.Object obj23 = timeSeriesDataItem21.clone();
        java.lang.Object obj24 = timeSeriesDataItem21.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 1.0d + "'", number22.equals(1.0d));
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        timeSeries3.setMaximumItemAge(10L);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener10);
        timeSeries3.setDomainDescription("ERROR : Relative To String");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 1561964399999L);
        timeSeries3.removeAgedItems(false);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        timeSeries4.setKey((java.lang.Comparable) spreadsheetDate6);
        java.lang.String str18 = spreadsheetDate6.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(3);
        int int23 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(3);
        int int30 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        int int35 = spreadsheetDate32.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean36 = spreadsheetDate27.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean37 = spreadsheetDate22.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(3);
        int int40 = spreadsheetDate39.toSerial();
        org.jfree.data.time.SerialDate serialDate41 = spreadsheetDate22.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate39);
        java.util.Date date42 = spreadsheetDate22.toDate();
        boolean boolean43 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2-January-1900" + "'", str18.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 3 + "'", int40 == 3);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate(regularTimePeriod15, (double) 1.0f);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.previous();
        long long20 = year18.getMiddleMillisecond();
        int int21 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(12, year18);
        int int24 = month22.compareTo((java.lang.Object) 1.0f);
        java.lang.Number number25 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month22);
        long long26 = month22.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-2) + "'", int21 == (-2));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1576526399999L + "'", long26 == 1576526399999L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getLastMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.util.Date date18 = spreadsheetDate7.toDate();
        spreadsheetDate7.setDescription("June 2019");
        int int21 = month3.compareTo((java.lang.Object) "June 2019");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        int int29 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        int int34 = spreadsheetDate31.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean35 = spreadsheetDate26.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        java.util.Date date37 = spreadsheetDate26.toDate();
        spreadsheetDate26.setDescription("June 2019");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate26);
        boolean boolean41 = timeSeriesDataItem23.equals((java.lang.Object) spreadsheetDate26);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(3);
        int int24 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        int int29 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean30 = spreadsheetDate21.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate31);
        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
        boolean boolean34 = timeSeries11.equals((java.lang.Object) class33);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener35);
        try {
            timeSeries11.delete(3, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        java.lang.Object obj7 = timeSeries3.clone();
        long long8 = timeSeries3.getMaximumItemAge();
        java.lang.Object obj9 = timeSeries3.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.String str6 = spreadsheetDate2.toString();
        spreadsheetDate2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2-January-1900" + "'", str6.equals("2-January-1900"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        timeSeries4.setKey((java.lang.Comparable) spreadsheetDate6);
        spreadsheetDate6.setDescription("Time");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(3);
        int int24 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(3);
        int int31 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(3);
        int int36 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean37 = spreadsheetDate28.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
        int int41 = spreadsheetDate40.toSerial();
        org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate23.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate40);
        int int43 = spreadsheetDate6.compareTo((java.lang.Object) serialDate42);
        int int44 = spreadsheetDate6.getMonth();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 3 + "'", int41 == 3);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-29) + "'", int43 == (-29));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.Class class19 = timeSeries11.getTimePeriodClass();
        java.util.List list20 = timeSeries11.getItems();
        timeSeries11.clear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        timeSeries4.setKey((java.lang.Comparable) spreadsheetDate6);
        spreadsheetDate6.setDescription("Time");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate21.getMonth();
        int int23 = spreadsheetDate21.getDayOfWeek();
        boolean boolean24 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        int int29 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(3);
        int int36 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
        int int41 = spreadsheetDate38.compare((org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean42 = spreadsheetDate33.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean43 = spreadsheetDate28.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(3);
        int int46 = spreadsheetDate45.toSerial();
        org.jfree.data.time.SerialDate serialDate47 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean49 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 3 + "'", int46 == 3);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        long long4 = year1.getSerialIndex();
        java.lang.String str5 = year1.toString();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) ' ', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.lang.String str24 = day23.toString();
        int int25 = day23.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2-January-1900" + "'", str24.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        timeSeries3.setMaximumItemAge(10L);
        java.util.Collection collection10 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(collection10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date23 = spreadsheetDate3.toDate();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date23, timeZone26);
        java.util.Calendar calendar28 = null;
        try {
            long long29 = year27.getMiddleMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(timeZone26);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.lang.String str17 = spreadsheetDate13.toString();
        org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2-January-1900" + "'", str17.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        java.util.Date date9 = year7.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date9);
        boolean boolean13 = fixedMillisecond1.equals((java.lang.Object) date9);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod16, class17);
        timeSeries18.setMaximumItemCount((int) '4');
        timeSeries18.removeAgedItems(false);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod24, class25);
        timeSeries26.setMaximumItemCount((int) '4');
        timeSeries26.removeAgedItems(false);
        timeSeries26.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries18.addAndOrUpdate(timeSeries26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(3);
        int int39 = spreadsheetDate36.compare((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(3);
        int int44 = spreadsheetDate41.compare((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean45 = spreadsheetDate36.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate46);
        java.lang.Class class48 = timeSeries47.getTimePeriodClass();
        boolean boolean49 = timeSeries26.equals((java.lang.Object) class48);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, class48);
        boolean boolean51 = fixedMillisecond1.equals((java.lang.Object) class48);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Tuesday");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate1.setDescription("2-January-1900");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate(regularTimePeriod11, (double) 1.0f);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod15, class16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate(regularTimePeriod21, (double) 1.0f);
        java.lang.Number number24 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries7.addOrUpdate(regularTimePeriod21, number24);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        int int29 = timeSeriesDataItem25.compareTo((java.lang.Object) year27);
        boolean boolean30 = spreadsheetDate1.equals((java.lang.Object) year27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(3);
        int int36 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean38 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(3);
        int int43 = spreadsheetDate40.compare((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(3);
        int int48 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean49 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(3);
        int int54 = spreadsheetDate51.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
        java.lang.String str55 = spreadsheetDate51.toString();
        org.jfree.data.time.SerialDate serialDate56 = spreadsheetDate40.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate51);
        int int57 = spreadsheetDate40.getDayOfWeek();
        int int58 = spreadsheetDate40.getMonth();
        boolean boolean59 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2-January-1900" + "'", str55.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 3 + "'", int57 == 3);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod6, class7);
        timeSeries8.setMaximumItemCount((int) '4');
        timeSeries8.removeAgedItems(false);
        boolean boolean13 = timeSeries8.getNotify();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries8.addAndOrUpdate(timeSeries18);
        boolean boolean20 = timeSeries4.equals((java.lang.Object) timeSeries8);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod22, class23);
        timeSeries24.setMaximumItemCount((int) '4');
        timeSeries24.removeAgedItems(false);
        timeSeries24.setMaximumItemAge(0L);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
        long long34 = year32.getMiddleMillisecond();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 1, year32);
        org.jfree.data.time.Year year36 = month35.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long42 = fixedMillisecond41.getMiddleMillisecond();
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond41.getLastMillisecond(calendar43);
        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        boolean boolean46 = timeSeries4.equals((java.lang.Object) timeSeries39);
        java.lang.String str47 = timeSeries4.getRangeDescription();
        timeSeries4.fireSeriesChanged();
        timeSeries4.removeAgedItems(2019L, false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1562097599999L + "'", long34 == 1562097599999L);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Value" + "'", str47.equals("Value"));
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.lang.String str2 = day0.toString();
//        int int3 = day0.getDayOfMonth();
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount(100);
        java.lang.String str6 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getMiddleMillisecond();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year8);
        long long12 = year8.getFirstMillisecond();
        java.lang.String str13 = year8.toString();
        timeSeries3.setKey((java.lang.Comparable) year8);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod16, class17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        java.util.List list21 = timeSeries18.getItems();
        timeSeries18.setMaximumItemCount((int) (short) 0);
        timeSeries18.setNotify(true);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        boolean boolean29 = year26.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 2019L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date13 = spreadsheetDate2.toDate();
        spreadsheetDate2.setDescription("June 2019");
        int int16 = spreadsheetDate2.getDayOfWeek();
        int int17 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate19.compare((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.String str23 = spreadsheetDate19.toString();
        int int24 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(3);
        int int30 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        int int35 = spreadsheetDate32.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean36 = spreadsheetDate27.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date38 = spreadsheetDate27.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(3);
        int int43 = spreadsheetDate40.compare((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(3);
        int int48 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(3);
        int int53 = spreadsheetDate50.compare((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean54 = spreadsheetDate45.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
        boolean boolean57 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate45, (-460));
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(3);
        int int62 = spreadsheetDate59.compare((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(3);
        int int69 = spreadsheetDate66.compare((org.jfree.data.time.SerialDate) spreadsheetDate68);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(3);
        int int74 = spreadsheetDate71.compare((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean75 = spreadsheetDate66.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean76 = spreadsheetDate61.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate64, (org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(3);
        int int79 = spreadsheetDate78.toSerial();
        org.jfree.data.time.SerialDate serialDate80 = spreadsheetDate61.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate78);
        boolean boolean82 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate61, (int) '#');
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2-January-1900" + "'", str23.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 3 + "'", int79 == 3);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        timeSeriesDataItem3.setValue((java.lang.Number) 9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem3.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        int int2 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.String str5 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Date date2 = year0.getEnd();
        long long3 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.lang.Object obj4 = null;
        int int5 = timeSeriesDataItem3.compareTo(obj4);
        timeSeriesDataItem3.setValue((java.lang.Number) 2958465);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        int int17 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate21.getMonth();
        int int23 = spreadsheetDate21.getDayOfWeek();
        boolean boolean24 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(serialDate25);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.Class class19 = timeSeries11.getTimePeriodClass();
        java.util.List list20 = timeSeries11.getItems();
        java.lang.Object obj21 = timeSeries11.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        timeSeries3.setMaximumItemCount((int) (short) 0);
        timeSeries3.clear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(regularTimePeriod7, (double) 1.0f);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        long long12 = year10.getMiddleMillisecond();
        int int13 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod15, class16);
        timeSeries17.setMaximumItemCount((int) '4');
        timeSeries17.removeAgedItems(false);
        boolean boolean22 = timeSeries17.getNotify();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class26);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries17.addAndOrUpdate(timeSeries27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.addAndOrUpdate(timeSeries28);
        timeSeries29.setRangeDescription("2-January-1900");
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2) + "'", int13 == (-2));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        long long4 = year2.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, year2);
        int int6 = month0.compareTo((java.lang.Object) (byte) 1);
        java.lang.String str7 = month0.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getMiddleMillisecond();
        int int12 = year8.compareTo((java.lang.Object) "June 2019");
        int int13 = month0.compareTo((java.lang.Object) "June 2019");
        java.util.Calendar calendar14 = null;
        try {
            long long15 = month0.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date13 = spreadsheetDate2.toDate();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(regularTimePeriod7, (double) 1.0f);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11, class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate(regularTimePeriod17, (double) 1.0f);
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate(regularTimePeriod17, number20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod23, class24);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries25.addPropertyChangeListener(propertyChangeListener26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate(regularTimePeriod29, (double) 1.0f);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod33, class34);
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries35.addOrUpdate(regularTimePeriod39, (double) 1.0f);
        java.lang.Number number42 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries25.addOrUpdate(regularTimePeriod39, number42);
        timeSeries3.setKey((java.lang.Comparable) regularTimePeriod39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) 'a');
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond47.getMiddleMillisecond(calendar50);
        java.util.Date date52 = fixedMillisecond47.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(3);
        int int58 = spreadsheetDate55.compare((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(3);
        int int63 = spreadsheetDate60.compare((org.jfree.data.time.SerialDate) spreadsheetDate62);
        boolean boolean64 = spreadsheetDate55.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate65);
        java.lang.Class class67 = timeSeries66.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date52, class67);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(3);
        int int75 = spreadsheetDate72.compare((org.jfree.data.time.SerialDate) spreadsheetDate74);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate79 = new org.jfree.data.time.SpreadsheetDate(3);
        int int80 = spreadsheetDate77.compare((org.jfree.data.time.SerialDate) spreadsheetDate79);
        boolean boolean81 = spreadsheetDate72.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate79);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate72);
        org.jfree.data.time.TimeSeries timeSeries83 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate82);
        java.lang.Class class84 = timeSeries83.getTimePeriodClass();
        java.io.InputStream inputStream85 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", class84);
        java.lang.Object obj86 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("First", class67, class84);
        org.jfree.data.time.TimeSeries timeSeries87 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod39, class84);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1L) + "'", long51 == (-1L));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(class67);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(class84);
        org.junit.Assert.assertNull(inputStream85);
        org.junit.Assert.assertNull(obj86);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(24234L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.lang.Object obj4 = null;
        int int5 = timeSeriesDataItem3.compareTo(obj4);
        java.lang.Number number6 = null;
        timeSeriesDataItem3.setValue(number6);
        java.lang.Object obj8 = timeSeriesDataItem3.clone();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int12 = day11.getMonth();
        java.lang.Object obj13 = null;
        boolean boolean14 = day11.equals(obj13);
        java.util.Date date15 = day11.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(regularTimePeriod7, (double) 1.0f);
        java.lang.Class class10 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNull(class10);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(3);
        int int24 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        int int29 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean30 = spreadsheetDate21.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate31);
        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
        boolean boolean34 = timeSeries11.equals((java.lang.Object) class33);
        timeSeries11.clear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        try {
            java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date23 = spreadsheetDate3.toDate();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date23, timeZone26);
        java.util.Calendar calendar28 = null;
        try {
            long long29 = year27.getLastMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(timeZone26);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        int int5 = year1.getYear();
        java.lang.String str6 = year1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year1.next();
        java.util.Date date8 = regularTimePeriod7.getStart();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7, class8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate(regularTimePeriod13, (double) 1.0f);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod17, class18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries19.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries19.addOrUpdate(regularTimePeriod23, (double) 1.0f);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries9.addOrUpdate(regularTimePeriod23, number26);
        timeSeries4.delete(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond4.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond4.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate12.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate22);
        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date9, class24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(3);
        int int32 = spreadsheetDate29.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(3);
        int int37 = spreadsheetDate34.compare((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean38 = spreadsheetDate29.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate39);
        java.lang.Class class41 = timeSeries40.getTimePeriodClass();
        java.io.InputStream inputStream42 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", class41);
        java.lang.Object obj43 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("First", class24, class41);
        java.lang.ClassLoader classLoader44 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class24);
        java.io.InputStream inputStream45 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Overwritten values from: 2018", class24);
        java.io.InputStream inputStream46 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", class24);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertNull(inputStream42);
        org.junit.Assert.assertNull(obj43);
        org.junit.Assert.assertNotNull(classLoader44);
        org.junit.Assert.assertNull(inputStream45);
        org.junit.Assert.assertNull(inputStream46);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Comparable comparable6 = timeSeries3.getKey();
        java.util.List list7 = timeSeries3.getItems();
        java.util.List list8 = timeSeries3.getItems();
        try {
            java.util.Collection collection9 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list8);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(comparable6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        int int17 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.String str18 = spreadsheetDate14.toString();
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int20 = spreadsheetDate3.getDayOfWeek();
        int int21 = month0.compareTo((java.lang.Object) int20);
        long long22 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2-January-1900" + "'", str18.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1559372400000L + "'", long22 == 1559372400000L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.lang.String str16 = spreadsheetDate12.toString();
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int18 = spreadsheetDate1.getDayOfWeek();
        int int19 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate21.getMonth();
        boolean boolean23 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        int int28 = spreadsheetDate25.compare((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        int int35 = spreadsheetDate32.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(3);
        int int40 = spreadsheetDate37.compare((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean41 = spreadsheetDate32.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean42 = spreadsheetDate27.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate30, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(3);
        int int45 = spreadsheetDate44.getMonth();
        int int46 = spreadsheetDate44.getDayOfWeek();
        boolean boolean47 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean48 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2-January-1900" + "'", str16.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 3 + "'", int46 == 3);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod2, class3);
        timeSeries4.setMaximumItemCount((int) '4');
        timeSeries4.removeAgedItems(false);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod10, class11);
        timeSeries12.setMaximumItemCount((int) '4');
        timeSeries12.removeAgedItems(false);
        timeSeries12.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(3);
        int int25 = spreadsheetDate22.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(3);
        int int30 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean31 = spreadsheetDate22.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate32);
        java.lang.Class class34 = timeSeries33.getTimePeriodClass();
        boolean boolean35 = timeSeries12.equals((java.lang.Object) class34);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, class34);
        java.lang.String str37 = timeSeries36.getDomainDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Time" + "'", str37.equals("Time"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        java.lang.String str4 = year0.toString();
        java.lang.Object obj5 = null;
        int int6 = year0.compareTo(obj5);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date14 = spreadsheetDate3.toDate();
        spreadsheetDate3.setDescription("June 2019");
        int int17 = spreadsheetDate3.getDayOfWeek();
        int int18 = spreadsheetDate3.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(3);
        int int23 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        java.lang.String str24 = spreadsheetDate20.toString();
        int int25 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        try {
            org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 100, (org.jfree.data.time.SerialDate) spreadsheetDate20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2-January-1900" + "'", str24.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date14 = spreadsheetDate3.toDate();
        spreadsheetDate3.setDescription("June 2019");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(8, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate3.getPreviousDayOfWeek((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        java.lang.Object obj7 = timeSeries3.clone();
        timeSeries3.setNotify(false);
        timeSeries3.setRangeDescription("2-January-1900");
        java.util.Collection collection12 = timeSeries3.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod18, class19);
        timeSeries20.setMaximumItemCount((int) '4');
        timeSeries20.removeAgedItems(false);
        boolean boolean25 = timeSeries20.getNotify();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries20.addAndOrUpdate(timeSeries30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod33, class34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod33, 10.0d);
        timeSeries30.delete(regularTimePeriod33);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries39);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate1.setDescription("2-January-1900");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate(regularTimePeriod11, (double) 1.0f);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod15, class16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate(regularTimePeriod21, (double) 1.0f);
        java.lang.Number number24 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries7.addOrUpdate(regularTimePeriod21, number24);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        int int29 = timeSeriesDataItem25.compareTo((java.lang.Object) year27);
        boolean boolean30 = spreadsheetDate1.equals((java.lang.Object) year27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(3);
        int int36 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean38 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SerialDate serialDate39 = null;
        try {
            boolean boolean40 = spreadsheetDate1.isOn(serialDate39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Value");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date23 = spreadsheetDate3.toDate();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.lang.Object obj26 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) date23);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) '4');
        int int3 = month2.getMonth();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        java.lang.Object obj10 = timeSeries7.clone();
        int int11 = month2.compareTo(obj10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod13, class14);
        timeSeries15.setMaximumItemCount((int) '4');
        timeSeries15.removeAgedItems(false);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod21, class22);
        timeSeries23.setMaximumItemCount((int) '4');
        timeSeries23.removeAgedItems(false);
        timeSeries23.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries15.addAndOrUpdate(timeSeries23);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.previous();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod32, class33);
        timeSeries34.setMaximumItemCount((int) '4');
        timeSeries34.removeAgedItems(false);
        boolean boolean39 = timeSeries34.getNotify();
        java.lang.Class class43 = null;
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class43);
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries34.addAndOrUpdate(timeSeries44);
        java.util.Collection collection46 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries44);
        int int47 = month2.compareTo((java.lang.Object) collection46);
        long long48 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertNotNull(collection46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-60523689600000L) + "'", long48 == (-60523689600000L));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        spreadsheetDate1.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.String str14 = spreadsheetDate10.toString();
        spreadsheetDate10.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.String str17 = spreadsheetDate10.toString();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears(9, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean19 = spreadsheetDate1.isAfter(serialDate18);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2-January-1900" + "'", str5.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2-January-1900" + "'", str14.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2-January-1900" + "'", str17.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate12);
        timeSeries13.setDescription("org.jfree.data.time.TimePeriodFormatException: ThreadContext");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        timeSeries3.setMaximumItemAge(10L);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener10);
        try {
            timeSeries3.setMaximumItemAge((-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(3);
        int int24 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        int int29 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean30 = spreadsheetDate21.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate31);
        java.lang.Class class33 = timeSeries32.getTimePeriodClass();
        boolean boolean34 = timeSeries11.equals((java.lang.Object) class33);
        java.lang.ClassLoader classLoader35 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class33);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader35);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(classLoader35);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int12 = day11.getMonth();
        java.lang.Object obj13 = null;
        boolean boolean14 = day11.equals(obj13);
        int int15 = day11.getYear();
        long long16 = day11.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208873600000L) + "'", long16 == (-2208873600000L));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.lang.String str16 = spreadsheetDate12.toString();
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int18 = spreadsheetDate1.getDayOfWeek();
        int int19 = spreadsheetDate1.getMonth();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod21, class22);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener24);
        java.lang.Object obj26 = timeSeries23.clone();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod29, class30);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries31.addPropertyChangeListener(propertyChangeListener32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate(regularTimePeriod35, (double) 1.0f);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.previous();
        long long40 = year38.getMiddleMillisecond();
        int int41 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(12, year38);
        int int44 = month42.compareTo((java.lang.Object) 1.0f);
        java.lang.Number number45 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) month42);
        try {
            int int46 = spreadsheetDate1.compareTo((java.lang.Object) number45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2-January-1900" + "'", str16.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1562097599999L + "'", long40 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-2) + "'", int41 == (-2));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNull(number45);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        int int17 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate21.toSerial();
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int17 = day16.getMonth();
        java.lang.Object obj18 = null;
        boolean boolean19 = day16.equals(obj18);
        java.util.Date date20 = day16.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        java.util.Date date22 = year21.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(3);
        int int27 = spreadsheetDate24.compare((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        int int34 = spreadsheetDate31.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(3);
        int int39 = spreadsheetDate36.compare((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean40 = spreadsheetDate31.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean41 = spreadsheetDate26.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(3);
        int int44 = spreadsheetDate43.toSerial();
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate26.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate43);
        java.util.Date date46 = spreadsheetDate26.toDate();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date46);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date46, timeZone49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date22, timeZone49);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date2, timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 3 + "'", int44 == 3);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(timeZone49);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate1.setDescription("2-January-1900");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate(regularTimePeriod11, (double) 1.0f);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod15, class16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate(regularTimePeriod21, (double) 1.0f);
        java.lang.Number number24 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries7.addOrUpdate(regularTimePeriod21, number24);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        int int29 = timeSeriesDataItem25.compareTo((java.lang.Object) year27);
        boolean boolean30 = spreadsheetDate1.equals((java.lang.Object) year27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(3);
        int int36 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean38 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(3);
        int int43 = spreadsheetDate40.compare((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(3);
        int int48 = spreadsheetDate45.compare((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean49 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(3);
        int int54 = spreadsheetDate51.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
        java.lang.String str55 = spreadsheetDate51.toString();
        org.jfree.data.time.SerialDate serialDate56 = spreadsheetDate40.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate51);
        int int57 = spreadsheetDate40.getDayOfWeek();
        boolean boolean58 = spreadsheetDate33.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2-January-1900" + "'", str55.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 3 + "'", int57 == 3);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date13 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(3);
        int int23 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        int int28 = spreadsheetDate25.compare((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate20.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean32 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate20, (-460));
        java.lang.String str33 = spreadsheetDate2.getDescription();
        int int34 = spreadsheetDate2.getMonth();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2-January-1900");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("ClassContext");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod15, class16);
        timeSeries17.setMaximumItemCount((int) '4');
        long long20 = timeSeries17.getMaximumItemAge();
        timeSeries17.fireSeriesChanged();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.previous();
        long long24 = year22.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year22.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries17.addOrUpdate(regularTimePeriod25, (double) 0L);
        int int28 = timeSeries13.getIndex(regularTimePeriod25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(3);
        int int33 = spreadsheetDate30.compare((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(3);
        int int40 = spreadsheetDate37.compare((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(3);
        int int45 = spreadsheetDate42.compare((org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean46 = spreadsheetDate37.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean47 = spreadsheetDate32.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(3);
        int int50 = spreadsheetDate49.toSerial();
        org.jfree.data.time.SerialDate serialDate51 = spreadsheetDate32.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = day52.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) day52);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1562097599999L + "'", long24 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 3 + "'", int50 == 3);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNull(timeSeriesDataItem54);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate1.setDescription("2-January-1900");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate(regularTimePeriod11, (double) 1.0f);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod15, class16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate(regularTimePeriod21, (double) 1.0f);
        java.lang.Number number24 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries7.addOrUpdate(regularTimePeriod21, number24);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        int int29 = timeSeriesDataItem25.compareTo((java.lang.Object) year27);
        boolean boolean30 = spreadsheetDate1.equals((java.lang.Object) year27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        int int35 = spreadsheetDate32.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(3);
        int int42 = spreadsheetDate39.compare((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(3);
        int int47 = spreadsheetDate44.compare((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean48 = spreadsheetDate39.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean49 = spreadsheetDate34.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate37, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(3);
        int int52 = spreadsheetDate51.toSerial();
        org.jfree.data.time.SerialDate serialDate53 = spreadsheetDate34.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate51);
        int int54 = year27.compareTo((java.lang.Object) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(3);
        int int59 = spreadsheetDate56.compare((org.jfree.data.time.SerialDate) spreadsheetDate58);
        int int60 = spreadsheetDate56.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate61 = spreadsheetDate34.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate56);
        java.lang.String str62 = spreadsheetDate56.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2 + "'", int60 == 2);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNull(str62);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries5.removeAgedItems((long) (byte) 100, false);
        java.lang.String str9 = timeSeries5.getDomainDescription();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod12, class13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate(regularTimePeriod18, (double) 1.0f);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        long long23 = year21.getMiddleMillisecond();
        int int24 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(12, year21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year21, (double) 0L);
        try {
            org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 100, year21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1562097599999L + "'", long23 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-2) + "'", int24 == (-2));
        org.junit.Assert.assertNull(timeSeriesDataItem27);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        long long7 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getLastMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        long long2 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(5, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "May" + "'", str2.equals("May"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, (int) '4');
        try {
            org.jfree.data.time.Year year3 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (52) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getFirstMillisecond(calendar1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560441203580L + "'", long2 == 1560441203580L);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long5 = year1.getFirstMillisecond();
        java.lang.String str6 = year1.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year1.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate14.setDescription("2-January-1900");
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod18, class19);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries20.addOrUpdate(regularTimePeriod24, (double) 1.0f);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod28, class29);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries30.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year33.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries30.addOrUpdate(regularTimePeriod34, (double) 1.0f);
        java.lang.Number number37 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries20.addOrUpdate(regularTimePeriod34, number37);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.previous();
        int int42 = timeSeriesDataItem38.compareTo((java.lang.Object) year40);
        boolean boolean43 = spreadsheetDate14.equals((java.lang.Object) year40);
        boolean boolean44 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int45 = spreadsheetDate14.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        int int7 = spreadsheetDate4.compare((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate14);
        java.lang.Class class16 = timeSeries15.getTimePeriodClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(3);
        int int23 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        int int28 = spreadsheetDate25.compare((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate20.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate30);
        java.lang.Class class32 = timeSeries31.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, class32);
        java.lang.Object obj34 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class16, class32);
        java.io.InputStream inputStream35 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("2019", class16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertNull(inputStream35);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int12 = day11.getMonth();
        java.lang.Object obj13 = null;
        boolean boolean14 = day11.equals(obj13);
        java.util.Date date15 = day11.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.util.Date date17 = year16.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate19.compare((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        int int29 = spreadsheetDate26.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        int int34 = spreadsheetDate31.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean35 = spreadsheetDate26.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean36 = spreadsheetDate21.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate24, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(3);
        int int39 = spreadsheetDate38.toSerial();
        org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate21.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.util.Date date41 = spreadsheetDate21.toDate();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date41);
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date41, timeZone44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date17, timeZone44);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date17);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(serialDate47);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod2, class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate(regularTimePeriod8, (double) 1.0f);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod12, class13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate(regularTimePeriod18, (double) 1.0f);
        java.lang.Number number21 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.addOrUpdate(regularTimePeriod18, number21);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.previous();
        int int26 = timeSeriesDataItem22.compareTo((java.lang.Object) year24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate28.setDescription("2-January-1900");
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.previous();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod32, class33);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year37.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.addOrUpdate(regularTimePeriod38, (double) 1.0f);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year41.previous();
        java.lang.Class class43 = null;
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod42, class43);
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries44.addOrUpdate(regularTimePeriod48, (double) 1.0f);
        java.lang.Number number51 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries34.addOrUpdate(regularTimePeriod48, number51);
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year54.previous();
        int int56 = timeSeriesDataItem52.compareTo((java.lang.Object) year54);
        boolean boolean57 = spreadsheetDate28.equals((java.lang.Object) year54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(3);
        int int62 = spreadsheetDate59.compare((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(3);
        int int69 = spreadsheetDate66.compare((org.jfree.data.time.SerialDate) spreadsheetDate68);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(3);
        int int74 = spreadsheetDate71.compare((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean75 = spreadsheetDate66.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean76 = spreadsheetDate61.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate64, (org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(3);
        int int79 = spreadsheetDate78.toSerial();
        org.jfree.data.time.SerialDate serialDate80 = spreadsheetDate61.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate78);
        int int81 = year54.compareTo((java.lang.Object) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate85 = new org.jfree.data.time.SpreadsheetDate(3);
        int int86 = spreadsheetDate83.compare((org.jfree.data.time.SerialDate) spreadsheetDate85);
        int int87 = spreadsheetDate83.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate88 = spreadsheetDate61.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate83);
        boolean boolean89 = timeSeriesDataItem22.equals((java.lang.Object) spreadsheetDate83);
        try {
            org.jfree.data.time.SerialDate serialDate90 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(12, (org.jfree.data.time.SerialDate) spreadsheetDate83);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertNotNull(timeSeriesDataItem52);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 3 + "'", int79 == 3);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 2 + "'", int87 == 2);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (double) 'a');
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond3.getMiddleMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond3.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(3);
        int int19 = spreadsheetDate16.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate21);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date8, class23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(3);
        int int31 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(3);
        int int36 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean37 = spreadsheetDate28.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate38);
        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
        java.io.InputStream inputStream41 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", class40);
        java.lang.Object obj42 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("First", class23, class40);
        java.lang.Object obj43 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.general.SeriesChangeEvent[source=-1]", class23);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNull(inputStream41);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNull(obj43);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str7 = timeSeries3.getDomainDescription();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(regularTimePeriod9, (double) (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate1.setDescription("2-January-1900");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate(regularTimePeriod11, (double) 1.0f);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod15, class16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate(regularTimePeriod21, (double) 1.0f);
        java.lang.Number number24 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries7.addOrUpdate(regularTimePeriod21, number24);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        int int29 = timeSeriesDataItem25.compareTo((java.lang.Object) year27);
        boolean boolean30 = spreadsheetDate1.equals((java.lang.Object) year27);
        long long31 = year27.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date13 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(3);
        int int25 = spreadsheetDate22.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate27);
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, class29);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date13, class29);
        timeSeries31.setDescription("");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(class29);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        long long4 = year2.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, year2);
        long long6 = year2.getFirstMillisecond();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(8, year2);
        boolean boolean9 = year2.equals((java.lang.Object) (-2));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
        long long25 = day23.getSerialIndex();
        long long26 = day23.getFirstMillisecond();
        int int27 = day23.getYear();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 3L + "'", long25 == 3L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208873600000L) + "'", long26 == (-2208873600000L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1900 + "'", int27 == 1900);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (-1));
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 'a');
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond8.getMiddleMillisecond(calendar11);
//        java.util.Date date13 = fixedMillisecond8.getStart();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(3);
//        int int19 = spreadsheetDate16.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(3);
//        int int24 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        boolean boolean25 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate16);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate26);
//        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date13, class28);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(3);
//        int int36 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
//        int int41 = spreadsheetDate38.compare((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        boolean boolean42 = spreadsheetDate33.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate33);
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate43);
//        java.lang.Class class45 = timeSeries44.getTimePeriodClass();
//        java.io.InputStream inputStream46 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", class45);
//        java.lang.Object obj47 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("First", class28, class45);
//        java.lang.ClassLoader classLoader48 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class28);
//        java.io.InputStream inputStream49 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Overwritten values from: 2018", class28);
//        java.net.URL uRL50 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Value", class28);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1, "2-January-1900", "org.jfree.data.time.TimePeriodFormatException: ThreadContext", class28);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNull(inputStream46);
//        org.junit.Assert.assertNull(obj47);
//        org.junit.Assert.assertNotNull(classLoader48);
//        org.junit.Assert.assertNull(inputStream49);
//        org.junit.Assert.assertNull(uRL50);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        int int17 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate21.toSerial();
        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int25 = spreadsheetDate21.getYYYY();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1900 + "'", int25 == 1900);
        org.junit.Assert.assertNotNull(serialDate26);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) 'a');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond4.getMiddleMillisecond(calendar7);
        java.util.Date date9 = fixedMillisecond4.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(3);
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate12.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate22);
        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date9, class24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(3);
        int int32 = spreadsheetDate29.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(3);
        int int37 = spreadsheetDate34.compare((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean38 = spreadsheetDate29.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate39);
        java.lang.Class class41 = timeSeries40.getTimePeriodClass();
        java.io.InputStream inputStream42 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", class41);
        java.lang.Object obj43 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("First", class24, class41);
        java.net.URL uRL44 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class24);
        java.io.InputStream inputStream45 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Tuesday", class24);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertNull(inputStream42);
        org.junit.Assert.assertNull(obj43);
        org.junit.Assert.assertNotNull(uRL44);
        org.junit.Assert.assertNull(inputStream45);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        int int12 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        int int17 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.lang.String str21 = serialDate20.getDescription();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "");
        boolean boolean3 = month0.equals((java.lang.Object) "");
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date13 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(3);
        int int23 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        int int28 = spreadsheetDate25.compare((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate20.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean32 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate20, (-460));
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        long long34 = month33.getFirstMillisecond();
        long long35 = month33.getSerialIndex();
        try {
            int int36 = spreadsheetDate20.compareTo((java.lang.Object) month33);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Month cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1559372400000L + "'", long34 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 24234L + "'", long35 == 24234L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (double) 'a');
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond3.getMiddleMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond3.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(3);
        int int19 = spreadsheetDate16.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate21);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date8, class23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(3);
        int int31 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(3);
        int int36 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean37 = spreadsheetDate28.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate38);
        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
        java.io.InputStream inputStream41 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", class40);
        java.lang.Object obj42 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("First", class23, class40);
        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize(class40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (double) 'a');
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond46.getMiddleMillisecond(calendar49);
        java.util.Date date51 = fixedMillisecond46.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(3);
        int int57 = spreadsheetDate54.compare((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(3);
        int int62 = spreadsheetDate59.compare((org.jfree.data.time.SerialDate) spreadsheetDate61);
        boolean boolean63 = spreadsheetDate54.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate64);
        java.lang.Class class66 = timeSeries65.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date51, class66);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(3);
        int int74 = spreadsheetDate71.compare((org.jfree.data.time.SerialDate) spreadsheetDate73);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(3);
        int int79 = spreadsheetDate76.compare((org.jfree.data.time.SerialDate) spreadsheetDate78);
        boolean boolean80 = spreadsheetDate71.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate78);
        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate71);
        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate81);
        java.lang.Class class83 = timeSeries82.getTimePeriodClass();
        java.io.InputStream inputStream84 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", class83);
        java.lang.Object obj85 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("First", class66, class83);
        java.lang.Object obj86 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("First", class40, class83);
        java.lang.ClassLoader classLoader87 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class40);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNull(inputStream41);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-1L) + "'", long50 == (-1L));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(class66);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(class83);
        org.junit.Assert.assertNull(inputStream84);
        org.junit.Assert.assertNull(obj85);
        org.junit.Assert.assertNull(obj86);
        org.junit.Assert.assertNotNull(classLoader87);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date23 = spreadsheetDate3.toDate();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date23);
        long long27 = year26.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year26.previous();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2177424000001L) + "'", long27 == (-2177424000001L));
        org.junit.Assert.assertNull(regularTimePeriod28);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(3);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(3);
        int int23 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.util.Date date26 = spreadsheetDate15.toDate();
        spreadsheetDate15.setDescription("June 2019");
        int int29 = spreadsheetDate15.getDayOfWeek();
        int int30 = spreadsheetDate15.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        int int35 = spreadsheetDate32.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        java.lang.String str36 = spreadsheetDate32.toString();
        int int37 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int38 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2-January-1900" + "'", str36.equals("2-January-1900"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod6, class7);
        timeSeries8.setMaximumItemCount((int) '4');
        timeSeries8.removeAgedItems(false);
        boolean boolean13 = timeSeries8.getNotify();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries8.addAndOrUpdate(timeSeries18);
        boolean boolean20 = timeSeries4.equals((java.lang.Object) timeSeries8);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod22, class23);
        timeSeries24.setMaximumItemCount((int) '4');
        timeSeries24.removeAgedItems(false);
        timeSeries24.setMaximumItemAge(0L);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
        long long34 = year32.getMiddleMillisecond();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 1, year32);
        org.jfree.data.time.Year year36 = month35.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long42 = fixedMillisecond41.getMiddleMillisecond();
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond41.getLastMillisecond(calendar43);
        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        boolean boolean46 = timeSeries4.equals((java.lang.Object) timeSeries39);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.previous();
        java.lang.Class class49 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod48, class49);
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries39.addAndOrUpdate(timeSeries50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year52.previous();
        java.util.Date date54 = year52.getEnd();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date54);
        long long56 = month55.getLastMillisecond();
        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) month55);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1562097599999L + "'", long34 == 1562097599999L);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1577865599999L + "'", long56 == 1577865599999L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        long long8 = timeSeries3.getMaximumItemAge();
        java.util.Collection collection9 = timeSeries3.getTimePeriods();
        java.util.Collection collection10 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(collection10);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        long long2 = month0.getSerialIndex();
        int int4 = month0.compareTo((java.lang.Object) 1.0d);
        int int6 = month0.compareTo((java.lang.Object) 11);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        timeSeries3.setMaximumItemAge(10L);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener10);
        try {
            timeSeries3.setMaximumItemAge((long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-457), (-459), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Overwritten values from: 2018");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int12 = day11.getMonth();
        java.lang.Object obj13 = null;
        boolean boolean14 = day11.equals(obj13);
        int int15 = day11.getYear();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day11.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod6, class7);
        timeSeries8.setMaximumItemCount((int) '4');
        timeSeries8.removeAgedItems(false);
        boolean boolean13 = timeSeries8.getNotify();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1559372400000L, "2019", "June 2019", class17);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries8.addAndOrUpdate(timeSeries18);
        boolean boolean20 = timeSeries4.equals((java.lang.Object) timeSeries8);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod22, class23);
        timeSeries24.setMaximumItemCount((int) '4');
        timeSeries24.removeAgedItems(false);
        timeSeries24.setMaximumItemAge(0L);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.previous();
        long long34 = year32.getMiddleMillisecond();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 1, year32);
        org.jfree.data.time.Year year36 = month35.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) month35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long42 = fixedMillisecond41.getMiddleMillisecond();
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond41.getLastMillisecond(calendar43);
        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
        boolean boolean46 = timeSeries4.equals((java.lang.Object) timeSeries39);
        boolean boolean47 = timeSeries39.isEmpty();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1562097599999L + "'", long34 == 1562097599999L);
        org.junit.Assert.assertNotNull(year36);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-1L) + "'", long42 == (-1L));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-1L) + "'", long44 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        long long4 = year2.getMiddleMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, year2);
        long long6 = year2.getFirstMillisecond();
        java.lang.String str7 = year2.toString();
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((-459), year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getMiddleMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, year1);
        long long5 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate1.setDescription("2-January-1900");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate(regularTimePeriod11, (double) 1.0f);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod15, class16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate(regularTimePeriod21, (double) 1.0f);
        java.lang.Number number24 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries7.addOrUpdate(regularTimePeriod21, number24);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        int int29 = timeSeriesDataItem25.compareTo((java.lang.Object) year27);
        boolean boolean30 = spreadsheetDate1.equals((java.lang.Object) year27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(3);
        int int35 = spreadsheetDate32.compare((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(3);
        int int42 = spreadsheetDate39.compare((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(3);
        int int47 = spreadsheetDate44.compare((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean48 = spreadsheetDate39.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean49 = spreadsheetDate34.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate37, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(3);
        int int52 = spreadsheetDate51.toSerial();
        org.jfree.data.time.SerialDate serialDate53 = spreadsheetDate34.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate51);
        int int54 = year27.compareTo((java.lang.Object) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(3);
        int int59 = spreadsheetDate56.compare((org.jfree.data.time.SerialDate) spreadsheetDate58);
        int int60 = spreadsheetDate56.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate61 = spreadsheetDate34.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year62.previous();
        long long64 = year62.getSerialIndex();
        boolean boolean65 = spreadsheetDate34.equals((java.lang.Object) long64);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2 + "'", int60 == 2);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 2019L + "'", long64 == 2019L);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, class10);
        timeSeries11.setMaximumItemCount((int) '4');
        timeSeries11.removeAgedItems(false);
        timeSeries11.setMaximumItemAge(10L);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.lang.Class class19 = timeSeries11.getTimePeriodClass();
        java.util.List list20 = timeSeries11.getItems();
        java.lang.Comparable comparable21 = timeSeries11.getKey();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(comparable21);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate(regularTimePeriod7, (double) 1.0f);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11, class12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate(regularTimePeriod17, (double) 1.0f);
        java.lang.Number number20 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate(regularTimePeriod17, number20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem21.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        spreadsheetDate8.setDescription("2-January-1900");
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod12, class13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate(regularTimePeriod18, (double) 1.0f);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod22, class23);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries24.addOrUpdate(regularTimePeriod28, (double) 1.0f);
        java.lang.Number number31 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries14.addOrUpdate(regularTimePeriod28, number31);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.previous();
        int int36 = timeSeriesDataItem32.compareTo((java.lang.Object) year34);
        boolean boolean37 = spreadsheetDate8.equals((java.lang.Object) year34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(3);
        int int43 = spreadsheetDate40.compare((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, (org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean45 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean46 = fixedMillisecond1.equals((java.lang.Object) boolean45);
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond1.getLastMillisecond(calendar47);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-1L) + "'", long48 == (-1L));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (double) 'a');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond5.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond5.getStart();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate18.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate13.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate23);
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date10, class25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(3);
        int int33 = spreadsheetDate30.compare((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(3);
        int int38 = spreadsheetDate35.compare((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean39 = spreadsheetDate30.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate40);
        java.lang.Class class42 = timeSeries41.getTimePeriodClass();
        java.io.InputStream inputStream43 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", class42);
        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("First", class25, class42);
        java.lang.ClassLoader classLoader45 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class25);
        java.io.InputStream inputStream46 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Overwritten values from: 2018", class25);
        java.net.URL uRL47 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Value", class25);
        java.lang.Class class48 = null;
        java.lang.Object obj49 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Value", class25, class48);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertNull(inputStream43);
        org.junit.Assert.assertNull(obj44);
        org.junit.Assert.assertNotNull(classLoader45);
        org.junit.Assert.assertNull(inputStream46);
        org.junit.Assert.assertNull(uRL47);
        org.junit.Assert.assertNull(obj49);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(3);
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(3);
        int int23 = spreadsheetDate22.toSerial();
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate22);
        int int26 = spreadsheetDate22.getYYYY();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths((int) (short) 10, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        try {
            org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) 'a', serialDate27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertNotNull(serialDate27);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount(100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(3);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int18 = day17.getMonth();
        java.lang.Object obj19 = null;
        boolean boolean20 = day17.equals(obj19);
        java.util.Date date21 = day17.getStart();
        int int22 = day17.getDayOfMonth();
        long long23 = day17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) 8);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2208873600000L) + "'", long23 == (-2208873600000L));
        org.junit.Assert.assertNull(timeSeriesDataItem25);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 'a');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
        timeSeries4.removeAgedItems(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries4.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod10, class11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.addPropertyChangeListener(propertyChangeListener13);
        java.util.List list15 = timeSeries12.getItems();
        timeSeries12.setMaximumItemCount((int) (short) 0);
        timeSeries12.setNotify(true);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        boolean boolean23 = year20.equals((java.lang.Object) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) year20);
        java.util.Collection collection25 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
        long long30 = fixedMillisecond27.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) 0.0f);
        try {
            timeSeries12.add(timeSeriesDataItem32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Following");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeriesDataItem2.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(3);
        int int25 = spreadsheetDate22.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(3);
        int int30 = spreadsheetDate27.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean31 = spreadsheetDate22.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        int int33 = spreadsheetDate22.getMonth();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(7, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean35 = spreadsheetDate8.isOnOrAfter(serialDate34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.previous();
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod37, class38);
        timeSeries39.setMaximumItemCount((int) '4');
        long long42 = timeSeries39.getMaximumItemAge();
        try {
            int int43 = spreadsheetDate8.compareTo((java.lang.Object) timeSeries39);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        timeSeries3.setMaximumItemCount((int) '4');
        java.lang.String str6 = timeSeries3.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(3);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate13);
        java.lang.Class class15 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, class15);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(class15);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        java.lang.String str4 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        java.lang.Object obj7 = timeSeries3.clone();
        timeSeries3.setNotify(false);
        timeSeries3.setRangeDescription("2-January-1900");
        java.util.Collection collection12 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        long long15 = year13.getSerialIndex();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year13, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem2);
        java.lang.Object obj4 = seriesChangeEvent3.getSource();
        java.lang.String str5 = seriesChangeEvent3.toString();
        java.lang.Object obj6 = seriesChangeEvent3.getSource();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(3);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.lang.String str16 = spreadsheetDate12.toString();
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int18 = spreadsheetDate1.getDayOfWeek();
        int int19 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(3);
        int int22 = spreadsheetDate21.getMonth();
        boolean boolean23 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.util.Date date24 = spreadsheetDate1.toDate();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2-January-1900" + "'", str16.equals("2-January-1900"));
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date23 = spreadsheetDate3.toDate();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date23);
        java.util.TimeZone timeZone27 = null;
        try {
            org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date23, timeZone27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0, (int) (short) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.getMonth();
        int int22 = spreadsheetDate20.getDayOfWeek();
        boolean boolean23 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date24 = spreadsheetDate20.toDate();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod1, class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str7 = timeSeries3.getDomainDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((int) (byte) 1, (-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(3);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(3);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(3);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(3);
        int int21 = spreadsheetDate20.toSerial();
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date23 = spreadsheetDate3.toDate();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date23);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date23);
    }
}

