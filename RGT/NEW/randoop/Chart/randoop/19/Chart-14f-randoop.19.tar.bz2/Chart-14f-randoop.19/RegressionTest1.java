import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        java.util.Date date5 = dateAxis1.getMaximumDate();
        dateAxis1.setUpperBound((double) 'a');
        double double8 = dateAxis1.getUpperMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        double double10 = categoryPlot9.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis12.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = dateAxis12.getTickMarkPosition();
        java.awt.Stroke stroke16 = dateAxis12.getAxisLineStroke();
        dateAxis12.setLowerBound((double) 8);
        java.awt.Shape shape19 = dateAxis12.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureRangeAxes();
        java.awt.Stroke stroke22 = xYPlot20.getDomainCrosshairStroke();
        java.awt.Font font23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot20.setNoDataMessageFont(font23);
        dateAxis12.setTickLabelFont(font23);
        org.jfree.data.Range range26 = categoryPlot9.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis12);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean33 = axisLocation31.equals((java.lang.Object) 128);
        categoryPlot29.setRangeAxisLocation((int) (byte) 10, axisLocation31);
        categoryPlot29.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation38 = categoryPlot29.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj42 = categoryAxis41.clone();
        java.awt.Font font44 = categoryAxis41.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot29.setDomainAxis((int) (short) 10, categoryAxis41);
        java.util.List list46 = categoryPlot9.getCategoriesForAxis(categoryAxis41);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = categoryPlot9.getInsets();
        boolean boolean48 = dateAxis1.hasListener((java.util.EventListener) categoryPlot9);
        dateAxis1.setPositiveArrowVisible(false);
        dateAxis1.setAutoTickUnitSelection(true);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot0.getRangeAxisLocation(4);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj25 = null;
        boolean boolean26 = plotOrientation24.equals(obj25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation23, plotOrientation24);
        java.lang.String str28 = axisLocation23.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str28.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean24 = axisLocation22.equals((java.lang.Object) 128);
        categoryPlot20.setRangeAxisLocation((int) (byte) 10, axisLocation22);
        categoryPlot20.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot20.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj33 = categoryAxis32.clone();
        java.awt.Font font35 = categoryAxis32.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot20.setDomainAxis((int) (short) 10, categoryAxis32);
        java.util.List list37 = categoryPlot0.getCategoriesForAxis(categoryAxis32);
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke41 = intervalMarker40.getStroke();
        categoryPlot0.setRangeGridlineStroke(stroke41);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis44.setLabelAngle(0.0d);
        java.util.Date date47 = dateAxis44.getMaximumDate();
        double double48 = dateAxis44.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = dateAxis44.getTickLabelInsets();
        org.jfree.chart.plot.Plot plot50 = dateAxis44.getPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = dateAxis44.getLabelInsets();
        categoryPlot0.setAxisOffset(rectangleInsets51);
        org.jfree.chart.axis.AxisLocation axisLocation54 = categoryPlot0.getDomainAxisLocation((int) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNull(plot50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(axisLocation54);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj8 = null;
        boolean boolean9 = plotOrientation7.equals(obj8);
        boolean boolean10 = dateAxis1.equals(obj8);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis14.setLabelAngle(0.0d);
        java.util.Date date17 = dateAxis14.getMaximumDate();
        java.util.Date date18 = dateAxis14.getMaximumDate();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis14.setRightArrow(shape19);
        dateAxis1.setRightArrow(shape19);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.setDomainCrosshairValue((double) 9);
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot4.getDataset();
        org.junit.Assert.assertNull(xYDataset7);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setAutoTickUnitSelection(false);
        dateAxis0.setLowerBound((double) (-2));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        java.awt.Paint paint8 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str10 = rectangleInsets9.toString();
        categoryPlot0.setInsets(rectangleInsets9, false);
        double double14 = rectangleInsets9.calculateBottomOutset((-8.0d));
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str10.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) (short) 100);
        double double3 = rectangleInsets0.getBottom();
        double double5 = rectangleInsets0.calculateBottomInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP;
        intervalMarker2.setLabelAnchor(rectangleAnchor5);
        java.awt.Font font7 = intervalMarker2.getLabelFont();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke11 = intervalMarker10.getStroke();
        java.awt.Paint paint12 = intervalMarker10.getOutlinePaint();
        java.lang.String str13 = intervalMarker10.getLabel();
        java.awt.Color color14 = java.awt.Color.orange;
        intervalMarker10.setPaint((java.awt.Paint) color14);
        float[] floatArray23 = new float[] { 8, (byte) 1, (short) 10, 10L };
        float[] floatArray24 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (short) 10, (int) ' ', floatArray23);
        float[] floatArray25 = color14.getRGBColorComponents(floatArray24);
        intervalMarker2.setOutlinePaint((java.awt.Paint) color14);
        int int27 = color14.getRed();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 255 + "'", int27 == 255);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        double double6 = dateAxis1.getLowerBound();
        dateAxis1.setUpperMargin(0.0d);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis10.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis10.getTickUnit();
        java.awt.Shape shape14 = dateAxis10.getLeftArrow();
        dateAxis1.setDownArrow(shape14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit13);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder17, jFreeChart18);
        categoryPlot0.setColumnRenderingOrder(sortOrder17);
        java.lang.String str21 = sortOrder17.toString();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "SortOrder.DESCENDING" + "'", str21.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke4 = intervalMarker3.getStroke();
        double double5 = intervalMarker3.getEndValue();
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker3);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        int int13 = xYPlot9.getRangeAxisIndex(valueAxis12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.configureRangeAxes();
        java.awt.Stroke stroke16 = xYPlot14.getDomainCrosshairStroke();
        xYPlot9.setRangeGridlineStroke(stroke16);
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke21 = intervalMarker20.getStroke();
        java.awt.Paint paint22 = intervalMarker20.getOutlinePaint();
        java.lang.String str23 = intervalMarker20.getLabel();
        java.awt.Color color24 = java.awt.Color.orange;
        intervalMarker20.setPaint((java.awt.Paint) color24);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot9.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker20, layer26);
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        xYPlot9.addChangeListener(plotChangeListener28);
        org.jfree.data.general.DatasetGroup datasetGroup30 = xYPlot9.getDatasetGroup();
        java.awt.Font font31 = xYPlot9.getNoDataMessageFont();
        java.awt.Paint paint32 = xYPlot9.getDomainGridlinePaint();
        java.awt.Stroke stroke33 = xYPlot9.getDomainZeroBaselineStroke();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        double double37 = categoryPlot36.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis39.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition42 = dateAxis39.getTickMarkPosition();
        java.awt.Stroke stroke43 = dateAxis39.getAxisLineStroke();
        dateAxis39.setLowerBound((double) 8);
        java.awt.Shape shape46 = dateAxis39.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        xYPlot47.configureRangeAxes();
        java.awt.Stroke stroke49 = xYPlot47.getDomainCrosshairStroke();
        java.awt.Font font50 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot47.setNoDataMessageFont(font50);
        dateAxis39.setTickLabelFont(font50);
        org.jfree.data.Range range53 = categoryPlot36.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis39);
        categoryPlot36.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation58 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean60 = axisLocation58.equals((java.lang.Object) 128);
        categoryPlot56.setRangeAxisLocation((int) (byte) 10, axisLocation58);
        categoryPlot56.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation65 = categoryPlot56.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis68 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj69 = categoryAxis68.clone();
        java.awt.Font font71 = categoryAxis68.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot56.setDomainAxis((int) (short) 10, categoryAxis68);
        java.util.List list73 = categoryPlot36.getCategoriesForAxis(categoryAxis68);
        xYPlot9.drawRangeTickBands(graphics2D34, rectangle2D35, list73);
        xYPlot0.drawRangeTickBands(graphics2D7, rectangle2D8, list73);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(datasetGroup30);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertNotNull(list73);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = xYPlot0.equals((java.lang.Object) dateTickUnit3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot0.getDomainAxisLocation(9);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot7.setDataset(xYDataset8);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        xYPlot11.setDomainCrosshairValue((double) '#');
        xYPlot11.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot11.setDomainAxisLocation(axisLocation17);
        xYPlot7.setRangeAxisLocation((int) 'a', axisLocation17, true);
        xYPlot0.setDomainAxisLocation(axisLocation17, true);
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 15, 100.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.configureRangeAxes();
        java.awt.Stroke stroke25 = xYPlot23.getDomainCrosshairStroke();
        boolean boolean26 = xYPlot23.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D27 = xYPlot23.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) 1.0f, plotRenderingInfo22, point2D27);
        double double29 = categoryPlot0.getAnchorValue();
        float float30 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        categoryPlot0.removeChangeListener(plotChangeListener31);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = xYPlot0.equals((java.lang.Object) dateTickUnit3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot0.getSeriesRenderingOrder();
        java.lang.Object obj6 = null;
        boolean boolean7 = seriesRenderingOrder5.equals(obj6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.configureRangeAxes();
        xYPlot8.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean12 = xYPlot8.equals((java.lang.Object) dateTickUnit11);
        xYPlot8.configureRangeAxes();
        java.awt.Stroke stroke14 = xYPlot8.getDomainZeroBaselineStroke();
        boolean boolean15 = seriesRenderingOrder5.equals((java.lang.Object) xYPlot8);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation17 = axisLocation16.getOpposite();
        xYPlot8.setRangeAxisLocation(axisLocation16, false);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) 10);
        double double4 = rectangleInsets0.trimWidth((double) (short) 0);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-8.0d) + "'", double4 == (-8.0d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis1.configure();
        java.awt.Stroke stroke3 = categoryAxis1.getAxisLineStroke();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis7.setLabelAngle(0.0d);
        java.util.Date date10 = dateAxis7.getMaximumDate();
        java.util.Date date11 = dateAxis7.getMaximumDate();
        java.awt.Shape shape12 = dateAxis7.getRightArrow();
        java.awt.Color color13 = java.awt.Color.magenta;
        dateAxis7.setTickLabelPaint((java.awt.Paint) color13);
        int int15 = color13.getRed();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) true, (java.awt.Paint) color13);
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot0.getDataRange(valueAxis8);
        double double10 = categoryPlot0.getAnchorValue();
        java.awt.Color color13 = java.awt.Color.getColor("PlotOrientation.HORIZONTAL", 10);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color13);
        org.jfree.chart.plot.Plot plot15 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(plot15);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomDomainAxes((double) 100, plotRenderingInfo10, point2D11);
        boolean boolean13 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        int int19 = xYPlot15.getRangeAxisIndex(valueAxis18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot15.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo22, point2D23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        xYPlot15.setRangeAxisLocation(5, axisLocation26, false);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        xYPlot29.configureRangeAxes();
        xYPlot29.setDomainCrosshairValue((double) '#');
        xYPlot29.setDomainCrosshairLockedOnData(false);
        xYPlot15.setParent((org.jfree.chart.plot.Plot) xYPlot29);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        xYPlot36.configureRangeAxes();
        xYPlot36.setDomainCrosshairValue((double) '#');
        xYPlot36.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation42 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot36.setDomainAxisLocation(axisLocation42);
        xYPlot29.setRangeAxisLocation(axisLocation42, true);
        try {
            xYPlot0.setRangeAxisLocation((-16777216), axisLocation42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(axisLocation42);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis7.setLabelAngle(0.0d);
        java.util.Date date10 = dateAxis7.getMaximumDate();
        double double11 = dateAxis7.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis7.getTickLabelInsets();
        dateAxis1.setTickLabelInsets(rectangleInsets12);
        dateAxis1.setVisible(true);
        float float16 = dateAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = xYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.configureRangeAxes();
        java.awt.Stroke stroke8 = xYPlot6.getDomainCrosshairStroke();
        xYPlot1.setRangeGridlineStroke(stroke8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot1.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot1.getDomainAxis(0);
        xYPlot1.setDomainCrosshairValue((double) 8, false);
        java.awt.Stroke stroke17 = xYPlot1.getDomainGridlineStroke();
        categoryPlot0.setDomainGridlineStroke(stroke17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot0.getDomainAxis((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot0.getDomainAxisLocation((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryPlot0.getInsets();
        java.lang.String str24 = rectangleInsets23.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str24.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis1.getTickLabelInsets();
        double double7 = rectangleInsets6.getLeft();
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj3 = categoryAxis2.clone();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis2.setMaximumCategoryLabelLines((int) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis8, categoryItemRenderer9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.configureRangeAxes();
        java.awt.Stroke stroke15 = xYPlot13.getDomainCrosshairStroke();
        boolean boolean16 = xYPlot13.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D17 = xYPlot13.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            categoryPlot10.draw(graphics2D11, rectangle2D12, point2D17, plotState18, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(point2D17);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.REVERSE");
        java.awt.Paint paint2 = categoryAxis1.getLabelPaint();
        categoryAxis1.setLowerMargin(10.0d);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.configureRangeAxes();
        xYPlot12.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean16 = xYPlot12.equals((java.lang.Object) dateTickUnit15);
        dateAxis11.setTickUnit(dateTickUnit15);
        boolean boolean18 = axisLocation9.equals((java.lang.Object) dateAxis11);
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation9, plotOrientation19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.axis.AxisState axisState22 = categoryAxis1.draw(graphics2D5, (double) 9, rectangle2D7, rectangle2D8, rectangleEdge20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color3 = java.awt.Color.GRAY;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color3);
        float[] floatArray5 = null;
        float[] floatArray6 = color3.getRGBComponents(floatArray5);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj3 = categoryAxis2.clone();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis2.setMaximumCategoryLabelLines((int) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis8, categoryItemRenderer9);
        categoryAxis2.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = categoryAxis2.getCategoryLabelPositions();
        categoryAxis2.setMaximumCategoryLabelLines((int) (short) 100);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.plot.Plot plot7 = dateAxis1.getPlot();
        dateAxis1.setInverted(false);
        dateAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(legendItemCollection20);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder17, jFreeChart18);
        categoryPlot0.setColumnRenderingOrder(sortOrder17);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        int int25 = xYPlot21.getRangeAxisIndex(valueAxis24);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.configureRangeAxes();
        java.awt.Stroke stroke28 = xYPlot26.getDomainCrosshairStroke();
        xYPlot21.setRangeGridlineStroke(stroke28);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke33 = intervalMarker32.getStroke();
        java.awt.Paint paint34 = intervalMarker32.getOutlinePaint();
        java.lang.String str35 = intervalMarker32.getLabel();
        java.awt.Color color36 = java.awt.Color.orange;
        intervalMarker32.setPaint((java.awt.Paint) color36);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker32, layer38);
        int int40 = xYPlot21.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier41 = xYPlot21.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker45 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke46 = intervalMarker45.getStroke();
        java.awt.Paint paint47 = intervalMarker45.getOutlinePaint();
        org.jfree.chart.util.Layer layer48 = null;
        boolean boolean50 = xYPlot21.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker45, layer48, false);
        xYPlot21.setBackgroundAlpha((float) (byte) 1);
        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot21.setNoDataMessagePaint((java.awt.Paint) color53);
        float float55 = xYPlot21.getBackgroundAlpha();
        java.awt.Graphics2D graphics2D56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        xYPlot21.drawBackgroundImage(graphics2D56, rectangle2D57);
        boolean boolean59 = sortOrder17.equals((java.lang.Object) rectangle2D57);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier41);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 1.0f + "'", float55 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        int int5 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace6);
        org.jfree.data.xy.XYDataset xYDataset9 = xYPlot0.getDataset(7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(xYDataset9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        java.util.Date date7 = dateAxis3.getMaximumDate();
        boolean boolean8 = day1.equals((java.lang.Object) dateAxis3);
        java.awt.Paint paint9 = dateAxis3.getLabelPaint();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setVerticalTickLabels(true);
        java.awt.Stroke stroke24 = dateAxis15.getTickMarkStroke();
        dateAxis15.setNegativeArrowVisible(true);
        java.awt.Paint paint27 = dateAxis15.getAxisLinePaint();
        double double28 = dateAxis15.getAutoRangeMinimumSize();
        java.lang.String str29 = dateAxis15.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.plot.Plot plot7 = dateAxis1.getPlot();
        dateAxis1.setInverted(false);
        dateAxis1.setVisible(false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19);
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.clearDomainMarkers((int) (byte) -1);
        boolean boolean25 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        int int31 = xYPlot27.getRangeAxisIndex(valueAxis30);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        xYPlot32.configureRangeAxes();
        java.awt.Stroke stroke34 = xYPlot32.getDomainCrosshairStroke();
        xYPlot27.setRangeGridlineStroke(stroke34);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke39 = intervalMarker38.getStroke();
        java.awt.Paint paint40 = intervalMarker38.getOutlinePaint();
        java.lang.String str41 = intervalMarker38.getLabel();
        java.awt.Color color42 = java.awt.Color.orange;
        intervalMarker38.setPaint((java.awt.Paint) color42);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot27.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker38, layer44);
        java.awt.Stroke stroke46 = null;
        xYPlot27.setOutlineStroke(stroke46);
        org.jfree.chart.axis.AxisSpace axisSpace48 = xYPlot27.getFixedDomainAxisSpace();
        java.awt.Paint paint49 = xYPlot27.getRangeTickBandPaint();
        org.jfree.chart.axis.AxisLocation axisLocation51 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot27.setDomainAxisLocation(3, axisLocation51);
        categoryPlot0.setRangeAxisLocation((int) (byte) 0, axisLocation51, true);
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertNull(axisSpace48);
        org.junit.Assert.assertNull(paint49);
        org.junit.Assert.assertNotNull(axisLocation51);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        int int5 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace6 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        xYPlot7.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot7.getIndexOf(xYItemRenderer10);
        xYPlot7.setRangeZeroBaselineVisible(false);
        boolean boolean14 = xYPlot7.isDomainZeroBaselineVisible();
        java.awt.Paint paint15 = xYPlot7.getOutlinePaint();
        xYPlot0.setDomainCrosshairPaint(paint15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 10.0d, (-8.0d), rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis2.setLabelAngle(0.0d);
        java.util.Date date5 = dateAxis2.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis7.setLabelAngle(0.0d);
        java.util.Date date10 = dateAxis7.getMaximumDate();
        dateAxis2.setMaximumDate(date10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis13.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis13.getTickMarkPosition();
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis13.setLeftArrow(shape17);
        java.awt.Stroke stroke19 = dateAxis13.getAxisLineStroke();
        dateAxis13.setFixedDimension(0.0d);
        boolean boolean23 = dateAxis13.isHiddenValue((long) 255);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis27.setLabelAngle(0.0d);
        java.util.Date date30 = dateAxis27.getMaximumDate();
        double double31 = dateAxis27.getUpperMargin();
        dateAxis27.setTickLabelsVisible(true);
        dateAxis27.setLabel("RectangleAnchor.TOP");
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis37.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = dateAxis37.getTickUnit();
        java.awt.Shape shape41 = dateAxis37.getLeftArrow();
        dateAxis27.setLeftArrow(shape41);
        boolean boolean43 = dateAxis27.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis45.setLabelAngle(0.0d);
        java.util.Date date48 = dateAxis45.getMaximumDate();
        double double49 = dateAxis45.getUpperMargin();
        dateAxis45.setTickLabelsVisible(true);
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis45.setMaximumDate(date52);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot();
        xYPlot56.configureRangeAxes();
        xYPlot56.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit59 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean60 = xYPlot56.equals((java.lang.Object) dateTickUnit59);
        dateAxis55.setTickUnit(dateTickUnit59);
        dateAxis45.setTickUnit(dateTickUnit59, false, false);
        java.util.Date date65 = dateAxis27.calculateHighestVisibleTickValue(dateTickUnit59);
        java.util.Date date66 = null;
        try {
            dateAxis2.setRange(date65, date66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.05d + "'", double49 == 0.05d);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(dateTickUnit59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date65);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getMiddleMillisecond();
//        int int3 = day1.getMonth();
//        long long4 = day1.getSerialIndex();
//        int int5 = day1.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day1.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day1.next();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke10 = intervalMarker9.getStroke();
        java.awt.Paint paint11 = intervalMarker9.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker9.setLabelTextAnchor(textAnchor12);
        java.awt.Stroke stroke14 = intervalMarker9.getStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke14);
        org.jfree.chart.LegendItemCollection legendItemCollection16 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis18.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition21 = dateAxis18.getTickMarkPosition();
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis18.setLeftArrow(shape22);
        org.jfree.chart.plot.Plot plot24 = dateAxis18.getPlot();
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis28.setLabelAngle(0.0d);
        java.util.Date date31 = dateAxis28.getMaximumDate();
        java.util.Date date32 = dateAxis28.getMaximumDate();
        boolean boolean33 = day26.equals((java.lang.Object) dateAxis28);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis35.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition38 = dateAxis35.getTickMarkPosition();
        java.awt.Shape shape39 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis35.setLeftArrow(shape39);
        java.awt.Stroke stroke41 = dateAxis35.getAxisLineStroke();
        dateAxis35.setFixedDimension(0.0d);
        boolean boolean45 = dateAxis35.isHiddenValue((long) 255);
        org.jfree.data.Range range46 = dateAxis35.getDefaultAutoRange();
        dateAxis28.setRange(range46);
        java.util.Date date48 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis51.setLabelAngle(0.0d);
        java.util.Date date54 = dateAxis51.getMaximumDate();
        java.util.Date date55 = dateAxis51.getMaximumDate();
        boolean boolean56 = day49.equals((java.lang.Object) dateAxis51);
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis58.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition61 = dateAxis58.getTickMarkPosition();
        java.awt.Shape shape62 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis58.setLeftArrow(shape62);
        java.awt.Stroke stroke64 = dateAxis58.getAxisLineStroke();
        dateAxis58.setFixedDimension(0.0d);
        boolean boolean68 = dateAxis58.isHiddenValue((long) 255);
        org.jfree.data.Range range69 = dateAxis58.getDefaultAutoRange();
        dateAxis51.setRange(range69);
        org.jfree.data.time.DateRange dateRange71 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis51.setDefaultAutoRange((org.jfree.data.Range) dateRange71);
        dateAxis28.setRangeWithMargins((org.jfree.data.Range) dateRange71);
        org.jfree.data.time.DateRange dateRange74 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis28.setDefaultAutoRange((org.jfree.data.Range) dateRange74);
        dateAxis18.setRange((org.jfree.data.Range) dateRange74, false, false);
        int int79 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(dateTickMarkPosition21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition61);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertNotNull(dateRange71);
        org.junit.Assert.assertNotNull(dateRange74);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot7.setDataset(xYDataset8);
        org.jfree.chart.plot.Plot plot10 = xYPlot7.getRootPlot();
        java.awt.geom.Point2D point2D11 = xYPlot7.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo6, point2D11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot0.getRangeAxis();
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Paint paint16 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis1.getTickLabelInsets();
        double double7 = rectangleInsets6.getRight();
        java.lang.String str8 = rectangleInsets6.toString();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str8.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean8 = xYPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str5 = chartChangeEventType4.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) false, jFreeChart3, chartChangeEventType4);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleInsets0, jFreeChart1, chartChangeEventType4);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.configureRangeAxes();
        xYPlot8.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke14 = intervalMarker13.getStroke();
        java.awt.Paint paint15 = intervalMarker13.getOutlinePaint();
        java.lang.String str16 = intervalMarker13.getLabel();
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean18 = xYPlot8.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13, layer17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = intervalMarker13.getLabelOffset();
        boolean boolean20 = chartChangeEventType4.equals((java.lang.Object) rectangleInsets19);
        double double22 = rectangleInsets19.calculateBottomInset((double) 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str5.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace21);
        boolean boolean23 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset25 = xYPlot0.getDataset(255);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(xYDataset25);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        double double6 = dateAxis1.getLowerBound();
        dateAxis1.setUpperMargin(0.0d);
        org.jfree.chart.axis.Timeline timeline9 = dateAxis1.getTimeline();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(timeline9);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setLabelToolTip("ChartChangeEventType.NEW_DATASET");
        dateAxis15.setVerticalTickLabels(true);
        java.awt.Shape shape26 = dateAxis15.getRightArrow();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setVerticalTickLabels(true);
        java.awt.Stroke stroke24 = dateAxis15.getTickMarkStroke();
        dateAxis15.setNegativeArrowVisible(true);
        java.awt.Shape shape27 = dateAxis15.getUpArrow();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxisForDataset(255);
        categoryPlot0.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis26.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = dateAxis26.getTickUnit();
        java.awt.Shape shape30 = dateAxis26.getLeftArrow();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray31 = new org.jfree.chart.axis.ValueAxis[] { dateAxis26 };
        categoryPlot0.setRangeAxes(valueAxisArray31);
        org.jfree.chart.axis.ValueAxis valueAxis34 = categoryPlot0.getRangeAxis(4);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(valueAxisArray31);
        org.junit.Assert.assertNull(valueAxis34);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setBackgroundAlpha(0.0f);
        java.awt.Paint paint5 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis6.setLabelAngle(0.0d);
        java.util.Date date9 = dateAxis6.getMaximumDate();
        dateAxis1.setMaximumDate(date9);
        dateAxis1.setTickMarkOutsideLength(0.0f);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
//        categoryMarker1.setKey((java.lang.Comparable) 10);
//        java.lang.Object obj4 = null;
//        boolean boolean5 = categoryMarker1.equals(obj4);
//        categoryMarker1.setDrawAsLine(false);
//        categoryMarker1.setDrawAsLine(false);
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        long long12 = day11.getMiddleMillisecond();
//        int int13 = day11.getYear();
//        int int14 = day11.getMonth();
//        categoryMarker1.setKey((java.lang.Comparable) int14);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560452399999L + "'", long12 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1.0f), jFreeChart1, chartChangeEventType2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        chartChangeEvent3.setChart(jFreeChart4);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit4);
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = numberAxis1.getStandardTickUnits();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis1.setNumberFormatOverride(numberFormat9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(tickUnitSource8);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19);
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean26 = axisLocation24.equals((java.lang.Object) 128);
        categoryPlot22.setRangeAxisLocation((int) (byte) 10, axisLocation24);
        categoryPlot22.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot22.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj35 = categoryAxis34.clone();
        java.awt.Font font37 = categoryAxis34.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot22.setDomainAxis((int) (short) 10, categoryAxis34);
        java.awt.Color color39 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass40 = color39.getClass();
        categoryPlot22.setRangeCrosshairPaint((java.awt.Paint) color39);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot22.getRangeAxisForDataset(255);
        categoryPlot22.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot22.getDomainAxisLocation(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = categoryPlot22.getOrientation();
        categoryPlot22.clearRangeMarkers();
        boolean boolean51 = sortOrder18.equals((java.lang.Object) categoryPlot22);
        boolean boolean52 = categoryPlot22.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(plotOrientation49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setBackgroundAlpha(0.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color10 = java.awt.Color.GRAY;
        intervalMarker9.setOutlinePaint((java.awt.Paint) color10);
        intervalMarker9.setStartValue((double) 8);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.configureRangeAxes();
        xYPlot14.setDomainCrosshairValue((double) '#');
        boolean boolean18 = intervalMarker9.equals((java.lang.Object) '#');
        java.awt.Stroke stroke19 = intervalMarker9.getStroke();
        xYPlot0.setRangeGridlineStroke(stroke19);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation21 = null;
        try {
            boolean boolean23 = xYPlot0.removeAnnotation(xYAnnotation21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis6.setLabelAngle(0.0d);
        java.util.Date date9 = dateAxis6.getMaximumDate();
        dateAxis1.setMaximumDate(date9);
        java.lang.String str11 = dateAxis1.getLabel();
        dateAxis1.centerRange((double) 12);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke6 = intervalMarker5.getStroke();
        java.awt.Paint paint7 = intervalMarker5.getOutlinePaint();
        java.lang.String str8 = intervalMarker5.getLabel();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer9);
        xYPlot0.clearDomainMarkers((int) (short) 10);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.REVERSE");
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        int int8 = xYPlot4.getRangeAxisIndex(valueAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.configureRangeAxes();
        java.awt.Stroke stroke11 = xYPlot9.getDomainCrosshairStroke();
        xYPlot4.setRangeGridlineStroke(stroke11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot4.getDomainAxis(0);
        xYPlot4.setDomainCrosshairValue((double) 8, false);
        java.awt.Stroke stroke20 = xYPlot4.getDomainGridlineStroke();
        categoryPlot3.setDomainGridlineStroke(stroke20);
        categoryAxis1.setTickMarkStroke(stroke20);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean5 = axisLocation3.equals((java.lang.Object) 128);
        categoryPlot1.setRangeAxisLocation((int) (byte) 10, axisLocation3);
        categoryPlot1.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.data.Range range10 = categoryPlot1.getDataRange(valueAxis9);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        xYPlot12.setDataset(xYDataset13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.configureRangeAxes();
        xYPlot16.setDomainCrosshairValue((double) '#');
        xYPlot16.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot16.setDomainAxisLocation(axisLocation22);
        xYPlot12.setRangeAxisLocation((int) 'a', axisLocation22, true);
        categoryPlot1.setRangeAxisLocation(0, axisLocation22);
        boolean boolean27 = lengthAdjustmentType0.equals((java.lang.Object) 0);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis29.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition32 = dateAxis29.getTickMarkPosition();
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis29.setLeftArrow(shape33);
        java.awt.Stroke stroke35 = dateAxis29.getAxisLineStroke();
        dateAxis29.setFixedDimension(0.0d);
        java.lang.String str38 = dateAxis29.getLabel();
        dateAxis29.centerRange((double) 1L);
        java.util.Date date41 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis44.setLabelAngle(0.0d);
        java.util.Date date47 = dateAxis44.getMaximumDate();
        java.util.Date date48 = dateAxis44.getMaximumDate();
        boolean boolean49 = day42.equals((java.lang.Object) dateAxis44);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis51.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition54 = dateAxis51.getTickMarkPosition();
        java.awt.Shape shape55 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis51.setLeftArrow(shape55);
        java.awt.Stroke stroke57 = dateAxis51.getAxisLineStroke();
        dateAxis51.setFixedDimension(0.0d);
        boolean boolean61 = dateAxis51.isHiddenValue((long) 255);
        org.jfree.data.Range range62 = dateAxis51.getDefaultAutoRange();
        dateAxis44.setRange(range62);
        java.util.Date date64 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis67.setLabelAngle(0.0d);
        java.util.Date date70 = dateAxis67.getMaximumDate();
        java.util.Date date71 = dateAxis67.getMaximumDate();
        boolean boolean72 = day65.equals((java.lang.Object) dateAxis67);
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis74.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition77 = dateAxis74.getTickMarkPosition();
        java.awt.Shape shape78 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis74.setLeftArrow(shape78);
        java.awt.Stroke stroke80 = dateAxis74.getAxisLineStroke();
        dateAxis74.setFixedDimension(0.0d);
        boolean boolean84 = dateAxis74.isHiddenValue((long) 255);
        org.jfree.data.Range range85 = dateAxis74.getDefaultAutoRange();
        dateAxis67.setRange(range85);
        org.jfree.data.time.DateRange dateRange87 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis67.setDefaultAutoRange((org.jfree.data.Range) dateRange87);
        dateAxis44.setRangeWithMargins((org.jfree.data.Range) dateRange87);
        org.jfree.data.time.DateRange dateRange90 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis44.setDefaultAutoRange((org.jfree.data.Range) dateRange90);
        dateAxis29.setRange((org.jfree.data.Range) dateRange90);
        boolean boolean93 = lengthAdjustmentType0.equals((java.lang.Object) dateRange90);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition54);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition77);
        org.junit.Assert.assertNotNull(shape78);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(range85);
        org.junit.Assert.assertNotNull(dateRange87);
        org.junit.Assert.assertNotNull(dateRange90);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        xYPlot0.setDataset(xYDataset1);
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureRangeAxes();
        xYPlot4.setDomainCrosshairValue((double) '#');
        xYPlot4.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot4.setDomainAxisLocation(axisLocation10);
        xYPlot0.setRangeAxisLocation((int) 'a', axisLocation10, true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot0.getDomainAxisLocation((int) (short) 0);
        xYPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = xYPlot0.equals((java.lang.Object) dateTickUnit3);
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) boolean4);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        dateAxis1.setTickLabelsVisible(true);
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMaximumDate(date8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        dateAxis1.setLabelPaint((java.awt.Paint) color10);
        java.lang.String str12 = color10.toString();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java.awt.Color[r=0,g=128,b=0]" + "'", str12.equals("java.awt.Color[r=0,g=128,b=0]"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace32, false);
        java.awt.Stroke stroke35 = xYPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke6 = intervalMarker5.getStroke();
        java.awt.Paint paint7 = intervalMarker5.getOutlinePaint();
        java.lang.String str8 = intervalMarker5.getLabel();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        int int12 = xYPlot0.getSeriesCount();
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis17.setLabelAngle(0.0d);
        java.util.Date date20 = dateAxis17.getMaximumDate();
        java.util.Date date21 = dateAxis17.getMaximumDate();
        boolean boolean22 = day15.equals((java.lang.Object) dateAxis17);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis24.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition27 = dateAxis24.getTickMarkPosition();
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis24.setLeftArrow(shape28);
        java.awt.Stroke stroke30 = dateAxis24.getAxisLineStroke();
        dateAxis24.setFixedDimension(0.0d);
        boolean boolean34 = dateAxis24.isHiddenValue((long) 255);
        org.jfree.data.Range range35 = dateAxis24.getDefaultAutoRange();
        dateAxis17.setRange(range35);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis38.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition41 = dateAxis38.getTickMarkPosition();
        java.awt.Shape shape42 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis38.setLeftArrow(shape42);
        dateAxis17.setRightArrow(shape42);
        xYPlot0.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) dateAxis17);
        dateAxis17.setAutoRangeMinimumSize((double) 2019);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(dateTickMarkPosition41);
        org.junit.Assert.assertNotNull(shape42);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        int int3 = color2.getGreen();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        double double5 = categoryPlot4.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis7.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis7.getTickMarkPosition();
        java.awt.Stroke stroke11 = dateAxis7.getAxisLineStroke();
        dateAxis7.setLowerBound((double) 8);
        java.awt.Shape shape14 = dateAxis7.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.configureRangeAxes();
        java.awt.Stroke stroke17 = xYPlot15.getDomainCrosshairStroke();
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot15.setNoDataMessageFont(font18);
        dateAxis7.setTickLabelFont(font18);
        org.jfree.data.Range range21 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition26 = dateAxis23.getTickMarkPosition();
        java.awt.Stroke stroke27 = dateAxis23.getAxisLineStroke();
        double double28 = dateAxis23.getLowerBound();
        java.awt.Font font29 = dateAxis23.getTickLabelFont();
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke34 = intervalMarker33.getStroke();
        java.awt.Paint paint35 = intervalMarker33.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker33.setLabelTextAnchor(textAnchor36);
        java.awt.Stroke stroke38 = intervalMarker33.getStroke();
        dateAxis23.setTickMarkStroke(stroke38);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        xYPlot40.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        int int44 = xYPlot40.getRangeAxisIndex(valueAxis43);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot40.setNoDataMessagePaint((java.awt.Paint) color45);
        java.awt.image.ColorModel colorModel47 = null;
        java.awt.Rectangle rectangle48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.awt.geom.AffineTransform affineTransform50 = null;
        java.awt.RenderingHints renderingHints51 = null;
        java.awt.PaintContext paintContext52 = color45.createContext(colorModel47, rectangle48, rectangle2D49, affineTransform50, renderingHints51);
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis54.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit57 = dateAxis54.getTickUnit();
        java.awt.Stroke stroke58 = dateAxis54.getAxisLineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((double) '4', (double) (byte) 100, (java.awt.Paint) color2, stroke38, (java.awt.Paint) color45, stroke58, 0.0f);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis62.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition65 = dateAxis62.getTickMarkPosition();
        java.awt.Stroke stroke66 = dateAxis62.getAxisLineStroke();
        double double67 = dateAxis62.getLowerBound();
        java.awt.Font font68 = dateAxis62.getTickLabelFont();
        intervalMarker60.setLabelFont(font68);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(dateTickMarkPosition26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(paintContext52);
        org.junit.Assert.assertNotNull(dateTickUnit57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(dateTickMarkPosition65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(font68);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        boolean boolean21 = xYPlot0.isRangeZoomable();
        java.awt.Image image22 = xYPlot0.getBackgroundImage();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CrosshairState crosshairState27 = null;
        boolean boolean28 = xYPlot0.render(graphics2D23, rectangle2D24, 0, plotRenderingInfo26, crosshairState27);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(image22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        long long2 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj3 = categoryAxis2.clone();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis2.setMaximumCategoryLabelLines((int) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot10.getDomainAxisEdge(0);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot10.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        try {
            int int15 = categoryPlot10.getDomainAxisIndex(categoryAxis14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP;
        intervalMarker2.setLabelAnchor(rectangleAnchor5);
        java.awt.Font font7 = intervalMarker2.getLabelFont();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke11 = intervalMarker10.getStroke();
        java.awt.Paint paint12 = intervalMarker10.getOutlinePaint();
        java.lang.String str13 = intervalMarker10.getLabel();
        java.awt.Color color14 = java.awt.Color.orange;
        intervalMarker10.setPaint((java.awt.Paint) color14);
        float[] floatArray23 = new float[] { 8, (byte) 1, (short) 10, 10L };
        float[] floatArray24 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (short) 10, (int) ' ', floatArray23);
        float[] floatArray25 = color14.getRGBColorComponents(floatArray24);
        intervalMarker2.setOutlinePaint((java.awt.Paint) color14);
        java.awt.Color color27 = java.awt.Color.pink;
        java.awt.Color color28 = java.awt.Color.green;
        int int29 = color28.getAlpha();
        float[] floatArray35 = new float[] { 4, 1.0f, 128, 5, 255 };
        float[] floatArray36 = color28.getRGBComponents(floatArray35);
        float[] floatArray37 = color27.getRGBComponents(floatArray35);
        float[] floatArray38 = color14.getComponents(floatArray37);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 255 + "'", int29 == 255);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean7 = xYPlot0.isDomainZeroBaselineVisible();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot0.getRenderer((int) '4');
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker14.setKey((java.lang.Comparable) 10);
        java.lang.Object obj17 = null;
        boolean boolean18 = categoryMarker14.equals(obj17);
        categoryMarker14.setDrawAsLine(false);
        org.jfree.chart.util.Layer layer21 = null;
        xYPlot0.addRangeMarker((-2), (org.jfree.chart.plot.Marker) categoryMarker14, layer21, true);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace24, true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        xYPlot0.drawAnnotations(graphics2D6, rectangle2D7, plotRenderingInfo8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = xYPlot0.getFixedLegendItems();
        try {
            java.awt.Paint paint12 = xYPlot0.getQuadrantPaint(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (12) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNull(legendItemCollection10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setBackgroundAlpha(0.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        xYPlot0.setDataset(xYDataset7);
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        double double12 = categoryPlot11.getRangeCrosshairValue();
        categoryPlot11.clearDomainMarkers();
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker16.setKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot11.addDomainMarker((-1), categoryMarker16, layer19, false);
        try {
            xYPlot0.addDomainMarker((int) 'a', marker10, layer19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(layer19);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        xYPlot0.setDataset(xYDataset1);
        java.lang.Object obj3 = xYPlot0.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = xYPlot0.getDomainAxisEdge(10);
        java.awt.Color color6 = java.awt.Color.GRAY;
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(color6);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getMiddleMillisecond();
//        int int3 = day1.getMonth();
//        long long4 = day1.getSerialIndex();
//        int int5 = day1.getDayOfMonth();
//        java.lang.Object obj6 = null;
//        int int7 = day1.compareTo(obj6);
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace21);
        boolean boolean23 = xYPlot0.isRangeGridlinesVisible();
        xYPlot0.setBackgroundImageAlignment(7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot0.setRangeAxisLocation(5, axisLocation11, false);
        xYPlot0.configureRangeAxes();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = xYPlot0.getDrawingSupplier();
        double double33 = xYPlot0.getDomainCrosshairValue();
        xYPlot0.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(drawingSupplier32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj8 = null;
        boolean boolean9 = plotOrientation7.equals(obj8);
        boolean boolean10 = dateAxis1.equals(obj8);
        dateAxis1.setAutoRange(false);
        java.util.Date date13 = dateAxis1.getMaximumDate();
        dateAxis1.setAxisLineVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis17.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = dateAxis17.getTickMarkPosition();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis17.setLeftArrow(shape21);
        java.awt.Stroke stroke23 = dateAxis17.getAxisLineStroke();
        dateAxis17.setFixedDimension(0.0d);
        java.lang.String str26 = dateAxis17.getLabel();
        dateAxis17.centerRange((double) 1L);
        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis32.setLabelAngle(0.0d);
        java.util.Date date35 = dateAxis32.getMaximumDate();
        java.util.Date date36 = dateAxis32.getMaximumDate();
        boolean boolean37 = day30.equals((java.lang.Object) dateAxis32);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis39.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition42 = dateAxis39.getTickMarkPosition();
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis39.setLeftArrow(shape43);
        java.awt.Stroke stroke45 = dateAxis39.getAxisLineStroke();
        dateAxis39.setFixedDimension(0.0d);
        boolean boolean49 = dateAxis39.isHiddenValue((long) 255);
        org.jfree.data.Range range50 = dateAxis39.getDefaultAutoRange();
        dateAxis32.setRange(range50);
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis55.setLabelAngle(0.0d);
        java.util.Date date58 = dateAxis55.getMaximumDate();
        java.util.Date date59 = dateAxis55.getMaximumDate();
        boolean boolean60 = day53.equals((java.lang.Object) dateAxis55);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis62.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition65 = dateAxis62.getTickMarkPosition();
        java.awt.Shape shape66 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis62.setLeftArrow(shape66);
        java.awt.Stroke stroke68 = dateAxis62.getAxisLineStroke();
        dateAxis62.setFixedDimension(0.0d);
        boolean boolean72 = dateAxis62.isHiddenValue((long) 255);
        org.jfree.data.Range range73 = dateAxis62.getDefaultAutoRange();
        dateAxis55.setRange(range73);
        org.jfree.data.time.DateRange dateRange75 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis55.setDefaultAutoRange((org.jfree.data.Range) dateRange75);
        dateAxis32.setRangeWithMargins((org.jfree.data.Range) dateRange75);
        org.jfree.data.time.DateRange dateRange78 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis32.setDefaultAutoRange((org.jfree.data.Range) dateRange78);
        dateAxis17.setRange((org.jfree.data.Range) dateRange78);
        dateAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange78);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(dateTickMarkPosition20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition65);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNotNull(dateRange75);
        org.junit.Assert.assertNotNull(dateRange78);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str5 = chartChangeEventType4.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) false, jFreeChart3, chartChangeEventType4);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleInsets0, jFreeChart1, chartChangeEventType4);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.configureRangeAxes();
        xYPlot8.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke14 = intervalMarker13.getStroke();
        java.awt.Paint paint15 = intervalMarker13.getOutlinePaint();
        java.lang.String str16 = intervalMarker13.getLabel();
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean18 = xYPlot8.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13, layer17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = intervalMarker13.getLabelOffset();
        boolean boolean20 = chartChangeEventType4.equals((java.lang.Object) rectangleInsets19);
        double double22 = rectangleInsets19.calculateRightInset((double) 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str5.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        java.util.Date date7 = dateAxis3.getMaximumDate();
        boolean boolean8 = day1.equals((java.lang.Object) dateAxis3);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis10.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition13 = dateAxis10.getTickMarkPosition();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis10.setLeftArrow(shape14);
        java.awt.Stroke stroke16 = dateAxis10.getAxisLineStroke();
        dateAxis10.setFixedDimension(0.0d);
        boolean boolean20 = dateAxis10.isHiddenValue((long) 255);
        org.jfree.data.Range range21 = dateAxis10.getDefaultAutoRange();
        dateAxis3.setRange(range21);
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis3.setTickUnit(dateTickUnit23, true, true);
        org.jfree.chart.util.ObjectList objectList28 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        java.lang.Object obj30 = objectList28.get(3);
        boolean boolean31 = dateAxis3.equals((java.lang.Object) 3);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        xYPlot0.setDomainAxis(valueAxis5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        xYPlot0.datasetChanged(datasetChangeEvent7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis2.setLabelAngle(0.0d);
        java.util.Date date5 = dateAxis2.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis7.setLabelAngle(0.0d);
        java.util.Date date10 = dateAxis7.getMaximumDate();
        dateAxis2.setMaximumDate(date10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis13.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis13.getTickMarkPosition();
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis13.setLeftArrow(shape17);
        java.awt.Stroke stroke19 = dateAxis13.getAxisLineStroke();
        dateAxis13.setFixedDimension(0.0d);
        boolean boolean23 = dateAxis13.isHiddenValue((long) 255);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        xYPlot25.drawBackgroundImage(graphics2D26, rectangle2D27);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        int int5 = xYPlot0.getRangeAxisCount();
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis9.setLabelAngle(0.0d);
        java.util.Date date12 = dateAxis9.getMaximumDate();
        java.util.Date date13 = dateAxis9.getMaximumDate();
        boolean boolean14 = day7.equals((java.lang.Object) dateAxis9);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis16.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition19 = dateAxis16.getTickMarkPosition();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis16.setLeftArrow(shape20);
        java.awt.Stroke stroke22 = dateAxis16.getAxisLineStroke();
        dateAxis16.setFixedDimension(0.0d);
        boolean boolean26 = dateAxis16.isHiddenValue((long) 255);
        org.jfree.data.Range range27 = dateAxis16.getDefaultAutoRange();
        dateAxis9.setRange(range27);
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis9.setDefaultAutoRange((org.jfree.data.Range) dateRange29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = dateAxis32.getTickUnit();
        java.util.Date date34 = dateAxis9.calculateLowestVisibleTickValue(dateTickUnit33);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker5.setKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addDomainMarker((-1), categoryMarker5, layer8, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(layer8);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot2.getRangeAxisIndex(valueAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        java.awt.Stroke stroke9 = xYPlot7.getDomainCrosshairStroke();
        xYPlot2.setRangeGridlineStroke(stroke9);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke14 = intervalMarker13.getStroke();
        java.awt.Paint paint15 = intervalMarker13.getOutlinePaint();
        java.lang.String str16 = intervalMarker13.getLabel();
        java.awt.Color color17 = java.awt.Color.orange;
        intervalMarker13.setPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot2.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13, layer19);
        int int21 = xYPlot2.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = xYPlot2.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke27 = intervalMarker26.getStroke();
        java.awt.Paint paint28 = intervalMarker26.getOutlinePaint();
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean31 = xYPlot2.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker26, layer29, false);
        xYPlot2.setBackgroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = xYPlot2.getDrawingSupplier();
        int int35 = objectList1.indexOf((java.lang.Object) xYPlot2);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot2.getRangeAxisLocation();
        java.awt.Paint paint37 = xYPlot2.getNoDataMessagePaint();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis39.setLabelAngle(0.0d);
        java.util.Date date42 = dateAxis39.getMaximumDate();
        double double43 = dateAxis39.getUpperMargin();
        dateAxis39.setTickLabelsVisible(true);
        dateAxis39.setAutoRangeMinimumSize((double) '4');
        java.text.DateFormat dateFormat48 = dateAxis39.getDateFormatOverride();
        int int49 = xYPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis39);
        double double50 = dateAxis39.getLabelAngle();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(drawingSupplier34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertNull(dateFormat48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        long long3 = day2.getMiddleMillisecond();
//        int int4 = day2.getMonth();
//        boolean boolean5 = unitType0.equals((java.lang.Object) int4);
//        org.junit.Assert.assertNotNull(unitType0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.REVERSE");
        java.lang.Object obj2 = categoryAxis1.clone();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 2);
        java.lang.Comparable comparable5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis7.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis7.getTickMarkPosition();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis7.setLeftArrow(shape11);
        java.awt.Stroke stroke13 = dateAxis7.getAxisLineStroke();
        dateAxis7.setFixedDimension(0.0d);
        java.lang.String str16 = dateAxis7.getLabel();
        dateAxis7.centerRange((double) 1L);
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis22.setLabelAngle(0.0d);
        java.util.Date date25 = dateAxis22.getMaximumDate();
        java.util.Date date26 = dateAxis22.getMaximumDate();
        boolean boolean27 = day20.equals((java.lang.Object) dateAxis22);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis29.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition32 = dateAxis29.getTickMarkPosition();
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis29.setLeftArrow(shape33);
        java.awt.Stroke stroke35 = dateAxis29.getAxisLineStroke();
        dateAxis29.setFixedDimension(0.0d);
        boolean boolean39 = dateAxis29.isHiddenValue((long) 255);
        org.jfree.data.Range range40 = dateAxis29.getDefaultAutoRange();
        dateAxis22.setRange(range40);
        java.util.Date date42 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis45.setLabelAngle(0.0d);
        java.util.Date date48 = dateAxis45.getMaximumDate();
        java.util.Date date49 = dateAxis45.getMaximumDate();
        boolean boolean50 = day43.equals((java.lang.Object) dateAxis45);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis52.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition55 = dateAxis52.getTickMarkPosition();
        java.awt.Shape shape56 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis52.setLeftArrow(shape56);
        java.awt.Stroke stroke58 = dateAxis52.getAxisLineStroke();
        dateAxis52.setFixedDimension(0.0d);
        boolean boolean62 = dateAxis52.isHiddenValue((long) 255);
        org.jfree.data.Range range63 = dateAxis52.getDefaultAutoRange();
        dateAxis45.setRange(range63);
        org.jfree.data.time.DateRange dateRange65 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis45.setDefaultAutoRange((org.jfree.data.Range) dateRange65);
        dateAxis22.setRangeWithMargins((org.jfree.data.Range) dateRange65);
        org.jfree.data.time.DateRange dateRange68 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange68);
        dateAxis7.setRange((org.jfree.data.Range) dateRange68);
        java.awt.Font font71 = dateAxis7.getTickLabelFont();
        try {
            categoryAxis1.setTickLabelFont(comparable5, font71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition55);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(dateRange65);
        org.junit.Assert.assertNotNull(dateRange68);
        org.junit.Assert.assertNotNull(font71);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19);
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color28 = java.awt.Color.green;
        categoryPlot27.setDomainGridlinePaint((java.awt.Paint) color28);
        categoryPlot27.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        xYPlot34.setDataset(xYDataset35);
        org.jfree.chart.plot.Plot plot37 = xYPlot34.getRootPlot();
        java.awt.geom.Point2D point2D38 = xYPlot34.getQuadrantOrigin();
        categoryPlot27.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo33, point2D38);
        categoryPlot0.zoomRangeAxes((double) (short) -1, plotRenderingInfo26, point2D38, false);
        java.lang.String str42 = categoryPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(plot37);
        org.junit.Assert.assertNotNull(point2D38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Category Plot" + "'", str42.equals("Category Plot"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot0.getDataRange(valueAxis8);
        double double10 = categoryPlot0.getAnchorValue();
        java.awt.Color color13 = java.awt.Color.getColor("PlotOrientation.HORIZONTAL", 10);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot0.setDataset(categoryDataset15);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        java.text.NumberFormat numberFormat3 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit4);
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit8, true, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(numberTickUnit8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot7.setDataset(xYDataset8);
        org.jfree.chart.plot.Plot plot10 = xYPlot7.getRootPlot();
        java.awt.geom.Point2D point2D11 = xYPlot7.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo6, point2D11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj15 = null;
        boolean boolean16 = plotOrientation14.equals(obj15);
        categoryPlot0.setOrientation(plotOrientation14);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        java.awt.Paint paint8 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str10 = rectangleInsets9.toString();
        categoryPlot0.setInsets(rectangleInsets9, false);
        org.jfree.chart.plot.Plot plot13 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str10.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(plot13);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke33 = intervalMarker32.getStroke();
        java.awt.Paint paint34 = intervalMarker32.getOutlinePaint();
        java.lang.String str35 = intervalMarker32.getLabel();
        java.awt.Color color36 = java.awt.Color.orange;
        intervalMarker32.setPaint((java.awt.Paint) color36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = intervalMarker32.getLabelAnchor();
        org.jfree.chart.util.Layer layer39 = null;
        xYPlot0.addRangeMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker32, layer39);
        org.jfree.chart.text.TextAnchor textAnchor41 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        intervalMarker32.setLabelTextAnchor(textAnchor41);
        double double43 = intervalMarker32.getEndValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = numberAxis1.getTickUnit();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(numberTickUnit3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        java.awt.Stroke stroke7 = dateAxis1.getAxisLineStroke();
        dateAxis1.setFixedDimension(0.0d);
        boolean boolean11 = dateAxis1.isHiddenValue((long) 255);
        org.jfree.data.Range range12 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setUpperBound(3.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis1.configure();
        java.awt.Stroke stroke3 = categoryAxis1.getAxisLineStroke();
        double double4 = categoryAxis1.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        xYPlot7.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean11 = xYPlot7.equals((java.lang.Object) dateTickUnit10);
        dateAxis6.setTickUnit(dateTickUnit10);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) dateTickUnit10, "RectangleAnchor.TOP");
        java.lang.Object obj15 = categoryAxis1.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.REVERSE");
        java.awt.Paint paint18 = categoryAxis17.getLabelPaint();
        categoryAxis1.setTickMarkPaint(paint18);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot0.setRangeAxisLocation(5, axisLocation11, false);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.configureRangeAxes();
        xYPlot14.setDomainCrosshairValue((double) '#');
        xYPlot14.setDomainCrosshairLockedOnData(false);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot14);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.configureRangeAxes();
        xYPlot21.setDomainCrosshairValue((double) '#');
        xYPlot21.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot21.setDomainAxisLocation(axisLocation27);
        xYPlot14.setRangeAxisLocation(axisLocation27, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        xYPlot14.setRenderer((int) '4', xYItemRenderer32, true);
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        xYPlot14.addChangeListener(plotChangeListener35);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot14.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot14.getDomainAxis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNull(valueAxis38);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = xYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.configureRangeAxes();
        java.awt.Stroke stroke8 = xYPlot6.getDomainCrosshairStroke();
        xYPlot1.setRangeGridlineStroke(stroke8);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke13 = intervalMarker12.getStroke();
        java.awt.Paint paint14 = intervalMarker12.getOutlinePaint();
        java.lang.String str15 = intervalMarker12.getLabel();
        java.awt.Color color16 = java.awt.Color.orange;
        intervalMarker12.setPaint((java.awt.Paint) color16);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot1.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker12, layer18);
        java.awt.Stroke stroke20 = null;
        xYPlot1.setOutlineStroke(stroke20);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis24.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = dateAxis24.getTickUnit();
        xYPlot1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis24, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke34 = intervalMarker33.getStroke();
        java.awt.Paint paint35 = intervalMarker33.getOutlinePaint();
        java.lang.String str36 = intervalMarker33.getLabel();
        java.awt.Color color37 = java.awt.Color.orange;
        intervalMarker33.setPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = intervalMarker33.getLabelAnchor();
        org.jfree.chart.util.Layer layer40 = null;
        xYPlot1.addRangeMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker33, layer40);
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        intervalMarker33.setLabelTextAnchor(textAnchor42);
        boolean boolean44 = color0.equals((java.lang.Object) textAnchor42);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        categoryPlot0.clearRangeMarkers();
        double double4 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot0.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = categoryPlot0.getRangeMarkers(layer7);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        java.util.Date date7 = dateAxis3.getMaximumDate();
        boolean boolean8 = day1.equals((java.lang.Object) dateAxis3);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis10.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition13 = dateAxis10.getTickMarkPosition();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis10.setLeftArrow(shape14);
        java.awt.Stroke stroke16 = dateAxis10.getAxisLineStroke();
        dateAxis10.setFixedDimension(0.0d);
        boolean boolean20 = dateAxis10.isHiddenValue((long) 255);
        org.jfree.data.Range range21 = dateAxis10.getDefaultAutoRange();
        dateAxis3.setRange(range21);
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis3.setDefaultAutoRange((org.jfree.data.Range) dateRange23);
        double double25 = dateAxis3.getFixedAutoRange();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition26 = dateAxis3.getTickMarkPosition();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(dateRange23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition26);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        int int8 = xYPlot4.getRangeAxisIndex(valueAxis7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color9);
        java.awt.Paint paint11 = xYPlot4.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis13.setLabelAngle(0.0d);
        java.util.Date date16 = dateAxis13.getMaximumDate();
        dateAxis13.setAxisLineVisible(true);
        xYPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis22.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition25 = dateAxis22.getTickMarkPosition();
        java.awt.Stroke stroke26 = dateAxis22.getAxisLineStroke();
        dateAxis22.setLowerBound((double) 8);
        java.awt.Shape shape29 = dateAxis22.getLeftArrow();
        xYPlot4.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis22, false);
        org.jfree.data.Range range32 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(dateTickMarkPosition25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNull(range32);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3, false);
        java.lang.String str6 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = xYPlot7.getRangeAxisIndex(valueAxis10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.configureRangeAxes();
        java.awt.Stroke stroke14 = xYPlot12.getDomainCrosshairStroke();
        xYPlot7.setRangeGridlineStroke(stroke14);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke19 = intervalMarker18.getStroke();
        java.awt.Paint paint20 = intervalMarker18.getOutlinePaint();
        java.lang.String str21 = intervalMarker18.getLabel();
        java.awt.Color color22 = java.awt.Color.orange;
        intervalMarker18.setPaint((java.awt.Paint) color22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker18, layer24);
        int int26 = xYPlot7.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = xYPlot7.getDrawingSupplier();
        java.awt.Paint paint28 = xYPlot7.getRangeGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot7.setDatasetRenderingOrder(datasetRenderingOrder29);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(markerAxisBand5);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke10 = intervalMarker9.getStroke();
        java.awt.Paint paint11 = intervalMarker9.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker9.setLabelTextAnchor(textAnchor12);
        java.awt.Stroke stroke14 = intervalMarker9.getStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot0.setRenderer(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        int int11 = xYPlot0.getRangeAxisCount();
        java.awt.Paint paint12 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        int int5 = xYPlot0.getRangeAxisCount();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        xYPlot0.drawAnnotations(graphics2D6, rectangle2D7, plotRenderingInfo8);
        xYPlot0.clearRangeMarkers((-2));
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation13 = axisLocation12.getOpposite();
        xYPlot0.setRangeAxisLocation(axisLocation13);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        xYPlot1.setDataset(xYDataset2);
        org.jfree.chart.plot.Plot plot4 = xYPlot1.getRootPlot();
        boolean boolean5 = lengthAdjustmentType0.equals((java.lang.Object) plot4);
        java.lang.String str6 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "CONTRACT" + "'", str6.equals("CONTRACT"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj3 = categoryAxis2.clone();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis2.setMaximumCategoryLabelLines((int) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis8, categoryItemRenderer9);
        categoryAxis2.configure();
        categoryAxis2.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Color color1 = java.awt.Color.ORANGE;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        double double3 = categoryPlot2.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis5.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = dateAxis5.getTickMarkPosition();
        java.awt.Stroke stroke9 = dateAxis5.getAxisLineStroke();
        dateAxis5.setLowerBound((double) 8);
        java.awt.Shape shape12 = dateAxis5.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.configureRangeAxes();
        java.awt.Stroke stroke15 = xYPlot13.getDomainCrosshairStroke();
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot13.setNoDataMessageFont(font16);
        dateAxis5.setTickLabelFont(font16);
        org.jfree.data.Range range19 = categoryPlot2.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis21.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition24 = dateAxis21.getTickMarkPosition();
        java.awt.Stroke stroke25 = dateAxis21.getAxisLineStroke();
        double double26 = dateAxis21.getLowerBound();
        java.awt.Font font27 = dateAxis21.getTickLabelFont();
        categoryPlot2.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke32 = intervalMarker31.getStroke();
        java.awt.Paint paint33 = intervalMarker31.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor34 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker31.setLabelTextAnchor(textAnchor34);
        java.awt.Stroke stroke36 = intervalMarker31.getStroke();
        dateAxis21.setTickMarkStroke(stroke36);
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        xYPlot38.configureRangeAxes();
        xYPlot38.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit41 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean42 = xYPlot38.equals((java.lang.Object) dateTickUnit41);
        xYPlot38.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke48 = intervalMarker47.getStroke();
        java.awt.Paint paint49 = intervalMarker47.getOutlinePaint();
        xYPlot38.setDomainTickBandPaint(paint49);
        org.jfree.chart.plot.IntervalMarker intervalMarker53 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke54 = intervalMarker53.getStroke();
        java.awt.Paint paint55 = intervalMarker53.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor56 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker53.setLabelTextAnchor(textAnchor56);
        java.awt.Stroke stroke58 = intervalMarker53.getStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker(2.0d, (java.awt.Paint) color1, stroke36, paint49, stroke58, (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(dateTickMarkPosition24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(textAnchor34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(dateTickUnit41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(textAnchor56);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis9.setLabelAngle(0.0d);
        java.util.Date date12 = dateAxis9.getMaximumDate();
        dateAxis9.setAxisLineVisible(true);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        boolean boolean16 = xYPlot0.isSubplot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        try {
            xYPlot0.zoomRangeAxes((double) 100.0f, 8.0d, plotRenderingInfo19, point2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (8.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color16 = java.awt.Color.GRAY;
        intervalMarker15.setOutlinePaint((java.awt.Paint) color16);
        intervalMarker15.setStartValue((double) 8);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureRangeAxes();
        xYPlot20.setDomainCrosshairValue((double) '#');
        boolean boolean24 = intervalMarker15.equals((java.lang.Object) '#');
        java.awt.Stroke stroke25 = intervalMarker15.getStroke();
        xYPlot0.setOutlineStroke(stroke25);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot0.addChangeListener(plotChangeListener20);
        java.awt.Stroke stroke22 = xYPlot0.getRangeZeroBaselineStroke();
        xYPlot0.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setLabelToolTip("ChartChangeEventType.NEW_DATASET");
        java.awt.Color color24 = java.awt.Color.MAGENTA;
        dateAxis15.setTickMarkPaint((java.awt.Paint) color24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis27.setLabelAngle(0.0d);
        java.util.Date date30 = dateAxis27.getMaximumDate();
        double double31 = dateAxis27.getUpperMargin();
        java.util.Date date32 = dateAxis27.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis34.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition37 = dateAxis34.getTickMarkPosition();
        java.awt.Shape shape38 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis34.setLeftArrow(shape38);
        boolean boolean40 = dateAxis34.isVerticalTickLabels();
        java.util.Date date41 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis44.setLabelAngle(0.0d);
        java.util.Date date47 = dateAxis44.getMaximumDate();
        java.util.Date date48 = dateAxis44.getMaximumDate();
        boolean boolean49 = day42.equals((java.lang.Object) dateAxis44);
        java.util.Date date50 = day42.getStart();
        org.jfree.chart.plot.CategoryMarker categoryMarker51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date50);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis53.setLabelAngle(0.0d);
        java.util.Date date56 = dateAxis53.getMaximumDate();
        double double57 = dateAxis53.getUpperMargin();
        dateAxis53.setTickLabelsVisible(true);
        java.util.Date date60 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis53.setMaximumDate(date60);
        dateAxis34.setRange(date50, date60);
        dateAxis15.setRange(date32, date60);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(dateTickMarkPosition37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.05d + "'", double57 == 0.05d);
        org.junit.Assert.assertNotNull(date60);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis4.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis4.getTickMarkPosition();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setLeftArrow(shape8);
        boolean boolean10 = dateAxis4.isVerticalTickLabels();
        int int11 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke15 = intervalMarker14.getStroke();
        intervalMarker14.setLabel("hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        double double19 = categoryPlot18.getRangeCrosshairValue();
        categoryPlot18.clearDomainMarkers();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker23.setKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot18.addDomainMarker((-1), categoryMarker23, layer26, false);
        boolean boolean29 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker14, layer26);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis31.setLabelAngle(0.0d);
        boolean boolean34 = layer26.equals((java.lang.Object) dateAxis31);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        boolean boolean5 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) ' ', dataset1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        xYPlot0.removeChangeListener(plotChangeListener33);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        int int36 = xYPlot0.indexOf(xYDataset35);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = null;
        xYPlot0.rendererChanged(rendererChangeEvent37);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(drawingSupplier32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis9.setLabelAngle(0.0d);
        java.util.Date date12 = dateAxis9.getMaximumDate();
        dateAxis9.setAxisLineVisible(true);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        boolean boolean16 = xYPlot0.isSubplot();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray17 = null;
        try {
            xYPlot0.setRenderers(xYItemRendererArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(5);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj3 = categoryAxis2.clone();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis2.setMaximumCategoryLabelLines((int) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis8, categoryItemRenderer9);
        categoryAxis2.configure();
        categoryAxis2.setMaximumCategoryLabelLines(64);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(1, axisLocation11, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryPlot0.addDomainMarker(categoryMarker15);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        categoryPlot0.clearRangeMarkers();
        java.util.List list4 = categoryPlot0.getCategories();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(list4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19);
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.clearDomainMarkers((int) (byte) -1);
        java.lang.Object obj25 = categoryPlot0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        int int11 = xYPlot0.getRangeAxisCount();
        double double12 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        boolean boolean10 = xYPlot0.isSubplot();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot2.getRangeAxisIndex(valueAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        java.awt.Stroke stroke9 = xYPlot7.getDomainCrosshairStroke();
        xYPlot2.setRangeGridlineStroke(stroke9);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke14 = intervalMarker13.getStroke();
        java.awt.Paint paint15 = intervalMarker13.getOutlinePaint();
        java.lang.String str16 = intervalMarker13.getLabel();
        java.awt.Color color17 = java.awt.Color.orange;
        intervalMarker13.setPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot2.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13, layer19);
        int int21 = xYPlot2.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = xYPlot2.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke27 = intervalMarker26.getStroke();
        java.awt.Paint paint28 = intervalMarker26.getOutlinePaint();
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean31 = xYPlot2.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker26, layer29, false);
        xYPlot2.setBackgroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = xYPlot2.getDrawingSupplier();
        int int35 = objectList1.indexOf((java.lang.Object) xYPlot2);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot2.getRangeAxisLocation();
        java.awt.Paint paint37 = xYPlot2.getOutlinePaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        xYPlot2.setRenderer(128, xYItemRenderer39);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(drawingSupplier34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        xYPlot0.clearDomainMarkers(100);
        org.jfree.chart.plot.Plot plot5 = xYPlot0.getParent();
        java.awt.Paint paint6 = xYPlot0.getDomainCrosshairPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset8 = xYPlot0.getDataset();
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot0.setRenderer(0, xYItemRenderer33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = dateAxis36.getTickUnit();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis36);
        xYPlot0.setWeight(1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTickUnit37);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        double double6 = dateAxis1.getLowerBound();
        dateAxis1.setUpperMargin(0.0d);
        boolean boolean9 = dateAxis1.isTickMarksVisible();
        java.text.DateFormat dateFormat10 = dateAxis1.getDateFormatOverride();
        dateAxis1.setLabelAngle((double) (short) 1);
        java.awt.Shape shape13 = dateAxis1.getUpArrow();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        java.util.Date date7 = dateAxis3.getMaximumDate();
        boolean boolean8 = day1.equals((java.lang.Object) dateAxis3);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis10.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition13 = dateAxis10.getTickMarkPosition();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis10.setLeftArrow(shape14);
        java.awt.Stroke stroke16 = dateAxis10.getAxisLineStroke();
        dateAxis10.setFixedDimension(0.0d);
        boolean boolean20 = dateAxis10.isHiddenValue((long) 255);
        org.jfree.data.Range range21 = dateAxis10.getDefaultAutoRange();
        dateAxis3.setRange(range21);
        java.awt.Shape shape23 = dateAxis3.getLeftArrow();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset(4.0d);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, 8.0d, (double) 0, (double) 15, (double) (-1L));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(unitType3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot0.setRenderer(0, xYItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace35);
        boolean boolean37 = xYPlot0.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        xYPlot0.removeChangeListener(plotChangeListener33);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        int int36 = xYPlot0.indexOf(xYDataset35);
        java.util.Date date38 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis41.setLabelAngle(0.0d);
        java.util.Date date44 = dateAxis41.getMaximumDate();
        java.util.Date date45 = dateAxis41.getMaximumDate();
        boolean boolean46 = day39.equals((java.lang.Object) dateAxis41);
        java.util.Date date47 = day39.getStart();
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date47);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType49 = categoryMarker48.getLabelOffsetType();
        org.jfree.chart.util.Layer layer50 = null;
        try {
            xYPlot0.addDomainMarker((int) (short) 0, (org.jfree.chart.plot.Marker) categoryMarker48, layer50, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(drawingSupplier32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(lengthAdjustmentType49);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = xYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.configureRangeAxes();
        java.awt.Stroke stroke8 = xYPlot6.getDomainCrosshairStroke();
        xYPlot1.setRangeGridlineStroke(stroke8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot1.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot1.getDomainAxis(0);
        xYPlot1.setDomainCrosshairValue((double) 8, false);
        java.awt.Stroke stroke17 = xYPlot1.getDomainGridlineStroke();
        categoryPlot0.setDomainGridlineStroke(stroke17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot0.getDomainAxis((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot0.getDomainAxisLocation((int) (byte) 1);
        java.lang.Object obj23 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis25.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition28 = dateAxis25.getTickMarkPosition();
        java.awt.Stroke stroke29 = dateAxis25.getAxisLineStroke();
        categoryPlot0.setDomainGridlineStroke(stroke29);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(dateTickMarkPosition28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker1);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1.0f), jFreeChart4, chartChangeEventType5);
        markerChangeEvent2.setType(chartChangeEventType5);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        double double9 = categoryPlot8.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis11.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis11.getTickMarkPosition();
        java.awt.Stroke stroke15 = dateAxis11.getAxisLineStroke();
        dateAxis11.setLowerBound((double) 8);
        java.awt.Shape shape18 = dateAxis11.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        xYPlot19.configureRangeAxes();
        java.awt.Stroke stroke21 = xYPlot19.getDomainCrosshairStroke();
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot19.setNoDataMessageFont(font22);
        dateAxis11.setTickLabelFont(font22);
        org.jfree.data.Range range25 = categoryPlot8.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.util.SortOrder sortOrder26 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder26, jFreeChart27);
        categoryPlot8.setColumnRenderingOrder(sortOrder26);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean34 = axisLocation32.equals((java.lang.Object) 128);
        categoryPlot30.setRangeAxisLocation((int) (byte) 10, axisLocation32);
        categoryPlot30.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot30.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj43 = categoryAxis42.clone();
        java.awt.Font font45 = categoryAxis42.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot30.setDomainAxis((int) (short) 10, categoryAxis42);
        java.awt.Color color47 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass48 = color47.getClass();
        categoryPlot30.setRangeCrosshairPaint((java.awt.Paint) color47);
        org.jfree.chart.axis.ValueAxis valueAxis51 = categoryPlot30.getRangeAxisForDataset(255);
        categoryPlot30.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.AxisLocation axisLocation56 = categoryPlot30.getDomainAxisLocation(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation57 = categoryPlot30.getOrientation();
        categoryPlot30.clearRangeMarkers();
        boolean boolean59 = sortOrder26.equals((java.lang.Object) categoryPlot30);
        categoryPlot30.configureRangeAxes();
        boolean boolean61 = chartChangeEventType5.equals((java.lang.Object) categoryPlot30);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNull(valueAxis51);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNotNull(plotOrientation57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getBottom();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get((int) (byte) 10);
        int int3 = objectList0.size();
        java.lang.Object obj4 = objectList0.clone();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        xYPlot0.clearRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot8.setDataset(xYDataset9);
        org.jfree.chart.plot.Plot plot11 = xYPlot8.getRootPlot();
        java.awt.geom.Point2D point2D12 = xYPlot8.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) 200, plotRenderingInfo7, point2D12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(point2D12);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        boolean boolean21 = xYPlot0.isRangeZoomable();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot0.drawBackgroundImage(graphics2D22, rectangle2D23);
        boolean boolean25 = xYPlot0.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis4.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis4.getTickMarkPosition();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setLeftArrow(shape8);
        boolean boolean10 = dateAxis4.isVerticalTickLabels();
        int int11 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke15 = intervalMarker14.getStroke();
        intervalMarker14.setLabel("hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        double double19 = categoryPlot18.getRangeCrosshairValue();
        categoryPlot18.clearDomainMarkers();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker23.setKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot18.addDomainMarker((-1), categoryMarker23, layer26, false);
        boolean boolean29 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker14, layer26);
        categoryPlot0.setRangeCrosshairValue(0.05d, true);
        categoryPlot0.mapDatasetToDomainAxis((int) ' ', 2);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) (byte) 100, plotRenderingInfo4, point2D5, true);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray8 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray8);
        boolean boolean10 = xYPlot0.isDomainCrosshairVisible();
        java.awt.geom.Point2D point2D11 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.configureRangeAxes();
        java.awt.Stroke stroke14 = xYPlot12.getDomainCrosshairStroke();
        boolean boolean15 = xYPlot12.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D16 = xYPlot12.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D16);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(xYItemRendererArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(point2D16);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setLabelToolTip("ChartChangeEventType.NEW_DATASET");
        org.jfree.chart.plot.Plot plot24 = dateAxis15.getPlot();
        java.util.Date date25 = dateAxis15.getMinimumDate();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(plot24);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj3 = categoryAxis2.clone();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis2.setMaximumCategoryLabelLines((int) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot10.getDomainAxisEdge(0);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot10.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj17 = categoryAxis16.clone();
        boolean boolean18 = categoryAxis16.isTickLabelsVisible();
        categoryPlot10.setDomainAxis((int) (short) 10, categoryAxis16, false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot0.getDataRange(valueAxis8);
        double double10 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        java.util.Date date5 = dateAxis1.getMaximumDate();
        dateAxis1.setUpperBound((double) 'a');
        dateAxis1.setFixedDimension((double) 12);
        java.awt.Paint paint10 = dateAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis2.setLabelAngle(0.0d);
        java.util.Date date5 = dateAxis2.getMaximumDate();
        double double6 = dateAxis2.getUpperMargin();
        dateAxis2.setTickLabelsVisible(true);
        dateAxis2.setLabel("RectangleAnchor.TOP");
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis12.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis12.getTickUnit();
        java.awt.Shape shape16 = dateAxis12.getLeftArrow();
        dateAxis2.setLeftArrow(shape16);
        boolean boolean18 = dateAxis2.isVerticalTickLabels();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        xYPlot19.configureRangeAxes();
        xYPlot19.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean23 = xYPlot19.equals((java.lang.Object) dateTickUnit22);
        dateAxis2.setTickUnit(dateTickUnit22);
        org.jfree.data.Range range25 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis29.setLabelAngle(0.0d);
        java.util.Date date32 = dateAxis29.getMaximumDate();
        java.util.Date date33 = dateAxis29.getMaximumDate();
        boolean boolean34 = day27.equals((java.lang.Object) dateAxis29);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis36.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition39 = dateAxis36.getTickMarkPosition();
        java.awt.Shape shape40 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis36.setLeftArrow(shape40);
        java.awt.Stroke stroke42 = dateAxis36.getAxisLineStroke();
        dateAxis36.setFixedDimension(0.0d);
        boolean boolean46 = dateAxis36.isHiddenValue((long) 255);
        org.jfree.data.Range range47 = dateAxis36.getDefaultAutoRange();
        dateAxis29.setRange(range47);
        java.util.Date date49 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis52.setLabelAngle(0.0d);
        java.util.Date date55 = dateAxis52.getMaximumDate();
        java.util.Date date56 = dateAxis52.getMaximumDate();
        boolean boolean57 = day50.equals((java.lang.Object) dateAxis52);
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis59.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition62 = dateAxis59.getTickMarkPosition();
        java.awt.Shape shape63 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis59.setLeftArrow(shape63);
        java.awt.Stroke stroke65 = dateAxis59.getAxisLineStroke();
        dateAxis59.setFixedDimension(0.0d);
        boolean boolean69 = dateAxis59.isHiddenValue((long) 255);
        org.jfree.data.Range range70 = dateAxis59.getDefaultAutoRange();
        dateAxis52.setRange(range70);
        org.jfree.data.time.DateRange dateRange72 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis52.setDefaultAutoRange((org.jfree.data.Range) dateRange72);
        dateAxis29.setRangeWithMargins((org.jfree.data.Range) dateRange72);
        org.jfree.data.time.DateRange dateRange75 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis29.setDefaultAutoRange((org.jfree.data.Range) dateRange75);
        dateAxis2.setRange((org.jfree.data.Range) dateRange75);
        org.jfree.chart.plot.XYPlot xYPlot78 = new org.jfree.chart.plot.XYPlot();
        xYPlot78.configureRangeAxes();
        java.awt.Stroke stroke80 = xYPlot78.getDomainCrosshairStroke();
        java.awt.Font font81 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot78.setNoDataMessageFont(font81);
        xYPlot78.clearAnnotations();
        java.awt.Stroke stroke84 = xYPlot78.getDomainZeroBaselineStroke();
        dateAxis2.setTickMarkStroke(stroke84);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition39);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition62);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertNotNull(dateRange72);
        org.junit.Assert.assertNotNull(dateRange75);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(font81);
        org.junit.Assert.assertNotNull(stroke84);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.Plot plot9 = xYPlot0.getParent();
        int int10 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        dateAxis1.setInverted(false);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = xYPlot7.getRangeAxisIndex(valueAxis10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.configureRangeAxes();
        java.awt.Stroke stroke14 = xYPlot12.getDomainCrosshairStroke();
        xYPlot7.setRangeGridlineStroke(stroke14);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke19 = intervalMarker18.getStroke();
        java.awt.Paint paint20 = intervalMarker18.getOutlinePaint();
        java.lang.String str21 = intervalMarker18.getLabel();
        java.awt.Color color22 = java.awt.Color.orange;
        intervalMarker18.setPaint((java.awt.Paint) color22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker18, layer24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        xYPlot7.addChangeListener(plotChangeListener26);
        org.jfree.data.general.DatasetGroup datasetGroup28 = xYPlot7.getDatasetGroup();
        java.awt.Font font29 = xYPlot7.getNoDataMessageFont();
        dateAxis1.setLabelFont(font29);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertNull(datasetGroup28);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, 3, (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot0.setRangeAxisLocation(5, axisLocation11, false);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.configureRangeAxes();
        xYPlot14.setDomainCrosshairValue((double) '#');
        xYPlot14.setDomainCrosshairLockedOnData(false);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot14);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        double double22 = categoryPlot21.getRangeCrosshairValue();
        categoryPlot21.clearDomainMarkers();
        org.jfree.chart.plot.Plot plot24 = categoryPlot21.getRootPlot();
        java.awt.Color color25 = java.awt.Color.yellow;
        java.awt.Color color26 = java.awt.Color.green;
        int int27 = color26.getAlpha();
        float[] floatArray33 = new float[] { 4, 1.0f, 128, 5, 255 };
        float[] floatArray34 = color26.getRGBComponents(floatArray33);
        float[] floatArray35 = color25.getRGBComponents(floatArray33);
        categoryPlot21.setRangeGridlinePaint((java.awt.Paint) color25);
        xYPlot14.setRangeCrosshairPaint((java.awt.Paint) color25);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(plot24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 255 + "'", int27 == 255);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis23.setMinimumDate(date29);
        double double31 = dateAxis23.getLowerMargin();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        dateAxis1.setInverted(false);
        dateAxis1.setRangeWithMargins((double) (-1.0f), (double) (byte) 10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource10);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(tickUnitSource10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot0.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        xYPlot22.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        int int26 = xYPlot22.getRangeAxisIndex(valueAxis25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.configureRangeAxes();
        java.awt.Stroke stroke29 = xYPlot27.getDomainCrosshairStroke();
        xYPlot22.setRangeGridlineStroke(stroke29);
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke34 = intervalMarker33.getStroke();
        java.awt.Paint paint35 = intervalMarker33.getOutlinePaint();
        java.lang.String str36 = intervalMarker33.getLabel();
        java.awt.Color color37 = java.awt.Color.orange;
        intervalMarker33.setPaint((java.awt.Paint) color37);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot22.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker33, layer39);
        java.awt.Stroke stroke41 = null;
        xYPlot22.setOutlineStroke(stroke41);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis45.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = dateAxis45.getTickUnit();
        xYPlot22.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis45, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke55 = intervalMarker54.getStroke();
        java.awt.Paint paint56 = intervalMarker54.getOutlinePaint();
        java.lang.String str57 = intervalMarker54.getLabel();
        java.awt.Color color58 = java.awt.Color.orange;
        intervalMarker54.setPaint((java.awt.Paint) color58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = intervalMarker54.getLabelAnchor();
        org.jfree.chart.util.Layer layer61 = null;
        xYPlot22.addRangeMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker54, layer61);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean64 = categoryPlot0.removeDomainMarker((-1), (org.jfree.chart.plot.Marker) intervalMarker54, layer63);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer65 = null;
        intervalMarker54.setGradientPaintTransformer(gradientPaintTransformer65);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertNotNull(dateTickUnit48);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        xYPlot0.clearDomainMarkers(100);
        org.jfree.chart.plot.Plot plot5 = xYPlot0.getParent();
        java.awt.Paint paint6 = xYPlot0.getDomainCrosshairPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot0.setDataset(xYDataset8);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker1);
        org.jfree.chart.plot.Marker marker3 = markerChangeEvent2.getMarker();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = marker3.getLabelAnchor();
        org.junit.Assert.assertNotNull(marker3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        java.lang.String str5 = intervalMarker2.getLabel();
        java.awt.Stroke stroke6 = intervalMarker2.getStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = intervalMarker2.getGradientPaintTransformer();
        java.awt.Font font8 = intervalMarker2.getLabelFont();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(gradientPaintTransformer7);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleAnchor.TOP");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        int int24 = xYPlot20.getRangeAxisIndex(valueAxis23);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        xYPlot25.configureRangeAxes();
        java.awt.Stroke stroke27 = xYPlot25.getDomainCrosshairStroke();
        xYPlot20.setRangeGridlineStroke(stroke27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        xYPlot20.setFixedDomainAxisSpace(axisSpace29);
        org.jfree.chart.axis.ValueAxis valueAxis32 = xYPlot20.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis35.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit38 = dateAxis35.getTickUnit();
        java.awt.Shape shape39 = dateAxis35.getLeftArrow();
        xYPlot20.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis35, true);
        dateAxis35.setLabelToolTip("ChartChangeEventType.NEW_DATASET");
        java.awt.Font font44 = dateAxis35.getLabelFont();
        java.awt.Stroke[] strokeArray45 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean46 = dateAxis35.equals((java.lang.Object) strokeArray45);
        java.lang.String str47 = dateAxis35.getLabelURL();
        int int48 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation51 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean53 = axisLocation51.equals((java.lang.Object) 128);
        categoryPlot49.setRangeAxisLocation((int) (byte) 10, axisLocation51);
        categoryPlot49.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation58 = categoryPlot49.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj62 = categoryAxis61.clone();
        java.awt.Font font64 = categoryAxis61.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot49.setDomainAxis((int) (short) 10, categoryAxis61);
        java.awt.Color color66 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass67 = color66.getClass();
        categoryPlot49.setRangeCrosshairPaint((java.awt.Paint) color66);
        org.jfree.chart.axis.ValueAxis valueAxis70 = categoryPlot49.getRangeAxisForDataset(255);
        categoryPlot49.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.AxisLocation axisLocation75 = categoryPlot49.getDomainAxisLocation(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation76 = categoryPlot49.getOrientation();
        categoryPlot0.setOrientation(plotOrientation76);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(dateTickUnit38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(strokeArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNull(valueAxis70);
        org.junit.Assert.assertNotNull(axisLocation75);
        org.junit.Assert.assertNotNull(plotOrientation76);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.Plot plot9 = xYPlot0.getParent();
        java.lang.Object obj10 = xYPlot0.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        double double6 = dateAxis1.getLowerBound();
        dateAxis1.setUpperMargin(0.0d);
        boolean boolean9 = dateAxis1.isTickMarksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = dateAxis1.getTickLabelInsets();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis1.configure();
        java.awt.Stroke stroke3 = categoryAxis1.getAxisLineStroke();
        double double4 = categoryAxis1.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        xYPlot7.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean11 = xYPlot7.equals((java.lang.Object) dateTickUnit10);
        dateAxis6.setTickUnit(dateTickUnit10);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) dateTickUnit10, "RectangleAnchor.TOP");
        java.awt.Paint paint16 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3);
        java.awt.Paint paint5 = categoryPlot0.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        java.awt.Stroke stroke5 = xYPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke6 = xYPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        xYPlot0.setRenderer((int) (byte) 0, xYItemRenderer8, false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19);
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.clearDomainMarkers((int) (byte) -1);
        boolean boolean25 = categoryPlot0.getDrawSharedDomainAxis();
        categoryPlot0.setDomainGridlinesVisible(false);
        double double28 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        org.jfree.chart.plot.Marker marker30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean35 = axisLocation33.equals((java.lang.Object) 128);
        categoryPlot31.setRangeAxisLocation((int) (byte) 10, axisLocation33);
        categoryPlot31.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot31.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj44 = categoryAxis43.clone();
        java.awt.Font font46 = categoryAxis43.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot31.setDomainAxis((int) (short) 10, categoryAxis43);
        java.awt.Color color48 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass49 = color48.getClass();
        categoryPlot31.setRangeCrosshairPaint((java.awt.Paint) color48);
        org.jfree.data.category.CategoryDataset categoryDataset51 = categoryPlot31.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        xYPlot53.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        int int57 = xYPlot53.getRangeAxisIndex(valueAxis56);
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot();
        xYPlot58.configureRangeAxes();
        java.awt.Stroke stroke60 = xYPlot58.getDomainCrosshairStroke();
        xYPlot53.setRangeGridlineStroke(stroke60);
        org.jfree.chart.plot.IntervalMarker intervalMarker64 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke65 = intervalMarker64.getStroke();
        java.awt.Paint paint66 = intervalMarker64.getOutlinePaint();
        java.lang.String str67 = intervalMarker64.getLabel();
        java.awt.Color color68 = java.awt.Color.orange;
        intervalMarker64.setPaint((java.awt.Paint) color68);
        org.jfree.chart.util.Layer layer70 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot53.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker64, layer70);
        java.awt.Stroke stroke72 = null;
        xYPlot53.setOutlineStroke(stroke72);
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis76.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit79 = dateAxis76.getTickUnit();
        xYPlot53.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis76, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker85 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke86 = intervalMarker85.getStroke();
        java.awt.Paint paint87 = intervalMarker85.getOutlinePaint();
        java.lang.String str88 = intervalMarker85.getLabel();
        java.awt.Color color89 = java.awt.Color.orange;
        intervalMarker85.setPaint((java.awt.Paint) color89);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor91 = intervalMarker85.getLabelAnchor();
        org.jfree.chart.util.Layer layer92 = null;
        xYPlot53.addRangeMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker85, layer92);
        org.jfree.chart.util.Layer layer94 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean95 = categoryPlot31.removeDomainMarker((-1), (org.jfree.chart.plot.Marker) intervalMarker85, layer94);
        try {
            boolean boolean96 = xYPlot0.removeRangeMarker(9, marker30, layer94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNull(categoryDataset51);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(layer70);
        org.junit.Assert.assertNotNull(dateTickUnit79);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNotNull(paint87);
        org.junit.Assert.assertNull(str88);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertNotNull(rectangleAnchor91);
        org.junit.Assert.assertNotNull(layer94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        java.lang.Object obj5 = numberAxis1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        java.util.Date date7 = dateAxis3.getMaximumDate();
        boolean boolean8 = day1.equals((java.lang.Object) dateAxis3);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis10.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition13 = dateAxis10.getTickMarkPosition();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis10.setLeftArrow(shape14);
        java.awt.Stroke stroke16 = dateAxis10.getAxisLineStroke();
        dateAxis10.setFixedDimension(0.0d);
        boolean boolean20 = dateAxis10.isHiddenValue((long) 255);
        org.jfree.data.Range range21 = dateAxis10.getDefaultAutoRange();
        dateAxis3.setRange(range21);
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis3.setDefaultAutoRange((org.jfree.data.Range) dateRange23);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = dateAxis26.getTickUnit();
        java.util.Date date28 = dateAxis3.calculateLowestVisibleTickValue(dateTickUnit27);
        dateAxis3.setLabelAngle(100.0d);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(dateRange23);
        org.junit.Assert.assertNotNull(dateTickUnit27);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis1.configure();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.configureRangeAxes();
        java.awt.Stroke stroke8 = xYPlot6.getDomainCrosshairStroke();
        boolean boolean9 = xYPlot6.isRangeZeroBaselineVisible();
        xYPlot6.clearDomainMarkers((-1));
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot6.getRangeAxisEdge(0);
        try {
            double double14 = categoryAxis1.getCategoryMiddle(3, 12, rectangle2D5, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = xYPlot0.equals((java.lang.Object) dateTickUnit3);
        xYPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke10 = intervalMarker9.getStroke();
        java.awt.Paint paint11 = intervalMarker9.getOutlinePaint();
        xYPlot0.setDomainTickBandPaint(paint11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        int int18 = xYPlot14.getRangeAxisIndex(valueAxis17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        xYPlot19.configureRangeAxes();
        java.awt.Stroke stroke21 = xYPlot19.getDomainCrosshairStroke();
        xYPlot14.setRangeGridlineStroke(stroke21);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        xYPlot14.setFixedDomainAxisSpace(axisSpace23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot14.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis29.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis29.getTickUnit();
        java.awt.Shape shape33 = dateAxis29.getLeftArrow();
        xYPlot14.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis29, true);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot14.getRangeAxisLocation(4);
        xYPlot13.setRangeAxisLocation(axisLocation37);
        xYPlot0.setDomainAxisLocation(axisLocation37, true);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font3);
        xYPlot0.clearAnnotations();
        boolean boolean6 = xYPlot0.isSubplot();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        double double8 = categoryPlot7.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis10.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition13 = dateAxis10.getTickMarkPosition();
        java.awt.Stroke stroke14 = dateAxis10.getAxisLineStroke();
        dateAxis10.setLowerBound((double) 8);
        java.awt.Shape shape17 = dateAxis10.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.configureRangeAxes();
        java.awt.Stroke stroke20 = xYPlot18.getDomainCrosshairStroke();
        java.awt.Font font21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot18.setNoDataMessageFont(font21);
        dateAxis10.setTickLabelFont(font21);
        org.jfree.data.Range range24 = categoryPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis26.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition29 = dateAxis26.getTickMarkPosition();
        java.awt.Stroke stroke30 = dateAxis26.getAxisLineStroke();
        double double31 = dateAxis26.getLowerBound();
        java.awt.Font font32 = dateAxis26.getTickLabelFont();
        categoryPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke37 = intervalMarker36.getStroke();
        java.awt.Paint paint38 = intervalMarker36.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor39 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker36.setLabelTextAnchor(textAnchor39);
        java.awt.Stroke stroke41 = intervalMarker36.getStroke();
        dateAxis26.setTickMarkStroke(stroke41);
        java.awt.Paint paint43 = dateAxis26.getTickLabelPaint();
        xYPlot0.setDomainGridlinePaint(paint43);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(dateTickMarkPosition29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(textAnchor39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis2.setLabelAngle(0.0d);
        java.util.Date date5 = dateAxis2.getMaximumDate();
        double double6 = dateAxis2.getUpperMargin();
        dateAxis2.setTickLabelsVisible(true);
        dateAxis2.setLabel("RectangleAnchor.TOP");
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis12.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis12.getTickUnit();
        java.awt.Shape shape16 = dateAxis12.getLeftArrow();
        dateAxis2.setLeftArrow(shape16);
        boolean boolean18 = dateAxis2.isVerticalTickLabels();
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        xYPlot19.configureRangeAxes();
        xYPlot19.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean23 = xYPlot19.equals((java.lang.Object) dateTickUnit22);
        dateAxis2.setTickUnit(dateTickUnit22);
        org.jfree.data.Range range25 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTickUnit22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.plot.Plot plot7 = dateAxis1.getPlot();
        dateAxis1.setUpperMargin((double) 7);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        int int3 = color2.getGreen();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        double double5 = categoryPlot4.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis7.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis7.getTickMarkPosition();
        java.awt.Stroke stroke11 = dateAxis7.getAxisLineStroke();
        dateAxis7.setLowerBound((double) 8);
        java.awt.Shape shape14 = dateAxis7.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.configureRangeAxes();
        java.awt.Stroke stroke17 = xYPlot15.getDomainCrosshairStroke();
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot15.setNoDataMessageFont(font18);
        dateAxis7.setTickLabelFont(font18);
        org.jfree.data.Range range21 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition26 = dateAxis23.getTickMarkPosition();
        java.awt.Stroke stroke27 = dateAxis23.getAxisLineStroke();
        double double28 = dateAxis23.getLowerBound();
        java.awt.Font font29 = dateAxis23.getTickLabelFont();
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke34 = intervalMarker33.getStroke();
        java.awt.Paint paint35 = intervalMarker33.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker33.setLabelTextAnchor(textAnchor36);
        java.awt.Stroke stroke38 = intervalMarker33.getStroke();
        dateAxis23.setTickMarkStroke(stroke38);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        xYPlot40.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        int int44 = xYPlot40.getRangeAxisIndex(valueAxis43);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot40.setNoDataMessagePaint((java.awt.Paint) color45);
        java.awt.image.ColorModel colorModel47 = null;
        java.awt.Rectangle rectangle48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.awt.geom.AffineTransform affineTransform50 = null;
        java.awt.RenderingHints renderingHints51 = null;
        java.awt.PaintContext paintContext52 = color45.createContext(colorModel47, rectangle48, rectangle2D49, affineTransform50, renderingHints51);
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis54.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit57 = dateAxis54.getTickUnit();
        java.awt.Stroke stroke58 = dateAxis54.getAxisLineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((double) '4', (double) (byte) 100, (java.awt.Paint) color2, stroke38, (java.awt.Paint) color45, stroke58, 0.0f);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer61 = null;
        intervalMarker60.setGradientPaintTransformer(gradientPaintTransformer61);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(dateTickMarkPosition26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(paintContext52);
        org.junit.Assert.assertNotNull(dateTickUnit57);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxisForDataset(255);
        categoryPlot0.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot0.getDomainAxisLocation(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = categoryPlot0.getOrientation();
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(plotOrientation27);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot0.setRenderer(0, xYItemRenderer33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = dateAxis36.getTickUnit();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis36);
        double double39 = dateAxis36.getLowerBound();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTickUnit37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        intervalMarker2.setLabel("hi!");
        java.awt.Font font6 = intervalMarker2.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = intervalMarker2.getLabelOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis9.configure();
        java.awt.Stroke stroke11 = categoryAxis9.getAxisLineStroke();
        categoryAxis9.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        int int18 = xYPlot14.getRangeAxisIndex(valueAxis17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        xYPlot19.configureRangeAxes();
        java.awt.Stroke stroke21 = xYPlot19.getDomainCrosshairStroke();
        xYPlot14.setRangeGridlineStroke(stroke21);
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke26 = intervalMarker25.getStroke();
        java.awt.Paint paint27 = intervalMarker25.getOutlinePaint();
        java.lang.String str28 = intervalMarker25.getLabel();
        java.awt.Color color29 = java.awt.Color.orange;
        intervalMarker25.setPaint((java.awt.Paint) color29);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker25, layer31);
        java.awt.Stroke stroke33 = null;
        xYPlot14.setOutlineStroke(stroke33);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis37.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = dateAxis37.getTickUnit();
        xYPlot14.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis37, true);
        java.util.Date date43 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis37.setMinimumDate(date43);
        categoryAxis9.removeCategoryLabelToolTip((java.lang.Comparable) date43);
        boolean boolean46 = rectangleInsets7.equals((java.lang.Object) date43);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNotNull(dateTickUnit40);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        dateAxis1.setTickLabelsVisible(true);
        dateAxis1.setLabel("RectangleAnchor.TOP");
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis11.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.awt.Shape shape15 = dateAxis11.getLeftArrow();
        dateAxis1.setLeftArrow(shape15);
        boolean boolean17 = dateAxis1.isVerticalTickLabels();
        java.awt.Paint paint18 = dateAxis1.getAxisLinePaint();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot7.setDataset(xYDataset8);
        org.jfree.chart.plot.Plot plot10 = xYPlot7.getRootPlot();
        java.awt.geom.Point2D point2D11 = xYPlot7.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo6, point2D11);
        java.util.List list13 = categoryPlot0.getAnnotations();
        java.awt.Paint paint14 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker5.setKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addDomainMarker((-1), categoryMarker5, layer8, false);
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot0.setDomainAxisLocation(10, axisLocation12);
        java.awt.Paint paint14 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis1.configure();
        java.awt.Stroke stroke3 = categoryAxis1.getAxisLineStroke();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        int int6 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color32);
        float float34 = xYPlot0.getBackgroundAlpha();
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        xYPlot0.drawBackgroundImage(graphics2D35, rectangle2D36);
        java.awt.Stroke stroke38 = xYPlot0.getDomainZeroBaselineStroke();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis40 = xYPlot0.getRangeAxisForDataset(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 13 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor5);
        java.awt.Stroke stroke7 = intervalMarker2.getStroke();
        java.awt.Paint paint8 = intervalMarker2.getOutlinePaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.configureRangeAxes();
        java.awt.Stroke stroke25 = xYPlot23.getDomainCrosshairStroke();
        boolean boolean26 = xYPlot23.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D27 = xYPlot23.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) 1.0f, plotRenderingInfo22, point2D27);
        double double29 = categoryPlot0.getAnchorValue();
        float float30 = categoryPlot0.getForegroundAlpha();
        boolean boolean31 = categoryPlot0.isSubplot();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot7.setDataset(xYDataset8);
        org.jfree.chart.plot.Plot plot10 = xYPlot7.getRootPlot();
        java.awt.geom.Point2D point2D11 = xYPlot7.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo6, point2D11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot0.getRangeAxis();
        boolean boolean14 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.REVERSE");
        java.awt.Paint paint2 = categoryAxis1.getLabelPaint();
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setCategoryLabelPositionOffset((int) (short) 1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        xYPlot5.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke11 = intervalMarker10.getStroke();
        java.awt.Paint paint12 = intervalMarker10.getOutlinePaint();
        java.lang.String str13 = intervalMarker10.getLabel();
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean15 = xYPlot5.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer14);
        java.util.Collection collection16 = categoryPlot0.getRangeMarkers(layer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        int int18 = categoryPlot0.getIndexOf(categoryItemRenderer17);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation19 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation19, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(layer14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        double double6 = dateAxis1.getLowerBound();
        java.awt.Font font7 = dateAxis1.getTickLabelFont();
        dateAxis1.setLabelURL("Layer.BACKGROUND");
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        java.util.Date date5 = dateAxis1.getMaximumDate();
        dateAxis1.setUpperBound((double) 'a');
        float float8 = dateAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19);
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = categoryPlot0.getDomainGridlinePosition();
        java.lang.String str23 = categoryAnchor22.toString();
        java.lang.String str24 = categoryAnchor22.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str23.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str24.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        double double6 = dateAxis1.getAutoRangeMinimumSize();
        dateAxis1.setAutoRangeMinimumSize((double) 0.8f);
        dateAxis1.setLowerMargin((double) 4);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.configureRangeAxes();
        java.awt.Stroke stroke25 = xYPlot23.getDomainCrosshairStroke();
        boolean boolean26 = xYPlot23.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D27 = xYPlot23.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) 1.0f, plotRenderingInfo22, point2D27);
        double double29 = categoryPlot0.getAnchorValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        int int31 = categoryPlot0.getIndexOf(categoryItemRenderer30);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.setDomainCrosshairValue((double) '#');
        xYPlot0.setDomainCrosshairLockedOnData(false);
        java.awt.Stroke stroke6 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        xYPlot0.clearDomainMarkers(100);
        org.jfree.chart.plot.Plot plot5 = xYPlot0.getParent();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = xYPlot6.getRangeAxisIndex(valueAxis9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        xYPlot6.setRangeGridlineStroke(stroke13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke18 = intervalMarker17.getStroke();
        java.awt.Paint paint19 = intervalMarker17.getOutlinePaint();
        java.lang.String str20 = intervalMarker17.getLabel();
        java.awt.Color color21 = java.awt.Color.orange;
        intervalMarker17.setPaint((java.awt.Paint) color21);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker17, layer23);
        java.awt.Stroke stroke25 = null;
        xYPlot6.setOutlineStroke(stroke25);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis29.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis29.getTickUnit();
        xYPlot6.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis29, true);
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis29.setMinimumDate(date35);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis29);
        double double38 = dateAxis29.getLabelAngle();
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis19.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis19.getTickMarkPosition();
        java.awt.Stroke stroke23 = dateAxis19.getAxisLineStroke();
        double double24 = dateAxis19.getLowerBound();
        java.awt.Font font25 = dateAxis19.getTickLabelFont();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        categoryPlot0.setRenderer(15, categoryItemRenderer28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean32 = axisLocation30.equals((java.lang.Object) 128);
        categoryPlot0.setDomainAxisLocation(axisLocation30);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        dateAxis1.setLowerBound((double) 8);
        java.awt.Shape shape8 = dateAxis1.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.configureRangeAxes();
        java.awt.Stroke stroke11 = xYPlot9.getDomainCrosshairStroke();
        java.awt.Font font12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot9.setNoDataMessageFont(font12);
        dateAxis1.setTickLabelFont(font12);
        double double15 = dateAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        xYPlot0.clearDomainMarkers(100);
        org.jfree.chart.plot.Plot plot5 = xYPlot0.getParent();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = xYPlot6.getRangeAxisIndex(valueAxis9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        xYPlot6.setRangeGridlineStroke(stroke13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke18 = intervalMarker17.getStroke();
        java.awt.Paint paint19 = intervalMarker17.getOutlinePaint();
        java.lang.String str20 = intervalMarker17.getLabel();
        java.awt.Color color21 = java.awt.Color.orange;
        intervalMarker17.setPaint((java.awt.Paint) color21);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker17, layer23);
        java.awt.Stroke stroke25 = null;
        xYPlot6.setOutlineStroke(stroke25);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis29.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis29.getTickUnit();
        xYPlot6.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis29, true);
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis29.setMinimumDate(date35);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis29);
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        xYPlot38.configureRangeAxes();
        java.awt.Stroke stroke40 = xYPlot38.getDomainCrosshairStroke();
        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot38.setNoDataMessageFont(font41);
        xYPlot38.clearAnnotations();
        java.awt.Stroke stroke44 = xYPlot38.getDomainZeroBaselineStroke();
        dateAxis29.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot38);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        boolean boolean7 = dateAxis1.isVerticalTickLabels();
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis11.setLabelAngle(0.0d);
        java.util.Date date14 = dateAxis11.getMaximumDate();
        java.util.Date date15 = dateAxis11.getMaximumDate();
        boolean boolean16 = day9.equals((java.lang.Object) dateAxis11);
        java.util.Date date17 = day9.getStart();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis20.setLabelAngle(0.0d);
        java.util.Date date23 = dateAxis20.getMaximumDate();
        double double24 = dateAxis20.getUpperMargin();
        dateAxis20.setTickLabelsVisible(true);
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis20.setMaximumDate(date27);
        dateAxis1.setRange(date17, date27);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date17, timeZone30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        double double33 = categoryPlot32.getRangeCrosshairValue();
        java.awt.Stroke stroke34 = categoryPlot32.getRangeGridlineStroke();
        boolean boolean35 = day31.equals((java.lang.Object) categoryPlot32);
        java.util.Date date36 = day31.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(date36);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis2.setLabelAngle(0.0d);
        java.util.Date date5 = dateAxis2.getMaximumDate();
        java.util.Date date6 = dateAxis2.getMaximumDate();
        dateAxis2.setUpperBound((double) 'a');
        double double9 = dateAxis2.getUpperMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        double double11 = categoryPlot10.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis13.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis13.getTickMarkPosition();
        java.awt.Stroke stroke17 = dateAxis13.getAxisLineStroke();
        dateAxis13.setLowerBound((double) 8);
        java.awt.Shape shape20 = dateAxis13.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.configureRangeAxes();
        java.awt.Stroke stroke23 = xYPlot21.getDomainCrosshairStroke();
        java.awt.Font font24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot21.setNoDataMessageFont(font24);
        dateAxis13.setTickLabelFont(font24);
        org.jfree.data.Range range27 = categoryPlot10.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis13);
        categoryPlot10.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean34 = axisLocation32.equals((java.lang.Object) 128);
        categoryPlot30.setRangeAxisLocation((int) (byte) 10, axisLocation32);
        categoryPlot30.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot30.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj43 = categoryAxis42.clone();
        java.awt.Font font45 = categoryAxis42.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot30.setDomainAxis((int) (short) 10, categoryAxis42);
        java.util.List list47 = categoryPlot10.getCategoriesForAxis(categoryAxis42);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = categoryPlot10.getInsets();
        boolean boolean49 = dateAxis2.hasListener((java.util.EventListener) categoryPlot10);
        boolean boolean50 = textAnchor0.equals((java.lang.Object) dateAxis2);
        boolean boolean51 = dateAxis2.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color3 = java.awt.Color.GRAY;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color3);
        intervalMarker2.setStartValue((double) 8);
        float float7 = intervalMarker2.getAlpha();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.8f + "'", float7 == 0.8f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 1, (float) 9, (float) 2);
        int int4 = color3.getBlue();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 17 + "'", int4 == 17);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.lang.Object obj4 = intervalMarker2.clone();
        java.lang.Class<?> wildcardClass5 = intervalMarker2.getClass();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
//        java.lang.Object obj3 = categoryAxis2.clone();
//        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (byte) -1);
//        categoryAxis2.setMaximumCategoryLabelLines((int) (byte) 1);
//        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis8, categoryItemRenderer9);
//        categoryAxis2.configure();
//        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
//        long long14 = day13.getMiddleMillisecond();
//        int int15 = day13.getMonth();
//        java.lang.String str16 = categoryAxis2.getCategoryLabelToolTip((java.lang.Comparable) int15);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertNotNull(font5);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560452399999L + "'", long14 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNull(str16);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        java.util.Date date7 = dateAxis3.getMaximumDate();
        boolean boolean8 = day1.equals((java.lang.Object) dateAxis3);
        java.util.Date date9 = day1.getStart();
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date9);
        java.awt.Color color11 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass12 = color11.getClass();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis14.setLabelAngle(0.0d);
        java.util.Date date17 = dateAxis14.getMaximumDate();
        double double18 = dateAxis14.getUpperMargin();
        dateAxis14.setTickLabelsVisible(true);
        java.util.Date date21 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis14.setMaximumDate(date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date21, timeZone23);
        java.util.Date date26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis28.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition31 = dateAxis28.getTickMarkPosition();
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis28.setLeftArrow(shape32);
        org.jfree.chart.plot.Plot plot34 = dateAxis28.getPlot();
        java.util.TimeZone timeZone35 = dateAxis28.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date26, timeZone35);
        try {
            java.util.EventListener[] eventListenerArray37 = categoryMarker10.getListeners((java.lang.Class) wildcardClass12);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.awt.Color; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(dateTickMarkPosition31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(plot34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis19.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis19.getTickMarkPosition();
        java.awt.Stroke stroke23 = dateAxis19.getAxisLineStroke();
        double double24 = dateAxis19.getLowerBound();
        java.awt.Font font25 = dateAxis19.getTickLabelFont();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        dateAxis19.centerRange((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = xYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.configureRangeAxes();
        java.awt.Stroke stroke8 = xYPlot6.getDomainCrosshairStroke();
        xYPlot1.setRangeGridlineStroke(stroke8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot1.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot1.getDomainAxis(0);
        xYPlot1.setDomainCrosshairValue((double) 8, false);
        java.awt.Stroke stroke17 = xYPlot1.getDomainGridlineStroke();
        categoryPlot0.setDomainGridlineStroke(stroke17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot0.getDomainAxis((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot0.getDomainAxisLocation((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean27 = axisLocation25.equals((java.lang.Object) 128);
        categoryPlot23.setRangeAxisLocation((int) (byte) 10, axisLocation25);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = categoryPlot23.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection29);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(legendItemCollection29);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        double double7 = dateAxis1.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj3 = categoryAxis2.clone();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis2.setMaximumCategoryLabelLines((int) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis8, categoryItemRenderer9);
        categoryAxis2.configure();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.setNoDataMessage("hi!");
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot15.getDomainAxisEdge();
        try {
            double double19 = categoryAxis2.getCategoryEnd(64, 13, rectangle2D14, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot0.setRenderer((int) (short) 0, categoryItemRenderer7, true);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray29 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray29);
        double double31 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(xYItemRendererArray29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = dateAxis2.getTickUnit();
        boolean boolean4 = defaultDrawingSupplier0.equals((java.lang.Object) dateTickUnit3);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis1.setFixedDimension((double) 1.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = java.awt.Color.getColor("ChartChangeEventType.NEW_DATASET", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19);
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot24.setDataset(xYDataset25);
        org.jfree.chart.plot.Plot plot27 = xYPlot24.getRootPlot();
        java.awt.geom.Point2D point2D28 = xYPlot24.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(4.0d, plotRenderingInfo23, point2D28, true);
        java.lang.Object obj31 = categoryPlot0.clone();
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeGridlineStroke(stroke32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(plot27);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        xYPlot0.addChangeListener(plotChangeListener19);
        org.jfree.data.general.DatasetGroup datasetGroup21 = xYPlot0.getDatasetGroup();
        java.awt.Font font22 = xYPlot0.getNoDataMessageFont();
        java.awt.Paint paint23 = xYPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke24 = xYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Marker marker26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.clearDomainMarkers((int) '4');
        categoryPlot27.setAnchorValue(4.0d, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean37 = axisLocation35.equals((java.lang.Object) 128);
        categoryPlot33.setRangeAxisLocation((int) (byte) 10, axisLocation35);
        categoryPlot33.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot33.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj46 = categoryAxis45.clone();
        java.awt.Font font48 = categoryAxis45.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot33.setDomainAxis((int) (short) 10, categoryAxis45);
        org.jfree.chart.plot.CategoryMarker categoryMarker51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker51.setKey((java.lang.Comparable) 10);
        java.lang.Object obj54 = null;
        boolean boolean55 = categoryMarker51.equals(obj54);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        double double57 = categoryPlot56.getRangeCrosshairValue();
        categoryPlot56.clearDomainMarkers();
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker61.setKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Layer layer64 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot56.addDomainMarker((-1), categoryMarker61, layer64, false);
        boolean boolean67 = categoryPlot33.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker51, layer64);
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot();
        xYPlot68.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        int int72 = xYPlot68.getRangeAxisIndex(valueAxis71);
        org.jfree.chart.plot.XYPlot xYPlot73 = new org.jfree.chart.plot.XYPlot();
        xYPlot73.configureRangeAxes();
        java.awt.Stroke stroke75 = xYPlot73.getDomainCrosshairStroke();
        xYPlot68.setRangeGridlineStroke(stroke75);
        org.jfree.chart.plot.IntervalMarker intervalMarker79 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke80 = intervalMarker79.getStroke();
        java.awt.Paint paint81 = intervalMarker79.getOutlinePaint();
        java.lang.String str82 = intervalMarker79.getLabel();
        java.awt.Color color83 = java.awt.Color.orange;
        intervalMarker79.setPaint((java.awt.Paint) color83);
        org.jfree.chart.util.Layer layer85 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot68.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker79, layer85);
        java.lang.String str87 = layer85.toString();
        categoryPlot27.addDomainMarker(categoryMarker51, layer85);
        try {
            boolean boolean90 = xYPlot0.removeRangeMarker(0, marker26, layer85, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(layer64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNull(str82);
        org.junit.Assert.assertNotNull(color83);
        org.junit.Assert.assertNotNull(layer85);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "Layer.BACKGROUND" + "'", str87.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        int int3 = color2.getGreen();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        double double5 = categoryPlot4.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis7.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis7.getTickMarkPosition();
        java.awt.Stroke stroke11 = dateAxis7.getAxisLineStroke();
        dateAxis7.setLowerBound((double) 8);
        java.awt.Shape shape14 = dateAxis7.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.configureRangeAxes();
        java.awt.Stroke stroke17 = xYPlot15.getDomainCrosshairStroke();
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot15.setNoDataMessageFont(font18);
        dateAxis7.setTickLabelFont(font18);
        org.jfree.data.Range range21 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition26 = dateAxis23.getTickMarkPosition();
        java.awt.Stroke stroke27 = dateAxis23.getAxisLineStroke();
        double double28 = dateAxis23.getLowerBound();
        java.awt.Font font29 = dateAxis23.getTickLabelFont();
        categoryPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke34 = intervalMarker33.getStroke();
        java.awt.Paint paint35 = intervalMarker33.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker33.setLabelTextAnchor(textAnchor36);
        java.awt.Stroke stroke38 = intervalMarker33.getStroke();
        dateAxis23.setTickMarkStroke(stroke38);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        xYPlot40.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        int int44 = xYPlot40.getRangeAxisIndex(valueAxis43);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot40.setNoDataMessagePaint((java.awt.Paint) color45);
        java.awt.image.ColorModel colorModel47 = null;
        java.awt.Rectangle rectangle48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.awt.geom.AffineTransform affineTransform50 = null;
        java.awt.RenderingHints renderingHints51 = null;
        java.awt.PaintContext paintContext52 = color45.createContext(colorModel47, rectangle48, rectangle2D49, affineTransform50, renderingHints51);
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis54.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit57 = dateAxis54.getTickUnit();
        java.awt.Stroke stroke58 = dateAxis54.getAxisLineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((double) '4', (double) (byte) 100, (java.awt.Paint) color2, stroke38, (java.awt.Paint) color45, stroke58, 0.0f);
        java.awt.Color color61 = java.awt.Color.yellow;
        java.awt.Color color62 = java.awt.Color.green;
        int int63 = color62.getAlpha();
        float[] floatArray69 = new float[] { 4, 1.0f, 128, 5, 255 };
        float[] floatArray70 = color62.getRGBComponents(floatArray69);
        float[] floatArray71 = color61.getRGBComponents(floatArray69);
        float[] floatArray72 = color45.getColorComponents(floatArray69);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(dateTickMarkPosition26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(paintContext52);
        org.junit.Assert.assertNotNull(dateTickUnit57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 255 + "'", int63 == 255);
        org.junit.Assert.assertNotNull(floatArray69);
        org.junit.Assert.assertNotNull(floatArray70);
        org.junit.Assert.assertNotNull(floatArray71);
        org.junit.Assert.assertNotNull(floatArray72);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19);
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot24.setDataset(xYDataset25);
        org.jfree.chart.plot.Plot plot27 = xYPlot24.getRootPlot();
        java.awt.geom.Point2D point2D28 = xYPlot24.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(4.0d, plotRenderingInfo23, point2D28, true);
        int int31 = categoryPlot0.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(plot27);
        org.junit.Assert.assertNotNull(point2D28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker5.setKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addDomainMarker((-1), categoryMarker5, layer8, false);
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot0.setDomainAxisLocation(10, axisLocation12);
        boolean boolean14 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Layer.BACKGROUND");
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean24 = axisLocation22.equals((java.lang.Object) 128);
        categoryPlot20.setRangeAxisLocation((int) (byte) 10, axisLocation22);
        categoryPlot20.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot20.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj33 = categoryAxis32.clone();
        java.awt.Font font35 = categoryAxis32.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot20.setDomainAxis((int) (short) 10, categoryAxis32);
        java.util.List list37 = categoryPlot0.getCategoriesForAxis(categoryAxis32);
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke41 = intervalMarker40.getStroke();
        categoryPlot0.setRangeGridlineStroke(stroke41);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis44.setLabelAngle(0.0d);
        java.util.Date date47 = dateAxis44.getMaximumDate();
        double double48 = dateAxis44.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = dateAxis44.getTickLabelInsets();
        org.jfree.chart.plot.Plot plot50 = dateAxis44.getPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = dateAxis44.getLabelInsets();
        categoryPlot0.setAxisOffset(rectangleInsets51);
        org.jfree.data.category.CategoryDataset categoryDataset54 = categoryPlot0.getDataset(1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNull(plot50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNull(categoryDataset54);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis1.configure();
        java.lang.Object obj3 = categoryAxis1.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis2.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis2.getTickMarkPosition();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis2.setLeftArrow(shape6);
        boolean boolean8 = dateAxis2.isVerticalTickLabels();
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis12.setLabelAngle(0.0d);
        java.util.Date date15 = dateAxis12.getMaximumDate();
        java.util.Date date16 = dateAxis12.getMaximumDate();
        boolean boolean17 = day10.equals((java.lang.Object) dateAxis12);
        java.util.Date date18 = day10.getStart();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date18);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis21.setLabelAngle(0.0d);
        java.util.Date date24 = dateAxis21.getMaximumDate();
        double double25 = dateAxis21.getUpperMargin();
        dateAxis21.setTickLabelsVisible(true);
        java.util.Date date28 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis21.setMaximumDate(date28);
        dateAxis2.setRange(date18, date28);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date18, timeZone31);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("PlotOrientation.HORIZONTAL", timeZone31);
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot0.getDomainAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot0.setRenderer(categoryItemRenderer7);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(categoryAxis6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        java.util.Date date5 = dateAxis1.getMaximumDate();
        dateAxis1.setUpperBound((double) 'a');
        double double8 = dateAxis1.getUpperMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        double double10 = categoryPlot9.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis12.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = dateAxis12.getTickMarkPosition();
        java.awt.Stroke stroke16 = dateAxis12.getAxisLineStroke();
        dateAxis12.setLowerBound((double) 8);
        java.awt.Shape shape19 = dateAxis12.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        xYPlot20.configureRangeAxes();
        java.awt.Stroke stroke22 = xYPlot20.getDomainCrosshairStroke();
        java.awt.Font font23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot20.setNoDataMessageFont(font23);
        dateAxis12.setTickLabelFont(font23);
        org.jfree.data.Range range26 = categoryPlot9.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis12);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean33 = axisLocation31.equals((java.lang.Object) 128);
        categoryPlot29.setRangeAxisLocation((int) (byte) 10, axisLocation31);
        categoryPlot29.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation38 = categoryPlot29.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj42 = categoryAxis41.clone();
        java.awt.Font font44 = categoryAxis41.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot29.setDomainAxis((int) (short) 10, categoryAxis41);
        java.util.List list46 = categoryPlot9.getCategoriesForAxis(categoryAxis41);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = categoryPlot9.getInsets();
        boolean boolean48 = dateAxis1.hasListener((java.util.EventListener) categoryPlot9);
        org.jfree.chart.plot.IntervalMarker intervalMarker51 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color52 = java.awt.Color.GRAY;
        intervalMarker51.setOutlinePaint((java.awt.Paint) color52);
        categoryPlot9.setDomainGridlinePaint((java.awt.Paint) color52);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(color52);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        int int11 = xYPlot0.getBackgroundImageAlignment();
        xYPlot0.setDomainGridlinesVisible(true);
        double double14 = xYPlot0.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation17 = null;
        try {
            boolean boolean19 = xYPlot0.removeAnnotation(xYAnnotation17, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(xYDataset16);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        java.lang.String str5 = intervalMarker2.getLabel();
        java.awt.Color color6 = java.awt.Color.orange;
        intervalMarker2.setPaint((java.awt.Paint) color6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        int int12 = xYPlot8.getRangeAxisIndex(valueAxis11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.configureRangeAxes();
        java.awt.Stroke stroke15 = xYPlot13.getDomainCrosshairStroke();
        xYPlot8.setRangeGridlineStroke(stroke15);
        intervalMarker2.setOutlineStroke(stroke15);
        java.awt.Stroke stroke18 = intervalMarker2.getStroke();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker1);
        org.jfree.chart.plot.Marker marker3 = markerChangeEvent2.getMarker();
        java.lang.Object obj4 = markerChangeEvent2.getSource();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis6.setLabelAngle(0.0d);
        java.util.Date date9 = dateAxis6.getMaximumDate();
        double double10 = dateAxis6.getUpperMargin();
        dateAxis6.setTickLabelsVisible(true);
        dateAxis6.setLabel("RectangleAnchor.TOP");
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis16.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis16.getTickUnit();
        java.awt.Shape shape20 = dateAxis16.getLeftArrow();
        dateAxis6.setLeftArrow(shape20);
        boolean boolean22 = dateAxis6.isVerticalTickLabels();
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.util.SortOrder sortOrder25 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder25, jFreeChart26);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType28 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent27.setType(chartChangeEventType28);
        boolean boolean30 = categoryAnchor24.equals((java.lang.Object) chartChangeEventType28);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis6, jFreeChart23, chartChangeEventType28);
        markerChangeEvent2.setType(chartChangeEventType28);
        java.lang.String str33 = markerChangeEvent2.toString();
        org.junit.Assert.assertNotNull(marker3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(categoryAnchor24);
        org.junit.Assert.assertNotNull(sortOrder25);
        org.junit.Assert.assertNotNull(chartChangeEventType28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = xYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.configureRangeAxes();
        java.awt.Stroke stroke8 = xYPlot6.getDomainCrosshairStroke();
        xYPlot1.setRangeGridlineStroke(stroke8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot1.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot1.getDomainAxis(0);
        xYPlot1.setDomainCrosshairValue((double) 8, false);
        java.awt.Stroke stroke17 = xYPlot1.getDomainGridlineStroke();
        categoryPlot0.setDomainGridlineStroke(stroke17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot0.getDomainAxis((int) (byte) -1);
        categoryPlot0.setAnchorValue((double) (byte) 100, true);
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(categoryAxis20);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        double double4 = intervalMarker2.getEndValue();
        java.awt.Paint paint5 = intervalMarker2.getPaint();
        java.awt.Paint paint6 = intervalMarker2.getPaint();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = xYPlot7.getRangeAxisIndex(valueAxis10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color12);
        java.awt.Paint paint14 = xYPlot7.getRangeCrosshairPaint();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot7.setDomainZeroBaselineStroke(stroke15);
        intervalMarker2.setStroke(stroke15);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis1.configure();
        java.awt.Stroke stroke3 = categoryAxis1.getAxisLineStroke();
        double double4 = categoryAxis1.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        xYPlot7.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean11 = xYPlot7.equals((java.lang.Object) dateTickUnit10);
        dateAxis6.setTickUnit(dateTickUnit10);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) dateTickUnit10, "RectangleAnchor.TOP");
        double double15 = categoryAxis1.getLowerMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean17 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot16);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.configureRangeAxes();
        xYPlot3.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean7 = xYPlot3.equals((java.lang.Object) dateTickUnit6);
        dateAxis2.setTickUnit(dateTickUnit6);
        boolean boolean9 = axisLocation0.equals((java.lang.Object) dateAxis2);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation10);
        java.lang.String str12 = plotOrientation10.toString();
        java.lang.String str13 = plotOrientation10.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PlotOrientation.VERTICAL" + "'", str12.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotOrientation.VERTICAL" + "'", str13.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray6 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, paintArray3, strokeArray4, strokeArray5, shapeArray6);
        java.awt.Paint[] paintArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray9 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray11 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray2, paintArray8, strokeArray9, strokeArray10, shapeArray11);
        java.awt.Paint paint13 = defaultDrawingSupplier12.getNextFillPaint();
        java.awt.Stroke stroke14 = defaultDrawingSupplier12.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(strokeArray5);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1.0f), jFreeChart3, chartChangeEventType4);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) false, jFreeChart1, chartChangeEventType4);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        boolean boolean7 = dateAxis1.isAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis9.setLabelAngle(0.0d);
        java.util.Date date12 = dateAxis9.getMaximumDate();
        double double13 = dateAxis9.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis9.getTickLabelInsets();
        org.jfree.chart.plot.Plot plot15 = dateAxis9.getPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = dateAxis9.getLabelInsets();
        dateAxis1.setLabelInsets(rectangleInsets16);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        int int11 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateTopInset((double) (byte) 0);
        double double16 = rectangleInsets12.calculateRightOutset((double) 10.0f);
        xYPlot0.setInsets(rectangleInsets12, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean23 = axisLocation21.equals((java.lang.Object) 128);
        categoryPlot19.setRangeAxisLocation((int) (byte) 10, axisLocation21);
        int int25 = categoryPlot19.getDomainAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot19.getLegendItems();
        xYPlot0.setFixedLegendItems(legendItemCollection26);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(legendItemCollection26);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = xYPlot0.equals((java.lang.Object) dateTickUnit3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = xYPlot0.getRendererForDataset(xYDataset7);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNull(xYItemRenderer8);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color3 = java.awt.Color.GRAY;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color3);
        intervalMarker2.setStartValue((double) 8);
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 8, jFreeChart7);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot0.getDataRange(valueAxis8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10, true);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker5.setKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addDomainMarker((-1), categoryMarker5, layer8, false);
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot0.setDomainAxisLocation(10, axisLocation12);
        java.awt.Paint paint14 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot0.getDomainAxis();
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryAxis15);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) (byte) 100, plotRenderingInfo4, point2D5, true);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray8 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray8);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke13 = intervalMarker12.getStroke();
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        intervalMarker12.setLabelTextAnchor(textAnchor14);
        boolean boolean16 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker12);
        java.awt.Font font18 = intervalMarker12.getLabelFont();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(xYItemRendererArray8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot0.getDataRange(valueAxis8);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        xYPlot11.setDataset(xYDataset12);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.configureRangeAxes();
        xYPlot15.setDomainCrosshairValue((double) '#');
        xYPlot15.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot15.setDomainAxisLocation(axisLocation21);
        xYPlot11.setRangeAxisLocation((int) 'a', axisLocation21, true);
        categoryPlot0.setRangeAxisLocation(0, axisLocation21);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot0.getFixedLegendItems();
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(legendItemCollection26);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.setDomainCrosshairValue((double) '#');
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = xYPlot0.getDatasetRenderingOrder();
        java.lang.String str7 = datasetRenderingOrder6.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str7.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj21 = null;
        boolean boolean22 = plotOrientation20.equals(obj21);
        categoryPlot0.setOrientation(plotOrientation20);
        java.awt.Stroke stroke24 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = xYPlot0.equals((java.lang.Object) dateTickUnit3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot0.getDomainAxisLocation(9);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.configureRangeAxes();
        xYPlot8.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke14 = intervalMarker13.getStroke();
        java.awt.Paint paint15 = intervalMarker13.getOutlinePaint();
        java.lang.String str16 = intervalMarker13.getLabel();
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean18 = xYPlot8.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13, layer17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = intervalMarker13.getLabelOffset();
        org.jfree.chart.util.SortOrder sortOrder20 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder20, jFreeChart21);
        boolean boolean23 = intervalMarker13.equals((java.lang.Object) chartChangeEvent22);
        java.awt.Font font24 = intervalMarker13.getLabelFont();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = null;
        intervalMarker13.setGradientPaintTransformer(gradientPaintTransformer25);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker13);
        xYPlot0.markerChanged(markerChangeEvent27);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createOutsetRectangle(rectangle2D2, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj3 = categoryAxis2.clone();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis2.setMaximumCategoryLabelLines((int) (byte) 1);
        double double8 = categoryAxis2.getLowerMargin();
        boolean boolean9 = categoryAxis2.isTickMarksVisible();
        categoryAxis2.setCategoryLabelPositionOffset(3);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer13);
        java.lang.String str15 = categoryPlot14.getNoDataMessage();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainMarkers((int) '4');
        categoryPlot0.setAnchorValue(4.0d, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean10 = axisLocation8.equals((java.lang.Object) 128);
        categoryPlot6.setRangeAxisLocation((int) (byte) 10, axisLocation8);
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot6.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj19 = categoryAxis18.clone();
        java.awt.Font font21 = categoryAxis18.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot6.setDomainAxis((int) (short) 10, categoryAxis18);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker24.setKey((java.lang.Comparable) 10);
        java.lang.Object obj27 = null;
        boolean boolean28 = categoryMarker24.equals(obj27);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        double double30 = categoryPlot29.getRangeCrosshairValue();
        categoryPlot29.clearDomainMarkers();
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker34.setKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot29.addDomainMarker((-1), categoryMarker34, layer37, false);
        boolean boolean40 = categoryPlot6.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker24, layer37);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        xYPlot41.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        int int45 = xYPlot41.getRangeAxisIndex(valueAxis44);
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot();
        xYPlot46.configureRangeAxes();
        java.awt.Stroke stroke48 = xYPlot46.getDomainCrosshairStroke();
        xYPlot41.setRangeGridlineStroke(stroke48);
        org.jfree.chart.plot.IntervalMarker intervalMarker52 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke53 = intervalMarker52.getStroke();
        java.awt.Paint paint54 = intervalMarker52.getOutlinePaint();
        java.lang.String str55 = intervalMarker52.getLabel();
        java.awt.Color color56 = java.awt.Color.orange;
        intervalMarker52.setPaint((java.awt.Paint) color56);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot41.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker52, layer58);
        java.lang.String str60 = layer58.toString();
        categoryPlot0.addDomainMarker(categoryMarker24, layer58);
        java.awt.Paint[] paintArray62 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray63 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray64 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray65 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray66 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray67 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier68 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray62, paintArray63, paintArray64, strokeArray65, strokeArray66, shapeArray67);
        java.awt.Paint paint69 = defaultDrawingSupplier68.getNextFillPaint();
        categoryMarker24.setLabelPaint(paint69);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Layer.BACKGROUND" + "'", str60.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertNotNull(paintArray62);
        org.junit.Assert.assertNotNull(paintArray63);
        org.junit.Assert.assertNotNull(paintArray64);
        org.junit.Assert.assertNotNull(strokeArray65);
        org.junit.Assert.assertNotNull(strokeArray66);
        org.junit.Assert.assertNotNull(paint69);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        double double7 = dateAxis3.getUpperMargin();
        dateAxis3.setTickLabelsVisible(true);
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis3.setMaximumDate(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date10, timeZone12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis16.setLabelAngle(0.0d);
        java.util.Date date19 = dateAxis16.getMaximumDate();
        java.util.Date date20 = dateAxis16.getMaximumDate();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date20, timeZone21);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone21);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(tickUnitSource23);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = xYPlot0.equals((java.lang.Object) dateTickUnit3);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        java.lang.Comparable comparable9 = categoryMarker8.getKey();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker8);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        int int17 = xYPlot13.getRangeAxisIndex(valueAxis16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.configureRangeAxes();
        java.awt.Stroke stroke20 = xYPlot18.getDomainCrosshairStroke();
        xYPlot13.setRangeGridlineStroke(stroke20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        java.lang.String str27 = intervalMarker24.getLabel();
        java.awt.Color color28 = java.awt.Color.orange;
        intervalMarker24.setPaint((java.awt.Paint) color28);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24, layer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        xYPlot13.addChangeListener(plotChangeListener32);
        float float34 = xYPlot13.getBackgroundImageAlpha();
        java.util.List list35 = xYPlot13.getAnnotations();
        xYPlot0.drawDomainTickBands(graphics2D11, rectangle2D12, list35);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + true + "'", comparable9.equals(true));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.5f + "'", float34 == 0.5f);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19);
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean26 = axisLocation24.equals((java.lang.Object) 128);
        categoryPlot22.setRangeAxisLocation((int) (byte) 10, axisLocation24);
        categoryPlot22.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot22.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj35 = categoryAxis34.clone();
        java.awt.Font font37 = categoryAxis34.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot22.setDomainAxis((int) (short) 10, categoryAxis34);
        java.awt.Color color39 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass40 = color39.getClass();
        categoryPlot22.setRangeCrosshairPaint((java.awt.Paint) color39);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot22.getRangeAxisForDataset(255);
        categoryPlot22.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot22.getDomainAxisLocation(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = categoryPlot22.getOrientation();
        categoryPlot22.clearRangeMarkers();
        boolean boolean51 = sortOrder18.equals((java.lang.Object) categoryPlot22);
        categoryPlot22.configureRangeAxes();
        categoryPlot22.mapDatasetToRangeAxis(11, 1);
        org.jfree.chart.axis.AxisSpace axisSpace56 = null;
        categoryPlot22.setFixedRangeAxisSpace(axisSpace56);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(plotOrientation49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        xYPlot0.mapDatasetToDomainAxis(4, 10);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker7.setKey((java.lang.Comparable) 10);
        java.lang.Object obj10 = null;
        boolean boolean11 = categoryMarker7.equals(obj10);
        categoryMarker7.setDrawAsLine(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryMarker7.getLabelOffset();
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        int int4 = day1.getMonth();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP;
        intervalMarker2.setLabelAnchor(rectangleAnchor5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = intervalMarker2.getLabelOffsetType();
        intervalMarker2.setAlpha(0.0f);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        intervalMarker2.setLabel("hi!");
        java.awt.Font font6 = intervalMarker2.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = intervalMarker2.getLabelOffset();
        java.lang.Object obj8 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot7.setDataset(xYDataset8);
        org.jfree.chart.plot.Plot plot10 = xYPlot7.getRootPlot();
        java.awt.geom.Point2D point2D11 = xYPlot7.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo6, point2D11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke14 = categoryPlot0.getOutlineStroke();
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker5.setKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addDomainMarker((-1), categoryMarker5, layer8, false);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace11, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot0.setRenderer(11, categoryItemRenderer15);
        org.jfree.data.general.DatasetGroup datasetGroup17 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNull(datasetGroup17);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.clearDomainMarkers((-1));
        java.awt.Stroke stroke6 = xYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) (byte) 100, plotRenderingInfo4, point2D5, true);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray8 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray8);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke13 = intervalMarker12.getStroke();
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        intervalMarker12.setLabelTextAnchor(textAnchor14);
        boolean boolean16 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker12);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color20 = java.awt.Color.green;
        categoryPlot19.setDomainGridlinePaint((java.awt.Paint) color20);
        categoryPlot19.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot26.setDataset(xYDataset27);
        org.jfree.chart.plot.Plot plot29 = xYPlot26.getRootPlot();
        java.awt.geom.Point2D point2D30 = xYPlot26.getQuadrantOrigin();
        categoryPlot19.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo25, point2D30);
        java.util.List list32 = categoryPlot19.getAnnotations();
        xYPlot0.drawRangeTickBands(graphics2D17, rectangle2D18, list32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        org.jfree.chart.plot.CrosshairState crosshairState38 = null;
        boolean boolean39 = xYPlot0.render(graphics2D34, rectangle2D35, 128, plotRenderingInfo37, crosshairState38);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color43 = java.awt.Color.GRAY;
        intervalMarker42.setOutlinePaint((java.awt.Paint) color43);
        intervalMarker42.setStartValue((double) 8);
        intervalMarker42.setStartValue((double) (byte) 100);
        boolean boolean49 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(xYItemRendererArray8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(plot29);
        org.junit.Assert.assertNotNull(point2D30);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = xYPlot0.getDrawingSupplier();
        double double33 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = xYPlot0.getAxisOffset();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(drawingSupplier32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke4 = intervalMarker3.getStroke();
        java.awt.Paint paint5 = intervalMarker3.getOutlinePaint();
        java.awt.Stroke stroke6 = null;
        java.awt.Paint paint7 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker9.setKey((java.lang.Comparable) 10);
        java.lang.Object obj12 = null;
        boolean boolean13 = categoryMarker9.equals(obj12);
        java.awt.Stroke stroke14 = categoryMarker9.getOutlineStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", paint5, stroke6, paint7, stroke14, (float) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxisForDataset(255);
        categoryPlot0.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot0.getDomainAxisLocation(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis29.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition32 = dateAxis29.getTickMarkPosition();
        java.awt.Stroke stroke33 = dateAxis29.getAxisLineStroke();
        dateAxis29.setLowerBound((double) 8);
        int int36 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis29);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean41 = axisLocation39.equals((java.lang.Object) 128);
        categoryPlot37.setRangeAxisLocation((int) (byte) 10, axisLocation39);
        org.jfree.chart.axis.AxisLocation axisLocation43 = axisLocation39.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation43, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis48.configure();
        java.awt.Stroke stroke50 = categoryAxis48.getAxisLineStroke();
        categoryPlot0.setDomainAxis((int) (short) 0, categoryAxis48);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(dateTickMarkPosition32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke6 = intervalMarker5.getStroke();
        java.awt.Paint paint7 = intervalMarker5.getOutlinePaint();
        java.lang.String str8 = intervalMarker5.getLabel();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        int int16 = xYPlot12.getRangeAxisIndex(valueAxis15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        xYPlot17.configureRangeAxes();
        java.awt.Stroke stroke19 = xYPlot17.getDomainCrosshairStroke();
        xYPlot12.setRangeGridlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke24 = intervalMarker23.getStroke();
        java.awt.Paint paint25 = intervalMarker23.getOutlinePaint();
        java.lang.String str26 = intervalMarker23.getLabel();
        java.awt.Color color27 = java.awt.Color.orange;
        intervalMarker23.setPaint((java.awt.Paint) color27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot12.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker23, layer29);
        java.lang.String str31 = layer29.toString();
        java.util.Collection collection32 = xYPlot0.getRangeMarkers(layer29);
        boolean boolean33 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.BACKGROUND" + "'", str31.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        double double6 = dateAxis1.getLowerBound();
        java.awt.Font font7 = dateAxis1.getTickLabelFont();
        dateAxis1.setTickMarksVisible(false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = xYPlot0.getAxisOffset();
        double double5 = rectangleInsets3.calculateRightInset((double) (byte) 0);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            rectangleInsets3.trim(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray5 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray5);
        java.awt.Paint paint7 = defaultDrawingSupplier6.getNextFillPaint();
        java.lang.Object obj8 = defaultDrawingSupplier6.clone();
        java.lang.Object obj9 = defaultDrawingSupplier6.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        xYPlot5.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke11 = intervalMarker10.getStroke();
        java.awt.Paint paint12 = intervalMarker10.getOutlinePaint();
        java.lang.String str13 = intervalMarker10.getLabel();
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean15 = xYPlot5.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer14);
        java.util.Collection collection16 = categoryPlot0.getRangeMarkers(layer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        int int18 = categoryPlot0.getIndexOf(categoryItemRenderer17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot0.setRenderer(categoryItemRenderer19);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(layer14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot0.setRenderer(0, xYItemRenderer33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = dateAxis36.getTickUnit();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis36);
        java.util.Date date39 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis42.setLabelAngle(0.0d);
        java.util.Date date45 = dateAxis42.getMaximumDate();
        java.util.Date date46 = dateAxis42.getMaximumDate();
        boolean boolean47 = day40.equals((java.lang.Object) dateAxis42);
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis49.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition52 = dateAxis49.getTickMarkPosition();
        java.awt.Shape shape53 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis49.setLeftArrow(shape53);
        java.awt.Stroke stroke55 = dateAxis49.getAxisLineStroke();
        dateAxis49.setFixedDimension(0.0d);
        boolean boolean59 = dateAxis49.isHiddenValue((long) 255);
        org.jfree.data.Range range60 = dateAxis49.getDefaultAutoRange();
        dateAxis42.setRange(range60);
        dateAxis36.setRange(range60);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTickUnit37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition52);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(range60);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) (byte) 100, plotRenderingInfo4, point2D5, true);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray8 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot0.zoomDomainAxes((double) (byte) 0, plotRenderingInfo11, point2D12, true);
        int int15 = xYPlot0.getWeight();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(xYItemRendererArray8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        int int11 = xYPlot0.getBackgroundImageAlignment();
        xYPlot0.setDomainGridlinesVisible(true);
        java.awt.Paint paint14 = xYPlot0.getOutlinePaint();
        xYPlot0.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean5 = axisLocation3.equals((java.lang.Object) 128);
        categoryPlot1.setRangeAxisLocation((int) (byte) 10, axisLocation3);
        categoryPlot1.setDrawSharedDomainAxis(true);
        java.awt.Paint paint9 = categoryPlot1.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str11 = rectangleInsets10.toString();
        categoryPlot1.setInsets(rectangleInsets10, false);
        java.awt.Paint paint14 = categoryPlot1.getRangeCrosshairPaint();
        categoryPlot0.setRangeCrosshairPaint(paint14);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str11.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color32);
        float float34 = xYPlot0.getBackgroundAlpha();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        xYPlot0.rendererChanged(rendererChangeEvent35);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.axis.Timeline timeline18 = dateAxis3.getTimeline();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(timeline18);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean24 = axisLocation22.equals((java.lang.Object) 128);
        categoryPlot20.setRangeAxisLocation((int) (byte) 10, axisLocation22);
        categoryPlot20.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot20.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj33 = categoryAxis32.clone();
        java.awt.Font font35 = categoryAxis32.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot20.setDomainAxis((int) (short) 10, categoryAxis32);
        java.util.List list37 = categoryPlot0.getCategoriesForAxis(categoryAxis32);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation38 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation38, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(list37);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
//        dateAxis1.setLabelAngle(0.0d);
//        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
//        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis1.setLeftArrow(shape5);
//        boolean boolean7 = dateAxis1.isVerticalTickLabels();
//        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
//        dateAxis11.setLabelAngle(0.0d);
//        java.util.Date date14 = dateAxis11.getMaximumDate();
//        java.util.Date date15 = dateAxis11.getMaximumDate();
//        boolean boolean16 = day9.equals((java.lang.Object) dateAxis11);
//        java.util.Date date17 = day9.getStart();
//        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date17);
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
//        dateAxis20.setLabelAngle(0.0d);
//        java.util.Date date23 = dateAxis20.getMaximumDate();
//        double double24 = dateAxis20.getUpperMargin();
//        dateAxis20.setTickLabelsVisible(true);
//        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis20.setMaximumDate(date27);
//        dateAxis1.setRange(date17, date27);
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date17, timeZone30);
//        long long32 = day31.getMiddleMillisecond();
//        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("hi!");
//        dateAxis34.setLabelAngle(0.0d);
//        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition37 = dateAxis34.getTickMarkPosition();
//        java.awt.Shape shape38 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis34.setLeftArrow(shape38);
//        boolean boolean40 = dateAxis34.isVerticalTickLabels();
//        int int41 = day31.compareTo((java.lang.Object) dateAxis34);
//        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
//        org.junit.Assert.assertNotNull(shape5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560452399999L + "'", long32 == 1560452399999L);
//        org.junit.Assert.assertNotNull(dateTickMarkPosition37);
//        org.junit.Assert.assertNotNull(shape38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis2.setLabelAngle(0.0d);
        java.util.Date date5 = dateAxis2.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis7.setLabelAngle(0.0d);
        java.util.Date date10 = dateAxis7.getMaximumDate();
        dateAxis2.setMaximumDate(date10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis13.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis13.getTickMarkPosition();
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis13.setLeftArrow(shape17);
        java.awt.Stroke stroke19 = dateAxis13.getAxisLineStroke();
        dateAxis13.setFixedDimension(0.0d);
        boolean boolean23 = dateAxis13.isHiddenValue((long) 255);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer24);
        int int26 = xYPlot25.getDatasetCount();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(1, axisLocation11, true);
        double double14 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(axisSpace15);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        dateAxis1.setTickLabelsVisible(true);
        dateAxis1.setLabel("RectangleAnchor.TOP");
        dateAxis1.setVisible(false);
        dateAxis1.setInverted(false);
        dateAxis1.zoomRange((double) 8, (double) 100);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D4 = xYPlot0.getQuadrantOrigin();
        xYPlot0.clearDomainMarkers();
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = xYPlot7.getRangeAxisIndex(valueAxis10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        xYPlot7.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        xYPlot7.setRangeAxisLocation(5, axisLocation18, false);
        xYPlot7.configureRangeAxes();
        boolean boolean22 = layer6.equals((java.lang.Object) xYPlot7);
        java.util.Collection collection23 = xYPlot0.getRangeMarkers(layer6);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertNotNull(layer6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection23);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        boolean boolean7 = dateAxis1.isVerticalTickLabels();
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis11.setLabelAngle(0.0d);
        java.util.Date date14 = dateAxis11.getMaximumDate();
        java.util.Date date15 = dateAxis11.getMaximumDate();
        boolean boolean16 = day9.equals((java.lang.Object) dateAxis11);
        java.util.Date date17 = day9.getStart();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis20.setLabelAngle(0.0d);
        java.util.Date date23 = dateAxis20.getMaximumDate();
        double double24 = dateAxis20.getUpperMargin();
        dateAxis20.setTickLabelsVisible(true);
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis20.setMaximumDate(date27);
        dateAxis1.setRange(date17, date27);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date17, timeZone30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        double double33 = categoryPlot32.getRangeCrosshairValue();
        java.awt.Stroke stroke34 = categoryPlot32.getRangeGridlineStroke();
        boolean boolean35 = day31.equals((java.lang.Object) categoryPlot32);
        categoryPlot32.setAnchorValue((double) 0.5f, true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color30);
        org.jfree.chart.axis.AxisSpace axisSpace32 = xYPlot0.getFixedRangeAxisSpace();
        xYPlot0.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(axisSpace32);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.Plot plot9 = xYPlot0.getParent();
        xYPlot0.clearDomainMarkers();
        java.awt.Image image11 = xYPlot0.getBackgroundImage();
        java.awt.Paint paint12 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj3 = categoryAxis2.clone();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis2.setMaximumCategoryLabelLines((int) (byte) 1);
        double double8 = categoryAxis2.getLowerMargin();
        boolean boolean9 = categoryAxis2.isTickMarksVisible();
        categoryAxis2.setCategoryLabelPositionOffset(3);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis16.setLabelAngle(0.0d);
        java.util.Date date19 = dateAxis16.getMaximumDate();
        java.util.Date date20 = dateAxis16.getMaximumDate();
        dateAxis16.setUpperBound((double) 'a');
        double double23 = dateAxis16.getUpperMargin();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        double double25 = categoryPlot24.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis27.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition30 = dateAxis27.getTickMarkPosition();
        java.awt.Stroke stroke31 = dateAxis27.getAxisLineStroke();
        dateAxis27.setLowerBound((double) 8);
        java.awt.Shape shape34 = dateAxis27.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        xYPlot35.configureRangeAxes();
        java.awt.Stroke stroke37 = xYPlot35.getDomainCrosshairStroke();
        java.awt.Font font38 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot35.setNoDataMessageFont(font38);
        dateAxis27.setTickLabelFont(font38);
        org.jfree.data.Range range41 = categoryPlot24.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis27);
        categoryPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean48 = axisLocation46.equals((java.lang.Object) 128);
        categoryPlot44.setRangeAxisLocation((int) (byte) 10, axisLocation46);
        categoryPlot44.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation53 = categoryPlot44.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj57 = categoryAxis56.clone();
        java.awt.Font font59 = categoryAxis56.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot44.setDomainAxis((int) (short) 10, categoryAxis56);
        java.util.List list61 = categoryPlot24.getCategoriesForAxis(categoryAxis56);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = categoryPlot24.getInsets();
        boolean boolean63 = dateAxis16.hasListener((java.util.EventListener) categoryPlot24);
        dateAxis16.setPositiveArrowVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot();
        xYPlot66.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        int int70 = xYPlot66.getRangeAxisIndex(valueAxis69);
        org.jfree.chart.plot.XYPlot xYPlot71 = new org.jfree.chart.plot.XYPlot();
        xYPlot71.configureRangeAxes();
        java.awt.Stroke stroke73 = xYPlot71.getDomainCrosshairStroke();
        xYPlot66.setRangeGridlineStroke(stroke73);
        org.jfree.chart.axis.AxisSpace axisSpace75 = null;
        xYPlot66.setFixedDomainAxisSpace(axisSpace75);
        org.jfree.chart.axis.ValueAxis valueAxis78 = xYPlot66.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis81 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis81.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit84 = dateAxis81.getTickUnit();
        java.awt.Shape shape85 = dateAxis81.getLeftArrow();
        xYPlot66.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis81, true);
        dateAxis81.setLabelToolTip("ChartChangeEventType.NEW_DATASET");
        java.awt.Font font90 = dateAxis81.getLabelFont();
        dateAxis81.setTickLabelsVisible(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit93 = dateAxis81.getTickUnit();
        java.util.Date date94 = dateAxis16.calculateHighestVisibleTickValue(dateTickUnit93);
        java.util.Date date95 = dateAxis12.calculateHighestVisibleTickValue(dateTickUnit93);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNull(range41);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNull(valueAxis78);
        org.junit.Assert.assertNotNull(dateTickUnit84);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(font90);
        org.junit.Assert.assertNotNull(dateTickUnit93);
        org.junit.Assert.assertNotNull(date94);
        org.junit.Assert.assertNotNull(date95);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        java.lang.String str5 = intervalMarker2.getLabel();
        java.awt.Color color6 = java.awt.Color.orange;
        intervalMarker2.setPaint((java.awt.Paint) color6);
        int int8 = color6.getTransparency();
        org.jfree.chart.util.SortOrder sortOrder9 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder9, jFreeChart10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent11.setType(chartChangeEventType12);
        boolean boolean14 = color6.equals((java.lang.Object) chartChangeEvent11);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = chartChangeEvent11.getType();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        java.util.Date date7 = dateAxis3.getMaximumDate();
        boolean boolean8 = day1.equals((java.lang.Object) dateAxis3);
        java.util.Date date9 = day1.getStart();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("CategoryAnchor.MIDDLE");
        int int12 = day1.compareTo((java.lang.Object) "CategoryAnchor.MIDDLE");
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean17 = axisLocation15.equals((java.lang.Object) 128);
        categoryPlot13.setRangeAxisLocation((int) (byte) 10, axisLocation15);
        categoryPlot13.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot13.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj26 = categoryAxis25.clone();
        java.awt.Font font28 = categoryAxis25.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot13.setDomainAxis((int) (short) 10, categoryAxis25);
        java.awt.Color color30 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass31 = color30.getClass();
        categoryPlot13.setRangeCrosshairPaint((java.awt.Paint) color30);
        java.awt.color.ColorSpace colorSpace33 = color30.getColorSpace();
        boolean boolean34 = day1.equals((java.lang.Object) color30);
        int int35 = day1.getMonth();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(colorSpace33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxisForDataset(255);
        categoryPlot0.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis26.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = dateAxis26.getTickUnit();
        java.awt.Shape shape30 = dateAxis26.getLeftArrow();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray31 = new org.jfree.chart.axis.ValueAxis[] { dateAxis26 };
        categoryPlot0.setRangeAxes(valueAxisArray31);
        categoryPlot0.setAnchorValue((double) 1.0f, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean40 = axisLocation38.equals((java.lang.Object) 128);
        categoryPlot36.setRangeAxisLocation((int) (byte) 10, axisLocation38);
        categoryPlot36.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.data.Range range45 = categoryPlot36.getDataRange(valueAxis44);
        double double46 = categoryPlot36.getAnchorValue();
        java.awt.Color color49 = java.awt.Color.getColor("PlotOrientation.HORIZONTAL", 10);
        categoryPlot36.setRangeGridlinePaint((java.awt.Paint) color49);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color49);
        org.jfree.chart.plot.CategoryMarker categoryMarker54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker54.setKey((java.lang.Comparable) 10);
        java.lang.Object obj57 = null;
        boolean boolean58 = categoryMarker54.equals(obj57);
        java.awt.Stroke stroke59 = categoryMarker54.getOutlineStroke();
        org.jfree.chart.util.Layer layer60 = null;
        try {
            categoryPlot0.addDomainMarker(11, categoryMarker54, layer60, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(valueAxisArray31);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(range45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.Plot plot9 = xYPlot0.getParent();
        xYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis12.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = dateAxis12.getTickMarkPosition();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis12.setLeftArrow(shape16);
        int int18 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.axis.Timeline timeline19 = null;
        dateAxis12.setTimeline(timeline19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis22.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition25 = dateAxis22.getTickMarkPosition();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis22.setLeftArrow(shape26);
        boolean boolean28 = dateAxis22.isAutoRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double30 = rectangleInsets29.getRight();
        dateAxis22.setTickLabelInsets(rectangleInsets29);
        dateAxis12.setTickLabelInsets(rectangleInsets29);
        java.lang.Class<?> wildcardClass33 = dateAxis12.getClass();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition34 = dateAxis12.getTickMarkPosition();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dateTickMarkPosition25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(dateTickMarkPosition34);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis4.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis4.getTickMarkPosition();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setLeftArrow(shape8);
        boolean boolean10 = dateAxis4.isVerticalTickLabels();
        int int11 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot0.getRendererForDataset(categoryDataset12);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer13);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot0.setRangeAxisLocation(5, axisLocation11, false);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.configureRangeAxes();
        xYPlot14.setDomainCrosshairValue((double) '#');
        xYPlot14.setDomainCrosshairLockedOnData(false);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot14);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color21);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj2 = categoryAxis1.clone();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 1);
        double double7 = categoryAxis1.getLowerMargin();
        boolean boolean8 = categoryAxis1.isTickMarksVisible();
        categoryAxis1.setCategoryLabelPositionOffset(3);
        categoryAxis1.setUpperMargin(6.0d);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.awt.Color color1 = java.awt.Color.getColor("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = xYPlot0.equals((java.lang.Object) dateTickUnit3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        xYPlot0.rendererChanged(rendererChangeEvent7);
        xYPlot0.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str3 = chartChangeEventType2.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) false, jFreeChart1, chartChangeEventType2);
        java.lang.String str5 = chartChangeEventType2.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str3.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str5.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        org.jfree.chart.plot.Plot plot7 = dateAxis1.getPlot();
        java.util.TimeZone timeZone8 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis10.setLabelAngle(0.0d);
        java.util.Date date13 = dateAxis10.getMaximumDate();
        double double14 = dateAxis10.getUpperMargin();
        dateAxis10.setTickLabelsVisible(true);
        dateAxis10.setAutoRangeMinimumSize((double) '4');
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis22.setLabelAngle(0.0d);
        java.util.Date date25 = dateAxis22.getMaximumDate();
        java.util.Date date26 = dateAxis22.getMaximumDate();
        boolean boolean27 = day20.equals((java.lang.Object) dateAxis22);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis29.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition32 = dateAxis29.getTickMarkPosition();
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis29.setLeftArrow(shape33);
        java.awt.Stroke stroke35 = dateAxis29.getAxisLineStroke();
        dateAxis29.setFixedDimension(0.0d);
        boolean boolean39 = dateAxis29.isHiddenValue((long) 255);
        org.jfree.data.Range range40 = dateAxis29.getDefaultAutoRange();
        dateAxis22.setRange(range40);
        org.jfree.data.time.DateRange dateRange42 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange42);
        dateAxis10.setRange((org.jfree.data.Range) dateRange42, false, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange42, false, true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(dateRange42);
    }
}

