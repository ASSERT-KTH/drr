import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getGreen();
        int int2 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Font font4 = null;
        try {
            intervalMarker2.setLabelFont(font4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        java.awt.Font font5 = null;
        try {
            intervalMarker2.setLabelFont(font5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder0, jFreeChart1);
        java.lang.Object obj3 = chartChangeEvent2.getSource();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) 10);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D3, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str1.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        try {
            xYPlot0.setDomainAxisLocation(0, axisLocation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            xYPlot0.drawBackground(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray7 = new float[] { (byte) -1, 10, 10L, 5, (short) 0 };
        try {
            float[] floatArray8 = color0.getComponents(colorSpace1, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = java.awt.Color.RGBtoHSB(0, (int) (short) 0, (int) '4', floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) (short) 1, xYItemRenderer2, false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 1, (float) 0, 2.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-2) + "'", int3 == (-2));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color3 = java.awt.Color.GRAY;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color3);
        int int5 = color3.getGreen();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 128 + "'", int5 == 128);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.Point2D point2D23 = null;
        org.jfree.chart.plot.PlotState plotState24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        try {
            xYPlot0.draw(graphics2D21, rectangle2D22, point2D23, plotState24, plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.util.List list12 = null;
        xYPlot0.drawRangeTickBands(graphics2D10, rectangle2D11, list12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        java.lang.String str2 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str2.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Color color2 = java.awt.Color.getColor("PlotOrientation.HORIZONTAL", 10);
        int int3 = color2.getBlue();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.Plot plot3 = xYPlot0.getParent();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        int int8 = xYPlot4.getRangeAxisIndex(valueAxis7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.configureRangeAxes();
        java.awt.Stroke stroke11 = xYPlot9.getDomainCrosshairStroke();
        xYPlot4.setRangeGridlineStroke(stroke11);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke16 = intervalMarker15.getStroke();
        java.awt.Paint paint17 = intervalMarker15.getOutlinePaint();
        java.lang.String str18 = intervalMarker15.getLabel();
        java.awt.Color color19 = java.awt.Color.orange;
        intervalMarker15.setPaint((java.awt.Paint) color19);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker15, layer21);
        int int23 = xYPlot4.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = xYPlot4.getDrawingSupplier();
        try {
            plot3.setDrawingSupplier(drawingSupplier24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier24);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) 10);
        double double3 = rectangleInsets0.getRight();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createAdjustedRectangle(rectangle2D4, lengthAdjustmentType5, lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        int int13 = xYPlot9.getRangeAxisIndex(valueAxis12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.configureRangeAxes();
        java.awt.Stroke stroke16 = xYPlot14.getDomainCrosshairStroke();
        xYPlot9.setRangeGridlineStroke(stroke16);
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke21 = intervalMarker20.getStroke();
        java.awt.Paint paint22 = intervalMarker20.getOutlinePaint();
        java.lang.String str23 = intervalMarker20.getLabel();
        java.awt.Color color24 = java.awt.Color.orange;
        intervalMarker20.setPaint((java.awt.Paint) color24);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot9.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker20, layer26);
        try {
            boolean boolean28 = xYPlot0.removeRangeMarker(0, marker8, layer26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(layer26);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke6 = intervalMarker5.getStroke();
        java.awt.Paint paint7 = intervalMarker5.getOutlinePaint();
        java.lang.String str8 = intervalMarker5.getLabel();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot0.getRangeAxisForDataset((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 52 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot0.setRenderer(255, xYItemRenderer20);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(128);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis5.setLabelAngle(0.0d);
        java.util.Date date8 = dateAxis5.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis10.setLabelAngle(0.0d);
        java.util.Date date13 = dateAxis10.getMaximumDate();
        try {
            dateAxis1.setRange(date8, date13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis8.setLabelAngle(0.0d);
        java.util.Date date11 = dateAxis8.getMaximumDate();
        try {
            dateAxis1.setRange(date6, date11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        java.awt.Paint paint21 = xYPlot0.getRangeGridlinePaint();
        boolean boolean22 = xYPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = xYPlot0.getAxisOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            xYPlot0.setAxisOffset(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) 10);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D3, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        try {
            dateAxis1.setRange((double) 1.0f, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP" + "'", str1.equals("RectangleAnchor.TOP"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.AxisState axisState23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        xYPlot25.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        int int29 = xYPlot25.getRangeAxisIndex(valueAxis28);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        xYPlot30.configureRangeAxes();
        java.awt.Stroke stroke32 = xYPlot30.getDomainCrosshairStroke();
        xYPlot25.setRangeGridlineStroke(stroke32);
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke37 = intervalMarker36.getStroke();
        java.awt.Paint paint38 = intervalMarker36.getOutlinePaint();
        java.lang.String str39 = intervalMarker36.getLabel();
        java.awt.Color color40 = java.awt.Color.orange;
        intervalMarker36.setPaint((java.awt.Paint) color40);
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot25.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker36, layer42);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = xYPlot25.getRangeAxisEdge(0);
        try {
            java.util.List list46 = dateAxis15.refreshTicks(graphics2D22, axisState23, rectangle2D24, rectangleEdge45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        java.lang.String str5 = intervalMarker2.getLabel();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = xYPlot6.getRangeAxisIndex(valueAxis9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        xYPlot6.setRangeGridlineStroke(stroke13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke18 = intervalMarker17.getStroke();
        java.awt.Paint paint19 = intervalMarker17.getOutlinePaint();
        java.lang.String str20 = intervalMarker17.getLabel();
        java.awt.Color color21 = java.awt.Color.orange;
        intervalMarker17.setPaint((java.awt.Paint) color21);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker17, layer23);
        int int25 = xYPlot6.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = xYPlot6.getDrawingSupplier();
        java.awt.Paint paint27 = xYPlot6.getRangeGridlinePaint();
        intervalMarker2.setPaint(paint27);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        xYPlot0.clearDomainAxes();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            xYPlot0.drawBackground(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        xYPlot0.clearDomainMarkers(100);
        int int5 = xYPlot0.getWeight();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color9 = java.awt.Color.GRAY;
        intervalMarker8.setOutlinePaint((java.awt.Paint) color9);
        intervalMarker8.setStartValue((double) 8);
        intervalMarker8.setStartValue((double) (byte) 100);
        boolean boolean15 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker8);
        java.lang.Object obj16 = intervalMarker8.clone();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace32, false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation35 = null;
        try {
            boolean boolean37 = xYPlot0.removeAnnotation(xYAnnotation35, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke10 = intervalMarker9.getStroke();
        java.awt.Paint paint11 = intervalMarker9.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker9.setLabelTextAnchor(textAnchor12);
        java.awt.Stroke stroke14 = intervalMarker9.getStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            xYPlot0.drawOutline(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke6 = intervalMarker5.getStroke();
        java.awt.Paint paint7 = intervalMarker5.getOutlinePaint();
        java.lang.String str8 = intervalMarker5.getLabel();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer9);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        boolean boolean14 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker13);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot0.getFixedDomainAxisSpace();
        java.awt.geom.Point2D point2D22 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(axisSpace21);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        xYPlot0.setDataset(xYDataset1);
        org.jfree.chart.plot.Plot plot3 = xYPlot0.getRootPlot();
        java.awt.Image image4 = null;
        plot3.setBackgroundImage(image4);
        org.junit.Assert.assertNotNull(plot3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        xYPlot0.clearDomainMarkers(100);
        int int5 = xYPlot0.getWeight();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color9 = java.awt.Color.GRAY;
        intervalMarker8.setOutlinePaint((java.awt.Paint) color9);
        intervalMarker8.setStartValue((double) 8);
        intervalMarker8.setStartValue((double) (byte) 100);
        boolean boolean15 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker8);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.Point2D point2D18 = null;
        org.jfree.chart.plot.PlotState plotState19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            xYPlot0.draw(graphics2D16, rectangle2D17, point2D18, plotState19, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        int int14 = xYPlot10.getRangeAxisIndex(valueAxis13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.configureRangeAxes();
        java.awt.Stroke stroke17 = xYPlot15.getDomainCrosshairStroke();
        xYPlot10.setRangeGridlineStroke(stroke17);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke22 = intervalMarker21.getStroke();
        java.awt.Paint paint23 = intervalMarker21.getOutlinePaint();
        java.lang.String str24 = intervalMarker21.getLabel();
        java.awt.Color color25 = java.awt.Color.orange;
        intervalMarker21.setPaint((java.awt.Paint) color25);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot10.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker21, layer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot10.getRangeAxisEdge(0);
        try {
            double double31 = dateAxis1.dateToJava2D(date7, rectangle2D9, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent2.setType(chartChangeEventType3);
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        org.jfree.chart.plot.Marker marker29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        xYPlot30.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        int int34 = xYPlot30.getRangeAxisIndex(valueAxis33);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke39 = intervalMarker38.getStroke();
        java.awt.Paint paint40 = intervalMarker38.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        xYPlot41.configureRangeAxes();
        xYPlot41.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker46 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke47 = intervalMarker46.getStroke();
        java.awt.Paint paint48 = intervalMarker46.getOutlinePaint();
        java.lang.String str49 = intervalMarker46.getLabel();
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean51 = xYPlot41.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker46, layer50);
        boolean boolean52 = xYPlot30.removeDomainMarker(5, (org.jfree.chart.plot.Marker) intervalMarker38, layer50);
        try {
            xYPlot0.addRangeMarker(marker29, layer50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 0, (int) (byte) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke6 = intervalMarker5.getStroke();
        java.awt.Paint paint7 = intervalMarker5.getOutlinePaint();
        java.lang.String str8 = intervalMarker5.getLabel();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = intervalMarker5.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets11.createInsetRectangle(rectangle2D12, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.Plot plot3 = xYPlot0.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        xYPlot0.datasetChanged(datasetChangeEvent4);
        xYPlot0.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color3 = java.awt.Color.GRAY;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color3);
        intervalMarker2.setStartValue((double) 8);
        intervalMarker2.setStartValue((double) (byte) 100);
        float float9 = intervalMarker2.getAlpha();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 128 + "'", int2 == 128);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = xYPlot0.equals((java.lang.Object) dateTickUnit3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot0.getSeriesRenderingOrder();
        xYPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        boolean boolean7 = dateAxis1.isVerticalTickLabels();
        double double8 = dateAxis1.getLowerBound();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor5);
        java.awt.Paint paint7 = null;
        try {
            intervalMarker2.setLabelPaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.configureRangeAxes();
        xYPlot2.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean6 = xYPlot2.equals((java.lang.Object) dateTickUnit5);
        dateAxis1.setTickUnit(dateTickUnit5);
        try {
            dateAxis1.setRange((double) 1560452399999L, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke6 = intervalMarker5.getStroke();
        java.awt.Paint paint7 = intervalMarker5.getOutlinePaint();
        java.lang.String str8 = intervalMarker5.getLabel();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        org.jfree.chart.plot.Plot plot12 = plotChangeEvent11.getPlot();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(plot12);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        int int11 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        xYPlot0.addChangeListener(plotChangeListener19);
        xYPlot0.setRangeCrosshairValue((double) 128, false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        java.lang.String str5 = intervalMarker2.getLabel();
        java.awt.Color color6 = java.awt.Color.orange;
        intervalMarker2.setPaint((java.awt.Paint) color6);
        int int8 = color6.getTransparency();
        int int9 = color6.getGreen();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 200 + "'", int9 == 200);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        java.awt.Shape shape5 = dateAxis1.getLeftArrow();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        xYPlot7.configureRangeAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        xYPlot7.addChangeListener(plotChangeListener10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        int int17 = xYPlot13.getRangeAxisIndex(valueAxis16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.configureRangeAxes();
        java.awt.Stroke stroke20 = xYPlot18.getDomainCrosshairStroke();
        xYPlot13.setRangeGridlineStroke(stroke20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        java.lang.String str27 = intervalMarker24.getLabel();
        java.awt.Color color28 = java.awt.Color.orange;
        intervalMarker24.setPaint((java.awt.Paint) color28);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24, layer30);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot13.getRangeAxisEdge(0);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace35 = dateAxis1.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) xYPlot7, rectangle2D12, rectangleEdge33, axisSpace34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Color color2 = java.awt.Color.getColor("Layer.BACKGROUND", (int) (byte) 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        boolean boolean7 = dateAxis1.isVerticalTickLabels();
        java.text.DateFormat dateFormat8 = null;
        dateAxis1.setDateFormatOverride(dateFormat8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke4 = intervalMarker3.getStroke();
        java.awt.Paint paint5 = intervalMarker3.getOutlinePaint();
        java.lang.String str6 = intervalMarker3.getLabel();
        java.awt.Color color7 = java.awt.Color.orange;
        intervalMarker3.setPaint((java.awt.Paint) color7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color10 = java.awt.Color.green;
        int int11 = color10.getAlpha();
        java.awt.Stroke stroke12 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 2.0f, (java.awt.Paint) color7, stroke9, (java.awt.Paint) color10, stroke12, (float) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setBackgroundAlpha(0.0f);
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot0.setDomainZeroBaselinePaint(paint5);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, (-1), 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.Plot plot9 = xYPlot0.getParent();
        xYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis12.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = dateAxis12.getTickMarkPosition();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis12.setLeftArrow(shape16);
        int int18 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis12);
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureRangeAxes();
        java.awt.Paint paint3 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        int int5 = xYPlot0.getIndexOf(xYItemRenderer4);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        dateAxis1.setTickMarkInsideLength((float) (byte) -1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis6.setLabelAngle(0.0d);
        java.util.Date date9 = dateAxis6.getMaximumDate();
        dateAxis1.setMaximumDate(date9);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape11);
        try {
            dateAxis1.setRangeWithMargins((double) (byte) 10, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color3 = java.awt.Color.GRAY;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateRightInset((double) 10);
        double double8 = rectangleInsets5.getRight();
        double double9 = rectangleInsets5.getRight();
        intervalMarker2.setLabelOffset(rectangleInsets5);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = xYPlot7.getRangeAxisIndex(valueAxis10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.configureRangeAxes();
        java.awt.Stroke stroke14 = xYPlot12.getDomainCrosshairStroke();
        xYPlot7.setRangeGridlineStroke(stroke14);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke19 = intervalMarker18.getStroke();
        java.awt.Paint paint20 = intervalMarker18.getOutlinePaint();
        java.lang.String str21 = intervalMarker18.getLabel();
        java.awt.Color color22 = java.awt.Color.orange;
        intervalMarker18.setPaint((java.awt.Paint) color22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker18, layer24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot7.getRangeAxisEdge(0);
        try {
            double double28 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) 4, (java.lang.Comparable) "PlotOrientation.HORIZONTAL", categoryDataset4, (double) 2.0f, rectangle2D6, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.Plot plot9 = xYPlot0.getParent();
        xYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis12.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = dateAxis12.getTickMarkPosition();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis12.setLeftArrow(shape16);
        int int18 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis12);
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot22.setDataset(xYDataset23);
        java.lang.Object obj25 = xYPlot22.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot22.getDomainAxisEdge(10);
        try {
            double double28 = dateAxis12.dateToJava2D(date19, rectangle2D21, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke13 = intervalMarker12.getStroke();
        java.awt.Paint paint14 = intervalMarker12.getOutlinePaint();
        java.lang.String str15 = intervalMarker12.getLabel();
        java.awt.Color color16 = java.awt.Color.orange;
        intervalMarker12.setPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        int int22 = xYPlot18.getRangeAxisIndex(valueAxis21);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.configureRangeAxes();
        java.awt.Stroke stroke25 = xYPlot23.getDomainCrosshairStroke();
        xYPlot18.setRangeGridlineStroke(stroke25);
        intervalMarker12.setOutlineStroke(stroke25);
        xYPlot0.setRangeZeroBaselineStroke(stroke25);
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj1 = null;
        boolean boolean2 = plotOrientation0.equals(obj1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) plotOrientation0, jFreeChart3);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke9 = intervalMarker8.getStroke();
        java.awt.Paint paint10 = intervalMarker8.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        xYPlot11.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke17 = intervalMarker16.getStroke();
        java.awt.Paint paint18 = intervalMarker16.getOutlinePaint();
        java.lang.String str19 = intervalMarker16.getLabel();
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean21 = xYPlot11.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker16, layer20);
        boolean boolean22 = xYPlot0.removeDomainMarker(5, (org.jfree.chart.plot.Marker) intervalMarker8, layer20);
        java.awt.Font font23 = intervalMarker8.getLabelFont();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor5);
        java.awt.Stroke stroke7 = intervalMarker2.getStroke();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.configureRangeAxes();
        xYPlot8.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot8.getAxisOffset();
        intervalMarker2.setLabelOffset(rectangleInsets11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        intervalMarker2.notifyListeners(markerChangeEvent13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke18 = intervalMarker17.getStroke();
        java.awt.Paint paint19 = intervalMarker17.getOutlinePaint();
        java.lang.String str20 = intervalMarker17.getLabel();
        java.awt.Stroke stroke21 = intervalMarker17.getStroke();
        intervalMarker2.setStroke(stroke21);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) (byte) 100, plotRenderingInfo4, point2D5, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot0.getRenderer((-1));
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) (byte) 100, plotRenderingInfo4, point2D5, true);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getDomainAxisForDataset(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 12 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot0.getRangeAxis((-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNull(valueAxis23);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke6 = intervalMarker5.getStroke();
        java.awt.Paint paint7 = intervalMarker5.getOutlinePaint();
        java.lang.String str8 = intervalMarker5.getLabel();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = intervalMarker5.getLabelOffset();
        org.jfree.chart.util.SortOrder sortOrder12 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder12, jFreeChart13);
        boolean boolean15 = intervalMarker5.equals((java.lang.Object) chartChangeEvent14);
        java.lang.String str16 = chartChangeEvent14.toString();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=SortOrder.DESCENDING]" + "'", str16.equals("org.jfree.chart.event.ChartChangeEvent[source=SortOrder.DESCENDING]"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        java.lang.String str5 = intervalMarker2.getLabel();
        java.awt.Stroke stroke6 = intervalMarker2.getStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = intervalMarker2.getGradientPaintTransformer();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = intervalMarker2.getLabelOffsetType();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(gradientPaintTransformer7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke13 = intervalMarker12.getStroke();
        java.awt.Paint paint14 = intervalMarker12.getOutlinePaint();
        java.lang.String str15 = intervalMarker12.getLabel();
        java.awt.Color color16 = java.awt.Color.orange;
        intervalMarker12.setPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        int int22 = xYPlot18.getRangeAxisIndex(valueAxis21);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.configureRangeAxes();
        java.awt.Stroke stroke25 = xYPlot23.getDomainCrosshairStroke();
        xYPlot18.setRangeGridlineStroke(stroke25);
        intervalMarker12.setOutlineStroke(stroke25);
        xYPlot0.setRangeZeroBaselineStroke(stroke25);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        xYPlot30.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        int int34 = xYPlot30.getRangeAxisIndex(valueAxis33);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        xYPlot35.configureRangeAxes();
        java.awt.Stroke stroke37 = xYPlot35.getDomainCrosshairStroke();
        xYPlot30.setRangeGridlineStroke(stroke37);
        org.jfree.chart.plot.Plot plot39 = xYPlot30.getParent();
        xYPlot30.clearDomainMarkers();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis42.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition45 = dateAxis42.getTickMarkPosition();
        java.awt.Shape shape46 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis42.setLeftArrow(shape46);
        int int48 = xYPlot30.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis42);
        org.jfree.chart.axis.Timeline timeline49 = null;
        dateAxis42.setTimeline(timeline49);
        try {
            xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) dateAxis42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(plot39);
        org.junit.Assert.assertNotNull(dateTickMarkPosition45);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot0.setRenderer(0, xYItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        xYPlot39.setDataset(xYDataset40);
        org.jfree.chart.plot.Plot plot42 = xYPlot39.getRootPlot();
        java.awt.geom.Point2D point2D43 = xYPlot39.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        try {
            xYPlot0.draw(graphics2D37, rectangle2D38, point2D43, plotState44, plotRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(plot42);
        org.junit.Assert.assertNotNull(point2D43);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke13 = intervalMarker12.getStroke();
        java.awt.Paint paint14 = intervalMarker12.getOutlinePaint();
        java.lang.String str15 = intervalMarker12.getLabel();
        java.awt.Color color16 = java.awt.Color.orange;
        intervalMarker12.setPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        int int22 = xYPlot18.getRangeAxisIndex(valueAxis21);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.configureRangeAxes();
        java.awt.Stroke stroke25 = xYPlot23.getDomainCrosshairStroke();
        xYPlot18.setRangeGridlineStroke(stroke25);
        intervalMarker12.setOutlineStroke(stroke25);
        xYPlot0.setRangeZeroBaselineStroke(stroke25);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis31.setLabelAngle(0.0d);
        java.util.Date date34 = dateAxis31.getMaximumDate();
        double double35 = dateAxis31.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = dateAxis31.getTickLabelInsets();
        org.jfree.chart.plot.Plot plot37 = dateAxis31.getPlot();
        dateAxis31.setInverted(false);
        try {
            xYPlot0.setDomainAxis((-2), (org.jfree.chart.axis.ValueAxis) dateAxis31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNull(plot37);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.configureRangeAxes();
        xYPlot2.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean6 = xYPlot2.equals((java.lang.Object) dateTickUnit5);
        dateAxis1.setTickUnit(dateTickUnit5);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        int int15 = xYPlot11.getRangeAxisIndex(valueAxis14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.configureRangeAxes();
        java.awt.Stroke stroke18 = xYPlot16.getDomainCrosshairStroke();
        xYPlot11.setRangeGridlineStroke(stroke18);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke23 = intervalMarker22.getStroke();
        java.awt.Paint paint24 = intervalMarker22.getOutlinePaint();
        java.lang.String str25 = intervalMarker22.getLabel();
        java.awt.Color color26 = java.awt.Color.orange;
        intervalMarker22.setPaint((java.awt.Paint) color26);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker22, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot11.getRangeAxisEdge(0);
        try {
            java.util.List list32 = dateAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = xYPlot0.equals((java.lang.Object) dateTickUnit3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot0.getDomainAxisLocation(9);
        org.jfree.chart.axis.AxisSpace axisSpace7 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        xYPlot0.addChangeListener(plotChangeListener19);
        float float21 = xYPlot0.getBackgroundImageAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertNull(valueAxis22);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        int int11 = xYPlot0.getRangeAxisCount();
        java.awt.Image image12 = null;
        xYPlot0.setBackgroundImage(image12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke33 = intervalMarker32.getStroke();
        java.awt.Paint paint34 = intervalMarker32.getOutlinePaint();
        java.lang.String str35 = intervalMarker32.getLabel();
        java.awt.Color color36 = java.awt.Color.orange;
        intervalMarker32.setPaint((java.awt.Paint) color36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = intervalMarker32.getLabelAnchor();
        org.jfree.chart.util.Layer layer39 = null;
        xYPlot0.addRangeMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker32, layer39);
        org.jfree.chart.plot.IntervalMarker intervalMarker44 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color45 = java.awt.Color.GRAY;
        intervalMarker44.setOutlinePaint((java.awt.Paint) color45);
        try {
            xYPlot0.setQuadrantPaint(64, (java.awt.Paint) color45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (64) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        boolean boolean7 = dateAxis1.isVerticalTickLabels();
        java.awt.Font font8 = dateAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        xYPlot0.setDomainCrosshairValue((double) 8, false);
        java.awt.Stroke stroke16 = xYPlot0.getDomainGridlineStroke();
        boolean boolean17 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup18 = xYPlot0.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(datasetGroup18);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) 10);
        double double3 = rectangleInsets0.getRight();
        double double4 = rectangleInsets0.getRight();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createOutsetRectangle(rectangle2D5, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        java.util.Date date7 = dateAxis3.getMaximumDate();
        boolean boolean8 = day1.equals((java.lang.Object) dateAxis3);
        java.util.Date date9 = day1.getStart();
        int int10 = day1.getYear();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) (-1L), (double) 64, 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean5 = axisLocation3.equals((java.lang.Object) 128);
        categoryPlot1.setRangeAxisLocation((int) (byte) 10, axisLocation3);
        categoryPlot1.setDrawSharedDomainAxis(true);
        java.awt.Paint paint9 = categoryPlot1.getRangeCrosshairPaint();
        int int10 = day0.compareTo((java.lang.Object) paint9);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker1.setKey((java.lang.Comparable) 10);
        java.lang.Comparable comparable4 = null;
        try {
            categoryMarker1.setKey(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        xYPlot31.setDataset(xYDataset32);
        java.lang.Object obj34 = xYPlot31.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot31.getDomainAxisEdge(10);
        try {
            double double37 = dateAxis23.lengthToJava2D((double) (short) 100, rectangle2D30, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis23.setMinimumDate(date29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis32.setLabelAngle(0.0d);
        java.util.Date date35 = dateAxis32.getMaximumDate();
        double double36 = dateAxis32.getUpperMargin();
        dateAxis32.setTickLabelsVisible(true);
        java.util.Date date39 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis32.setMaximumDate(date39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date39);
        dateAxis23.setMinimumDate(date39);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        boolean boolean22 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        boolean boolean21 = xYPlot0.isRangeZoomable();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot0.drawBackgroundImage(graphics2D22, rectangle2D23);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = null;
        try {
            xYPlot0.setInsets(rectangleInsets25, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke10 = intervalMarker9.getStroke();
        java.awt.Paint paint11 = intervalMarker9.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker9.setLabelTextAnchor(textAnchor12);
        java.awt.Stroke stroke14 = intervalMarker9.getStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot0.getRangeAxisEdge();
        boolean boolean17 = xYPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis9.setLabelAngle(0.0d);
        java.util.Date date12 = dateAxis9.getMaximumDate();
        dateAxis9.setAxisLineVisible(true);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation16 = null;
        try {
            boolean boolean18 = xYPlot0.removeAnnotation(xYAnnotation16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(date12);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.lang.Object obj17 = categoryPlot0.clone();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.configureRangeAxes();
        xYPlot1.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot1.zoomDomainAxes((double) (byte) 10, plotRenderingInfo5, point2D6, true);
        int int9 = objectList0.indexOf((java.lang.Object) plotRenderingInfo5);
        objectList0.clear();
        java.lang.Object obj11 = objectList0.clone();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        java.util.Date date7 = dateAxis3.getMaximumDate();
        boolean boolean8 = day1.equals((java.lang.Object) dateAxis3);
        java.util.Date date9 = day1.getStart();
        java.util.Date date10 = day1.getEnd();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot2.getRangeAxisIndex(valueAxis5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot2.setNoDataMessagePaint((java.awt.Paint) color7);
        java.awt.color.ColorSpace colorSpace9 = color7.getColorSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke13 = intervalMarker12.getStroke();
        java.awt.Paint paint14 = intervalMarker12.getOutlinePaint();
        java.lang.String str15 = intervalMarker12.getLabel();
        java.awt.Color color16 = java.awt.Color.orange;
        intervalMarker12.setPaint((java.awt.Paint) color16);
        float[] floatArray25 = new float[] { 8, (byte) 1, (short) 10, 10L };
        float[] floatArray26 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (short) 10, (int) ' ', floatArray25);
        float[] floatArray27 = color16.getRGBColorComponents(floatArray26);
        float[] floatArray28 = color1.getColorComponents(colorSpace9, floatArray26);
        boolean boolean29 = plotOrientation0.equals((java.lang.Object) floatArray28);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setVerticalTickLabels(true);
        java.awt.Stroke stroke24 = dateAxis15.getTickMarkStroke();
        dateAxis15.setNegativeArrowVisible(true);
        boolean boolean27 = dateAxis15.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        java.util.Date date5 = dateAxis1.getMaximumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets();
        dateAxis1.setLabelInsets(rectangleInsets6);
        boolean boolean8 = dateAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Color color1 = java.awt.Color.green;
        int int2 = color1.getAlpha();
        float[] floatArray8 = new float[] { 4, 1.0f, 128, 5, 255 };
        float[] floatArray9 = color1.getRGBComponents(floatArray8);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke13 = intervalMarker12.getStroke();
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        intervalMarker12.setLabelTextAnchor(textAnchor14);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke19 = intervalMarker18.getStroke();
        java.awt.Paint paint20 = intervalMarker18.getOutlinePaint();
        java.lang.String str21 = intervalMarker18.getLabel();
        java.awt.Color color22 = java.awt.Color.orange;
        intervalMarker18.setPaint((java.awt.Paint) color22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        int int28 = xYPlot24.getRangeAxisIndex(valueAxis27);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        xYPlot29.configureRangeAxes();
        java.awt.Stroke stroke31 = xYPlot29.getDomainCrosshairStroke();
        xYPlot24.setRangeGridlineStroke(stroke31);
        intervalMarker18.setOutlineStroke(stroke31);
        intervalMarker12.setStroke(stroke31);
        java.awt.Paint paint35 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke39 = intervalMarker38.getStroke();
        java.awt.Paint paint40 = intervalMarker38.getOutlinePaint();
        java.lang.String str41 = intervalMarker38.getLabel();
        java.awt.Stroke stroke42 = intervalMarker38.getStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 2019, (java.awt.Paint) color1, stroke31, paint35, stroke42, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        valueMarker1.setValue((double) 128);
        valueMarker1.setValue((double) 5);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str1.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = xYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.configureRangeAxes();
        java.awt.Stroke stroke8 = xYPlot6.getDomainCrosshairStroke();
        xYPlot1.setRangeGridlineStroke(stroke8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot1.setFixedDomainAxisSpace(axisSpace10);
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot1.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis16.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis16.getTickUnit();
        java.awt.Shape shape20 = dateAxis16.getLeftArrow();
        xYPlot1.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis16, true);
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot1.getRangeAxisLocation(4);
        xYPlot0.setRangeAxisLocation(axisLocation24);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        int int31 = xYPlot27.getRangeAxisIndex(valueAxis30);
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        xYPlot32.configureRangeAxes();
        java.awt.Stroke stroke34 = xYPlot32.getDomainCrosshairStroke();
        xYPlot27.setRangeGridlineStroke(stroke34);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        xYPlot27.setFixedDomainAxisSpace(axisSpace36);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot27.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis42.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit45 = dateAxis42.getTickUnit();
        java.awt.Shape shape46 = dateAxis42.getLeftArrow();
        xYPlot27.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis42, true);
        dateAxis42.setLabelToolTip("ChartChangeEventType.NEW_DATASET");
        try {
            xYPlot0.setDomainAxis((int) (short) -1, (org.jfree.chart.axis.ValueAxis) dateAxis42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertNotNull(dateTickUnit45);
        org.junit.Assert.assertNotNull(shape46);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        int int9 = xYPlot5.getRangeAxisIndex(valueAxis8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.configureRangeAxes();
        java.awt.Stroke stroke12 = xYPlot10.getDomainCrosshairStroke();
        xYPlot5.setRangeGridlineStroke(stroke12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace14);
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot5.getDomainAxis(0);
        xYPlot5.setDomainCrosshairValue((double) 8, false);
        java.awt.Stroke stroke21 = xYPlot5.getDomainGridlineStroke();
        boolean boolean22 = xYPlot5.isRangeGridlinesVisible();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) xYPlot5);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.setDomainCrosshairValue((double) '#');
        xYPlot0.setDomainCrosshairLockedOnData(false);
        boolean boolean6 = xYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot2.getRangeAxisIndex(valueAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        java.awt.Stroke stroke9 = xYPlot7.getDomainCrosshairStroke();
        xYPlot2.setRangeGridlineStroke(stroke9);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke14 = intervalMarker13.getStroke();
        java.awt.Paint paint15 = intervalMarker13.getOutlinePaint();
        java.lang.String str16 = intervalMarker13.getLabel();
        java.awt.Color color17 = java.awt.Color.orange;
        intervalMarker13.setPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot2.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13, layer19);
        int int21 = xYPlot2.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = xYPlot2.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke27 = intervalMarker26.getStroke();
        java.awt.Paint paint28 = intervalMarker26.getOutlinePaint();
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean31 = xYPlot2.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker26, layer29, false);
        xYPlot2.setBackgroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = xYPlot2.getDrawingSupplier();
        int int35 = objectList1.indexOf((java.lang.Object) xYPlot2);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot2.getRangeAxisLocation();
        java.lang.String str37 = xYPlot2.getPlotType();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(drawingSupplier34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "XY Plot" + "'", str37.equals("XY Plot"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        java.lang.Object obj3 = objectList1.get(3);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis6.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis6.getTickMarkPosition();
        java.awt.Stroke stroke10 = dateAxis6.getAxisLineStroke();
        double double11 = dateAxis6.getLowerBound();
        dateAxis6.setUpperMargin(0.0d);
        boolean boolean14 = dateAxis6.isTickMarksVisible();
        java.text.DateFormat dateFormat15 = dateAxis6.getDateFormatOverride();
        try {
            objectList1.set((int) (short) 0, (java.lang.Object) dateFormat15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(dateFormat15);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot0.setRangeAxisLocation(5, axisLocation11, false);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.configureRangeAxes();
        xYPlot14.setDomainCrosshairValue((double) '#');
        xYPlot14.setDomainCrosshairLockedOnData(false);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot14);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        xYPlot22.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        int int26 = xYPlot22.getRangeAxisIndex(valueAxis25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.configureRangeAxes();
        java.awt.Stroke stroke29 = xYPlot27.getDomainCrosshairStroke();
        xYPlot22.setRangeGridlineStroke(stroke29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        xYPlot22.setFixedDomainAxisSpace(axisSpace31);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot22.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis37.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = dateAxis37.getTickUnit();
        java.awt.Shape shape41 = dateAxis37.getLeftArrow();
        xYPlot22.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis37, true);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot22.getRangeAxisLocation(4);
        xYPlot0.setDomainAxisLocation((int) (byte) 100, axisLocation45, true);
        org.jfree.chart.axis.ValueAxis valueAxis48 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertNotNull(dateTickUnit40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNull(valueAxis48);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot0.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        xYPlot22.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        int int26 = xYPlot22.getRangeAxisIndex(valueAxis25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.configureRangeAxes();
        java.awt.Stroke stroke29 = xYPlot27.getDomainCrosshairStroke();
        xYPlot22.setRangeGridlineStroke(stroke29);
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke34 = intervalMarker33.getStroke();
        java.awt.Paint paint35 = intervalMarker33.getOutlinePaint();
        java.lang.String str36 = intervalMarker33.getLabel();
        java.awt.Color color37 = java.awt.Color.orange;
        intervalMarker33.setPaint((java.awt.Paint) color37);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot22.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker33, layer39);
        java.awt.Stroke stroke41 = null;
        xYPlot22.setOutlineStroke(stroke41);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis45.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = dateAxis45.getTickUnit();
        xYPlot22.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis45, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke55 = intervalMarker54.getStroke();
        java.awt.Paint paint56 = intervalMarker54.getOutlinePaint();
        java.lang.String str57 = intervalMarker54.getLabel();
        java.awt.Color color58 = java.awt.Color.orange;
        intervalMarker54.setPaint((java.awt.Paint) color58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = intervalMarker54.getLabelAnchor();
        org.jfree.chart.util.Layer layer61 = null;
        xYPlot22.addRangeMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker54, layer61);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean64 = categoryPlot0.removeDomainMarker((-1), (org.jfree.chart.plot.Marker) intervalMarker54, layer63);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor65 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertNotNull(dateTickUnit48);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset((int) ' ', categoryDataset6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke5 = intervalMarker4.getStroke();
        java.awt.Paint paint6 = intervalMarker4.getOutlinePaint();
        java.lang.String str7 = intervalMarker4.getLabel();
        java.awt.Color color8 = java.awt.Color.orange;
        intervalMarker4.setPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke13 = intervalMarker12.getStroke();
        java.awt.Paint paint14 = intervalMarker12.getOutlinePaint();
        java.lang.String str15 = intervalMarker12.getLabel();
        java.awt.Color color16 = java.awt.Color.orange;
        intervalMarker12.setPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        int int22 = xYPlot18.getRangeAxisIndex(valueAxis21);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.configureRangeAxes();
        java.awt.Stroke stroke25 = xYPlot23.getDomainCrosshairStroke();
        xYPlot18.setRangeGridlineStroke(stroke25);
        intervalMarker12.setOutlineStroke(stroke25);
        java.awt.Paint paint28 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke32 = intervalMarker31.getStroke();
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        intervalMarker31.setLabelTextAnchor(textAnchor33);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke38 = intervalMarker37.getStroke();
        java.awt.Paint paint39 = intervalMarker37.getOutlinePaint();
        java.lang.String str40 = intervalMarker37.getLabel();
        java.awt.Color color41 = java.awt.Color.orange;
        intervalMarker37.setPaint((java.awt.Paint) color41);
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot();
        xYPlot43.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        int int47 = xYPlot43.getRangeAxisIndex(valueAxis46);
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        xYPlot48.configureRangeAxes();
        java.awt.Stroke stroke50 = xYPlot48.getDomainCrosshairStroke();
        xYPlot43.setRangeGridlineStroke(stroke50);
        intervalMarker37.setOutlineStroke(stroke50);
        intervalMarker31.setStroke(stroke50);
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker55 = new org.jfree.chart.plot.IntervalMarker((double) 9, 0.05d, (java.awt.Paint) color8, stroke25, paint28, stroke50, (float) 64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        boolean boolean7 = dateAxis1.isAutoRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double9 = rectangleInsets8.getRight();
        dateAxis1.setTickLabelInsets(rectangleInsets8);
        try {
            dateAxis1.setAutoRangeMinimumSize((double) (-1L), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str1.equals("RectangleAnchor.TOP_RIGHT"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot0.getDataRange(valueAxis8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot0.setDataset((int) (byte) 10, categoryDataset11);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.configureRangeAxes();
        xYPlot14.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean18 = xYPlot14.equals((java.lang.Object) dateTickUnit17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot14.getDomainAxisLocation(9);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj22 = null;
        boolean boolean23 = plotOrientation21.equals(obj22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation20, plotOrientation21);
        categoryPlot0.setRangeAxisLocation((int) (short) 10, axisLocation20);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(dateTickUnit17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        boolean boolean21 = xYPlot0.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        int int23 = xYPlot0.indexOf(xYDataset22);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace21);
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        xYPlot25.configureRangeAxes();
        xYPlot25.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke31 = intervalMarker30.getStroke();
        java.awt.Paint paint32 = intervalMarker30.getOutlinePaint();
        java.lang.String str33 = intervalMarker30.getLabel();
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean35 = xYPlot25.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker30, layer34);
        try {
            xYPlot0.addDomainMarker(12, marker24, layer34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        java.util.Date date26 = dateAxis23.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis28.setLabelAngle(0.0d);
        java.util.Date date31 = dateAxis28.getMaximumDate();
        dateAxis23.setMaximumDate(date31);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        xYPlot34.setDataset(xYDataset35);
        java.lang.Object obj37 = xYPlot34.clone();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot34.getDomainAxisEdge(10);
        try {
            double double40 = dateAxis15.dateToJava2D(date31, rectangle2D33, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot0.setRangeAxisLocation(5, axisLocation11, false);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.configureRangeAxes();
        xYPlot14.setDomainCrosshairValue((double) '#');
        xYPlot14.setDomainCrosshairLockedOnData(false);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot14);
        xYPlot0.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.setDomainCrosshairValue((double) '#');
        org.jfree.chart.axis.AxisLocation axisLocation5 = xYPlot0.getDomainAxisLocation(0);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis1.configure();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        int int12 = xYPlot8.getRangeAxisIndex(valueAxis11);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.configureRangeAxes();
        java.awt.Stroke stroke15 = xYPlot13.getDomainCrosshairStroke();
        xYPlot8.setRangeGridlineStroke(stroke15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot8.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot8.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        java.awt.Shape shape27 = dateAxis23.getLeftArrow();
        xYPlot8.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot8.getRangeAxisLocation(4);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj33 = null;
        boolean boolean34 = plotOrientation32.equals(obj33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation31, plotOrientation32);
        try {
            double double36 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) 100L, (java.lang.Comparable) 15, categoryDataset5, 1.0d, rectangle2D7, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj3 = categoryAxis2.clone();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis2.setMaximumCategoryLabelLines((int) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = org.jfree.chart.axis.CategoryAnchor.END;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        int int19 = xYPlot15.getRangeAxisIndex(valueAxis18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot15.setNoDataMessagePaint((java.awt.Paint) color20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker24.setLabelTextAnchor(textAnchor27);
        java.awt.Stroke stroke29 = intervalMarker24.getStroke();
        xYPlot15.setRangeZeroBaselineStroke(stroke29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot15.getRangeAxisEdge();
        try {
            double double32 = categoryAxis2.getCategoryJava2DCoordinate(categoryAnchor11, 0, (int) (short) 10, rectangle2D14, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        dateAxis23.setLowerBound(0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(dateTickUnit26);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke6 = intervalMarker5.getStroke();
        java.awt.Paint paint7 = intervalMarker5.getOutlinePaint();
        java.lang.String str8 = intervalMarker5.getLabel();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer9);
        java.awt.Paint paint12 = xYPlot0.getQuadrantPaint(0);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        xYPlot0.setDataset(xYDataset13);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis6.setLabelAngle(0.0d);
        java.util.Date date9 = dateAxis6.getMaximumDate();
        dateAxis1.setMaximumDate(date9);
        boolean boolean11 = dateAxis1.isInverted();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        xYPlot0.removeChangeListener(plotChangeListener33);
        org.jfree.chart.plot.Plot plot35 = xYPlot0.getRootPlot();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(drawingSupplier32);
        org.junit.Assert.assertNotNull(plot35);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        try {
            java.awt.Paint paint6 = xYPlot0.getQuadrantPaint(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (7) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot0.getDataRange(valueAxis8);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        xYPlot11.setDataset(xYDataset12);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        xYPlot15.configureRangeAxes();
        xYPlot15.setDomainCrosshairValue((double) '#');
        xYPlot15.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot15.setDomainAxisLocation(axisLocation21);
        xYPlot11.setRangeAxisLocation((int) 'a', axisLocation21, true);
        categoryPlot0.setRangeAxisLocation(0, axisLocation21);
        java.awt.Stroke stroke26 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot0.setRangeAxisLocation(5, axisLocation11, false);
        xYPlot0.configureRangeAxes();
        boolean boolean15 = xYPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        java.awt.Stroke stroke7 = dateAxis1.getAxisLineStroke();
        dateAxis1.setFixedDimension(0.0d);
        double double10 = dateAxis1.getLabelAngle();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        float[] floatArray4 = new float[] { 43629L, 4, '4' };
        try {
            float[] floatArray5 = color0.getComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot0.getRangeAxisLocation(4);
        boolean boolean24 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.configureRangeAxes();
        xYPlot2.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean6 = xYPlot2.equals((java.lang.Object) dateTickUnit5);
        dateAxis1.setTickUnit(dateTickUnit5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        boolean boolean7 = dateAxis1.isVerticalTickLabels();
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis11.setLabelAngle(0.0d);
        java.util.Date date14 = dateAxis11.getMaximumDate();
        java.util.Date date15 = dateAxis11.getMaximumDate();
        boolean boolean16 = day9.equals((java.lang.Object) dateAxis11);
        java.util.Date date17 = day9.getStart();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis20.setLabelAngle(0.0d);
        java.util.Date date23 = dateAxis20.getMaximumDate();
        double double24 = dateAxis20.getUpperMargin();
        dateAxis20.setTickLabelsVisible(true);
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis20.setMaximumDate(date27);
        dateAxis1.setRange(date17, date27);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date17, timeZone30);
        java.util.Calendar calendar32 = null;
        try {
            long long33 = day31.getFirstMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color1 = color0.brighter();
        java.awt.Color color2 = java.awt.Color.yellow;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        int int7 = xYPlot3.getRangeAxisIndex(valueAxis6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot3.setNoDataMessagePaint((java.awt.Paint) color8);
        java.awt.color.ColorSpace colorSpace10 = color8.getColorSpace();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        int int15 = xYPlot11.getRangeAxisIndex(valueAxis14);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        xYPlot16.configureRangeAxes();
        java.awt.Stroke stroke18 = xYPlot16.getDomainCrosshairStroke();
        xYPlot11.setRangeGridlineStroke(stroke18);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke23 = intervalMarker22.getStroke();
        java.awt.Paint paint24 = intervalMarker22.getOutlinePaint();
        java.lang.String str25 = intervalMarker22.getLabel();
        java.awt.Color color26 = java.awt.Color.orange;
        intervalMarker22.setPaint((java.awt.Paint) color26);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot11.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker22, layer28);
        int int30 = xYPlot11.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier31 = xYPlot11.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker35 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke36 = intervalMarker35.getStroke();
        java.awt.Paint paint37 = intervalMarker35.getOutlinePaint();
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean40 = xYPlot11.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker35, layer38, false);
        xYPlot11.setBackgroundAlpha((float) (byte) 1);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot11.setNoDataMessagePaint((java.awt.Paint) color43);
        float[] floatArray52 = new float[] { 8, (byte) 1, (short) 10, 10L };
        float[] floatArray53 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (short) 10, (int) ' ', floatArray52);
        float[] floatArray54 = color43.getRGBColorComponents(floatArray53);
        float[] floatArray55 = color2.getComponents(colorSpace10, floatArray53);
        java.awt.color.ColorSpace colorSpace56 = color2.getColorSpace();
        java.awt.Color color57 = java.awt.Color.yellow;
        java.awt.Color color58 = java.awt.Color.green;
        int int59 = color58.getAlpha();
        float[] floatArray65 = new float[] { 4, 1.0f, 128, 5, 255 };
        float[] floatArray66 = color58.getRGBComponents(floatArray65);
        float[] floatArray67 = color57.getRGBComponents(floatArray65);
        float[] floatArray68 = color0.getComponents(colorSpace56, floatArray65);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier31);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(colorSpace56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 255 + "'", int59 == 255);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray68);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        valueMarker1.setValue((double) 1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        float[] floatArray21 = new float[] { 0 };
        try {
            float[] floatArray22 = color17.getRGBColorComponents(floatArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.REVERSE");
        double double2 = categoryAxis1.getUpperMargin();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureRangeAxes();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        int int8 = xYPlot4.getIndexOf(xYItemRenderer7);
        xYPlot4.setRangeZeroBaselineVisible(false);
        boolean boolean11 = xYPlot4.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot14.setDataset(xYDataset15);
        org.jfree.chart.plot.Plot plot17 = xYPlot14.getRootPlot();
        java.awt.geom.Point2D point2D18 = xYPlot14.getQuadrantOrigin();
        xYPlot4.zoomRangeAxes((double) (byte) 100, plotRenderingInfo13, point2D18, true);
        boolean boolean21 = xYPlot4.isRangeZoomable();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.configureRangeAxes();
        xYPlot26.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean30 = xYPlot26.equals((java.lang.Object) dateTickUnit29);
        dateAxis25.setTickUnit(dateTickUnit29);
        boolean boolean32 = axisLocation23.equals((java.lang.Object) dateAxis25);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation23, plotOrientation33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace36 = categoryAxis1.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) xYPlot4, rectangle2D22, rectangleEdge34, axisSpace35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setLabelToolTip("ChartChangeEventType.NEW_DATASET");
        java.awt.Font font24 = dateAxis15.getLabelFont();
        java.awt.Font font25 = dateAxis15.getTickLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean30 = axisLocation28.equals((java.lang.Object) 128);
        categoryPlot26.setRangeAxisLocation((int) (byte) 10, axisLocation28);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = categoryPlot26.getLegendItems();
        org.jfree.chart.plot.IntervalMarker intervalMarker35 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke36 = intervalMarker35.getStroke();
        java.awt.Paint paint37 = intervalMarker35.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker35.setLabelTextAnchor(textAnchor38);
        java.awt.Stroke stroke40 = intervalMarker35.getStroke();
        categoryPlot26.setRangeCrosshairStroke(stroke40);
        dateAxis15.setTickMarkStroke(stroke40);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Color color3 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        int int8 = xYPlot4.getRangeAxisIndex(valueAxis7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color9);
        java.awt.color.ColorSpace colorSpace11 = color9.getColorSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke15 = intervalMarker14.getStroke();
        java.awt.Paint paint16 = intervalMarker14.getOutlinePaint();
        java.lang.String str17 = intervalMarker14.getLabel();
        java.awt.Color color18 = java.awt.Color.orange;
        intervalMarker14.setPaint((java.awt.Paint) color18);
        float[] floatArray27 = new float[] { 8, (byte) 1, (short) 10, 10L };
        float[] floatArray28 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (short) 10, (int) ' ', floatArray27);
        float[] floatArray29 = color18.getRGBColorComponents(floatArray28);
        float[] floatArray30 = color3.getColorComponents(colorSpace11, floatArray28);
        float[] floatArray31 = java.awt.Color.RGBtoHSB(0, (int) (byte) -1, 11, floatArray28);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis1.configure();
        categoryAxis1.setLowerMargin(0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.REVERSE");
        double double2 = categoryAxis1.getUpperMargin();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean8 = axisLocation6.equals((java.lang.Object) 128);
        categoryPlot4.setRangeAxisLocation((int) (byte) 10, axisLocation6);
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot4.getDataRange(valueAxis12);
        double double14 = categoryPlot4.getAnchorValue();
        org.jfree.chart.util.SortOrder sortOrder15 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.Object obj16 = null;
        boolean boolean17 = sortOrder15.equals(obj16);
        categoryPlot4.setRowRenderingOrder(sortOrder15);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        xYPlot21.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        int int25 = xYPlot21.getRangeAxisIndex(valueAxis24);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        xYPlot26.configureRangeAxes();
        java.awt.Stroke stroke28 = xYPlot26.getDomainCrosshairStroke();
        xYPlot21.setRangeGridlineStroke(stroke28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        xYPlot21.setFixedDomainAxisSpace(axisSpace30);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot21.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis36.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = dateAxis36.getTickUnit();
        java.awt.Shape shape40 = dateAxis36.getLeftArrow();
        xYPlot21.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis36, true);
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot21.getRangeAxisLocation(4);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj46 = null;
        boolean boolean47 = plotOrientation45.equals(obj46);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation44, plotOrientation45);
        java.lang.Object obj49 = null;
        boolean boolean50 = plotOrientation45.equals(obj49);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation20, plotOrientation45);
        org.jfree.chart.axis.AxisSpace axisSpace52 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace53 = categoryAxis1.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) categoryPlot4, rectangle2D19, rectangleEdge51, axisSpace52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNotNull(dateTickUnit39);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) -1, 0.0d, (double) 1560495599999L, (double) (short) 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot0.getRangeAxisEdge(0);
        float float21 = xYPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str5 = chartChangeEventType4.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) false, jFreeChart3, chartChangeEventType4);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleInsets0, jFreeChart1, chartChangeEventType4);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.configureRangeAxes();
        xYPlot8.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke14 = intervalMarker13.getStroke();
        java.awt.Paint paint15 = intervalMarker13.getOutlinePaint();
        java.lang.String str16 = intervalMarker13.getLabel();
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean18 = xYPlot8.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13, layer17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = intervalMarker13.getLabelOffset();
        boolean boolean20 = chartChangeEventType4.equals((java.lang.Object) rectangleInsets19);
        java.lang.String str21 = rectangleInsets19.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str5.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str21.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        int int11 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateTopInset((double) (byte) 0);
        double double16 = rectangleInsets12.calculateRightOutset((double) 10.0f);
        xYPlot0.setInsets(rectangleInsets12, true);
        double double20 = rectangleInsets12.calculateBottomOutset((double) 15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        try {
            categoryPlot0.handleClick(0, 13, plotRenderingInfo4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) -1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot0.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setBackgroundAlpha(0.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        int int7 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.REVERSE");
        double double2 = categoryAxis1.getUpperMargin();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureRangeAxes();
        xYPlot4.setDomainCrosshairValue((double) '#');
        xYPlot4.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = xYPlot4.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        int int17 = xYPlot13.getRangeAxisIndex(valueAxis16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        xYPlot18.configureRangeAxes();
        java.awt.Stroke stroke20 = xYPlot18.getDomainCrosshairStroke();
        xYPlot13.setRangeGridlineStroke(stroke20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace22);
        org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot13.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis28.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis28.getTickUnit();
        java.awt.Shape shape32 = dateAxis28.getLeftArrow();
        xYPlot13.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis28, true);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot13.getRangeAxisLocation(4);
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj38 = null;
        boolean boolean39 = plotOrientation37.equals(obj38);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation36, plotOrientation37);
        java.lang.Object obj41 = null;
        boolean boolean42 = plotOrientation37.equals(obj41);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation12, plotOrientation37);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace45 = categoryAxis1.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) xYPlot4, rectangle2D11, rectangleEdge43, axisSpace44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureRangeAxes();
        java.awt.Paint paint3 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureRangeAxes();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke10 = intervalMarker9.getStroke();
        java.awt.Paint paint11 = intervalMarker9.getOutlinePaint();
        java.lang.String str12 = intervalMarker9.getLabel();
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = xYPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker9, layer13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = intervalMarker9.getLabelOffset();
        org.jfree.chart.util.SortOrder sortOrder16 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder16, jFreeChart17);
        boolean boolean19 = intervalMarker9.equals((java.lang.Object) chartChangeEvent18);
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        intervalMarker9.setLabelPaint(paint20);
        xYPlot0.setRangeTickBandPaint(paint20);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace23);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot0.setRenderer(0, xYItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace35);
        org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(valueAxis37);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean3 = valueMarker1.equals((java.lang.Object) color2);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot7.setDataset(xYDataset8);
        org.jfree.chart.plot.Plot plot10 = xYPlot7.getRootPlot();
        java.awt.geom.Point2D point2D11 = xYPlot7.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo6, point2D11);
        java.util.List list13 = categoryPlot0.getAnnotations();
        int int14 = categoryPlot0.getWeight();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder17, jFreeChart18);
        categoryPlot0.setColumnRenderingOrder(sortOrder17);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot0.getDomainAxis(0);
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        try {
            categoryPlot0.setDomainAxisLocation(axisLocation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNull(categoryAxis22);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        xYPlot0.clearDomainMarkers(100);
        int int5 = xYPlot0.getWeight();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color9 = java.awt.Color.GRAY;
        intervalMarker8.setOutlinePaint((java.awt.Paint) color9);
        intervalMarker8.setStartValue((double) 8);
        intervalMarker8.setStartValue((double) (byte) 100);
        boolean boolean15 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker8);
        xYPlot0.mapDatasetToDomainAxis(3, 4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = xYPlot0.equals((java.lang.Object) dateTickUnit3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder6 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        int int8 = xYPlot0.getIndexOf(xYItemRenderer7);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertNotNull(seriesRenderingOrder6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray5 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray5);
        java.lang.Object obj7 = defaultDrawingSupplier6.clone();
        try {
            java.awt.Shape shape8 = defaultDrawingSupplier6.getNextShape();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 10L);
        java.awt.Paint paint3 = intervalMarker2.getPaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font3);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(legendItemCollection5);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker1.setKey((java.lang.Comparable) 10);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis5.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = dateAxis5.getTickMarkPosition();
        java.awt.Stroke stroke9 = dateAxis5.getAxisLineStroke();
        double double10 = dateAxis5.getAutoRangeMinimumSize();
        boolean boolean11 = categoryMarker1.equals((java.lang.Object) dateAxis5);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        int int16 = xYPlot12.getRangeAxisIndex(valueAxis15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        xYPlot17.configureRangeAxes();
        java.awt.Stroke stroke19 = xYPlot17.getDomainCrosshairStroke();
        xYPlot12.setRangeGridlineStroke(stroke19);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke24 = intervalMarker23.getStroke();
        java.awt.Paint paint25 = intervalMarker23.getOutlinePaint();
        java.lang.String str26 = intervalMarker23.getLabel();
        java.awt.Color color27 = java.awt.Color.orange;
        intervalMarker23.setPaint((java.awt.Paint) color27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot12.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker23, layer29);
        java.awt.Stroke stroke31 = null;
        xYPlot12.setOutlineStroke(stroke31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        xYPlot12.setFixedDomainAxisSpace(axisSpace33);
        boolean boolean35 = xYPlot12.isRangeGridlinesVisible();
        dateAxis5.setPlot((org.jfree.chart.plot.Plot) xYPlot12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomDomainAxes((double) 100, plotRenderingInfo10, point2D11);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis4.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis4.getTickMarkPosition();
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis4.setLeftArrow(shape8);
        boolean boolean10 = dateAxis4.isVerticalTickLabels();
        int int11 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        int int12 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        org.jfree.chart.plot.Plot plot7 = dateAxis1.getPlot();
        java.util.TimeZone timeZone8 = dateAxis1.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        xYPlot11.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean15 = xYPlot11.equals((java.lang.Object) dateTickUnit14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot11.getDomainAxisLocation(9);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj19 = null;
        boolean boolean20 = plotOrientation18.equals(obj19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation17, plotOrientation18);
        try {
            double double22 = dateAxis1.lengthToJava2D((double) 7, rectangle2D10, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setVerticalTickLabels(true);
        java.awt.Stroke stroke24 = dateAxis15.getTickMarkStroke();
        dateAxis15.setNegativeArrowVisible(true);
        dateAxis15.setAutoRange(true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        dateAxis1.setTickLabelsVisible(true);
        dateAxis1.setLabel("RectangleAnchor.TOP");
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis11.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.awt.Shape shape15 = dateAxis11.getLeftArrow();
        dateAxis1.setLeftArrow(shape15);
        boolean boolean17 = dateAxis1.isAxisLineVisible();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.configureRangeAxes();
        xYPlot23.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean27 = xYPlot23.equals((java.lang.Object) dateTickUnit26);
        dateAxis22.setTickUnit(dateTickUnit26);
        boolean boolean29 = axisLocation20.equals((java.lang.Object) dateAxis22);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation20, plotOrientation30);
        try {
            double double32 = dateAxis1.lengthToJava2D((double) 0, rectangle2D19, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot0.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        xYPlot22.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        int int26 = xYPlot22.getRangeAxisIndex(valueAxis25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.configureRangeAxes();
        java.awt.Stroke stroke29 = xYPlot27.getDomainCrosshairStroke();
        xYPlot22.setRangeGridlineStroke(stroke29);
        org.jfree.chart.plot.IntervalMarker intervalMarker33 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke34 = intervalMarker33.getStroke();
        java.awt.Paint paint35 = intervalMarker33.getOutlinePaint();
        java.lang.String str36 = intervalMarker33.getLabel();
        java.awt.Color color37 = java.awt.Color.orange;
        intervalMarker33.setPaint((java.awt.Paint) color37);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot22.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker33, layer39);
        java.awt.Stroke stroke41 = null;
        xYPlot22.setOutlineStroke(stroke41);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis45.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = dateAxis45.getTickUnit();
        xYPlot22.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis45, true);
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke55 = intervalMarker54.getStroke();
        java.awt.Paint paint56 = intervalMarker54.getOutlinePaint();
        java.lang.String str57 = intervalMarker54.getLabel();
        java.awt.Color color58 = java.awt.Color.orange;
        intervalMarker54.setPaint((java.awt.Paint) color58);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = intervalMarker54.getLabelAnchor();
        org.jfree.chart.util.Layer layer61 = null;
        xYPlot22.addRangeMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker54, layer61);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean64 = categoryPlot0.removeDomainMarker((-1), (org.jfree.chart.plot.Marker) intervalMarker54, layer63);
        try {
            categoryPlot0.zoom(2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertNotNull(dateTickUnit48);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color32);
        float float34 = xYPlot0.getBackgroundAlpha();
        java.awt.Paint paint35 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        int int11 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateTopInset((double) (byte) 0);
        double double16 = rectangleInsets12.calculateRightOutset((double) 10.0f);
        xYPlot0.setInsets(rectangleInsets12, true);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets12.createOutsetRectangle(rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset((double) (short) 100);
        double double4 = rectangleInsets0.extendHeight(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.0d + "'", double4 == 6.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        intervalMarker2.setLabelTextAnchor(textAnchor4);
        intervalMarker2.setEndValue((double) 10);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 10.0f, 0.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        java.util.Date date5 = dateAxis1.getMaximumDate();
        dateAxis1.setUpperBound((double) 'a');
        double double8 = dateAxis1.getUpperMargin();
        dateAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color32);
        boolean boolean34 = xYPlot0.isRangeZeroBaselineVisible();
        boolean boolean35 = xYPlot0.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        java.util.Date date7 = dateAxis3.getMaximumDate();
        boolean boolean8 = day1.equals((java.lang.Object) dateAxis3);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis10.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition13 = dateAxis10.getTickMarkPosition();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis10.setLeftArrow(shape14);
        java.awt.Stroke stroke16 = dateAxis10.getAxisLineStroke();
        dateAxis10.setFixedDimension(0.0d);
        boolean boolean20 = dateAxis10.isHiddenValue((long) 255);
        org.jfree.data.Range range21 = dateAxis10.getDefaultAutoRange();
        dateAxis3.setRange(range21);
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis3.setDefaultAutoRange((org.jfree.data.Range) dateRange23);
        dateAxis3.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(dateRange23);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.lang.String str3 = intervalMarker2.getLabel();
        java.awt.Stroke stroke4 = intervalMarker2.getOutlineStroke();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit5);
        dateAxis1.setVerticalTickLabels(true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        java.awt.Paint paint4 = intervalMarker2.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor5);
        java.awt.Stroke stroke7 = intervalMarker2.getStroke();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.configureRangeAxes();
        xYPlot8.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot8.getAxisOffset();
        intervalMarker2.setLabelOffset(rectangleInsets11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        intervalMarker2.notifyListeners(markerChangeEvent13);
        intervalMarker2.setEndValue((double) (byte) 10);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot2.getRangeAxisIndex(valueAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        java.awt.Stroke stroke9 = xYPlot7.getDomainCrosshairStroke();
        xYPlot2.setRangeGridlineStroke(stroke9);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke14 = intervalMarker13.getStroke();
        java.awt.Paint paint15 = intervalMarker13.getOutlinePaint();
        java.lang.String str16 = intervalMarker13.getLabel();
        java.awt.Color color17 = java.awt.Color.orange;
        intervalMarker13.setPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot2.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13, layer19);
        int int21 = xYPlot2.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = xYPlot2.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke27 = intervalMarker26.getStroke();
        java.awt.Paint paint28 = intervalMarker26.getOutlinePaint();
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean31 = xYPlot2.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker26, layer29, false);
        xYPlot2.setBackgroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = xYPlot2.getDrawingSupplier();
        int int35 = objectList1.indexOf((java.lang.Object) xYPlot2);
        objectList1.clear();
        boolean boolean38 = objectList1.equals((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(drawingSupplier34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        double double6 = dateAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis8.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition11 = dateAxis8.getTickMarkPosition();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis8.setLeftArrow(shape12);
        java.awt.Stroke stroke14 = dateAxis8.getAxisLineStroke();
        dateAxis8.setFixedDimension(0.0d);
        boolean boolean18 = dateAxis8.isHiddenValue((long) 255);
        org.jfree.data.Range range19 = dateAxis8.getDefaultAutoRange();
        dateAxis1.setRangeWithMargins(range19, true, true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(range19);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.Plot plot9 = xYPlot0.getParent();
        try {
            float float10 = plot9.getBackgroundImageAlpha();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(plot9);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.REVERSE");
        java.awt.Paint paint2 = categoryAxis1.getLabelPaint();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = xYPlot6.getRangeAxisIndex(valueAxis9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        xYPlot6.setRangeGridlineStroke(stroke13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot6.setFixedDomainAxisSpace(axisSpace15);
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot6.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis21.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = dateAxis21.getTickUnit();
        java.awt.Shape shape25 = dateAxis21.getLeftArrow();
        xYPlot6.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis21, true);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot6.getRangeAxisLocation(4);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj31 = null;
        boolean boolean32 = plotOrientation30.equals(obj31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation29, plotOrientation30);
        try {
            java.util.List list34 = categoryAxis1.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        double double6 = dateAxis1.getLowerBound();
        dateAxis1.setUpperMargin(0.0d);
        boolean boolean9 = dateAxis1.isTickMarksVisible();
        java.text.DateFormat dateFormat10 = dateAxis1.getDateFormatOverride();
        double double11 = dateAxis1.getUpperMargin();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot0.setRangeAxisLocation(5, axisLocation11, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean19 = axisLocation17.equals((java.lang.Object) 128);
        categoryPlot15.setRangeAxisLocation((int) (byte) 10, axisLocation17);
        categoryPlot15.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot15.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj28 = categoryAxis27.clone();
        java.awt.Font font30 = categoryAxis27.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot15.setDomainAxis((int) (short) 10, categoryAxis27);
        java.awt.Color color32 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass33 = color32.getClass();
        categoryPlot15.setRangeCrosshairPaint((java.awt.Paint) color32);
        org.jfree.chart.axis.ValueAxis valueAxis36 = categoryPlot15.getRangeAxisForDataset(255);
        categoryPlot15.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot15.getDomainAxisLocation(0);
        xYPlot0.setRangeAxisLocation(11, axisLocation41);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNotNull(axisLocation41);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setVerticalTickLabels(true);
        java.awt.Stroke stroke24 = dateAxis15.getTickMarkStroke();
        dateAxis15.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition27 = dateAxis15.getTickMarkPosition();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj33 = categoryAxis32.clone();
        java.awt.Font font35 = categoryAxis32.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis32.setMaximumCategoryLabelLines((int) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis32, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot40.getDomainAxisEdge(0);
        try {
            double double43 = dateAxis15.java2DToValue((double) ' ', rectangle2D29, rectangleEdge42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(dateTickMarkPosition27);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder17, jFreeChart18);
        categoryPlot0.setColumnRenderingOrder(sortOrder17);
        java.awt.Color color21 = java.awt.Color.black;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setRange((double) 0.8f, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        dateAxis1.setLowerBound((double) 8);
        dateAxis1.setLowerMargin((double) (-2));
        dateAxis1.setLabelURL("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        java.util.Date date7 = dateAxis3.getMaximumDate();
        boolean boolean8 = day1.equals((java.lang.Object) dateAxis3);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis10.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition13 = dateAxis10.getTickMarkPosition();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis10.setLeftArrow(shape14);
        java.awt.Stroke stroke16 = dateAxis10.getAxisLineStroke();
        dateAxis10.setFixedDimension(0.0d);
        boolean boolean20 = dateAxis10.isHiddenValue((long) 255);
        org.jfree.data.Range range21 = dateAxis10.getDefaultAutoRange();
        dateAxis3.setRange(range21);
        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis26.setLabelAngle(0.0d);
        java.util.Date date29 = dateAxis26.getMaximumDate();
        java.util.Date date30 = dateAxis26.getMaximumDate();
        boolean boolean31 = day24.equals((java.lang.Object) dateAxis26);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis33.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition36 = dateAxis33.getTickMarkPosition();
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis33.setLeftArrow(shape37);
        java.awt.Stroke stroke39 = dateAxis33.getAxisLineStroke();
        dateAxis33.setFixedDimension(0.0d);
        boolean boolean43 = dateAxis33.isHiddenValue((long) 255);
        org.jfree.data.Range range44 = dateAxis33.getDefaultAutoRange();
        dateAxis26.setRange(range44);
        org.jfree.data.time.DateRange dateRange46 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis26.setDefaultAutoRange((org.jfree.data.Range) dateRange46);
        dateAxis3.setRangeWithMargins((org.jfree.data.Range) dateRange46);
        org.jfree.data.time.DateRange dateRange49 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis3.setDefaultAutoRange((org.jfree.data.Range) dateRange49);
        try {
            dateAxis3.setRangeWithMargins((double) 2019, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2019.0) <= upper (97.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(dateRange46);
        org.junit.Assert.assertNotNull(dateRange49);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        boolean boolean7 = dateAxis1.isAutoRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double9 = rectangleInsets8.getRight();
        dateAxis1.setTickLabelInsets(rectangleInsets8);
        double double11 = dateAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("Layer.BACKGROUND");
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(1, axisLocation11, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot0.getRenderer(7);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(categoryItemRenderer15);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color5);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke10 = intervalMarker9.getStroke();
        java.awt.Paint paint11 = intervalMarker9.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker9.setLabelTextAnchor(textAnchor12);
        java.awt.Stroke stroke14 = intervalMarker9.getStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke14);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        xYPlot0.setRenderer(7, xYItemRenderer17, false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis1.configure();
        java.awt.Stroke stroke3 = categoryAxis1.getAxisLineStroke();
        double double4 = categoryAxis1.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        xYPlot7.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean11 = xYPlot7.equals((java.lang.Object) dateTickUnit10);
        dateAxis6.setTickUnit(dateTickUnit10);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) dateTickUnit10, "RectangleAnchor.TOP");
        int int15 = categoryAxis1.getMaximumCategoryLabelLines();
        double double16 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        xYPlot23.configureRangeAxes();
        java.awt.Stroke stroke25 = xYPlot23.getDomainCrosshairStroke();
        boolean boolean26 = xYPlot23.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D27 = xYPlot23.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) 1.0f, plotRenderingInfo22, point2D27);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertNull(legendItemCollection29);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxisForDataset(255);
        categoryPlot0.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        xYPlot29.configureRangeAxes();
        xYPlot29.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean33 = xYPlot29.equals((java.lang.Object) dateTickUnit32);
        dateAxis28.setTickUnit(dateTickUnit32);
        boolean boolean35 = axisLocation26.equals((java.lang.Object) dateAxis28);
        categoryPlot0.setRangeAxisLocation(0, axisLocation26);
        org.jfree.chart.LegendItemCollection legendItemCollection37 = categoryPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(legendItemCollection37);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj1 = null;
        boolean boolean2 = plotOrientation0.equals(obj1);
        java.lang.String str3 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str3.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3, false);
        boolean boolean6 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        double double10 = categoryPlot9.getRangeCrosshairValue();
        categoryPlot9.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot9.setFixedDomainAxisSpace(axisSpace12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.configureRangeAxes();
        xYPlot14.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke20 = intervalMarker19.getStroke();
        java.awt.Paint paint21 = intervalMarker19.getOutlinePaint();
        java.lang.String str22 = intervalMarker19.getLabel();
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean24 = xYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker19, layer23);
        java.util.Collection collection25 = categoryPlot9.getRangeMarkers(layer23);
        try {
            categoryPlot0.addRangeMarker(2019, marker8, layer23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(collection25);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        try {
            dateAxis23.setRangeWithMargins((double) ' ', (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (32.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(dateTickUnit26);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        dateAxis1.setTickLabelsVisible(true);
        dateAxis1.setLabel("RectangleAnchor.TOP");
        dateAxis1.setVisible(false);
        dateAxis1.setRange(4.0d, (double) 1560495599999L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        boolean boolean7 = dateAxis1.isVerticalTickLabels();
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis11.setLabelAngle(0.0d);
        java.util.Date date14 = dateAxis11.getMaximumDate();
        java.util.Date date15 = dateAxis11.getMaximumDate();
        boolean boolean16 = day9.equals((java.lang.Object) dateAxis11);
        java.util.Date date17 = day9.getStart();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis20.setLabelAngle(0.0d);
        java.util.Date date23 = dateAxis20.getMaximumDate();
        double double24 = dateAxis20.getUpperMargin();
        dateAxis20.setTickLabelsVisible(true);
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis20.setMaximumDate(date27);
        dateAxis1.setRange(date17, date27);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date17, timeZone30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        double double33 = categoryPlot32.getRangeCrosshairValue();
        java.awt.Stroke stroke34 = categoryPlot32.getRangeGridlineStroke();
        boolean boolean35 = day31.equals((java.lang.Object) categoryPlot32);
        java.util.Calendar calendar36 = null;
        try {
            long long37 = day31.getLastMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        java.awt.Shape shape5 = dateAxis1.getLeftArrow();
        java.awt.Stroke stroke6 = dateAxis1.getAxisLineStroke();
        java.lang.Class<?> wildcardClass7 = stroke6.getClass();
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis11.setLabelAngle(0.0d);
        java.util.Date date14 = dateAxis11.getMaximumDate();
        java.util.Date date15 = dateAxis11.getMaximumDate();
        boolean boolean16 = day9.equals((java.lang.Object) dateAxis11);
        java.util.Date date17 = day9.getStart();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date17);
        java.awt.Color color19 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass20 = color19.getClass();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis22.setLabelAngle(0.0d);
        java.util.Date date25 = dateAxis22.getMaximumDate();
        double double26 = dateAxis22.getUpperMargin();
        dateAxis22.setTickLabelsVisible(true);
        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis22.setMaximumDate(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date29, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date17, timeZone31);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNull(regularTimePeriod34);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        java.awt.Stroke stroke29 = xYPlot0.getDomainGridlineStroke();
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis33.setLabelAngle(0.0d);
        java.util.Date date36 = dateAxis33.getMaximumDate();
        java.util.Date date37 = dateAxis33.getMaximumDate();
        boolean boolean38 = day31.equals((java.lang.Object) dateAxis33);
        org.jfree.data.Range range39 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis33);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation40 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(range39);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot0.getDataRange(valueAxis8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot0.setDataset((int) (byte) 10, categoryDataset11);
        boolean boolean13 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean20 = axisLocation18.equals((java.lang.Object) 128);
        categoryPlot16.setRangeAxisLocation((int) (byte) 10, axisLocation18);
        categoryPlot16.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot16.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj29 = categoryAxis28.clone();
        java.awt.Font font31 = categoryAxis28.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot16.setDomainAxis((int) (short) 10, categoryAxis28);
        java.awt.Color color33 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass34 = color33.getClass();
        categoryPlot16.setRangeCrosshairPaint((java.awt.Paint) color33);
        categoryPlot16.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot();
        xYPlot39.configureRangeAxes();
        java.awt.Stroke stroke41 = xYPlot39.getDomainCrosshairStroke();
        boolean boolean42 = xYPlot39.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D43 = xYPlot39.getQuadrantOrigin();
        categoryPlot16.zoomDomainAxes((double) 1.0f, plotRenderingInfo38, point2D43);
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo15, point2D43, true);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(point2D43);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19);
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean26 = axisLocation24.equals((java.lang.Object) 128);
        categoryPlot22.setRangeAxisLocation((int) (byte) 10, axisLocation24);
        categoryPlot22.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot22.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj35 = categoryAxis34.clone();
        java.awt.Font font37 = categoryAxis34.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot22.setDomainAxis((int) (short) 10, categoryAxis34);
        java.awt.Color color39 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass40 = color39.getClass();
        categoryPlot22.setRangeCrosshairPaint((java.awt.Paint) color39);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot22.getRangeAxisForDataset(255);
        categoryPlot22.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot22.getDomainAxisLocation(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = categoryPlot22.getOrientation();
        categoryPlot22.clearRangeMarkers();
        boolean boolean51 = sortOrder18.equals((java.lang.Object) categoryPlot22);
        org.jfree.chart.LegendItemCollection legendItemCollection52 = categoryPlot22.getFixedLegendItems();
        categoryPlot22.mapDatasetToDomainAxis((int) ' ', 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(plotOrientation49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(legendItemCollection52);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19);
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker26.setKey((java.lang.Comparable) 10);
        java.lang.Object obj29 = null;
        boolean boolean30 = categoryMarker26.equals(obj29);
        categoryMarker26.setDrawAsLine(false);
        categoryMarker26.setDrawAsLine(false);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        xYPlot35.configureRangeAxes();
        xYPlot35.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke41 = intervalMarker40.getStroke();
        java.awt.Paint paint42 = intervalMarker40.getOutlinePaint();
        java.lang.String str43 = intervalMarker40.getLabel();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean45 = xYPlot35.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker40, layer44);
        boolean boolean46 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker26, layer44);
        java.lang.String str47 = layer44.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Layer.BACKGROUND" + "'", str47.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        xYPlot0.setDomainAxis(valueAxis5);
        org.jfree.data.xy.XYDataset xYDataset7 = xYPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(xYDataset7);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        java.util.Date date5 = dateAxis1.getMaximumDate();
        dateAxis1.setUpperBound((double) 'a');
        dateAxis1.setFixedDimension((double) 12);
        dateAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxisForDataset(255);
        categoryPlot0.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis26.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = dateAxis26.getTickUnit();
        java.awt.Shape shape30 = dateAxis26.getLeftArrow();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray31 = new org.jfree.chart.axis.ValueAxis[] { dateAxis26 };
        categoryPlot0.setRangeAxes(valueAxisArray31);
        categoryPlot0.setAnchorValue((double) 1.0f, true);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        xYPlot36.configureRangeAxes();
        xYPlot36.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker41 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke42 = intervalMarker41.getStroke();
        java.awt.Paint paint43 = intervalMarker41.getOutlinePaint();
        java.lang.String str44 = intervalMarker41.getLabel();
        org.jfree.chart.util.Layer layer45 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean46 = xYPlot36.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker41, layer45);
        java.lang.String str47 = intervalMarker41.getLabel();
        java.awt.Font font48 = intervalMarker41.getLabelFont();
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker41);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(dateTickUnit29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(valueAxisArray31);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(layer45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(font48);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot0.getRangeAxisEdge(0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = xYPlot0.getDatasetRenderingOrder();
        java.lang.String str22 = datasetRenderingOrder21.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str22.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot0.getDataset();
        int int21 = categoryPlot0.getWeight();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setBackgroundAlpha(0.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        xYPlot0.setRangeCrosshairValue((double) (-1.0f), false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.clearDomainMarkers((-1));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot8.setDataset(xYDataset9);
        org.jfree.chart.plot.Plot plot11 = xYPlot8.getRootPlot();
        java.awt.geom.Point2D point2D12 = xYPlot8.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) 6, plotRenderingInfo7, point2D12, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        xYPlot0.datasetChanged(datasetChangeEvent15);
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis20.setLabelAngle(0.0d);
        java.util.Date date23 = dateAxis20.getMaximumDate();
        java.util.Date date24 = dateAxis20.getMaximumDate();
        boolean boolean25 = day18.equals((java.lang.Object) dateAxis20);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis27.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition30 = dateAxis27.getTickMarkPosition();
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis27.setLeftArrow(shape31);
        java.awt.Stroke stroke33 = dateAxis27.getAxisLineStroke();
        dateAxis27.setFixedDimension(0.0d);
        boolean boolean37 = dateAxis27.isHiddenValue((long) 255);
        org.jfree.data.Range range38 = dateAxis27.getDefaultAutoRange();
        dateAxis20.setRange(range38);
        org.jfree.data.Range range40 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis20);
        java.awt.Paint paint41 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertNull(paint41);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        dateAxis1.setLowerBound((double) 8);
        dateAxis1.setLowerMargin((double) (-2));
        dateAxis1.setLabelToolTip("");
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color32);
        int int34 = xYPlot0.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.plot.Plot plot7 = dateAxis1.getPlot();
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMinimumDate(date8);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        dateAxis1.setTickLabelsVisible(true);
        dateAxis1.setLabel("RectangleAnchor.TOP");
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis11.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.awt.Shape shape15 = dateAxis11.getLeftArrow();
        dateAxis1.setLeftArrow(shape15);
        boolean boolean17 = dateAxis1.isVerticalTickLabels();
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor19 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.util.SortOrder sortOrder20 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder20, jFreeChart21);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent22.setType(chartChangeEventType23);
        boolean boolean25 = categoryAnchor19.equals((java.lang.Object) chartChangeEventType23);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis1, jFreeChart18, chartChangeEventType23);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        xYPlot29.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        int int33 = xYPlot29.getRangeAxisIndex(valueAxis32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot29.setNoDataMessagePaint((java.awt.Paint) color34);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke39 = intervalMarker38.getStroke();
        java.awt.Paint paint40 = intervalMarker38.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor41 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker38.setLabelTextAnchor(textAnchor41);
        java.awt.Stroke stroke43 = intervalMarker38.getStroke();
        xYPlot29.setRangeZeroBaselineStroke(stroke43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = xYPlot29.getRangeAxisEdge();
        try {
            double double46 = dateAxis1.valueToJava2D((double) (short) 10, rectangle2D28, rectangleEdge45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(categoryAnchor19);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot0.getDataRange(valueAxis8);
        double double10 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot0.getDomainAxis((int) (byte) 100);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(categoryAxis12);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.configureRangeAxes();
        xYPlot1.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean5 = xYPlot1.equals((java.lang.Object) dateTickUnit4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot1.getDomainAxisLocation(9);
        boolean boolean8 = unitType0.equals((java.lang.Object) xYPlot1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot2.getRangeAxisIndex(valueAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        java.awt.Stroke stroke9 = xYPlot7.getDomainCrosshairStroke();
        xYPlot2.setRangeGridlineStroke(stroke9);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke14 = intervalMarker13.getStroke();
        java.awt.Paint paint15 = intervalMarker13.getOutlinePaint();
        java.lang.String str16 = intervalMarker13.getLabel();
        java.awt.Color color17 = java.awt.Color.orange;
        intervalMarker13.setPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot2.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13, layer19);
        int int21 = xYPlot2.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = xYPlot2.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke27 = intervalMarker26.getStroke();
        java.awt.Paint paint28 = intervalMarker26.getOutlinePaint();
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean31 = xYPlot2.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker26, layer29, false);
        xYPlot2.setBackgroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = xYPlot2.getDrawingSupplier();
        int int35 = objectList1.indexOf((java.lang.Object) xYPlot2);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot2.getRangeAxisLocation();
        java.awt.Paint paint37 = xYPlot2.getNoDataMessagePaint();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis39.setLabelAngle(0.0d);
        java.util.Date date42 = dateAxis39.getMaximumDate();
        double double43 = dateAxis39.getUpperMargin();
        dateAxis39.setTickLabelsVisible(true);
        dateAxis39.setAutoRangeMinimumSize((double) '4');
        java.text.DateFormat dateFormat48 = dateAxis39.getDateFormatOverride();
        int int49 = xYPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis39);
        xYPlot2.mapDatasetToDomainAxis(6, 500);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(drawingSupplier34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertNull(dateFormat48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getMiddleMillisecond();
//        int int3 = day1.getYear();
//        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
//        java.awt.Stroke stroke7 = intervalMarker6.getStroke();
//        intervalMarker6.setLabel("hi!");
//        java.awt.Font font10 = intervalMarker6.getLabelFont();
//        boolean boolean11 = day1.equals((java.lang.Object) intervalMarker6);
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(stroke7);
//        org.junit.Assert.assertNotNull(font10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        boolean boolean3 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.clearDomainMarkers((-1));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot8.setDataset(xYDataset9);
        org.jfree.chart.plot.Plot plot11 = xYPlot8.getRootPlot();
        java.awt.geom.Point2D point2D12 = xYPlot8.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) 6, plotRenderingInfo7, point2D12, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        xYPlot0.datasetChanged(datasetChangeEvent15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        xYPlot0.setBackgroundAlpha(0.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        int int6 = xYPlot0.getIndexOf(xYItemRenderer5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = xYPlot7.getRangeAxisIndex(valueAxis10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.configureRangeAxes();
        java.awt.Stroke stroke14 = xYPlot12.getDomainCrosshairStroke();
        xYPlot7.setRangeGridlineStroke(stroke14);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke19 = intervalMarker18.getStroke();
        java.awt.Paint paint20 = intervalMarker18.getOutlinePaint();
        java.lang.String str21 = intervalMarker18.getLabel();
        java.awt.Color color22 = java.awt.Color.orange;
        intervalMarker18.setPaint((java.awt.Paint) color22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker18, layer24);
        int int26 = xYPlot7.getDomainAxisCount();
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        xYPlot7.addChangeListener(plotChangeListener27);
        java.awt.Stroke stroke29 = xYPlot7.getOutlineStroke();
        xYPlot0.setDomainGridlineStroke(stroke29);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        java.awt.Paint paint8 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str10 = rectangleInsets9.toString();
        categoryPlot0.setInsets(rectangleInsets9, false);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets9.createInsetRectangle(rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str10.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        xYPlot0.addChangeListener(plotChangeListener19);
        org.jfree.data.general.DatasetGroup datasetGroup21 = xYPlot0.getDatasetGroup();
        java.awt.Font font22 = xYPlot0.getNoDataMessageFont();
        java.awt.Paint paint23 = xYPlot0.getDomainGridlinePaint();
        java.lang.Object obj24 = xYPlot0.clone();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        org.jfree.chart.plot.CrosshairState crosshairState29 = null;
        boolean boolean30 = xYPlot0.render(graphics2D25, rectangle2D26, 0, plotRenderingInfo28, crosshairState29);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker1.setKey((java.lang.Comparable) 10);
        java.lang.Object obj4 = null;
        boolean boolean5 = categoryMarker1.equals(obj4);
        categoryMarker1.setDrawAsLine(false);
        categoryMarker1.setDrawAsLine(false);
        java.lang.Object obj10 = categoryMarker1.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis9.setLabelAngle(0.0d);
        java.util.Date date12 = dateAxis9.getMaximumDate();
        dateAxis9.setAxisLineVisible(true);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis17.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = dateAxis17.getTickMarkPosition();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis17.setLeftArrow(shape21);
        boolean boolean23 = dateAxis17.isVerticalTickLabels();
        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis27.setLabelAngle(0.0d);
        java.util.Date date30 = dateAxis27.getMaximumDate();
        java.util.Date date31 = dateAxis27.getMaximumDate();
        boolean boolean32 = day25.equals((java.lang.Object) dateAxis27);
        java.util.Date date33 = day25.getStart();
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis36.setLabelAngle(0.0d);
        java.util.Date date39 = dateAxis36.getMaximumDate();
        double double40 = dateAxis36.getUpperMargin();
        dateAxis36.setTickLabelsVisible(true);
        java.util.Date date43 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis36.setMaximumDate(date43);
        dateAxis17.setRange(date33, date43);
        dateAxis9.setMinimumDate(date43);
        java.util.Date date47 = dateAxis9.getMaximumDate();
        double double48 = dateAxis9.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.data.xy.XYDataset xYDataset21 = xYPlot0.getDataset();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot0.getDomainAxisForDataset(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 2019 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNull(xYDataset21);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj2 = categoryAxis1.clone();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 1);
        double double7 = categoryAxis1.getLowerMargin();
        boolean boolean8 = categoryAxis1.isTickMarksVisible();
        double double9 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setMaximumCategoryLabelLines((int) '#');
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        org.jfree.chart.plot.Plot plot7 = dateAxis1.getPlot();
        java.util.TimeZone timeZone8 = dateAxis1.getTimeZone();
        dateAxis1.setNegativeArrowVisible(true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis8.setLabelAngle(0.0d);
        java.util.Date date11 = dateAxis8.getMaximumDate();
        double double12 = dateAxis8.getUpperMargin();
        dateAxis8.setTickLabelsVisible(true);
        dateAxis8.setAutoRangeMinimumSize((double) '4');
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis20.setLabelAngle(0.0d);
        java.util.Date date23 = dateAxis20.getMaximumDate();
        java.util.Date date24 = dateAxis20.getMaximumDate();
        boolean boolean25 = day18.equals((java.lang.Object) dateAxis20);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis27.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition30 = dateAxis27.getTickMarkPosition();
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis27.setLeftArrow(shape31);
        java.awt.Stroke stroke33 = dateAxis27.getAxisLineStroke();
        dateAxis27.setFixedDimension(0.0d);
        boolean boolean37 = dateAxis27.isHiddenValue((long) 255);
        org.jfree.data.Range range38 = dateAxis27.getDefaultAutoRange();
        dateAxis20.setRange(range38);
        org.jfree.data.time.DateRange dateRange40 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis20.setDefaultAutoRange((org.jfree.data.Range) dateRange40);
        dateAxis8.setRange((org.jfree.data.Range) dateRange40, false, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange40);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(dateRange40);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        double double6 = dateAxis1.getLowerBound();
        dateAxis1.setUpperMargin(0.0d);
        boolean boolean9 = dateAxis1.isTickMarksVisible();
        java.text.DateFormat dateFormat10 = dateAxis1.getDateFormatOverride();
        dateAxis1.setFixedDimension((double) 100);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(dateFormat10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis1.configure();
        java.awt.Stroke stroke3 = categoryAxis1.getAxisLineStroke();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        boolean boolean5 = categoryAxis1.isTickLabelsVisible();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.configureRangeAxes();
        xYPlot12.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean16 = xYPlot12.equals((java.lang.Object) dateTickUnit15);
        dateAxis11.setTickUnit(dateTickUnit15);
        boolean boolean18 = axisLocation9.equals((java.lang.Object) dateAxis11);
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation9, plotOrientation19);
        try {
            double double21 = categoryAxis1.getCategoryEnd((int) (short) 100, (int) 'a', rectangle2D8, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        xYPlot0.zoomDomainAxes((double) 100, plotRenderingInfo10, point2D11);
        boolean boolean13 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot0.getDomainAxis((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray5 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray5);
        java.awt.Paint paint7 = defaultDrawingSupplier6.getNextFillPaint();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        int int12 = xYPlot8.getRangeAxisIndex(valueAxis11);
        boolean boolean13 = defaultDrawingSupplier6.equals((java.lang.Object) int12);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot0.getDataset();
        categoryPlot0.setWeight((int) (byte) -1);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(categoryDataset20);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean7 = xYPlot0.isDomainZeroBaselineVisible();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke13 = intervalMarker12.getStroke();
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        intervalMarker12.setLabelTextAnchor(textAnchor14);
        boolean boolean16 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        xYPlot0.setDomainCrosshairValue((double) 8, false);
        java.awt.Stroke stroke16 = xYPlot0.getDomainGridlineStroke();
        boolean boolean17 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        xYPlot0.removeChangeListener(plotChangeListener18);
        boolean boolean20 = xYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis8.setLabelAngle(0.0d);
        java.util.Date date11 = dateAxis8.getMaximumDate();
        dateAxis1.setMaximumDate(date11);
        dateAxis1.resizeRange((double) 3, (double) 0.0f);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot2.getRangeAxisIndex(valueAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        java.awt.Stroke stroke9 = xYPlot7.getDomainCrosshairStroke();
        xYPlot2.setRangeGridlineStroke(stroke9);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke14 = intervalMarker13.getStroke();
        java.awt.Paint paint15 = intervalMarker13.getOutlinePaint();
        java.lang.String str16 = intervalMarker13.getLabel();
        java.awt.Color color17 = java.awt.Color.orange;
        intervalMarker13.setPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot2.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13, layer19);
        int int21 = xYPlot2.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = xYPlot2.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke27 = intervalMarker26.getStroke();
        java.awt.Paint paint28 = intervalMarker26.getOutlinePaint();
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean31 = xYPlot2.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker26, layer29, false);
        xYPlot2.setBackgroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = xYPlot2.getDrawingSupplier();
        int int35 = objectList1.indexOf((java.lang.Object) xYPlot2);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot2.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str38 = plotOrientation37.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation36, plotOrientation37);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(drawingSupplier34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str38.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) (byte) 100, plotRenderingInfo4, point2D5, true);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray8 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray8);
        boolean boolean10 = xYPlot0.isDomainCrosshairVisible();
        java.awt.Paint[] paintArray11 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray12 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray13 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray14 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray15 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray16 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray11, paintArray12, paintArray13, strokeArray14, strokeArray15, shapeArray16);
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextFillPaint();
        java.lang.Object obj19 = defaultDrawingSupplier17.clone();
        java.awt.Stroke stroke20 = defaultDrawingSupplier17.getNextOutlineStroke();
        xYPlot0.setDomainZeroBaselineStroke(stroke20);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(xYItemRendererArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke6 = intervalMarker5.getStroke();
        java.awt.Paint paint7 = intervalMarker5.getOutlinePaint();
        java.lang.String str8 = intervalMarker5.getLabel();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = intervalMarker5.getLabelOffset();
        double double13 = rectangleInsets11.calculateRightInset((double) 10.0f);
        java.lang.String str14 = rectangleInsets11.toString();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str14.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.data.general.DatasetGroup datasetGroup21 = xYPlot0.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(datasetGroup21);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis1.configure();
        java.awt.Stroke stroke3 = categoryAxis1.getAxisLineStroke();
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.chart.plot.Plot plot6 = categoryAxis1.getPlot();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot0.addChangeListener(plotChangeListener20);
        java.awt.Stroke stroke22 = xYPlot0.getOutlineStroke();
        java.awt.Paint paint23 = xYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot2.getRangeAxisIndex(valueAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        java.awt.Stroke stroke9 = xYPlot7.getDomainCrosshairStroke();
        xYPlot2.setRangeGridlineStroke(stroke9);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke14 = intervalMarker13.getStroke();
        java.awt.Paint paint15 = intervalMarker13.getOutlinePaint();
        java.lang.String str16 = intervalMarker13.getLabel();
        java.awt.Color color17 = java.awt.Color.orange;
        intervalMarker13.setPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot2.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker13, layer19);
        int int21 = xYPlot2.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = xYPlot2.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke27 = intervalMarker26.getStroke();
        java.awt.Paint paint28 = intervalMarker26.getOutlinePaint();
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean31 = xYPlot2.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker26, layer29, false);
        xYPlot2.setBackgroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = xYPlot2.getDrawingSupplier();
        int int35 = objectList1.indexOf((java.lang.Object) xYPlot2);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot2.getRangeAxisLocation();
        java.awt.Paint paint37 = xYPlot2.getNoDataMessagePaint();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis39.setLabelAngle(0.0d);
        java.util.Date date42 = dateAxis39.getMaximumDate();
        double double43 = dateAxis39.getUpperMargin();
        dateAxis39.setTickLabelsVisible(true);
        dateAxis39.setAutoRangeMinimumSize((double) '4');
        java.text.DateFormat dateFormat48 = dateAxis39.getDateFormatOverride();
        int int49 = xYPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis39);
        org.jfree.chart.axis.ValueAxis valueAxis50 = xYPlot2.getRangeAxis();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(drawingSupplier34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertNull(dateFormat48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNull(valueAxis50);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        org.jfree.chart.util.UnitType unitType2 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str1.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(unitType2);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getMiddleMillisecond();
//        int int3 = day1.getYear();
//        int int4 = day1.getYear();
//        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
//        xYPlot5.setNoDataMessage("hi!");
//        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
//        int int9 = xYPlot5.getRangeAxisIndex(valueAxis8);
//        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
//        xYPlot10.configureRangeAxes();
//        java.awt.Stroke stroke12 = xYPlot10.getDomainCrosshairStroke();
//        xYPlot5.setRangeGridlineStroke(stroke12);
//        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
//        java.awt.Stroke stroke17 = intervalMarker16.getStroke();
//        java.awt.Paint paint18 = intervalMarker16.getOutlinePaint();
//        java.lang.String str19 = intervalMarker16.getLabel();
//        java.awt.Color color20 = java.awt.Color.orange;
//        intervalMarker16.setPaint((java.awt.Paint) color20);
//        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
//        xYPlot5.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker16, layer22);
//        java.awt.Stroke stroke24 = null;
//        xYPlot5.setOutlineStroke(stroke24);
//        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
//        dateAxis28.setLabelAngle(0.0d);
//        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis28.getTickUnit();
//        xYPlot5.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis28, true);
//        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray34 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
//        xYPlot5.setRenderers(xYItemRendererArray34);
//        int int36 = day1.compareTo((java.lang.Object) xYPlot5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day1.previous();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(stroke12);
//        org.junit.Assert.assertNotNull(stroke17);
//        org.junit.Assert.assertNotNull(paint18);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNotNull(color20);
//        org.junit.Assert.assertNotNull(layer22);
//        org.junit.Assert.assertNotNull(dateTickUnit31);
//        org.junit.Assert.assertNotNull(xYItemRendererArray34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot0.getDataRange(valueAxis8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot0.setDataset((int) (byte) 10, categoryDataset11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            categoryPlot0.drawBackground(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot2.getRangeAxisIndex(valueAxis5);
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke11 = intervalMarker10.getStroke();
        java.awt.Paint paint12 = intervalMarker10.getOutlinePaint();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        xYPlot13.configureRangeAxes();
        xYPlot13.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke19 = intervalMarker18.getStroke();
        java.awt.Paint paint20 = intervalMarker18.getOutlinePaint();
        java.lang.String str21 = intervalMarker18.getLabel();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean23 = xYPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker18, layer22);
        boolean boolean24 = xYPlot2.removeDomainMarker(5, (org.jfree.chart.plot.Marker) intervalMarker10, layer22);
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean26 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer25);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19);
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean26 = axisLocation24.equals((java.lang.Object) 128);
        categoryPlot22.setRangeAxisLocation((int) (byte) 10, axisLocation24);
        categoryPlot22.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot22.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj35 = categoryAxis34.clone();
        java.awt.Font font37 = categoryAxis34.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot22.setDomainAxis((int) (short) 10, categoryAxis34);
        java.awt.Color color39 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass40 = color39.getClass();
        categoryPlot22.setRangeCrosshairPaint((java.awt.Paint) color39);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot22.getRangeAxisForDataset(255);
        categoryPlot22.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot22.getDomainAxisLocation(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = categoryPlot22.getOrientation();
        categoryPlot22.clearRangeMarkers();
        boolean boolean51 = sortOrder18.equals((java.lang.Object) categoryPlot22);
        org.jfree.chart.LegendItemCollection legendItemCollection52 = categoryPlot22.getFixedLegendItems();
        categoryPlot22.setRangeCrosshairValue(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(plotOrientation49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(legendItemCollection52);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray5 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray5);
        java.awt.Paint paint7 = defaultDrawingSupplier6.getNextFillPaint();
        java.lang.Object obj8 = defaultDrawingSupplier6.clone();
        java.awt.Stroke stroke9 = defaultDrawingSupplier6.getNextOutlineStroke();
        java.awt.Stroke stroke10 = defaultDrawingSupplier6.getNextStroke();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
//        dateAxis1.setLabelAngle(0.0d);
//        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
//        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis1.setLeftArrow(shape5);
//        boolean boolean7 = dateAxis1.isVerticalTickLabels();
//        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
//        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
//        dateAxis11.setLabelAngle(0.0d);
//        java.util.Date date14 = dateAxis11.getMaximumDate();
//        java.util.Date date15 = dateAxis11.getMaximumDate();
//        boolean boolean16 = day9.equals((java.lang.Object) dateAxis11);
//        java.util.Date date17 = day9.getStart();
//        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date17);
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
//        dateAxis20.setLabelAngle(0.0d);
//        java.util.Date date23 = dateAxis20.getMaximumDate();
//        double double24 = dateAxis20.getUpperMargin();
//        dateAxis20.setTickLabelsVisible(true);
//        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis20.setMaximumDate(date27);
//        dateAxis1.setRange(date17, date27);
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date17, timeZone30);
//        long long32 = day31.getLastMillisecond();
//        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
//        org.junit.Assert.assertNotNull(shape5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560495599999L + "'", long32 == 1560495599999L);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        java.util.Date date5 = dateAxis1.getMaximumDate();
        dateAxis1.setUpperBound((double) 'a');
        double double8 = dateAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis1.getTickLabelInsets();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        intervalMarker2.setLabel("hi!");
        java.awt.Font font6 = intervalMarker2.getLabelFont();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = xYPlot7.getRangeAxisIndex(valueAxis10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.configureRangeAxes();
        java.awt.Stroke stroke14 = xYPlot12.getDomainCrosshairStroke();
        xYPlot7.setRangeGridlineStroke(stroke14);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke19 = intervalMarker18.getStroke();
        java.awt.Paint paint20 = intervalMarker18.getOutlinePaint();
        java.lang.String str21 = intervalMarker18.getLabel();
        java.awt.Color color22 = java.awt.Color.orange;
        intervalMarker18.setPaint((java.awt.Paint) color22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker18, layer24);
        java.awt.Stroke stroke26 = null;
        xYPlot7.setOutlineStroke(stroke26);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis30.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = dateAxis30.getTickUnit();
        xYPlot7.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis30, true);
        java.awt.Stroke stroke36 = xYPlot7.getDomainGridlineStroke();
        intervalMarker2.setOutlineStroke(stroke36);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        xYPlot0.setRangeZeroBaselineVisible(false);
        boolean boolean7 = xYPlot0.isDomainZeroBaselineVisible();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot0.getRenderer((int) '4');
        org.jfree.data.xy.XYDataset xYDataset13 = xYPlot0.getDataset(0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertNull(xYDataset13);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        java.util.Date date5 = dateAxis1.getMaximumDate();
        dateAxis1.setUpperBound((double) 'a');
        double double8 = dateAxis1.getUpperMargin();
        java.awt.Paint paint9 = dateAxis1.getTickMarkPaint();
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis13.setLabelAngle(0.0d);
        java.util.Date date16 = dateAxis13.getMaximumDate();
        java.util.Date date17 = dateAxis13.getMaximumDate();
        boolean boolean18 = day11.equals((java.lang.Object) dateAxis13);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis20.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition23 = dateAxis20.getTickMarkPosition();
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis20.setLeftArrow(shape24);
        java.awt.Stroke stroke26 = dateAxis20.getAxisLineStroke();
        dateAxis20.setFixedDimension(0.0d);
        boolean boolean30 = dateAxis20.isHiddenValue((long) 255);
        org.jfree.data.Range range31 = dateAxis20.getDefaultAutoRange();
        dateAxis13.setRange(range31);
        dateAxis1.setRangeWithMargins(range31, false, false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        dateAxis1.setTickLabelsVisible(true);
        dateAxis1.setLabel("RectangleAnchor.TOP");
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis11.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        java.awt.Shape shape15 = dateAxis11.getLeftArrow();
        dateAxis1.setLeftArrow(shape15);
        boolean boolean17 = dateAxis1.isVerticalTickLabels();
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor19 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.util.SortOrder sortOrder20 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder20, jFreeChart21);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent22.setType(chartChangeEventType23);
        boolean boolean25 = categoryAnchor19.equals((java.lang.Object) chartChangeEventType23);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis1, jFreeChart18, chartChangeEventType23);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis28.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition31 = dateAxis28.getTickMarkPosition();
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis28.setLeftArrow(shape32);
        java.awt.Stroke stroke34 = dateAxis28.getAxisLineStroke();
        dateAxis28.setFixedDimension(0.0d);
        java.lang.String str37 = dateAxis28.getLabel();
        dateAxis28.centerRange((double) 1L);
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis43.setLabelAngle(0.0d);
        java.util.Date date46 = dateAxis43.getMaximumDate();
        java.util.Date date47 = dateAxis43.getMaximumDate();
        boolean boolean48 = day41.equals((java.lang.Object) dateAxis43);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis50.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition53 = dateAxis50.getTickMarkPosition();
        java.awt.Shape shape54 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis50.setLeftArrow(shape54);
        java.awt.Stroke stroke56 = dateAxis50.getAxisLineStroke();
        dateAxis50.setFixedDimension(0.0d);
        boolean boolean60 = dateAxis50.isHiddenValue((long) 255);
        org.jfree.data.Range range61 = dateAxis50.getDefaultAutoRange();
        dateAxis43.setRange(range61);
        java.util.Date date63 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date63);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis66.setLabelAngle(0.0d);
        java.util.Date date69 = dateAxis66.getMaximumDate();
        java.util.Date date70 = dateAxis66.getMaximumDate();
        boolean boolean71 = day64.equals((java.lang.Object) dateAxis66);
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis73.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition76 = dateAxis73.getTickMarkPosition();
        java.awt.Shape shape77 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis73.setLeftArrow(shape77);
        java.awt.Stroke stroke79 = dateAxis73.getAxisLineStroke();
        dateAxis73.setFixedDimension(0.0d);
        boolean boolean83 = dateAxis73.isHiddenValue((long) 255);
        org.jfree.data.Range range84 = dateAxis73.getDefaultAutoRange();
        dateAxis66.setRange(range84);
        org.jfree.data.time.DateRange dateRange86 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis66.setDefaultAutoRange((org.jfree.data.Range) dateRange86);
        dateAxis43.setRangeWithMargins((org.jfree.data.Range) dateRange86);
        org.jfree.data.time.DateRange dateRange89 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis43.setDefaultAutoRange((org.jfree.data.Range) dateRange89);
        dateAxis28.setRange((org.jfree.data.Range) dateRange89);
        dateAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange89);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(categoryAnchor19);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition53);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition76);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(range84);
        org.junit.Assert.assertNotNull(dateRange86);
        org.junit.Assert.assertNotNull(dateRange89);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.data.RangeType rangeType2 = null;
        try {
            numberAxis1.setRangeType(rangeType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot0.setRangeAxisLocation(5, axisLocation11, false);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.configureRangeAxes();
        xYPlot14.setDomainCrosshairValue((double) '#');
        xYPlot14.setDomainCrosshairLockedOnData(false);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot14);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        xYPlot22.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        int int26 = xYPlot22.getRangeAxisIndex(valueAxis25);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        xYPlot27.configureRangeAxes();
        java.awt.Stroke stroke29 = xYPlot27.getDomainCrosshairStroke();
        xYPlot22.setRangeGridlineStroke(stroke29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        xYPlot22.setFixedDomainAxisSpace(axisSpace31);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot22.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis37.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = dateAxis37.getTickUnit();
        java.awt.Shape shape41 = dateAxis37.getLeftArrow();
        xYPlot22.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis37, true);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot22.getRangeAxisLocation(4);
        xYPlot0.setDomainAxisLocation((int) (byte) 100, axisLocation45, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = xYPlot0.getAxisOffset();
        double double49 = rectangleInsets48.getTop();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertNotNull(dateTickUnit40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 4.0d + "'", double49 == 4.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean11 = axisLocation9.equals((java.lang.Object) 128);
        categoryPlot7.setRangeAxisLocation((int) (byte) 10, axisLocation9);
        org.jfree.chart.axis.AxisLocation axisLocation13 = axisLocation9.getOpposite();
        categoryPlot0.setDomainAxisLocation((int) '4', axisLocation13, true);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.REVERSE");
        java.lang.Object obj2 = categoryAxis1.clone();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 2);
        float float5 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis6.setLabelAngle(0.0d);
        java.util.Date date9 = dateAxis6.getMaximumDate();
        dateAxis1.setMaximumDate(date9);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape11);
        boolean boolean13 = dateAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj2 = categoryAxis1.clone();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.configureRangeAxes();
        xYPlot9.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean13 = xYPlot9.equals((java.lang.Object) dateTickUnit12);
        dateAxis8.setTickUnit(dateTickUnit12);
        boolean boolean15 = axisLocation6.equals((java.lang.Object) dateAxis8);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation6, plotOrientation16);
        try {
            double double18 = categoryAxis1.getCategoryMiddle(12, 100, rectangle2D5, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color3 = java.awt.Color.GRAY;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color3);
        float float5 = intervalMarker2.getAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = intervalMarker2.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets6.createOutsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8f + "'", float5 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        dateAxis1.setTickLabelsVisible(true);
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMaximumDate(date8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.configureRangeAxes();
        xYPlot12.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean16 = xYPlot12.equals((java.lang.Object) dateTickUnit15);
        dateAxis11.setTickUnit(dateTickUnit15);
        dateAxis1.setTickUnit(dateTickUnit15, false, false);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis22.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition25 = dateAxis22.getTickMarkPosition();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis22.setLeftArrow(shape26);
        java.awt.Stroke stroke28 = dateAxis22.getAxisLineStroke();
        dateAxis22.setFixedDimension(0.0d);
        boolean boolean32 = dateAxis22.isHiddenValue((long) 255);
        org.jfree.data.Range range33 = dateAxis22.getDefaultAutoRange();
        dateAxis1.setRange(range33);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(range33);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit5);
        dateAxis1.setTickMarkOutsideLength((float) (byte) 0);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        java.lang.Object obj3 = objectList1.get(3);
        java.lang.Object obj5 = objectList1.get(4);
        int int6 = objectList1.size();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        xYPlot1.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        int int5 = xYPlot1.getRangeAxisIndex(valueAxis4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.configureRangeAxes();
        java.awt.Stroke stroke8 = xYPlot6.getDomainCrosshairStroke();
        xYPlot1.setRangeGridlineStroke(stroke8);
        org.jfree.chart.plot.IntervalMarker intervalMarker12 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke13 = intervalMarker12.getStroke();
        java.awt.Paint paint14 = intervalMarker12.getOutlinePaint();
        java.lang.String str15 = intervalMarker12.getLabel();
        java.awt.Color color16 = java.awt.Color.orange;
        intervalMarker12.setPaint((java.awt.Paint) color16);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot1.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker12, layer18);
        int int20 = xYPlot1.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = xYPlot1.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke26 = intervalMarker25.getStroke();
        java.awt.Paint paint27 = intervalMarker25.getOutlinePaint();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean30 = xYPlot1.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker25, layer28, false);
        xYPlot1.setBackgroundAlpha((float) (byte) 1);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot1.setNoDataMessagePaint((java.awt.Paint) color33);
        float[] floatArray42 = new float[] { 8, (byte) 1, (short) 10, 10L };
        float[] floatArray43 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (short) 10, (int) ' ', floatArray42);
        float[] floatArray44 = color33.getRGBColorComponents(floatArray43);
        boolean boolean45 = defaultDrawingSupplier0.equals((java.lang.Object) floatArray44);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot0.getFixedDomainAxisSpace();
        java.awt.Paint paint22 = xYPlot0.getRangeTickBandPaint();
        int int23 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color5);
        float[] floatArray14 = new float[] { 8, (byte) 1, (short) 10, 10L };
        float[] floatArray15 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (short) 10, (int) ' ', floatArray14);
        boolean boolean16 = xYPlot0.equals((java.lang.Object) floatArray15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        xYPlot0.mapDatasetToDomainAxis(4, 10);
        org.jfree.data.general.DatasetGroup datasetGroup6 = xYPlot0.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis9.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = dateAxis9.getTickMarkPosition();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis9.setLeftArrow(shape13);
        java.awt.Stroke stroke15 = dateAxis9.getAxisLineStroke();
        dateAxis9.setFixedDimension(0.0d);
        java.lang.String str18 = dateAxis9.getLabel();
        dateAxis9.centerRange((double) 1L);
        xYPlot0.setDomainAxis(64, (org.jfree.chart.axis.ValueAxis) dateAxis9);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_RED;
        int int25 = color24.getGreen();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        double double27 = categoryPlot26.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis29.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition32 = dateAxis29.getTickMarkPosition();
        java.awt.Stroke stroke33 = dateAxis29.getAxisLineStroke();
        dateAxis29.setLowerBound((double) 8);
        java.awt.Shape shape36 = dateAxis29.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        xYPlot37.configureRangeAxes();
        java.awt.Stroke stroke39 = xYPlot37.getDomainCrosshairStroke();
        java.awt.Font font40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot37.setNoDataMessageFont(font40);
        dateAxis29.setTickLabelFont(font40);
        org.jfree.data.Range range43 = categoryPlot26.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis29);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis45.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition48 = dateAxis45.getTickMarkPosition();
        java.awt.Stroke stroke49 = dateAxis45.getAxisLineStroke();
        double double50 = dateAxis45.getLowerBound();
        java.awt.Font font51 = dateAxis45.getTickLabelFont();
        categoryPlot26.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis45);
        org.jfree.chart.plot.IntervalMarker intervalMarker55 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke56 = intervalMarker55.getStroke();
        java.awt.Paint paint57 = intervalMarker55.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor58 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker55.setLabelTextAnchor(textAnchor58);
        java.awt.Stroke stroke60 = intervalMarker55.getStroke();
        dateAxis45.setTickMarkStroke(stroke60);
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot();
        xYPlot62.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        int int66 = xYPlot62.getRangeAxisIndex(valueAxis65);
        java.awt.Color color67 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot62.setNoDataMessagePaint((java.awt.Paint) color67);
        java.awt.image.ColorModel colorModel69 = null;
        java.awt.Rectangle rectangle70 = null;
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        java.awt.geom.AffineTransform affineTransform72 = null;
        java.awt.RenderingHints renderingHints73 = null;
        java.awt.PaintContext paintContext74 = color67.createContext(colorModel69, rectangle70, rectangle2D71, affineTransform72, renderingHints73);
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis76.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit79 = dateAxis76.getTickUnit();
        java.awt.Stroke stroke80 = dateAxis76.getAxisLineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker82 = new org.jfree.chart.plot.IntervalMarker((double) '4', (double) (byte) 100, (java.awt.Paint) color24, stroke60, (java.awt.Paint) color67, stroke80, 0.0f);
        dateAxis9.setTickMarkStroke(stroke80);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 64 + "'", int25 == 64);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(dateTickMarkPosition48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(textAnchor58);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(paintContext74);
        org.junit.Assert.assertNotNull(dateTickUnit79);
        org.junit.Assert.assertNotNull(stroke80);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = xYPlot0.equals((java.lang.Object) dateTickUnit3);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = xYPlot0.getSeriesRenderingOrder();
        java.lang.Object obj6 = null;
        boolean boolean7 = seriesRenderingOrder5.equals(obj6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        xYPlot8.configureRangeAxes();
        xYPlot8.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean12 = xYPlot8.equals((java.lang.Object) dateTickUnit11);
        xYPlot8.configureRangeAxes();
        java.awt.Stroke stroke14 = xYPlot8.getDomainZeroBaselineStroke();
        boolean boolean15 = seriesRenderingOrder5.equals((java.lang.Object) xYPlot8);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        xYPlot8.datasetChanged(datasetChangeEvent16);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        xYPlot0.addChangeListener(plotChangeListener20);
        java.awt.Stroke stroke22 = xYPlot0.getRangeZeroBaselineStroke();
        boolean boolean23 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = xYPlot0.equals((java.lang.Object) dateTickUnit3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = xYPlot0.getDomainAxisLocation(9);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot7.setDataset(xYDataset8);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        xYPlot11.setDomainCrosshairValue((double) '#');
        xYPlot11.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot11.setDomainAxisLocation(axisLocation17);
        xYPlot7.setRangeAxisLocation((int) 'a', axisLocation17, true);
        xYPlot0.setDomainAxisLocation(axisLocation17, true);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = null;
        try {
            xYPlot0.setDomainAxes(valueAxisArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color3 = java.awt.Color.GRAY;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color3);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor5);
        java.awt.Font font7 = intervalMarker2.getLabelFont();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        boolean boolean21 = xYPlot0.isRangeZoomable();
        java.awt.Image image22 = xYPlot0.getBackgroundImage();
        java.lang.Object obj23 = xYPlot0.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(image22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot0.setRenderer(0, xYItemRenderer33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = dateAxis36.getTickUnit();
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis36);
        java.lang.String str39 = xYPlot0.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTickUnit37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxisForDataset(255);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis25.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition28 = dateAxis25.getTickMarkPosition();
        java.awt.Stroke stroke29 = dateAxis25.getAxisLineStroke();
        dateAxis25.setLowerBound((double) 8);
        java.awt.Shape shape32 = dateAxis25.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        xYPlot33.configureRangeAxes();
        java.awt.Stroke stroke35 = xYPlot33.getDomainCrosshairStroke();
        java.awt.Font font36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot33.setNoDataMessageFont(font36);
        dateAxis25.setTickLabelFont(font36);
        org.jfree.data.Range range39 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.axis.ValueAxis valueAxis41 = categoryPlot0.getRangeAxisForDataset(13);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(dateTickMarkPosition28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNull(valueAxis41);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        xYPlot0.zoomRangeAxes((double) 1.0f, 0.0d, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot0.setRangeAxisLocation(5, axisLocation11, false);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        xYPlot14.configureRangeAxes();
        xYPlot14.setDomainCrosshairValue((double) '#');
        xYPlot14.setDomainCrosshairLockedOnData(false);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot14);
        xYPlot14.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj9 = categoryAxis8.clone();
        java.awt.Font font11 = categoryAxis8.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis8.setMaximumCategoryLabelLines((int) (byte) 1);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis8, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot16.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            org.jfree.chart.axis.AxisState axisState20 = numberAxis1.draw(graphics2D2, 0.05d, rectangle2D4, rectangle2D5, rectangleEdge18, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        java.util.Date date7 = dateAxis3.getMaximumDate();
        boolean boolean8 = day1.equals((java.lang.Object) dateAxis3);
        java.util.Date date9 = day1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day1.next();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getMiddleMillisecond();
//        int int3 = day1.getYear();
//        int int4 = day1.getYear();
//        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
//        xYPlot5.setNoDataMessage("hi!");
//        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
//        int int9 = xYPlot5.getRangeAxisIndex(valueAxis8);
//        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
//        xYPlot10.configureRangeAxes();
//        java.awt.Stroke stroke12 = xYPlot10.getDomainCrosshairStroke();
//        xYPlot5.setRangeGridlineStroke(stroke12);
//        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
//        java.awt.Stroke stroke17 = intervalMarker16.getStroke();
//        java.awt.Paint paint18 = intervalMarker16.getOutlinePaint();
//        java.lang.String str19 = intervalMarker16.getLabel();
//        java.awt.Color color20 = java.awt.Color.orange;
//        intervalMarker16.setPaint((java.awt.Paint) color20);
//        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
//        xYPlot5.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker16, layer22);
//        java.awt.Stroke stroke24 = null;
//        xYPlot5.setOutlineStroke(stroke24);
//        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
//        dateAxis28.setLabelAngle(0.0d);
//        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis28.getTickUnit();
//        xYPlot5.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis28, true);
//        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray34 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
//        xYPlot5.setRenderers(xYItemRendererArray34);
//        int int36 = day1.compareTo((java.lang.Object) xYPlot5);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray38 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer37 };
//        xYPlot5.setRenderers(xYItemRendererArray38);
//        java.awt.Graphics2D graphics2D40 = null;
//        java.awt.geom.Rectangle2D rectangle2D41 = null;
//        try {
//            xYPlot5.drawBackground(graphics2D40, rectangle2D41);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(stroke12);
//        org.junit.Assert.assertNotNull(stroke17);
//        org.junit.Assert.assertNotNull(paint18);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNotNull(color20);
//        org.junit.Assert.assertNotNull(layer22);
//        org.junit.Assert.assertNotNull(dateTickUnit31);
//        org.junit.Assert.assertNotNull(xYItemRendererArray34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(xYItemRendererArray38);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        xYPlot5.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke11 = intervalMarker10.getStroke();
        java.awt.Paint paint12 = intervalMarker10.getOutlinePaint();
        java.lang.String str13 = intervalMarker10.getLabel();
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean15 = xYPlot5.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker10, layer14);
        java.util.Collection collection16 = categoryPlot0.getRangeMarkers(layer14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        int int18 = categoryPlot0.getIndexOf(categoryItemRenderer17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        double double20 = categoryPlot19.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis22.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition25 = dateAxis22.getTickMarkPosition();
        java.awt.Stroke stroke26 = dateAxis22.getAxisLineStroke();
        dateAxis22.setLowerBound((double) 8);
        java.awt.Shape shape29 = dateAxis22.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        xYPlot30.configureRangeAxes();
        java.awt.Stroke stroke32 = xYPlot30.getDomainCrosshairStroke();
        java.awt.Font font33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot30.setNoDataMessageFont(font33);
        dateAxis22.setTickLabelFont(font33);
        org.jfree.data.Range range36 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.util.SortOrder sortOrder37 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart38 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder37, jFreeChart38);
        categoryPlot19.setColumnRenderingOrder(sortOrder37);
        categoryPlot0.setRowRenderingOrder(sortOrder37);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(layer14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertNotNull(sortOrder37);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxisForDataset(255);
        categoryPlot0.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot0.getDomainAxisLocation(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis29.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition32 = dateAxis29.getTickMarkPosition();
        java.awt.Stroke stroke33 = dateAxis29.getAxisLineStroke();
        dateAxis29.setLowerBound((double) 8);
        int int36 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis29);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis38.setLabelAngle(0.0d);
        java.util.Date date41 = dateAxis38.getMaximumDate();
        double double42 = dateAxis38.getUpperMargin();
        dateAxis38.setTickLabelsVisible(true);
        java.util.Date date45 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis38.setMaximumDate(date45);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
        xYPlot49.configureRangeAxes();
        xYPlot49.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean53 = xYPlot49.equals((java.lang.Object) dateTickUnit52);
        dateAxis48.setTickUnit(dateTickUnit52);
        dateAxis38.setTickUnit(dateTickUnit52, false, false);
        java.util.Date date58 = dateAxis29.calculateHighestVisibleTickValue(dateTickUnit52);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(dateTickMarkPosition32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(dateTickUnit52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date58);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = xYPlot0.getRangeCrosshairPaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot0.setDomainZeroBaselineStroke(stroke8);
        xYPlot0.setDomainCrosshairVisible(true);
        boolean boolean12 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis(1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(categoryAxis7);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis19.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis19.getTickMarkPosition();
        java.awt.Stroke stroke23 = dateAxis19.getAxisLineStroke();
        double double24 = dateAxis19.getLowerBound();
        java.awt.Font font25 = dateAxis19.getTickLabelFont();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        java.lang.String str27 = dateAxis19.getLabelURL();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        xYPlot28.configureRangeAxes();
        xYPlot28.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean32 = xYPlot28.equals((java.lang.Object) dateTickUnit31);
        dateAxis19.setTickUnit(dateTickUnit31);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(dateTickUnit31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis9.setLabelAngle(0.0d);
        java.util.Date date12 = dateAxis9.getMaximumDate();
        dateAxis9.setAxisLineVisible(true);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis17.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition20 = dateAxis17.getTickMarkPosition();
        java.awt.Shape shape21 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis17.setLeftArrow(shape21);
        boolean boolean23 = dateAxis17.isVerticalTickLabels();
        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis27.setLabelAngle(0.0d);
        java.util.Date date30 = dateAxis27.getMaximumDate();
        java.util.Date date31 = dateAxis27.getMaximumDate();
        boolean boolean32 = day25.equals((java.lang.Object) dateAxis27);
        java.util.Date date33 = day25.getStart();
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date33);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis36.setLabelAngle(0.0d);
        java.util.Date date39 = dateAxis36.getMaximumDate();
        double double40 = dateAxis36.getUpperMargin();
        dateAxis36.setTickLabelsVisible(true);
        java.util.Date date43 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis36.setMaximumDate(date43);
        dateAxis17.setRange(date33, date43);
        dateAxis9.setMinimumDate(date43);
        java.util.Date date47 = dateAxis9.getMaximumDate();
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        xYPlot48.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        int int52 = xYPlot48.getRangeAxisIndex(valueAxis51);
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot();
        xYPlot53.configureRangeAxes();
        java.awt.Stroke stroke55 = xYPlot53.getDomainCrosshairStroke();
        xYPlot48.setRangeGridlineStroke(stroke55);
        org.jfree.chart.plot.IntervalMarker intervalMarker59 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke60 = intervalMarker59.getStroke();
        java.awt.Paint paint61 = intervalMarker59.getOutlinePaint();
        java.lang.String str62 = intervalMarker59.getLabel();
        java.awt.Color color63 = java.awt.Color.orange;
        intervalMarker59.setPaint((java.awt.Paint) color63);
        org.jfree.chart.util.Layer layer65 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot48.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker59, layer65);
        int int67 = xYPlot48.getDomainAxisCount();
        org.jfree.chart.event.PlotChangeListener plotChangeListener68 = null;
        xYPlot48.addChangeListener(plotChangeListener68);
        java.awt.Stroke stroke70 = xYPlot48.getRangeZeroBaselineStroke();
        dateAxis9.setTickMarkStroke(stroke70);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(dateTickMarkPosition20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(layer65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(stroke70);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxisForDataset(255);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot0.getDomainAxisEdge();
        categoryPlot0.setOutlineVisible(true);
        categoryPlot0.clearDomainMarkers((int) '#');
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("SeriesRenderingOrder.REVERSE");
        java.awt.Paint paint29 = categoryAxis28.getLabelPaint();
        categoryPlot0.setBackgroundPaint(paint29);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        java.util.Date date5 = dateAxis1.getMaximumDate();
        dateAxis1.setUpperBound((double) 'a');
        dateAxis1.setFixedDimension((double) 12);
        java.awt.Paint paint10 = dateAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj2 = categoryAxis1.clone();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 1);
        double double7 = categoryAxis1.getLowerMargin();
        boolean boolean8 = categoryAxis1.isTickMarksVisible();
        boolean boolean9 = categoryAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.plot.Plot plot7 = dateAxis1.getPlot();
        dateAxis1.setVerticalTickLabels(true);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Color color3 = java.awt.Color.GRAY;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color3);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        intervalMarker2.setLabelTextAnchor(textAnchor5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        xYPlot7.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean11 = xYPlot7.equals((java.lang.Object) dateTickUnit10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot7.getSeriesRenderingOrder();
        java.lang.String str13 = seriesRenderingOrder12.toString();
        java.lang.String str14 = seriesRenderingOrder12.toString();
        java.lang.String str15 = seriesRenderingOrder12.toString();
        boolean boolean16 = textAnchor5.equals((java.lang.Object) str15);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str13.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str14.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str15.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        boolean boolean7 = dateAxis1.isAutoRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double9 = rectangleInsets8.getRight();
        dateAxis1.setTickLabelInsets(rectangleInsets8);
        double double12 = rectangleInsets8.calculateTopInset(0.05d);
        double double14 = rectangleInsets8.extendHeight(0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 6.0d + "'", double14 == 6.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis19.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition22 = dateAxis19.getTickMarkPosition();
        java.awt.Stroke stroke23 = dateAxis19.getAxisLineStroke();
        double double24 = dateAxis19.getLowerBound();
        java.awt.Font font25 = dateAxis19.getTickLabelFont();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.chart.plot.IntervalMarker intervalMarker29 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke30 = intervalMarker29.getStroke();
        java.awt.Paint paint31 = intervalMarker29.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker29.setLabelTextAnchor(textAnchor32);
        java.awt.Stroke stroke34 = intervalMarker29.getStroke();
        dateAxis19.setTickMarkStroke(stroke34);
        java.awt.Paint paint36 = dateAxis19.getTickLabelPaint();
        dateAxis19.setTickMarkOutsideLength(0.8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(dateTickMarkPosition22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color32);
        float float34 = xYPlot0.getBackgroundAlpha();
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        xYPlot0.drawBackgroundImage(graphics2D35, rectangle2D36);
        float float38 = xYPlot0.getBackgroundImageAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 0.5f + "'", float38 == 0.5f);
        org.junit.Assert.assertNull(valueAxis39);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.Plot plot3 = categoryPlot0.getRootPlot();
        categoryPlot0.setBackgroundImageAlignment((-1));
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean12 = axisLocation10.equals((java.lang.Object) 128);
        categoryPlot8.setRangeAxisLocation((int) (byte) 10, axisLocation10);
        categoryPlot8.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj21 = categoryAxis20.clone();
        java.awt.Font font23 = categoryAxis20.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot8.setDomainAxis((int) (short) 10, categoryAxis20);
        java.awt.Color color25 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass26 = color25.getClass();
        categoryPlot8.setRangeCrosshairPaint((java.awt.Paint) color25);
        categoryPlot8.clearDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot();
        xYPlot31.configureRangeAxes();
        java.awt.Stroke stroke33 = xYPlot31.getDomainCrosshairStroke();
        boolean boolean34 = xYPlot31.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D35 = xYPlot31.getQuadrantOrigin();
        categoryPlot8.zoomDomainAxes((double) 1.0f, plotRenderingInfo30, point2D35);
        org.jfree.chart.plot.PlotState plotState37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        try {
            categoryPlot0.draw(graphics2D6, rectangle2D7, point2D35, plotState37, plotRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(plot3);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(point2D35);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        xYPlot0.clearDomainMarkers(100);
        org.jfree.chart.plot.Plot plot5 = xYPlot0.getParent();
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean12 = axisLocation10.equals((java.lang.Object) 128);
        categoryPlot8.setRangeAxisLocation((int) (byte) 10, axisLocation10);
        categoryPlot8.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot8.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj21 = categoryAxis20.clone();
        java.awt.Font font23 = categoryAxis20.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot8.setDomainAxis((int) (short) 10, categoryAxis20);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker26.setKey((java.lang.Comparable) 10);
        java.lang.Object obj29 = null;
        boolean boolean30 = categoryMarker26.equals(obj29);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        double double32 = categoryPlot31.getRangeCrosshairValue();
        categoryPlot31.clearDomainMarkers();
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker36.setKey((java.lang.Comparable) 10);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot31.addDomainMarker((-1), categoryMarker36, layer39, false);
        boolean boolean42 = categoryPlot8.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker26, layer39);
        try {
            boolean boolean43 = xYPlot0.removeRangeMarker(500, marker7, layer39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.Plot plot3 = categoryPlot0.getRootPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer((int) (short) 10, categoryItemRenderer5, true);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(plot3);
        org.junit.Assert.assertNull(axisSpace8);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot0.getRangeAxisEdge(0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = null;
        xYPlot0.axisChanged(axisChangeEvent22);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        dateAxis1.setInverted(false);
        dateAxis1.setRangeWithMargins((double) (-1.0f), (double) (byte) 10);
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis1.setRange((org.jfree.data.Range) dateRange10);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(dateRange10);
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getMiddleMillisecond();
//        long long3 = day1.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis33.setLabelAngle(0.0d);
        java.util.Date date36 = dateAxis33.getMaximumDate();
        java.util.Date date37 = dateAxis33.getMaximumDate();
        boolean boolean38 = day31.equals((java.lang.Object) dateAxis33);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis40.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition43 = dateAxis40.getTickMarkPosition();
        java.awt.Shape shape44 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis40.setLeftArrow(shape44);
        java.awt.Stroke stroke46 = dateAxis40.getAxisLineStroke();
        dateAxis40.setFixedDimension(0.0d);
        boolean boolean50 = dateAxis40.isHiddenValue((long) 255);
        org.jfree.data.Range range51 = dateAxis40.getDefaultAutoRange();
        dateAxis33.setRange(range51);
        java.util.Date date53 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date53);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis56.setLabelAngle(0.0d);
        java.util.Date date59 = dateAxis56.getMaximumDate();
        java.util.Date date60 = dateAxis56.getMaximumDate();
        boolean boolean61 = day54.equals((java.lang.Object) dateAxis56);
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis63.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition66 = dateAxis63.getTickMarkPosition();
        java.awt.Shape shape67 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis63.setLeftArrow(shape67);
        java.awt.Stroke stroke69 = dateAxis63.getAxisLineStroke();
        dateAxis63.setFixedDimension(0.0d);
        boolean boolean73 = dateAxis63.isHiddenValue((long) 255);
        org.jfree.data.Range range74 = dateAxis63.getDefaultAutoRange();
        dateAxis56.setRange(range74);
        org.jfree.data.time.DateRange dateRange76 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis56.setDefaultAutoRange((org.jfree.data.Range) dateRange76);
        dateAxis33.setRangeWithMargins((org.jfree.data.Range) dateRange76);
        org.jfree.data.time.DateRange dateRange79 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis33.setDefaultAutoRange((org.jfree.data.Range) dateRange79);
        boolean boolean81 = dateAxis33.isAutoRange();
        org.jfree.data.Range range82 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis33);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition43);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition66);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertNotNull(dateRange76);
        org.junit.Assert.assertNotNull(dateRange79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNull(range82);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        dateAxis1.setTickLabelsVisible(true);
        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis1.setMaximumDate(date8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.configureRangeAxes();
        xYPlot12.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean16 = xYPlot12.equals((java.lang.Object) dateTickUnit15);
        dateAxis11.setTickUnit(dateTickUnit15);
        dateAxis1.setTickUnit(dateTickUnit15, false, false);
        double double21 = dateAxis1.getLowerMargin();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        xYPlot0.clearDomainMarkers(100);
        org.jfree.chart.plot.Plot plot5 = xYPlot0.getParent();
        java.awt.Paint paint6 = xYPlot0.getDomainCrosshairPaint();
        java.lang.String str7 = xYPlot0.getPlotType();
        xYPlot0.setRangeCrosshairValue(0.0d);
        xYPlot0.setRangeCrosshairValue((double) 0.8f, false);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "XY Plot" + "'", str7.equals("XY Plot"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxisForDataset(255);
        categoryPlot0.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        xYPlot29.configureRangeAxes();
        xYPlot29.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean33 = xYPlot29.equals((java.lang.Object) dateTickUnit32);
        dateAxis28.setTickUnit(dateTickUnit32);
        boolean boolean35 = axisLocation26.equals((java.lang.Object) dateAxis28);
        categoryPlot0.setRangeAxisLocation(0, axisLocation26);
        org.jfree.chart.axis.AxisLocation axisLocation37 = axisLocation26.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.Plot plot9 = xYPlot0.getParent();
        xYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis12.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition15 = dateAxis12.getTickMarkPosition();
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis12.setLeftArrow(shape16);
        int int18 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot0.zoomRangeAxes((-1.0d), plotRenderingInfo20, point2D21, true);
        org.jfree.chart.axis.AxisSpace axisSpace24 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(dateTickMarkPosition15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(axisSpace24);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot0.getDataRange(valueAxis8);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot0.setDataset((int) (byte) 10, categoryDataset11);
        org.jfree.chart.util.SortOrder sortOrder13 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder13, jFreeChart14);
        categoryPlot0.setRowRenderingOrder(sortOrder13);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(sortOrder13);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.Object obj1 = null;
        boolean boolean2 = datasetRenderingOrder0.equals(obj1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.axis.AxisSpace axisSpace3 = xYPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(axisSpace3);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19);
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        categoryPlot0.configureRangeAxes();
        categoryPlot0.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker26.setKey((java.lang.Comparable) 10);
        java.lang.Object obj29 = null;
        boolean boolean30 = categoryMarker26.equals(obj29);
        categoryMarker26.setDrawAsLine(false);
        categoryMarker26.setDrawAsLine(false);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        xYPlot35.configureRangeAxes();
        xYPlot35.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke41 = intervalMarker40.getStroke();
        java.awt.Paint paint42 = intervalMarker40.getOutlinePaint();
        java.lang.String str43 = intervalMarker40.getLabel();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean45 = xYPlot35.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker40, layer44);
        boolean boolean46 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker26, layer44);
        categoryMarker26.setDrawAsLine(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj2 = categoryAxis1.clone();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 1);
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setVisible(true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureRangeAxes();
        java.awt.Paint paint3 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        xYPlot4.configureRangeAxes();
        xYPlot4.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke10 = intervalMarker9.getStroke();
        java.awt.Paint paint11 = intervalMarker9.getOutlinePaint();
        java.lang.String str12 = intervalMarker9.getLabel();
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean14 = xYPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker9, layer13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = intervalMarker9.getLabelOffset();
        org.jfree.chart.util.SortOrder sortOrder16 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder16, jFreeChart17);
        boolean boolean19 = intervalMarker9.equals((java.lang.Object) chartChangeEvent18);
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        intervalMarker9.setLabelPaint(paint20);
        xYPlot0.setRangeTickBandPaint(paint20);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        int int24 = xYPlot0.indexOf(xYDataset23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = java.awt.Color.green;
        categoryPlot25.setDomainGridlinePaint((java.awt.Paint) color26);
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color26);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(sortOrder16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis1.getTickLabelInsets();
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets6.getUnitType();
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(unitType7);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        dateAxis3.setUpperBound((double) 12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) '4', (float) 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        xYPlot3.configureRangeAxes();
        xYPlot3.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean7 = xYPlot3.equals((java.lang.Object) dateTickUnit6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot3.getSeriesRenderingOrder();
        java.lang.String str9 = seriesRenderingOrder8.toString();
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder8);
        int int11 = xYPlot0.getRangeAxisCount();
        xYPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str9.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        int int6 = xYPlot2.getRangeAxisIndex(valueAxis5);
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        java.awt.Stroke stroke9 = xYPlot7.getDomainCrosshairStroke();
        xYPlot2.setRangeGridlineStroke(stroke9);
        org.jfree.chart.plot.Plot plot11 = xYPlot2.getParent();
        xYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis14.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition17 = dateAxis14.getTickMarkPosition();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis14.setLeftArrow(shape18);
        int int20 = xYPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        int int22 = color21.getGreen();
        xYPlot2.setRangeZeroBaselinePaint((java.awt.Paint) color21);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        int int28 = xYPlot24.getRangeAxisIndex(valueAxis27);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        xYPlot29.configureRangeAxes();
        java.awt.Stroke stroke31 = xYPlot29.getDomainCrosshairStroke();
        xYPlot24.setRangeGridlineStroke(stroke31);
        org.jfree.chart.plot.IntervalMarker intervalMarker35 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke36 = intervalMarker35.getStroke();
        java.awt.Paint paint37 = intervalMarker35.getOutlinePaint();
        java.lang.String str38 = intervalMarker35.getLabel();
        java.awt.Color color39 = java.awt.Color.orange;
        intervalMarker35.setPaint((java.awt.Paint) color39);
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot24.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker35, layer41);
        int int43 = xYPlot24.getDomainAxisCount();
        org.jfree.chart.event.PlotChangeListener plotChangeListener44 = null;
        xYPlot24.addChangeListener(plotChangeListener44);
        java.awt.Stroke stroke46 = xYPlot24.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot();
        xYPlot47.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        int int51 = xYPlot47.getRangeAxisIndex(valueAxis50);
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
        xYPlot52.configureRangeAxes();
        java.awt.Stroke stroke54 = xYPlot52.getDomainCrosshairStroke();
        xYPlot47.setRangeGridlineStroke(stroke54);
        org.jfree.chart.plot.IntervalMarker intervalMarker58 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke59 = intervalMarker58.getStroke();
        java.awt.Paint paint60 = intervalMarker58.getOutlinePaint();
        java.lang.String str61 = intervalMarker58.getLabel();
        java.awt.Color color62 = java.awt.Color.orange;
        intervalMarker58.setPaint((java.awt.Paint) color62);
        org.jfree.chart.util.Layer layer64 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot47.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker58, layer64);
        int int66 = xYPlot47.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier67 = xYPlot47.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker71 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke72 = intervalMarker71.getStroke();
        java.awt.Paint paint73 = intervalMarker71.getOutlinePaint();
        org.jfree.chart.util.Layer layer74 = null;
        boolean boolean76 = xYPlot47.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker71, layer74, false);
        xYPlot47.setBackgroundAlpha((float) (byte) 1);
        java.awt.Color color79 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot47.setNoDataMessagePaint((java.awt.Paint) color79);
        float[] floatArray88 = new float[] { 8, (byte) 1, (short) 10, 10L };
        float[] floatArray89 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (short) 10, (int) ' ', floatArray88);
        float[] floatArray90 = color79.getRGBColorComponents(floatArray89);
        org.jfree.chart.axis.DateAxis dateAxis92 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis92.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit95 = dateAxis92.getTickUnit();
        java.awt.Stroke stroke96 = dateAxis92.getAxisLineStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker98 = new org.jfree.chart.plot.IntervalMarker((double) '4', 0.0d, (java.awt.Paint) color21, stroke46, (java.awt.Paint) color79, stroke96, (float) 64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(dateTickMarkPosition17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 64 + "'", int22 == 64);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(layer64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier67);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertNotNull(floatArray88);
        org.junit.Assert.assertNotNull(floatArray89);
        org.junit.Assert.assertNotNull(floatArray90);
        org.junit.Assert.assertNotNull(dateTickUnit95);
        org.junit.Assert.assertNotNull(stroke96);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        categoryPlot0.clearRangeMarkers();
        double double4 = categoryPlot0.getRangeCrosshairValue();
        float float5 = categoryPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setLabelToolTip("ChartChangeEventType.NEW_DATASET");
        java.awt.Font font24 = dateAxis15.getLabelFont();
        dateAxis15.setTickLabelsVisible(false);
        float float27 = dateAxis15.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 2.0f + "'", float27 == 2.0f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        java.awt.Paint paint21 = xYPlot0.getRangeGridlinePaint();
        boolean boolean22 = xYPlot0.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot0.getRangeAxisForDataset(255);
        categoryPlot0.mapDatasetToRangeAxis((int) '4', 200);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot0.getDomainAxisLocation(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = categoryPlot0.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis29.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition32 = dateAxis29.getTickMarkPosition();
        java.awt.Stroke stroke33 = dateAxis29.getAxisLineStroke();
        dateAxis29.setLowerBound((double) 8);
        int int36 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis29);
        org.jfree.data.Range range37 = dateAxis29.getRange();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(dateTickMarkPosition32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(range37);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj2 = null;
        boolean boolean3 = plotOrientation1.equals(obj2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj6 = null;
        boolean boolean7 = plotOrientation5.equals(obj6);
        boolean boolean8 = axisLocation0.equals((java.lang.Object) boolean7);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke6 = intervalMarker5.getStroke();
        java.awt.Paint paint7 = intervalMarker5.getOutlinePaint();
        java.lang.String str8 = intervalMarker5.getLabel();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean10 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        int int12 = xYPlot0.getSeriesCount();
        java.awt.Stroke stroke13 = null;
        try {
            xYPlot0.setDomainGridlineStroke(stroke13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.Plot plot9 = xYPlot0.getParent();
        xYPlot0.clearDomainMarkers();
        xYPlot0.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(plot9);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setVerticalTickLabels(true);
        dateAxis15.setInverted(true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setLabelToolTip("ChartChangeEventType.NEW_DATASET");
        java.awt.Font font24 = dateAxis15.getLabelFont();
        java.awt.Stroke[] strokeArray25 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean26 = dateAxis15.equals((java.lang.Object) strokeArray25);
        java.lang.String str27 = dateAxis15.getLabelURL();
        dateAxis15.setFixedDimension(0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setLabelToolTip("ChartChangeEventType.NEW_DATASET");
        java.awt.Color color24 = java.awt.Color.MAGENTA;
        dateAxis15.setTickMarkPaint((java.awt.Paint) color24);
        java.awt.Color color29 = java.awt.Color.DARK_GRAY;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        xYPlot30.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        int int34 = xYPlot30.getRangeAxisIndex(valueAxis33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot30.setNoDataMessagePaint((java.awt.Paint) color35);
        java.awt.color.ColorSpace colorSpace37 = color35.getColorSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke41 = intervalMarker40.getStroke();
        java.awt.Paint paint42 = intervalMarker40.getOutlinePaint();
        java.lang.String str43 = intervalMarker40.getLabel();
        java.awt.Color color44 = java.awt.Color.orange;
        intervalMarker40.setPaint((java.awt.Paint) color44);
        float[] floatArray53 = new float[] { 8, (byte) 1, (short) 10, 10L };
        float[] floatArray54 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (short) 10, (int) ' ', floatArray53);
        float[] floatArray55 = color44.getRGBColorComponents(floatArray54);
        float[] floatArray56 = color29.getColorComponents(colorSpace37, floatArray54);
        float[] floatArray57 = java.awt.Color.RGBtoHSB(10, 15, (int) '#', floatArray54);
        float[] floatArray58 = color24.getRGBColorComponents(floatArray54);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(colorSpace37);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertNotNull(floatArray58);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        java.util.Date date5 = dateAxis1.getMaximumDate();
        dateAxis1.setUpperBound((double) 'a');
        dateAxis1.setFixedDimension((double) 12);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.configureRangeAxes();
        xYPlot10.configureRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = xYPlot10.getAxisOffset();
        dateAxis1.setLabelInsets(rectangleInsets13);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        org.jfree.chart.plot.Plot plot7 = dateAxis1.getPlot();
        java.util.TimeZone timeZone8 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis10.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition13 = dateAxis10.getTickMarkPosition();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis10.setLeftArrow(shape14);
        dateAxis1.setRightArrow(shape14);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis18.getTickUnit();
        java.util.Date date20 = dateAxis1.calculateHighestVisibleTickValue(dateTickUnit19);
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(dateTickMarkPosition13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(dateTickUnit19);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean4 = xYPlot0.equals((java.lang.Object) dateTickUnit3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot0.setAxisOffset(rectangleInsets5);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets5.createInsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        xYPlot0.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        int int7 = xYPlot0.getDomainAxisIndex(valueAxis6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition6 = dateAxis3.getTickMarkPosition();
        java.awt.Stroke stroke7 = dateAxis3.getAxisLineStroke();
        dateAxis3.setLowerBound((double) 8);
        java.awt.Shape shape10 = dateAxis3.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot11.setNoDataMessageFont(font14);
        dateAxis3.setTickLabelFont(font14);
        org.jfree.data.Range range17 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis3);
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) sortOrder18, jFreeChart19);
        categoryPlot0.setColumnRenderingOrder(sortOrder18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        xYPlot24.setDataset(xYDataset25);
        org.jfree.chart.plot.Plot plot27 = xYPlot24.getRootPlot();
        java.awt.geom.Point2D point2D28 = xYPlot24.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(4.0d, plotRenderingInfo23, point2D28, true);
        org.jfree.chart.axis.AxisLocation axisLocation31 = null;
        try {
            categoryPlot0.setDomainAxisLocation(axisLocation31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNotNull(plot27);
        org.junit.Assert.assertNotNull(point2D28);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.Object obj13 = categoryAxis12.clone();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) (byte) -1);
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis12);
        java.awt.Color color17 = java.awt.Color.GRAY;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        int int5 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        xYPlot0.removeChangeListener(plotChangeListener6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double10 = rectangleInsets8.calculateTopInset((double) (byte) 0);
        xYPlot0.setAxisOffset(rectangleInsets8);
        double double12 = rectangleInsets8.getRight();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker1.setKey((java.lang.Comparable) 10);
        java.lang.Object obj4 = null;
        boolean boolean5 = categoryMarker1.equals(obj4);
        categoryMarker1.setDrawAsLine(false);
        java.lang.Comparable comparable8 = categoryMarker1.getKey();
        java.lang.Comparable comparable9 = categoryMarker1.getKey();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10 + "'", comparable8.equals(10));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10 + "'", comparable9.equals(10));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        double double5 = dateAxis1.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = dateAxis1.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean11 = lengthAdjustmentType9.equals((java.lang.Object) "RectangleAnchor.TOP");
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets6.createAdjustedRectangle(rectangle2D7, lengthAdjustmentType8, lengthAdjustmentType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        xYPlot0.setDomainAxis(valueAxis5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        int int8 = xYPlot0.indexOf(xYDataset7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis1.configure();
        java.awt.Stroke stroke3 = categoryAxis1.getAxisLineStroke();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis7.setLabelAngle(0.0d);
        java.util.Date date10 = dateAxis7.getMaximumDate();
        java.util.Date date11 = dateAxis7.getMaximumDate();
        java.awt.Shape shape12 = dateAxis7.getRightArrow();
        java.awt.Color color13 = java.awt.Color.magenta;
        dateAxis7.setTickLabelPaint((java.awt.Paint) color13);
        int int15 = color13.getRed();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) true, (java.awt.Paint) color13);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = java.awt.Color.green;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot7.setDataset(xYDataset8);
        org.jfree.chart.plot.Plot plot10 = xYPlot7.getRootPlot();
        java.awt.geom.Point2D point2D11 = xYPlot7.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo6, point2D11);
        java.util.List list13 = categoryPlot0.getAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot0.getRendererForDataset(categoryDataset14);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(categoryItemRenderer15);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str5 = chartChangeEventType4.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) false, jFreeChart3, chartChangeEventType4);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleInsets0, jFreeChart1, chartChangeEventType4);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets0.createInsetRectangle(rectangle2D8, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str5.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        xYPlot0.removeChangeListener(plotChangeListener33);
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = xYPlot0.getOrientation();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(drawingSupplier32);
        org.junit.Assert.assertNotNull(plotOrientation35);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis1.setLeftArrow(shape5);
        java.awt.Stroke stroke7 = dateAxis1.getAxisLineStroke();
        double double8 = dateAxis1.getFixedDimension();
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        xYPlot0.clearDomainMarkers(100);
        org.jfree.chart.plot.Plot plot5 = xYPlot0.getParent();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        int int10 = xYPlot6.getRangeAxisIndex(valueAxis9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        xYPlot11.configureRangeAxes();
        java.awt.Stroke stroke13 = xYPlot11.getDomainCrosshairStroke();
        xYPlot6.setRangeGridlineStroke(stroke13);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke18 = intervalMarker17.getStroke();
        java.awt.Paint paint19 = intervalMarker17.getOutlinePaint();
        java.lang.String str20 = intervalMarker17.getLabel();
        java.awt.Color color21 = java.awt.Color.orange;
        intervalMarker17.setPaint((java.awt.Paint) color21);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker17, layer23);
        java.awt.Stroke stroke25 = null;
        xYPlot6.setOutlineStroke(stroke25);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis29.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis29.getTickUnit();
        xYPlot6.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis29, true);
        java.util.Date date35 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis29.setMinimumDate(date35);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis29);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str39 = rectangleInsets38.toString();
        java.lang.String str40 = rectangleInsets38.toString();
        double double42 = rectangleInsets38.calculateLeftInset((double) (short) 10);
        dateAxis29.setTickLabelInsets(rectangleInsets38);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNotNull(dateTickUnit32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str39.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str40.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = dateAxis1.getTickMarkPosition();
        java.awt.Stroke stroke5 = dateAxis1.getAxisLineStroke();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis7.setLabelAngle(0.0d);
        java.util.Date date10 = dateAxis7.getMaximumDate();
        double double11 = dateAxis7.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = dateAxis7.getTickLabelInsets();
        dateAxis1.setTickLabelInsets(rectangleInsets12);
        dateAxis1.setVisible(true);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.AxisState axisState17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        xYPlot19.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        int int23 = xYPlot19.getRangeAxisIndex(valueAxis22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.configureRangeAxes();
        java.awt.Stroke stroke26 = xYPlot24.getDomainCrosshairStroke();
        xYPlot19.setRangeGridlineStroke(stroke26);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke31 = intervalMarker30.getStroke();
        java.awt.Paint paint32 = intervalMarker30.getOutlinePaint();
        java.lang.String str33 = intervalMarker30.getLabel();
        java.awt.Color color34 = java.awt.Color.orange;
        intervalMarker30.setPaint((java.awt.Paint) color34);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot19.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker30, layer36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot19.getRangeAxisEdge(0);
        try {
            java.util.List list40 = dateAxis1.refreshTicks(graphics2D16, axisState17, rectangle2D18, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = intervalMarker2.getGradientPaintTransformer();
        java.awt.Paint paint5 = intervalMarker2.getPaint();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(gradientPaintTransformer4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-14336) + "'", int1 == (-14336));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        xYPlot0.addChangeListener(plotChangeListener19);
        float float21 = xYPlot0.getBackgroundImageAlpha();
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis9.setLabelAngle(0.0d);
        java.util.Date date12 = dateAxis9.getMaximumDate();
        dateAxis9.setAxisLineVisible(true);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        boolean boolean16 = xYPlot0.isSubplot();
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        xYPlot17.configureRangeAxes();
        java.awt.Stroke stroke19 = xYPlot17.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke19);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke19);
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
//        dateAxis3.setLabelAngle(0.0d);
//        java.util.Date date6 = dateAxis3.getMaximumDate();
//        java.util.Date date7 = dateAxis3.getMaximumDate();
//        boolean boolean8 = day1.equals((java.lang.Object) dateAxis3);
//        int int9 = day1.getDayOfMonth();
//        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
//        dateAxis11.setLabelAngle(0.0d);
//        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition14 = dateAxis11.getTickMarkPosition();
//        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
//        dateAxis11.setLeftArrow(shape15);
//        java.awt.Stroke stroke17 = dateAxis11.getAxisLineStroke();
//        dateAxis11.setFixedDimension(0.0d);
//        java.lang.String str20 = dateAxis11.getLabel();
//        int int21 = day1.compareTo((java.lang.Object) str20);
//        long long22 = day1.getLastMillisecond();
//        long long23 = day1.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//        org.junit.Assert.assertNotNull(dateTickMarkPosition14);
//        org.junit.Assert.assertNotNull(shape15);
//        org.junit.Assert.assertNotNull(stroke17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560495599999L + "'", long22 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560452399999L + "'", long23 == 1560452399999L);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = intervalMarker24.getLabelAnchor();
        java.lang.String str31 = rectangleAnchor30.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str31.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        xYPlot0.zoomDomainAxes((double) (byte) 10, plotRenderingInfo4, point2D5, true);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.configureRangeAxes();
        java.awt.Stroke stroke11 = xYPlot9.getDomainCrosshairStroke();
        boolean boolean12 = xYPlot9.isRangeZeroBaselineVisible();
        xYPlot9.clearDomainMarkers((-1));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        xYPlot17.setDataset(xYDataset18);
        org.jfree.chart.plot.Plot plot20 = xYPlot17.getRootPlot();
        java.awt.geom.Point2D point2D21 = xYPlot17.getQuadrantOrigin();
        xYPlot9.zoomDomainAxes((double) 6, plotRenderingInfo16, point2D21, false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = null;
        xYPlot9.datasetChanged(datasetChangeEvent24);
        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis29.setLabelAngle(0.0d);
        java.util.Date date32 = dateAxis29.getMaximumDate();
        java.util.Date date33 = dateAxis29.getMaximumDate();
        boolean boolean34 = day27.equals((java.lang.Object) dateAxis29);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis36.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition39 = dateAxis36.getTickMarkPosition();
        java.awt.Shape shape40 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis36.setLeftArrow(shape40);
        java.awt.Stroke stroke42 = dateAxis36.getAxisLineStroke();
        dateAxis36.setFixedDimension(0.0d);
        boolean boolean46 = dateAxis36.isHiddenValue((long) 255);
        org.jfree.data.Range range47 = dateAxis36.getDefaultAutoRange();
        dateAxis29.setRange(range47);
        org.jfree.data.Range range49 = xYPlot9.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis29);
        try {
            xYPlot0.setDomainAxis((int) (byte) -1, (org.jfree.chart.axis.ValueAxis) dateAxis29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(plot20);
        org.junit.Assert.assertNotNull(point2D21);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition39);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNull(range49);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        org.jfree.chart.plot.Plot plot3 = categoryPlot0.getRootPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer((int) (short) 10, categoryItemRenderer5, true);
        java.util.List list8 = categoryPlot0.getCategories();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(plot3);
        org.junit.Assert.assertNull(list8);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) true);
        categoryMarker1.setKey((java.lang.Comparable) 10);
        java.lang.Object obj4 = null;
        boolean boolean5 = categoryMarker1.equals(obj4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.configureRangeAxes();
        xYPlot6.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        int int10 = xYPlot6.getIndexOf(xYItemRenderer9);
        xYPlot6.setRangeZeroBaselineVisible(false);
        boolean boolean13 = xYPlot6.isDomainZeroBaselineVisible();
        categoryMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.lang.String str16 = rectangleAnchor15.toString();
        categoryMarker1.setLabelAnchor(rectangleAnchor15);
        java.lang.String str18 = rectangleAnchor15.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleAnchor.RIGHT" + "'", str16.equals("RectangleAnchor.RIGHT"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleAnchor.RIGHT" + "'", str18.equals("RectangleAnchor.RIGHT"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(0);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis15.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = dateAxis15.getTickUnit();
        java.awt.Shape shape19 = dateAxis15.getLeftArrow();
        xYPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, true);
        dateAxis15.setLabelToolTip("ChartChangeEventType.NEW_DATASET");
        java.awt.Font font24 = dateAxis15.getLabelFont();
        java.awt.Font font25 = dateAxis15.getTickLabelFont();
        java.awt.Paint paint26 = dateAxis15.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        int int9 = xYPlot5.getRangeAxisIndex(valueAxis8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.configureRangeAxes();
        java.awt.Stroke stroke12 = xYPlot10.getDomainCrosshairStroke();
        xYPlot5.setRangeGridlineStroke(stroke12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace14);
        int int16 = xYPlot5.getBackgroundImageAlignment();
        xYPlot5.setDomainGridlinesVisible(true);
        java.awt.Paint paint19 = xYPlot5.getOutlinePaint();
        xYPlot0.setRangeTickBandPaint(paint19);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke4 = intervalMarker3.getStroke();
        java.awt.Paint paint5 = intervalMarker3.getOutlinePaint();
        java.lang.String str6 = intervalMarker3.getLabel();
        java.awt.Color color7 = java.awt.Color.orange;
        intervalMarker3.setPaint((java.awt.Paint) color7);
        float[] floatArray16 = new float[] { 8, (byte) 1, (short) 10, 10L };
        float[] floatArray17 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (short) 10, (int) ' ', floatArray16);
        float[] floatArray18 = color7.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color0.getColorComponents(floatArray18);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getRangeCrosshairValue();
        categoryPlot0.clearDomainMarkers();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis3.setLabelAngle(0.0d);
        java.util.Date date6 = dateAxis3.getMaximumDate();
        java.util.Date date7 = dateAxis3.getMaximumDate();
        boolean boolean8 = day1.equals((java.lang.Object) dateAxis3);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis10.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition13 = dateAxis10.getTickMarkPosition();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis10.setLeftArrow(shape14);
        java.awt.Stroke stroke16 = dateAxis10.getAxisLineStroke();
        dateAxis10.setFixedDimension(0.0d);
        boolean boolean20 = dateAxis10.isHiddenValue((long) 255);
        org.jfree.data.Range range21 = dateAxis10.getDefaultAutoRange();
        dateAxis3.setRange(range21);
        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis26.setLabelAngle(0.0d);
        java.util.Date date29 = dateAxis26.getMaximumDate();
        java.util.Date date30 = dateAxis26.getMaximumDate();
        boolean boolean31 = day24.equals((java.lang.Object) dateAxis26);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis33.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition36 = dateAxis33.getTickMarkPosition();
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis33.setLeftArrow(shape37);
        java.awt.Stroke stroke39 = dateAxis33.getAxisLineStroke();
        dateAxis33.setFixedDimension(0.0d);
        boolean boolean43 = dateAxis33.isHiddenValue((long) 255);
        org.jfree.data.Range range44 = dateAxis33.getDefaultAutoRange();
        dateAxis26.setRange(range44);
        org.jfree.data.time.DateRange dateRange46 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis26.setDefaultAutoRange((org.jfree.data.Range) dateRange46);
        dateAxis3.setRangeWithMargins((org.jfree.data.Range) dateRange46);
        org.jfree.data.time.DateRange dateRange49 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis3.setDefaultAutoRange((org.jfree.data.Range) dateRange49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis53.setLabelAngle(0.0d);
        java.util.Date date56 = dateAxis53.getMaximumDate();
        double double57 = dateAxis53.getUpperMargin();
        dateAxis53.setTickLabelsVisible(true);
        dateAxis53.setLabel("RectangleAnchor.TOP");
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis63.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit66 = dateAxis63.getTickUnit();
        java.awt.Shape shape67 = dateAxis63.getLeftArrow();
        dateAxis53.setLeftArrow(shape67);
        boolean boolean69 = dateAxis53.isVerticalTickLabels();
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot();
        xYPlot70.configureRangeAxes();
        xYPlot70.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit73 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean74 = xYPlot70.equals((java.lang.Object) dateTickUnit73);
        dateAxis53.setTickUnit(dateTickUnit73);
        org.jfree.data.Range range76 = categoryPlot51.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis53);
        java.awt.Shape shape77 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis53.setRightArrow(shape77);
        dateAxis3.setRightArrow(shape77);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTickMarkPosition36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(dateRange46);
        org.junit.Assert.assertNotNull(dateRange49);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.05d + "'", double57 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit66);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(dateTickUnit73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNull(range76);
        org.junit.Assert.assertNotNull(shape77);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.configureRangeAxes();
        java.awt.Stroke stroke2 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.Plot plot3 = xYPlot0.getParent();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        xYPlot0.datasetChanged(datasetChangeEvent4);
        xYPlot0.setDomainCrosshairVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        int int9 = xYPlot0.getIndexOf(xYItemRenderer8);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) 10);
        double double4 = rectangleInsets0.trimWidth((double) (short) 0);
        double double6 = rectangleInsets0.calculateTopOutset((double) 'a');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-8.0d) + "'", double4 == (-8.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean4 = axisLocation2.equals((java.lang.Object) 128);
        categoryPlot0.setRangeAxisLocation((int) (byte) 10, axisLocation2);
        categoryPlot0.setDrawSharedDomainAxis(true);
        java.awt.Paint paint8 = categoryPlot0.getRangeCrosshairPaint();
        java.awt.Paint paint9 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) 1560495599999L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        java.awt.Paint paint26 = intervalMarker24.getOutlinePaint();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = xYPlot0.removeDomainMarker(100, (org.jfree.chart.plot.Marker) intervalMarker24, layer27, false);
        xYPlot0.setBackgroundAlpha((float) (byte) 1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        xYPlot0.setRenderer(0, xYItemRenderer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace35);
        java.lang.Object obj37 = xYPlot0.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        int int19 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = xYPlot0.getDrawingSupplier();
        java.awt.Paint paint21 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder22);
        java.awt.Paint paint24 = xYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        org.jfree.data.RangeType rangeType5 = null;
        try {
            numberAxis1.setRangeType(rangeType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        int int4 = xYPlot0.getRangeAxisIndex(valueAxis3);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        xYPlot5.configureRangeAxes();
        java.awt.Stroke stroke7 = xYPlot5.getDomainCrosshairStroke();
        xYPlot0.setRangeGridlineStroke(stroke7);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        java.awt.Paint paint13 = intervalMarker11.getOutlinePaint();
        java.lang.String str14 = intervalMarker11.getLabel();
        java.awt.Color color15 = java.awt.Color.orange;
        intervalMarker11.setPaint((java.awt.Paint) color15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11, layer17);
        java.awt.Stroke stroke19 = null;
        xYPlot0.setOutlineStroke(stroke19);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis23.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis23, true);
        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis23.setMinimumDate(date29);
        boolean boolean31 = dateAxis23.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        categoryAxis1.configure();
        java.awt.Stroke stroke3 = categoryAxis1.getAxisLineStroke();
        double double4 = categoryAxis1.getUpperMargin();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.configureRangeAxes();
        xYPlot7.configureDomainAxes();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        boolean boolean11 = xYPlot7.equals((java.lang.Object) dateTickUnit10);
        dateAxis6.setTickUnit(dateTickUnit10);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) dateTickUnit10, "RectangleAnchor.TOP");
        java.lang.Object obj15 = categoryAxis1.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        double double18 = categoryPlot17.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis20.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition23 = dateAxis20.getTickMarkPosition();
        java.awt.Stroke stroke24 = dateAxis20.getAxisLineStroke();
        dateAxis20.setLowerBound((double) 8);
        java.awt.Shape shape27 = dateAxis20.getLeftArrow();
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        xYPlot28.configureRangeAxes();
        java.awt.Stroke stroke30 = xYPlot28.getDomainCrosshairStroke();
        java.awt.Font font31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot28.setNoDataMessageFont(font31);
        dateAxis20.setTickLabelFont(font31);
        org.jfree.data.Range range34 = categoryPlot17.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis36.setLabelAngle(0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition39 = dateAxis36.getTickMarkPosition();
        java.awt.Stroke stroke40 = dateAxis36.getAxisLineStroke();
        double double41 = dateAxis36.getLowerBound();
        java.awt.Font font42 = dateAxis36.getTickLabelFont();
        categoryPlot17.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis36);
        org.jfree.chart.plot.IntervalMarker intervalMarker46 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke47 = intervalMarker46.getStroke();
        java.awt.Paint paint48 = intervalMarker46.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor49 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        intervalMarker46.setLabelTextAnchor(textAnchor49);
        java.awt.Stroke stroke51 = intervalMarker46.getStroke();
        dateAxis36.setTickMarkStroke(stroke51);
        java.awt.Paint paint53 = dateAxis36.getTickLabelPaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0.2d, paint53);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(dateTickMarkPosition39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(textAnchor49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        dateAxis1.setLabelAngle(0.0d);
        java.util.Date date4 = dateAxis1.getMaximumDate();
        java.util.Date date5 = dateAxis1.getMaximumDate();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        xYPlot7.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        int int11 = xYPlot7.getRangeAxisIndex(valueAxis10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        xYPlot12.configureRangeAxes();
        java.awt.Stroke stroke14 = xYPlot12.getDomainCrosshairStroke();
        xYPlot7.setRangeGridlineStroke(stroke14);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) 'a', 0.0d);
        java.awt.Stroke stroke19 = intervalMarker18.getStroke();
        java.awt.Paint paint20 = intervalMarker18.getOutlinePaint();
        java.lang.String str21 = intervalMarker18.getLabel();
        java.awt.Color color22 = java.awt.Color.orange;
        intervalMarker18.setPaint((java.awt.Paint) color22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker18, layer24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        xYPlot7.addChangeListener(plotChangeListener26);
        float float28 = xYPlot7.getBackgroundImageAlpha();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.Object obj32 = null;
        boolean boolean33 = plotOrientation31.equals(obj32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation30, plotOrientation31);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace36 = dateAxis1.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) xYPlot7, rectangle2D29, rectangleEdge34, axisSpace35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.5f + "'", float28 == 0.5f);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }
}

