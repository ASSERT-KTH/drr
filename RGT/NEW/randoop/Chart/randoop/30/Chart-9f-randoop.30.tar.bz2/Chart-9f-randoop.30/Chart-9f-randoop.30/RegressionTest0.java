import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Class<?> wildcardClass3 = timeSeriesDataItem2.getClass();
        boolean boolean5 = timeSeriesDataItem2.equals((java.lang.Object) 10L);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Calendar calendar3 = null;
        try {
            month2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean4 = month2.equals((java.lang.Object) year3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year3);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year3.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getPreviousDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        try {
            org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) 'a');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            day3.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.lang.String str5 = month2.toString();
        java.lang.Class<?> wildcardClass6 = month2.getClass();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January 10" + "'", str5.equals("January 10"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries9.getTimePeriod(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        java.util.Calendar calendar5 = null;
        try {
            month4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean4 = month2.equals((java.lang.Object) year3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year3);
        java.util.Calendar calendar6 = null;
        try {
            year3.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries9.getDataItem(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2147483647);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 520764324 + "'", int1 == 520764324);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int5 = month3.compareTo((java.lang.Object) 2);
        java.lang.String str6 = month3.toString();
        java.lang.Class<?> wildcardClass7 = month3.getClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries(comparable0, (java.lang.Class) wildcardClass7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "January 10" + "'", str6.equals("January 10"));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears(6, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 1, (int) (byte) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean15 = month13.equals((java.lang.Object) year14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries9.setMaximumItemCount(0);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        java.lang.Number number22 = timeSeriesDataItem21.getValue();
        try {
            timeSeries9.add(timeSeriesDataItem21);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.previous();
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year18, (double) 0.0f, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean15 = month13.equals((java.lang.Object) year14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries9.clear();
        try {
            java.lang.Number number19 = timeSeries9.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getMonth();
        try {
            org.jfree.data.time.Year year5 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.SerialDate serialDate6 = null;
        try {
            boolean boolean8 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, serialDate6, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day3.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        try {
            timeSeries9.delete(11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(4, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "April" + "'", str2.equals("April"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(6, 8);
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month21, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(3, serialDate4);
        boolean boolean6 = spreadsheetDate1.isBefore(serialDate4);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        try {
            int int12 = spreadsheetDate1.compareTo((java.lang.Object) date11);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = null;
        try {
            timeSeries9.add(regularTimePeriod40, (double) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        try {
            timeSeries9.update((int) ' ', (java.lang.Number) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(520764324, (-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(3, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        boolean boolean18 = timeSeries9.isEmpty();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries9.getDataItem(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Following");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long5 = month4.getFirstMillisecond();
        java.lang.Number number6 = null;
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month4, number6, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61851744000000L) + "'", long5 == (-61851744000000L));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        int int12 = day3.getMonth();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day3.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener11);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.getDataItem(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date3, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4', (int) (byte) 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(3, serialDate4);
        boolean boolean6 = spreadsheetDate1.isBefore(serialDate4);
        try {
            int int8 = spreadsheetDate1.compareTo((java.lang.Object) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        try {
            timeSeries1.update((int) (byte) 1, (java.lang.Number) 520764324);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(4, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date3);
        java.lang.Object obj6 = seriesChangeEvent5.getSource();
        java.lang.String str7 = seriesChangeEvent5.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Fri Jan 31 23:59:59 PST 10]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=Fri Jan 31 23:59:59 PST 10]"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean15 = month13.equals((java.lang.Object) year14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        try {
            org.jfree.data.time.TimeSeries timeSeries19 = timeSeries9.createCopy((int) (short) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (-1.0f));
        java.lang.Class<?> wildcardClass17 = timeSeriesDataItem16.getClass();
        try {
            timeSeries9.add(timeSeriesDataItem16, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(3, serialDate4);
        boolean boolean6 = spreadsheetDate1.isBefore(serialDate4);
        java.lang.String str7 = serialDate4.toString();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        long long6 = year0.getFirstMillisecond();
        long long7 = year0.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year0.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long22 = month21.getFirstMillisecond();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (-1.0f));
        java.lang.Class<?> wildcardClass27 = timeSeriesDataItem26.getClass();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date23, (java.lang.Class) wildcardClass27);
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        try {
            org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem16, "January 10", "org.jfree.data.general.SeriesChangeEvent[source=Fri Jan 31 23:59:59 PST 10]", class29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61851744000000L) + "'", long22 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(class29);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.addChangeListener(seriesChangeListener19);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries9.addChangeListener(seriesChangeListener21);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '4', 1900, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean15 = month13.equals((java.lang.Object) year14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries9.setMaximumItemCount(0);
        try {
            java.lang.Number number20 = timeSeries9.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date3);
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8, timeZone9);
        try {
            org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date3, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        java.util.Date date5 = year4.getStart();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
        try {
            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date3, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "Following", class17);
        java.lang.Comparable comparable19 = timeSeries18.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        int int25 = day23.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        boolean boolean30 = timeSeriesDataItem28.equals((java.lang.Object) 5);
        int int31 = day23.compareTo((java.lang.Object) timeSeriesDataItem28);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears(6, serialDate34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate34);
        try {
            org.jfree.data.time.TimeSeries timeSeries37 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) day36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("11-January-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(3, serialDate12);
        boolean boolean14 = spreadsheetDate9.isBefore(serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears(12, serialDate12);
        boolean boolean16 = spreadsheetDate6.isOn(serialDate15);
        java.lang.String str17 = spreadsheetDate6.toString();
        org.jfree.data.time.SerialDate serialDate18 = null;
        try {
            boolean boolean20 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, serialDate18, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "11-January-1900" + "'", str17.equals("11-January-1900"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        boolean boolean9 = spreadsheetDate2.isAfter(serialDate7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(520764324, serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long7 = month6.getFirstMillisecond();
        java.util.Date date8 = month6.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) (-1.0f));
        java.lang.Class<?> wildcardClass12 = timeSeriesDataItem11.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date8, (java.lang.Class) wildcardClass12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date17 = month16.getEnd();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date17, timeZone22);
        try {
            org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date3, timeZone22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851744000000L) + "'", long7 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        java.lang.String str12 = day3.toString();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day3.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1-January-2019" + "'", str12.equals("1-January-2019"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        long long16 = year14.getFirstMillisecond();
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year14, (java.lang.Number) 3, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.removeChangeListener(seriesChangeListener14);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries13.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(3, serialDate2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        boolean boolean9 = spreadsheetDate2.isAfter(serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        int int44 = month42.getYearValue();
        int int45 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month42.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNull(regularTimePeriod46);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        java.lang.Object obj10 = timeSeries9.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        try {
            org.jfree.data.time.Year year18 = month15.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        java.lang.String str11 = serialDate7.toString();
        int int12 = spreadsheetDate1.compareTo((java.lang.Object) serialDate7);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long16 = month15.getFirstMillisecond();
        int int17 = month15.getMonth();
        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) month15);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = month15.getMiddleMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851744000000L) + "'", long16 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        int int44 = month42.getYearValue();
        int int45 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month42);
        java.util.Calendar calendar46 = null;
        try {
            month42.peg(calendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) (-1.0f));
        java.lang.Class<?> wildcardClass11 = timeSeriesDataItem10.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date7, (java.lang.Class) wildcardClass11);
        int int13 = timeSeries12.getMaximumItemCount();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date17 = month16.getEnd();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) month18);
        int int20 = timeSeries12.getMaximumItemCount();
        timeSeries12.setDescription("");
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long26 = month25.getFirstMillisecond();
        java.util.Date date27 = month25.getEnd();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) (-1.0f));
        java.lang.Class<?> wildcardClass31 = timeSeriesDataItem30.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date27, (java.lang.Class) wildcardClass31);
        int int33 = timeSeries32.getMaximumItemCount();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        boolean boolean38 = month36.equals((java.lang.Object) year37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries32.getDataItem((org.jfree.data.time.RegularTimePeriod) month36);
        timeSeries32.setMaximumItemCount(0);
        java.util.Collection collection42 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries32);
        try {
            int int43 = spreadsheetDate1.compareTo((java.lang.Object) timeSeries12);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61851744000000L) + "'", long26 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2147483647 + "'", int33 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(collection42);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        long long12 = day3.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43466L + "'", long12 == 43466L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(3, serialDate8);
        boolean boolean10 = spreadsheetDate5.isBefore(serialDate8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(12, serialDate8);
        boolean boolean12 = spreadsheetDate2.isOn(serialDate11);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears(6, serialDate15);
        boolean boolean17 = spreadsheetDate2.isOn(serialDate16);
        try {
            org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(11, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("January 10");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "Following", class17);
        java.lang.Comparable comparable19 = timeSeries18.getKey();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.lang.String str23 = month22.toString();
        try {
            timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Millisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "January 10" + "'", str23.equals("January 10"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
        try {
            java.lang.Number number47 = timeSeries29.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 3, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
        boolean boolean7 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        timeSeries9.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-458));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (9) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        java.lang.Class<?> wildcardClass14 = timeSeriesDataItem13.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date10, (java.lang.Class) wildcardClass14);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class16);
        java.util.List list18 = timeSeries17.getItems();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        int int24 = day22.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        boolean boolean29 = timeSeriesDataItem27.equals((java.lang.Object) 5);
        int int30 = day22.compareTo((java.lang.Object) timeSeriesDataItem27);
        java.lang.String str31 = day22.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries33 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) day22, regularTimePeriod32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1-January-2019" + "'", str31.equals("1-January-2019"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "Following", class17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.removePropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        java.lang.String str11 = serialDate7.toString();
        int int12 = spreadsheetDate1.compareTo((java.lang.Object) serialDate7);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long16 = month15.getFirstMillisecond();
        int int17 = month15.getMonth();
        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) month15);
        spreadsheetDate1.setDescription("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851744000000L) + "'", long16 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-61851744000000L));
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61851744000000L) + "'", long5 == (-61851744000000L));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("January 10");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        boolean boolean4 = fixedMillisecond1.equals((java.lang.Object) 520764324);
        long long5 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 12L + "'", long7 == 12L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year3.next();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long13 = month12.getFirstMillisecond();
        java.util.Date date14 = month12.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) (-1.0f));
        java.lang.Class<?> wildcardClass18 = timeSeriesDataItem17.getClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date14, (java.lang.Class) wildcardClass18);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year3, class20);
        boolean boolean22 = month2.equals((java.lang.Object) class20);
        java.lang.Object obj23 = null;
        boolean boolean24 = month2.equals(obj23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61851744000000L) + "'", long13 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(regularTimePeriod25);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#', 12, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.util.Collection collection18 = timeSeries9.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries19 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries20 = timeSeries9.addAndOrUpdate(timeSeries19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(collection18);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        int int5 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        org.jfree.data.time.TimeSeries timeSeries19 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries20 = timeSeries18.addAndOrUpdate(timeSeries19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100, 2, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        int int12 = day3.getMonth();
        int int13 = day3.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        try {
            timeSeries12.delete(0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long15 = month14.getFirstMillisecond();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem19.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date16, (java.lang.Class) wildcardClass20);
        int int22 = timeSeries21.getMaximumItemCount();
        int int23 = day3.compareTo((java.lang.Object) int22);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = day3.getFirstMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61851744000000L) + "'", long15 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        java.lang.Class<?> wildcardClass9 = timeSeriesDataItem8.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5, (java.lang.Class) wildcardClass9);
        int int11 = timeSeries10.getMaximumItemCount();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears(6, serialDate14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate14);
        timeSeries10.setKey((java.lang.Comparable) serialDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(3, serialDate25);
        boolean boolean27 = spreadsheetDate22.isBefore(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears(12, serialDate25);
        boolean boolean29 = spreadsheetDate19.isOn(serialDate28);
        org.jfree.data.time.SerialDate serialDate30 = serialDate14.getEndOfCurrentMonth(serialDate28);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate28);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61851744000000L) + "'", long4 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        java.util.Calendar calendar17 = null;
        try {
            long long18 = month15.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        long long3 = year0.getFirstMillisecond();
        boolean boolean5 = year0.equals((java.lang.Object) 9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "January" + "'", str1.equals("January"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(3, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        boolean boolean14 = spreadsheetDate8.equals((java.lang.Object) day12);
        boolean boolean15 = spreadsheetDate1.isInRange(serialDate5, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day19.previous();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long25 = month24.getFirstMillisecond();
        java.util.Date date26 = month24.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (double) (-1.0f));
        java.lang.Class<?> wildcardClass30 = timeSeriesDataItem29.getClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date26, (java.lang.Class) wildcardClass30);
        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod21, class32);
        try {
            int int34 = spreadsheetDate8.compareTo((java.lang.Object) class32);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Class cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61851744000000L) + "'", long25 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(class32);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = null;
        try {
            timeSeries13.add(timeSeriesDataItem16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate3.getMonth();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(6, serialDate8);
        boolean boolean10 = spreadsheetDate3.isAfter(serialDate8);
        int int11 = spreadsheetDate3.getYYYY();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(12);
        int int15 = spreadsheetDate14.getDayOfWeek();
        int int16 = spreadsheetDate14.getDayOfMonth();
        int int17 = spreadsheetDate14.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(3, serialDate22);
        boolean boolean24 = spreadsheetDate19.isBefore(serialDate22);
        boolean boolean26 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate19, 11);
        int int27 = spreadsheetDate14.getMonth();
        try {
            org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays(520764324, (org.jfree.data.time.SerialDate) spreadsheetDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Class<?> wildcardClass3 = timeSeriesDataItem2.getClass();
        java.lang.Object obj4 = timeSeriesDataItem2.clone();
        timeSeriesDataItem2.setValue((java.lang.Number) 12);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.Comparable comparable17 = timeSeries9.getKey();
        try {
            timeSeries9.delete(7, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(comparable17);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(3, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(8);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year46);
        java.util.List list48 = timeSeries9.getItems();
        timeSeries9.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(list48);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        java.util.Date date4 = spreadsheetDate1.toDate();
        int int5 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries9.setKey((java.lang.Comparable) (byte) 0);
        timeSeries9.setDomainDescription("");
        java.lang.Object obj44 = timeSeries9.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(obj44);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.addChangeListener(seriesChangeListener19);
        try {
            timeSeries9.delete(1, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean15 = month13.equals((java.lang.Object) year14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries9.setNotify(false);
        boolean boolean19 = timeSeries9.isEmpty();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("January");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.addChangeListener(seriesChangeListener19);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        boolean boolean9 = spreadsheetDate2.isAfter(serialDate7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7);
        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries(comparable0, class11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(class11);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "Following", class17);
        java.lang.Comparable comparable19 = timeSeries18.getKey();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date22 = spreadsheetDate21.toDate();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long26 = month25.getFirstMillisecond();
        java.util.Date date27 = month25.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date22, timeZone28);
        int int31 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date33, timeZone34);
        int int37 = day35.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (double) (-1.0f));
        boolean boolean42 = timeSeriesDataItem40.equals((java.lang.Object) 5);
        int int43 = day35.compareTo((java.lang.Object) timeSeriesDataItem40);
        int int44 = day35.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 7);
        boolean boolean47 = timeSeries18.getNotify();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61851744000000L) + "'", long26 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Class<?> wildcardClass3 = timeSeriesDataItem2.getClass();
        java.lang.Object obj4 = timeSeriesDataItem2.clone();
        boolean boolean6 = timeSeriesDataItem2.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem2.getPeriod();
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeriesDataItem2.equals(obj8);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date22 = month21.getEnd();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22);
        try {
            timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 1900);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("January");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem19.getClass();
        java.lang.Object obj21 = timeSeriesDataItem19.clone();
        boolean boolean23 = timeSeriesDataItem19.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem19.getPeriod();
        try {
            timeSeries9.add(timeSeriesDataItem19);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ERROR : Relative To String");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date20 = month19.getEnd();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getStart();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date20, timeZone25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date30 = spreadsheetDate29.toDate();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long34 = month33.getFirstMillisecond();
        java.util.Date date35 = month33.getEnd();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35, timeZone36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date30, timeZone36);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date20, timeZone36);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date3, timeZone36);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date3);
        java.util.Calendar calendar42 = null;
        try {
            long long43 = year41.getFirstMillisecond(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-61851744000000L) + "'", long34 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(1900);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year2.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 0.0f);
        long long8 = year2.getFirstMillisecond();
        long long9 = year2.getSerialIndex();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 12L + "'", long6 == 12L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(7, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        long long20 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long24 = month23.getFirstMillisecond();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        java.lang.Class<?> wildcardClass29 = timeSeriesDataItem28.getClass();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date25, (java.lang.Class) wildcardClass29);
        int int31 = timeSeries30.getMaximumItemCount();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date35 = month34.getEnd();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) month36);
        int int38 = timeSeries30.getMaximumItemCount();
        timeSeries30.setDescription("");
        java.lang.String str41 = timeSeries30.getDomainDescription();
        java.util.Collection collection42 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        try {
            java.lang.Number number44 = timeSeries30.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61851744000000L) + "'", long24 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2147483647 + "'", int31 == 2147483647);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2147483647 + "'", int38 == 2147483647);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Time" + "'", str41.equals("Time"));
        org.junit.Assert.assertNotNull(collection42);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate5);
        boolean boolean7 = spreadsheetDate1.isOnOrBefore(serialDate5);
        org.jfree.data.time.SerialDate serialDate8 = null;
        try {
            org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate1.getEndOfCurrentMonth(serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        int int10 = spreadsheetDate9.getDayOfWeek();
        int int11 = spreadsheetDate9.getDayOfMonth();
        int int12 = spreadsheetDate9.getMonth();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears(6, serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = serialDate15.getFollowingDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        int int21 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths(3, serialDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date29, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.previous();
        boolean boolean33 = spreadsheetDate27.equals((java.lang.Object) day31);
        boolean boolean34 = spreadsheetDate20.isInRange(serialDate24, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean36 = spreadsheetDate9.isInRange(serialDate18, (org.jfree.data.time.SerialDate) spreadsheetDate20, (int) (byte) -1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(12);
        int int39 = spreadsheetDate38.getDayOfWeek();
        int int40 = spreadsheetDate38.getDayOfMonth();
        int int41 = spreadsheetDate38.getMonth();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears(6, serialDate44);
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getFollowingDayOfWeek(1);
        java.lang.String str48 = serialDate44.toString();
        int int49 = spreadsheetDate38.compareTo((java.lang.Object) serialDate44);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long53 = month52.getFirstMillisecond();
        int int54 = month52.getMonth();
        boolean boolean55 = spreadsheetDate38.equals((java.lang.Object) month52);
        int int56 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int57 = day5.compareTo((java.lang.Object) spreadsheetDate38);
        java.util.Calendar calendar58 = null;
        try {
            day5.peg(calendar58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 11 + "'", int40 == 11);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-January-1900" + "'", str48.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2 + "'", int49 == 2);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-61851744000000L) + "'", long53 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(3, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        boolean boolean14 = spreadsheetDate8.equals((java.lang.Object) day12);
        boolean boolean15 = spreadsheetDate1.isInRange(serialDate5, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        try {
            org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate1.getFollowingDayOfWeek((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        long long6 = month4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean15 = month13.equals((java.lang.Object) year14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries9.clear();
        timeSeries9.setDomainDescription("11-January-1900");
        timeSeries9.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-61851744000000L));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        long long18 = day17.getFirstMillisecond();
        int int19 = day17.getDayOfMonth();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (-1));
        java.lang.Comparable comparable22 = timeSeries12.getKey();
        boolean boolean23 = timeSeries12.isEmpty();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100 + "'", comparable22.equals(100));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("January");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries9.setKey((java.lang.Comparable) (byte) 0);
        java.lang.Object obj42 = timeSeries9.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-61851744000000L));
        long long2 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61851744000000L) + "'", long2 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean4 = month2.equals((java.lang.Object) year3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year3);
        java.lang.String str6 = year3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(520764324, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 520764324");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        boolean boolean18 = timeSeries9.isEmpty();
        timeSeries9.setMaximumItemAge((long) 520764324);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ERROR : Relative To String");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date13 = month12.getEnd();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone18);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long24 = month23.getFirstMillisecond();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        java.lang.Class<?> wildcardClass29 = timeSeriesDataItem28.getClass();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date25, (java.lang.Class) wildcardClass29);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date34);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        java.util.Date date38 = year37.getStart();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date34, timeZone39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date13, timeZone39);
        java.util.Calendar calendar43 = null;
        try {
            year42.peg(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61851744000000L) + "'", long24 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod41);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        java.lang.Object obj11 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries9.createCopy((int) (short) 0, (int) '#');
        java.lang.Object obj15 = timeSeries9.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean4 = month2.equals((java.lang.Object) year3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        long long25 = day23.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) (short) -1);
        long long28 = day23.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43466L + "'", long25 == 43466L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546415999999L + "'", long28 == 1546415999999L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        java.lang.Class<?> wildcardClass14 = timeSeriesDataItem13.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date10, (java.lang.Class) wildcardClass14);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class16);
        java.util.List list18 = timeSeries17.getItems();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        java.lang.Class<?> wildcardClass22 = timeSeriesDataItem21.getClass();
        java.lang.Object obj23 = timeSeriesDataItem21.clone();
        java.lang.Object obj24 = timeSeriesDataItem21.clone();
        try {
            timeSeries17.add(timeSeriesDataItem21, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Millisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean4 = month2.equals((java.lang.Object) year3);
        long long5 = year3.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year3.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean15 = month13.equals((java.lang.Object) year14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries9.clear();
        timeSeries9.setDomainDescription("11-January-1900");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(6, 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (double) '4');
        try {
            timeSeries9.add(timeSeriesDataItem24, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(11, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        int int37 = timeSeries29.getMaximumItemCount();
        java.lang.Object obj38 = timeSeries29.clone();
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year40, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year40.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year40.next();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long50 = month49.getFirstMillisecond();
        java.util.Date date51 = month49.getEnd();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year52, (double) (-1.0f));
        java.lang.Class<?> wildcardClass55 = timeSeriesDataItem54.getClass();
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date51, (java.lang.Class) wildcardClass55);
        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass55);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year40, class57);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.lang.String str62 = month61.toString();
        int int63 = month61.getYearValue();
        long long64 = month61.getFirstMillisecond();
        int int65 = year40.compareTo((java.lang.Object) month61);
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2147483647 + "'", int37 == 2147483647);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61851744000000L) + "'", long50 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(class57);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "January 10" + "'", str62.equals("January 10"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-61851744000000L) + "'", long64 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day3.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date13 = month12.getEnd();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date23 = spreadsheetDate22.toDate();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long27 = month26.getFirstMillisecond();
        java.util.Date date28 = month26.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date23, timeZone29);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date13, timeZone29);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int37 = month35.compareTo((java.lang.Object) 2);
        java.lang.String str38 = month35.toString();
        java.lang.Class<?> wildcardClass39 = month35.getClass();
        java.util.Date date40 = null;
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long44 = month43.getFirstMillisecond();
        java.util.Date date45 = month43.getEnd();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date45, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date40, timeZone46);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date13, timeZone46);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-61851744000000L) + "'", long27 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "January 10" + "'", str38.equals("January 10"));
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-61851744000000L) + "'", long44 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod48);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(12);
        int int13 = spreadsheetDate12.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(3, serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        boolean boolean25 = spreadsheetDate19.equals((java.lang.Object) day23);
        boolean boolean26 = spreadsheetDate12.isInRange(serialDate16, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean28 = spreadsheetDate1.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate12, (int) (byte) -1);
        java.lang.String str29 = spreadsheetDate1.toString();
        int int30 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(2);
        boolean boolean33 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "11-January-1900" + "'", str29.equals("11-January-1900"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        long long6 = day3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546415999999L + "'", long6 == 1546415999999L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (31) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date13 = month12.getEnd();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date23 = spreadsheetDate22.toDate();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long27 = month26.getFirstMillisecond();
        java.util.Date date28 = month26.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date23, timeZone29);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date13, timeZone29);
        java.util.Calendar calendar33 = null;
        try {
            long long34 = month32.getMiddleMillisecond(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-61851744000000L) + "'", long27 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9999, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        int int4 = year0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        java.lang.Object obj7 = null;
        boolean boolean8 = year0.equals(obj7);
        int int9 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        java.util.Date date7 = month5.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        int int11 = year10.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.SerialDate serialDate8 = null;
        try {
            boolean boolean9 = spreadsheetDate1.isOnOrBefore(serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "Following", class17);
        java.lang.Comparable comparable19 = timeSeries18.getKey();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date22 = spreadsheetDate21.toDate();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long26 = month25.getFirstMillisecond();
        java.util.Date date27 = month25.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date22, timeZone28);
        int int31 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year30);
        timeSeries18.removeAgedItems((long) 8, false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61851744000000L) + "'", long26 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        boolean boolean4 = fixedMillisecond1.equals((java.lang.Object) 12);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        long long20 = timeSeries9.getMaximumItemAge();
        timeSeries9.setMaximumItemCount(4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        java.util.Date date7 = day3.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        boolean boolean18 = timeSeries9.isEmpty();
        timeSeries9.setDescription("April");
        timeSeries9.setRangeDescription("Following");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries9.addChangeListener(seriesChangeListener23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        java.lang.String str12 = day3.toString();
        java.util.Calendar calendar13 = null;
        try {
            day3.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1-January-2019" + "'", str12.equals("1-January-2019"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod6, (double) 2147483647);
        java.lang.Object obj9 = timeSeriesDataItem8.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546415999999L + "'", long5 == 1546415999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(3, serialDate2);
        java.lang.String str4 = serialDate2.toString();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9-January-1900" + "'", str4.equals("9-January-1900"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date6 = month5.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long13 = month12.getFirstMillisecond();
        java.util.Date date14 = month12.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) (-1.0f));
        java.lang.Class<?> wildcardClass18 = timeSeriesDataItem17.getClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date14, (java.lang.Class) wildcardClass18);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date23 = month22.getEnd();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getStart();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date23, timeZone28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date33 = spreadsheetDate32.toDate();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long37 = month36.getFirstMillisecond();
        java.util.Date date38 = month36.getEnd();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date38, timeZone39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date33, timeZone39);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date23, timeZone39);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date6, timeZone39);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date1, timeZone39);
        java.util.Calendar calendar45 = null;
        try {
            day44.peg(calendar45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61851744000000L) + "'", long13 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61851744000000L) + "'", long37 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 8);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean4 = month2.equals((java.lang.Object) year3);
        int int5 = month2.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "Following", class17);
        java.lang.Comparable comparable19 = timeSeries18.getKey();
        timeSeries18.setMaximumItemCount(0);
        try {
            timeSeries18.delete(3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(comparable19);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) -1, (int) (byte) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(3, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        boolean boolean14 = spreadsheetDate8.equals((java.lang.Object) day12);
        boolean boolean15 = spreadsheetDate1.isInRange(serialDate5, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(6, serialDate18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getFollowingDayOfWeek(1);
        java.lang.String str22 = serialDate18.toString();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        boolean boolean25 = spreadsheetDate8.isInRange(serialDate18, serialDate24);
        int int26 = spreadsheetDate8.getDayOfWeek();
        int int27 = spreadsheetDate8.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-January-1900" + "'", str22.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5 + "'", int26 == 5);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 1546415999999L);
        java.util.Calendar calendar7 = null;
        try {
            month4.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) class10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        int int44 = month42.getYearValue();
        int int45 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) month42);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries9.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        java.lang.Class<?> wildcardClass14 = timeSeriesDataItem13.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date10, (java.lang.Class) wildcardClass14);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class16);
        java.lang.String str18 = timeSeries17.getDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year46);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long51 = month50.getFirstMillisecond();
        java.util.Date date52 = month50.getEnd();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long58 = month57.getFirstMillisecond();
        java.util.Date date59 = month57.getEnd();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year60, (double) (-1.0f));
        java.lang.Class<?> wildcardClass63 = timeSeriesDataItem62.getClass();
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date59, (java.lang.Class) wildcardClass63);
        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass63);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month50, "hi!", "Following", class65);
        java.lang.Comparable comparable67 = timeSeries66.getKey();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date70 = spreadsheetDate69.toDate();
        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long74 = month73.getFirstMillisecond();
        java.util.Date date75 = month73.getEnd();
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date75, timeZone76);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date70, timeZone76);
        int int79 = timeSeries66.getIndex((org.jfree.data.time.RegularTimePeriod) year78);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year78, (java.lang.Number) 2019L);
        java.beans.PropertyChangeListener propertyChangeListener82 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener82);
        int int84 = timeSeries9.getItemCount();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-61851744000000L) + "'", long51 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-61851744000000L) + "'", long58 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(class65);
        org.junit.Assert.assertNotNull(comparable67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-61851744000000L) + "'", long74 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem81);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 9999);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        int int5 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            timeSeries9.update(regularTimePeriod14, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
        java.util.List list46 = timeSeries29.getItems();
        java.util.Collection collection47 = timeSeries29.getTimePeriods();
        timeSeries29.setMaximumItemAge((long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(collection47);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears(6, serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getFollowingDayOfWeek(1);
        serialDate5.setDescription("April");
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int4 = month2.compareTo((java.lang.Object) 2);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date8 = month7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date8);
        java.lang.Object obj11 = seriesChangeEvent10.getSource();
        int int12 = month2.compareTo(obj11);
        int int13 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        java.lang.String str18 = month15.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "January 10" + "'", str18.equals("January 10"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(3, serialDate7);
        boolean boolean9 = spreadsheetDate4.isBefore(serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        int int18 = day16.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) 5);
        int int24 = day16.compareTo((java.lang.Object) timeSeriesDataItem21);
        boolean boolean25 = spreadsheetDate11.equals((java.lang.Object) int24);
        boolean boolean26 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int27 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int28 = spreadsheetDate11.toSerial();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long32 = month31.getFirstMillisecond();
        java.util.Date date33 = month31.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (-1.0f));
        java.lang.Class<?> wildcardClass37 = timeSeriesDataItem36.getClass();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date33, (java.lang.Class) wildcardClass37);
        int int39 = timeSeries38.getMaximumItemCount();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        timeSeries38.setKey((java.lang.Comparable) serialDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths(3, serialDate53);
        boolean boolean55 = spreadsheetDate50.isBefore(serialDate53);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addYears(12, serialDate53);
        boolean boolean57 = spreadsheetDate47.isOn(serialDate56);
        org.jfree.data.time.SerialDate serialDate58 = serialDate42.getEndOfCurrentMonth(serialDate56);
        boolean boolean59 = spreadsheetDate11.isOn(serialDate42);
        try {
            org.jfree.data.time.SerialDate serialDate61 = spreadsheetDate11.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61851744000000L) + "'", long32 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2147483647 + "'", int39 == 2147483647);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        timeSeries9.setDescription("9-January-1900");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year46);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
        timeSeries9.addChangeListener(seriesChangeListener48);
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener50);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries9.getTimePeriod(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(12);
        int int13 = spreadsheetDate12.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(3, serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        boolean boolean25 = spreadsheetDate19.equals((java.lang.Object) day23);
        boolean boolean26 = spreadsheetDate12.isInRange(serialDate16, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean28 = spreadsheetDate1.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate12, (int) (byte) -1);
        java.lang.String str29 = spreadsheetDate1.toString();
        int int30 = spreadsheetDate1.getDayOfMonth();
        java.lang.String str31 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "11-January-1900" + "'", str29.equals("11-January-1900"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "First" + "'", str1.equals("First"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        long long25 = day23.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) (short) -1);
        java.lang.String str28 = day23.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43466L + "'", long25 == 43466L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1-January-2019" + "'", str28.equals("1-January-2019"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
        long long46 = day44.getFirstMillisecond();
        int int47 = day44.getYear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-2208268800000L) + "'", long46 == (-2208268800000L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1900 + "'", int47 == 1900);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        boolean boolean5 = month3.equals((java.lang.Object) year4);
        long long6 = year4.getMiddleMillisecond();
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) '4', year4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day21.previous();
        int int24 = timeSeries9.getIndex(regularTimePeriod23);
        int int25 = timeSeries9.getMaximumItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeries9.getTimePeriod((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
        java.util.List list46 = timeSeries29.getItems();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addYears(6, serialDate49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(serialDate49);
        timeSeries29.setKey((java.lang.Comparable) serialDate49);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timeSeries29.removeChangeListener(seriesChangeListener53);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.previous();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long17 = month16.getFirstMillisecond();
        java.util.Date date18 = month16.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        java.lang.Class<?> wildcardClass22 = timeSeriesDataItem21.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date18, (java.lang.Class) wildcardClass22);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod13, class24);
        java.util.List list26 = timeSeries25.getItems();
        int int27 = year6.compareTo((java.lang.Object) list26);
        boolean boolean28 = fixedMillisecond5.equals((java.lang.Object) list26);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61851744000000L) + "'", long17 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(3, serialDate4);
        boolean boolean6 = spreadsheetDate1.isBefore(serialDate4);
        java.lang.String str7 = serialDate4.getDescription();
        org.jfree.data.time.SerialDate serialDate8 = null;
        try {
            org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.util.Collection collection18 = timeSeries9.getTimePeriods();
        java.lang.String str19 = timeSeries9.getRangeDescription();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        boolean boolean25 = month23.equals((java.lang.Object) year24);
        boolean boolean26 = year20.equals((java.lang.Object) month23);
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) (byte) 10, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getDayOfMonth();
        int int5 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(6, serialDate8);
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getFollowingDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(12);
        int int14 = spreadsheetDate13.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(3, serialDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        boolean boolean26 = spreadsheetDate20.equals((java.lang.Object) day24);
        boolean boolean27 = spreadsheetDate13.isInRange(serialDate17, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean29 = spreadsheetDate2.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate13, (int) (byte) -1);
        int int30 = spreadsheetDate2.getDayOfMonth();
        try {
            org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 11 + "'", int4 == 11);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        long long25 = day23.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day23.previous();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (double) (-1.0f));
        long long32 = year29.getFirstMillisecond();
        int int33 = day23.compareTo((java.lang.Object) year29);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43466L + "'", long25 == 43466L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long21 = fixedMillisecond20.getSerialIndex();
        boolean boolean23 = fixedMillisecond20.equals((java.lang.Object) 520764324);
        java.lang.Number number24 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 12L + "'", long21 == 12L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(number24);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Class<?> wildcardClass3 = timeSeriesDataItem2.getClass();
        java.lang.Object obj4 = timeSeriesDataItem2.clone();
        java.lang.Object obj5 = timeSeriesDataItem2.clone();
        java.lang.Object obj6 = timeSeriesDataItem2.clone();
        java.lang.Number number7 = timeSeriesDataItem2.getValue();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener11);
        java.lang.Comparable comparable13 = timeSeries9.getKey();
        timeSeries9.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(comparable13);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date4 = month3.getEnd();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date4);
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(0, year7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1);
        long long5 = timeSeries4.getMaximumItemAge();
        java.lang.Comparable comparable6 = timeSeries4.getKey();
        java.lang.String str7 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(comparable6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (double) 9223372036854775807L);
        int int25 = timeSeries13.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Number number3 = timeSeriesDataItem2.getValue();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        int int6 = spreadsheetDate5.getDayOfWeek();
        int int7 = spreadsheetDate5.getMonth();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate5);
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries8.createCopy(1, 6);
        int int12 = timeSeriesDataItem2.compareTo((java.lang.Object) 1);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        java.lang.Class<?> wildcardClass14 = timeSeriesDataItem13.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date10, (java.lang.Class) wildcardClass14);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class16);
        java.util.List list18 = timeSeries17.getItems();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries17.getTimePeriod(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
        java.util.List list46 = timeSeries29.getItems();
        java.util.Collection collection47 = timeSeries29.getTimePeriods();
        java.util.List list48 = timeSeries29.getItems();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertNotNull(list48);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        java.lang.Class<?> wildcardClass14 = timeSeriesDataItem13.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date10, (java.lang.Class) wildcardClass14);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class16);
        java.util.List list18 = timeSeries17.getItems();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 0.0f);
        timeSeries17.setKey((java.lang.Comparable) 0.0f);
        int int26 = timeSeries17.getMaximumItemCount();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
        int int32 = day30.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (-1.0f));
        boolean boolean37 = timeSeriesDataItem35.equals((java.lang.Object) 5);
        int int38 = day30.compareTo((java.lang.Object) timeSeriesDataItem35);
        java.lang.String str39 = day30.toString();
        try {
            timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day30, 0.0d, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Millisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1-January-2019" + "'", str39.equals("1-January-2019"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedMillisecond5.equals(obj6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2958465, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) class10);
        java.lang.String str12 = seriesChangeEvent11.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=class org.jfree.data.time.Millisecond]" + "'", str12.equals("org.jfree.data.general.SeriesChangeEvent[source=class org.jfree.data.time.Millisecond]"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.util.List list2 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (52) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.lang.String str5 = month2.toString();
        java.lang.Class<?> wildcardClass6 = month2.getClass();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January 10" + "'", str5.equals("January 10"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        long long18 = day17.getFirstMillisecond();
        int int19 = day17.getDayOfMonth();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (-1));
        timeSeries12.setRangeDescription("1-January-2019");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        long long5 = day3.getLastMillisecond();
        long long6 = day3.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day3.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546415999999L + "'", long5 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546415999999L + "'", long6 == 1546415999999L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long7 = month6.getFirstMillisecond();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851744000000L) + "'", long7 == (-61851744000000L));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(6, serialDate6);
        boolean boolean8 = spreadsheetDate1.isAfter(serialDate6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        int int18 = day16.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) 5);
        int int24 = day16.compareTo((java.lang.Object) timeSeriesDataItem21);
        boolean boolean25 = year11.equals((java.lang.Object) timeSeriesDataItem21);
        java.lang.Object obj26 = null;
        boolean boolean27 = timeSeriesDataItem21.equals(obj26);
        timeSeriesDataItem21.setValue((java.lang.Number) (-61850404800001L));
        try {
            timeSeries9.add(timeSeriesDataItem21);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(12);
        int int13 = spreadsheetDate12.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(3, serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        boolean boolean25 = spreadsheetDate19.equals((java.lang.Object) day23);
        boolean boolean26 = spreadsheetDate12.isInRange(serialDate16, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean28 = spreadsheetDate1.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate12, (int) (byte) -1);
        java.lang.String str29 = spreadsheetDate1.toString();
        int int30 = spreadsheetDate1.getDayOfMonth();
        int int31 = spreadsheetDate1.getMonth();
        int int32 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "11-January-1900" + "'", str29.equals("11-January-1900"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Class<?> wildcardClass3 = timeSeriesDataItem2.getClass();
        java.lang.Object obj4 = timeSeriesDataItem2.clone();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
        long long9 = day8.getFirstMillisecond();
        long long10 = day8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.next();
        boolean boolean12 = timeSeriesDataItem2.equals((java.lang.Object) regularTimePeriod11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date16 = month15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date33 = month32.getEnd();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date33);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getStart();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date33, timeZone38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date43 = spreadsheetDate42.toDate();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long47 = month46.getFirstMillisecond();
        java.util.Date date48 = month46.getEnd();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date48, timeZone49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date43, timeZone49);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date33, timeZone49);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date16, timeZone49);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date16);
        boolean boolean55 = timeSeriesDataItem2.equals((java.lang.Object) date16);
        java.lang.Object obj56 = timeSeriesDataItem2.clone();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546415999999L + "'", long10 == 1546415999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61851744000000L) + "'", long47 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(obj56);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.addChangeListener(seriesChangeListener19);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries18.addChangeListener(seriesChangeListener21);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries24.setMaximumItemCount(1900);
        java.util.Collection collection27 = timeSeries24.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries18.addAndOrUpdate(timeSeries24);
        timeSeries24.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(timeSeries28);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Last");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        boolean boolean9 = spreadsheetDate2.isAfter(serialDate7);
        int int10 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths(3, serialDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(12);
        int int19 = spreadsheetDate18.getDayOfWeek();
        int int20 = spreadsheetDate18.getMonth();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears(6, serialDate23);
        boolean boolean25 = spreadsheetDate18.isAfter(serialDate23);
        int int26 = spreadsheetDate18.getYYYY();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate28 = serialDate14.getEndOfCurrentMonth(serialDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(12);
        int int31 = spreadsheetDate30.getDayOfWeek();
        int int32 = spreadsheetDate30.getMonth();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears(6, serialDate35);
        boolean boolean37 = spreadsheetDate30.isAfter(serialDate35);
        boolean boolean39 = spreadsheetDate2.isInRange(serialDate28, (org.jfree.data.time.SerialDate) spreadsheetDate30, 100);
        java.lang.String str40 = spreadsheetDate30.getDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 5 + "'", int31 == 5);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(str40);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=2019]");
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(3, serialDate4);
        boolean boolean6 = spreadsheetDate1.isBefore(serialDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        int int15 = day13.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (-1.0f));
        boolean boolean20 = timeSeriesDataItem18.equals((java.lang.Object) 5);
        int int21 = day13.compareTo((java.lang.Object) timeSeriesDataItem18);
        boolean boolean22 = spreadsheetDate8.equals((java.lang.Object) int21);
        boolean boolean23 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(12);
        int int26 = spreadsheetDate25.getDayOfWeek();
        int int27 = spreadsheetDate25.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears(6, serialDate30);
        boolean boolean32 = spreadsheetDate25.isAfter(serialDate30);
        boolean boolean33 = spreadsheetDate1.isAfter(serialDate30);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5 + "'", int26 == 5);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean4 = month2.equals((java.lang.Object) year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(6, serialDate6);
        boolean boolean8 = spreadsheetDate1.isAfter(serialDate6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 0.0f);
        long long16 = year10.getFirstMillisecond();
        long long17 = year10.getSerialIndex();
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(12);
        int int22 = spreadsheetDate21.getDayOfWeek();
        int int23 = spreadsheetDate21.getMonth();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears(6, serialDate26);
        boolean boolean28 = spreadsheetDate21.isAfter(serialDate26);
        int int29 = spreadsheetDate21.getYYYY();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(12);
        int int33 = spreadsheetDate32.getDayOfWeek();
        int int34 = spreadsheetDate32.getDayOfMonth();
        int int35 = spreadsheetDate32.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths(3, serialDate40);
        boolean boolean42 = spreadsheetDate37.isBefore(serialDate40);
        boolean boolean44 = spreadsheetDate21.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, (org.jfree.data.time.SerialDate) spreadsheetDate37, 11);
        int int45 = spreadsheetDate32.getDayOfWeek();
        boolean boolean46 = timeSeries9.equals((java.lang.Object) spreadsheetDate32);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        boolean boolean51 = month49.equals((java.lang.Object) year50);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent52 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year50);
        int int54 = year50.compareTo((java.lang.Object) 8);
        try {
            int int55 = spreadsheetDate32.compareTo((java.lang.Object) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 2019L + "'", long17 == 2019L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5 + "'", int22 == 5);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1900 + "'", int29 == 1900);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 11 + "'", int34 == 11);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 5 + "'", int45 == 5);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate3.getMonth();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(6, serialDate8);
        boolean boolean10 = spreadsheetDate3.isAfter(serialDate8);
        int int11 = spreadsheetDate3.getYYYY();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.util.Collection collection18 = timeSeries9.getTimePeriods();
        java.lang.String str19 = timeSeries9.getRangeDescription();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = null;
        try {
            timeSeries9.add(timeSeriesDataItem20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("ERROR : Relative To String");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException5);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException5);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean15 = month13.equals((java.lang.Object) year14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries9.clear();
        timeSeries9.setNotify(true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(3, serialDate8);
        boolean boolean10 = spreadsheetDate5.isBefore(serialDate8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(12, serialDate8);
        boolean boolean12 = spreadsheetDate2.isOn(serialDate11);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears(6, serialDate15);
        boolean boolean17 = spreadsheetDate2.isOn(serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(8, serialDate16);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (short) 100);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day3.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        long long19 = timeSeries18.getMaximumItemAge();
        timeSeries18.setMaximumItemCount(8);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date25 = month24.getEnd();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date25);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long32 = month31.getFirstMillisecond();
        java.util.Date date33 = month31.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (-1.0f));
        java.lang.Class<?> wildcardClass37 = timeSeriesDataItem36.getClass();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date33, (java.lang.Class) wildcardClass37);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date42 = month41.getEnd();
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date42);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        java.util.Date date46 = year45.getStart();
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date42, timeZone47);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date52 = spreadsheetDate51.toDate();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long56 = month55.getFirstMillisecond();
        java.util.Date date57 = month55.getEnd();
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date57, timeZone58);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date52, timeZone58);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(date42, timeZone58);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date25, timeZone58);
        boolean boolean63 = timeSeries18.equals((java.lang.Object) timeZone58);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61851744000000L) + "'", long32 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-61851744000000L) + "'", long56 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        long long18 = day17.getFirstMillisecond();
        int int19 = day17.getDayOfMonth();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day17.previous();
        int int23 = day17.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries1.setMaximumItemCount(1900);
        java.util.List list4 = timeSeries1.getItems();
        timeSeries1.setRangeDescription("January");
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("January 10");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Following");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4);
        timeSeries5.setMaximumItemCount(0);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Following");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.lang.String str5 = month2.toString();
        int int6 = month2.getYearValue();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January 10" + "'", str5.equals("January 10"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Class<?> wildcardClass3 = timeSeriesDataItem2.getClass();
        java.lang.Object obj4 = timeSeriesDataItem2.clone();
        java.lang.Object obj5 = null;
        boolean boolean6 = timeSeriesDataItem2.equals(obj5);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(3, serialDate7);
        boolean boolean9 = spreadsheetDate4.isBefore(serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        int int18 = day16.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) 5);
        int int24 = day16.compareTo((java.lang.Object) timeSeriesDataItem21);
        boolean boolean25 = spreadsheetDate11.equals((java.lang.Object) int24);
        boolean boolean26 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int27 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int28 = spreadsheetDate11.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2958465);
        boolean boolean31 = spreadsheetDate11.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate34);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addYears(6, serialDate39);
        org.jfree.data.time.SerialDate serialDate42 = serialDate39.getFollowingDayOfWeek(1);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(1, serialDate39);
        boolean boolean44 = spreadsheetDate30.isInRange(serialDate35, serialDate39);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year46);
        timeSeries9.fireSeriesChanged();
        java.lang.Class<?> wildcardClass49 = timeSeries9.getClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Class<?> wildcardClass18 = timeSeries9.getClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries9.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) (-1.0f));
        java.lang.Class<?> wildcardClass6 = timeSeriesDataItem5.getClass();
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) wildcardClass6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long14 = month13.getFirstMillisecond();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (-1.0f));
        java.lang.Class<?> wildcardClass19 = timeSeriesDataItem18.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date15, (java.lang.Class) wildcardClass19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date24 = month23.getEnd();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date24);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date24, timeZone29);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date10, timeZone29);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 12L + "'", long9 == 12L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61851744000000L) + "'", long14 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Class<?> wildcardClass3 = timeSeriesDataItem2.getClass();
        java.lang.Object obj4 = timeSeriesDataItem2.clone();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
        long long9 = day8.getFirstMillisecond();
        long long10 = day8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.next();
        boolean boolean12 = timeSeriesDataItem2.equals((java.lang.Object) regularTimePeriod11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date16 = month15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date33 = month32.getEnd();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date33);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getStart();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date33, timeZone38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date43 = spreadsheetDate42.toDate();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long47 = month46.getFirstMillisecond();
        java.util.Date date48 = month46.getEnd();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date48, timeZone49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date43, timeZone49);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date33, timeZone49);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date16, timeZone49);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date16);
        boolean boolean55 = timeSeriesDataItem2.equals((java.lang.Object) date16);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date16);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546415999999L + "'", long10 == 1546415999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61851744000000L) + "'", long47 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        long long2 = year0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(12);
        int int13 = spreadsheetDate12.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(3, serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        boolean boolean25 = spreadsheetDate19.equals((java.lang.Object) day23);
        boolean boolean26 = spreadsheetDate12.isInRange(serialDate16, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean28 = spreadsheetDate1.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate12, (int) (byte) -1);
        org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate1.getPreviousDayOfWeek(1);
        try {
            org.jfree.data.time.SerialDate serialDate32 = spreadsheetDate1.getFollowingDayOfWeek(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(serialDate30);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
        java.util.List list46 = timeSeries29.getItems();
        java.util.Collection collection47 = timeSeries29.getTimePeriods();
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long51 = month50.getFirstMillisecond();
        java.util.Date date52 = month50.getEnd();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long58 = month57.getFirstMillisecond();
        java.util.Date date59 = month57.getEnd();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year60, (double) (-1.0f));
        java.lang.Class<?> wildcardClass63 = timeSeriesDataItem62.getClass();
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date59, (java.lang.Class) wildcardClass63);
        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass63);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month50, "hi!", "Following", class65);
        long long67 = month50.getFirstMillisecond();
        try {
            timeSeries29.add((org.jfree.data.time.RegularTimePeriod) month50, (double) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-61851744000000L) + "'", long51 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-61851744000000L) + "'", long58 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(class65);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-61851744000000L) + "'", long67 == (-61851744000000L));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) (-1.0f));
        java.lang.Class<?> wildcardClass6 = timeSeriesDataItem5.getClass();
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) wildcardClass6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 12L + "'", long9 == 12L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        timeSeries9.removeAgedItems(false);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long50 = month49.getFirstMillisecond();
        java.util.Date date51 = month49.getEnd();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year52, (double) (-1.0f));
        java.lang.Class<?> wildcardClass55 = timeSeriesDataItem54.getClass();
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date51, (java.lang.Class) wildcardClass55);
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date60 = month59.getEnd();
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(date60);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent62 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date60);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        java.util.Date date64 = year63.getStart();
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date64, timeZone65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date60, timeZone65);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date70 = spreadsheetDate69.toDate();
        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long74 = month73.getFirstMillisecond();
        java.util.Date date75 = month73.getEnd();
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date75, timeZone76);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date70, timeZone76);
        org.jfree.data.time.Month month79 = new org.jfree.data.time.Month(date60, timeZone76);
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date43, timeZone76);
        long long81 = year80.getFirstMillisecond();
        int int82 = year80.getYear();
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year80, (java.lang.Number) 1546415999999L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61851744000000L) + "'", long50 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-61851744000000L) + "'", long74 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-61851744000000L) + "'", long81 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 10 + "'", int82 == 10);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 100.0f);
        long long3 = year0.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        timeSeries9.setMaximumItemCount((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.addChangeListener(seriesChangeListener19);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries18.addChangeListener(seriesChangeListener21);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries24.setMaximumItemCount(1900);
        java.util.Collection collection27 = timeSeries24.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries18.addAndOrUpdate(timeSeries24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries28);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(timeSeries28);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-458));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries1.setMaximumItemCount(1900);
        long long4 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.next();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(3, serialDate7);
        boolean boolean9 = spreadsheetDate4.isBefore(serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        int int18 = day16.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) 5);
        int int24 = day16.compareTo((java.lang.Object) timeSeriesDataItem21);
        boolean boolean25 = spreadsheetDate11.equals((java.lang.Object) int24);
        boolean boolean26 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int27 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int28 = spreadsheetDate11.toSerial();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long32 = month31.getFirstMillisecond();
        java.util.Date date33 = month31.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, (double) (-1.0f));
        java.lang.Class<?> wildcardClass37 = timeSeriesDataItem36.getClass();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date33, (java.lang.Class) wildcardClass37);
        int int39 = timeSeries38.getMaximumItemCount();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        timeSeries38.setKey((java.lang.Comparable) serialDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths(3, serialDate53);
        boolean boolean55 = spreadsheetDate50.isBefore(serialDate53);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addYears(12, serialDate53);
        boolean boolean57 = spreadsheetDate47.isOn(serialDate56);
        org.jfree.data.time.SerialDate serialDate58 = serialDate42.getEndOfCurrentMonth(serialDate56);
        boolean boolean59 = spreadsheetDate11.isOn(serialDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(2958465);
        int int62 = spreadsheetDate61.getMonth();
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate65);
        boolean boolean67 = spreadsheetDate61.isOnOrBefore(serialDate65);
        boolean boolean68 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61851744000000L) + "'", long32 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2147483647 + "'", int39 == 2147483647);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 12 + "'", int62 == 12);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        long long5 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        java.lang.String str11 = serialDate7.toString();
        int int12 = spreadsheetDate1.compareTo((java.lang.Object) serialDate7);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long16 = month15.getFirstMillisecond();
        int int17 = month15.getMonth();
        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) month15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        int int21 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(3, serialDate26);
        boolean boolean28 = spreadsheetDate23.isBefore(serialDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date31 = spreadsheetDate30.toDate();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date33, timeZone34);
        int int37 = day35.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (double) (-1.0f));
        boolean boolean42 = timeSeriesDataItem40.equals((java.lang.Object) 5);
        int int43 = day35.compareTo((java.lang.Object) timeSeriesDataItem40);
        boolean boolean44 = spreadsheetDate30.equals((java.lang.Object) int43);
        boolean boolean45 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int46 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate20.getNearestDayOfWeek(1);
        boolean boolean49 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int50 = spreadsheetDate20.getYYYY();
        try {
            org.jfree.data.time.SerialDate serialDate52 = spreadsheetDate20.getNearestDayOfWeek(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851744000000L) + "'", long16 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        java.lang.String str11 = serialDate7.toString();
        int int12 = spreadsheetDate1.compareTo((java.lang.Object) serialDate7);
        java.lang.String str13 = serialDate7.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-January-1900" + "'", str13.equals("9-January-1900"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        boolean boolean18 = timeSeries9.isEmpty();
        timeSeries9.setDescription("April");
        java.lang.Object obj21 = timeSeries9.clone();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long25 = month24.getFirstMillisecond();
        java.util.Date date26 = month24.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (double) (-1.0f));
        java.lang.Class<?> wildcardClass30 = timeSeriesDataItem29.getClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date26, (java.lang.Class) wildcardClass30);
        int int32 = timeSeries31.getMaximumItemCount();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date36 = month35.getEnd();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries31.getDataItem((org.jfree.data.time.RegularTimePeriod) month37);
        int int39 = timeSeries31.getMaximumItemCount();
        timeSeries31.setDescription("");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long45 = month44.getFirstMillisecond();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year47, (double) (-1.0f));
        java.lang.Class<?> wildcardClass50 = timeSeriesDataItem49.getClass();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date46, (java.lang.Class) wildcardClass50);
        int int52 = timeSeries51.getMaximumItemCount();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        boolean boolean57 = month55.equals((java.lang.Object) year56);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) month55);
        timeSeries51.setMaximumItemCount(0);
        java.util.Collection collection61 = timeSeries31.getTimePeriodsUniqueToOtherSeries(timeSeries51);
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date65 = month64.getEnd();
        int int66 = month64.getYearValue();
        int int67 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) month64);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month64, (double) 31);
        try {
            timeSeries9.update((org.jfree.data.time.RegularTimePeriod) month64, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61851744000000L) + "'", long25 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2147483647 + "'", int32 == 2147483647);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2147483647 + "'", int39 == 2147483647);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61851744000000L) + "'", long45 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2147483647 + "'", int52 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertNotNull(collection61);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 10 + "'", int66 == 10);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        long long19 = timeSeries18.getMaximumItemAge();
        timeSeries18.setMaximumItemCount(8);
        timeSeries18.setMaximumItemAge(1577865599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year46);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
        timeSeries9.addChangeListener(seriesChangeListener48);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long52 = fixedMillisecond51.getSerialIndex();
        boolean boolean54 = fixedMillisecond51.equals((java.lang.Object) 520764324);
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond51.getLastMillisecond(calendar55);
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (java.lang.Number) 43466L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 12L + "'", long52 == 12L);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 12L + "'", long56 == 12L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Value");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int14 = month12.compareTo((java.lang.Object) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month12.next();
        java.lang.Number number16 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month12);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Class<?> wildcardClass3 = timeSeriesDataItem2.getClass();
        java.lang.Object obj4 = timeSeriesDataItem2.clone();
        boolean boolean6 = timeSeriesDataItem2.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem2.getPeriod();
        java.lang.Number number8 = timeSeriesDataItem2.getValue();
        timeSeriesDataItem2.setValue((java.lang.Number) (byte) 10);
        java.lang.Number number11 = timeSeriesDataItem2.getValue();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1.0d) + "'", number8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 10 + "'", number11.equals((byte) 10));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2019, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "Following", class17);
        java.lang.Comparable comparable19 = timeSeries18.getKey();
        timeSeries18.setMaximumItemCount(0);
        timeSeries18.setMaximumItemCount(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = null;
        java.lang.Number number25 = null;
        try {
            timeSeries18.update(regularTimePeriod24, number25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(comparable19);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        java.lang.Object obj9 = timeSeriesDataItem7.clone();
        boolean boolean10 = month2.equals(obj9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month2.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(6, serialDate6);
        boolean boolean8 = spreadsheetDate1.isAfter(serialDate6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long15 = month14.getFirstMillisecond();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem19.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date16, (java.lang.Class) wildcardClass20);
        int int22 = timeSeries21.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries21.addAndOrUpdate(timeSeries24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getStart();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27, timeZone28);
        long long30 = day29.getFirstMillisecond();
        int int31 = day29.getDayOfMonth();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) (-1));
        try {
            timeSeries9.update((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61851744000000L) + "'", long15 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1546329600000L + "'", long30 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        long long20 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long24 = month23.getFirstMillisecond();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        java.lang.Class<?> wildcardClass29 = timeSeriesDataItem28.getClass();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date25, (java.lang.Class) wildcardClass29);
        int int31 = timeSeries30.getMaximumItemCount();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date35 = month34.getEnd();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) month36);
        int int38 = timeSeries30.getMaximumItemCount();
        timeSeries30.setDescription("");
        java.lang.String str41 = timeSeries30.getDomainDescription();
        java.util.Collection collection42 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        try {
            java.lang.Number number44 = timeSeries30.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61851744000000L) + "'", long24 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2147483647 + "'", int31 == 2147483647);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2147483647 + "'", int38 == 2147483647);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Time" + "'", str41.equals("Time"));
        org.junit.Assert.assertNotNull(collection42);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        timeSeries9.removeAgedItems(false);
        timeSeries9.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate3);
        java.lang.String str5 = serialDate3.getDescription();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate3);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
        long long6 = fixedMillisecond5.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61849065600001L) + "'", long6 == (-61849065600001L));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long3 = fixedMillisecond2.getSerialIndex();
        boolean boolean5 = fixedMillisecond2.equals((java.lang.Object) 520764324);
        long long6 = fixedMillisecond2.getFirstMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.util.Date date8 = year7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        int int14 = day12.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) (-1.0f));
        boolean boolean19 = timeSeriesDataItem17.equals((java.lang.Object) 5);
        int int20 = day12.compareTo((java.lang.Object) timeSeriesDataItem17);
        boolean boolean21 = year7.equals((java.lang.Object) timeSeriesDataItem17);
        boolean boolean22 = fixedMillisecond2.equals((java.lang.Object) year7);
        try {
            org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) -1, year7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 12L + "'", long6 == 12L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries1.setMaximumItemCount(1900);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year4, (double) 2019);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4, timeZone5);
        long long7 = year6.getMiddleMillisecond();
        java.lang.String str8 = year6.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61835976000001L) + "'", long7 == (-61835976000001L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10" + "'", str8.equals("10"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(520764324);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        timeSeries9.removeAgedItems(false);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year40, (double) (-1.0f));
        java.lang.Class<?> wildcardClass43 = timeSeriesDataItem42.getClass();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long47 = month46.getFirstMillisecond();
        java.util.Date date48 = month46.getEnd();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year49, (double) (-1.0f));
        java.lang.Class<?> wildcardClass52 = timeSeriesDataItem51.getClass();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date48, (java.lang.Class) wildcardClass52);
        int int54 = timeSeriesDataItem42.compareTo((java.lang.Object) date48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = timeSeriesDataItem42.getPeriod();
        try {
            timeSeries9.add(regularTimePeriod55, 0.0d, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61851744000000L) + "'", long47 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.addChangeListener(seriesChangeListener19);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries18.addChangeListener(seriesChangeListener21);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries24.setMaximumItemCount(1900);
        java.util.Collection collection27 = timeSeries24.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries18.addAndOrUpdate(timeSeries24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) 12);
        java.util.Date date31 = fixedMillisecond30.getTime();
        java.util.Date date32 = fixedMillisecond30.getTime();
        try {
            timeSeries28.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 100.0f, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day5.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) (-1.0f));
        boolean boolean12 = timeSeriesDataItem10.equals((java.lang.Object) 5);
        int int13 = day5.compareTo((java.lang.Object) timeSeriesDataItem10);
        boolean boolean14 = year0.equals((java.lang.Object) timeSeriesDataItem10);
        java.lang.Object obj15 = null;
        boolean boolean16 = timeSeriesDataItem10.equals(obj15);
        timeSeriesDataItem10.setValue((java.lang.Number) (-61850404800001L));
        java.lang.Object obj19 = timeSeriesDataItem10.clone();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate22);
        java.lang.String str24 = serialDate22.getDescription();
        int int25 = timeSeriesDataItem10.compareTo((java.lang.Object) str24);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1);
        long long5 = timeSeries4.getMaximumItemAge();
        int int6 = timeSeries4.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("10");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "11-January-1900");
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, class17);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long22 = month21.getFirstMillisecond();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (-1.0f));
        java.lang.Class<?> wildcardClass27 = timeSeriesDataItem26.getClass();
        java.lang.Object obj28 = timeSeriesDataItem26.clone();
        boolean boolean29 = month21.equals(obj28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, (-1.0d));
        timeSeries18.setRangeDescription("January");
        timeSeries18.removeAgedItems((long) 30, false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61851744000000L) + "'", long22 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate3 = null;
        try {
            boolean boolean4 = spreadsheetDate1.isBefore(serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        long long19 = timeSeries18.getMaximumItemAge();
        boolean boolean20 = timeSeries18.isEmpty();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1);
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(1, 6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (java.lang.Number) 0.0f);
        long long14 = year8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year8.next();
        try {
            timeSeries4.add(regularTimePeriod15, (double) 12L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(timeSeries7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(3, serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        boolean boolean15 = spreadsheetDate9.equals((java.lang.Object) day13);
        boolean boolean16 = spreadsheetDate2.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears(6, serialDate19);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getFollowingDayOfWeek(1);
        java.lang.String str23 = serialDate19.toString();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        boolean boolean26 = spreadsheetDate9.isInRange(serialDate19, serialDate25);
        try {
            org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), serialDate19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-January-1900" + "'", str23.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (double) 9223372036854775807L);
        java.util.Calendar calendar25 = null;
        try {
            long long26 = year16.getLastMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-61851744000000L));
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-61849065600001L));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Class<?> wildcardClass18 = timeSeries9.getClass();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries9.getDataItem(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        long long5 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str17 = timeSeries9.getDomainDescription();
        java.lang.String str18 = timeSeries9.getRangeDescription();
        timeSeries9.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int4 = month2.compareTo((java.lang.Object) 2);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date8 = month7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date8);
        java.lang.Object obj11 = seriesChangeEvent10.getSource();
        int int12 = month2.compareTo(obj11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long16 = month15.getFirstMillisecond();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (double) (-1.0f));
        java.lang.Class<?> wildcardClass21 = timeSeriesDataItem20.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date17, (java.lang.Class) wildcardClass21);
        int int23 = timeSeries22.getMaximumItemCount();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date27 = month26.getEnd();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) month28);
        long long30 = month28.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long30);
        long long32 = timeSeries31.getMaximumItemAge();
        timeSeries31.clear();
        int int34 = month2.compareTo((java.lang.Object) timeSeries31);
        try {
            java.lang.Number number36 = timeSeries31.getValue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851744000000L) + "'", long16 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61850404800001L) + "'", long30 == (-61850404800001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        long long20 = timeSeries9.getMaximumItemAge();
        java.lang.String str21 = timeSeries9.getDescription();
        timeSeries9.setMaximumItemAge((long) 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, class17);
        int int19 = year0.getYear();
        int int20 = year0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.addChangeListener(seriesChangeListener19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        long long25 = day24.getFirstMillisecond();
        long long26 = day24.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day24.next();
        timeSeries9.setKey((java.lang.Comparable) day24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day24.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546415999999L + "'", long26 == 1546415999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        boolean boolean18 = timeSeries9.isEmpty();
        timeSeries9.setDescription("April");
        timeSeries9.setRangeDescription("Following");
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries9.createCopy((int) (short) 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(timeSeries25);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        long long18 = day17.getFirstMillisecond();
        int int19 = day17.getDayOfMonth();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (-1));
        try {
            timeSeries12.update(10, (java.lang.Number) 1562097599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year46);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long51 = month50.getFirstMillisecond();
        java.util.Date date52 = month50.getEnd();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long58 = month57.getFirstMillisecond();
        java.util.Date date59 = month57.getEnd();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year60, (double) (-1.0f));
        java.lang.Class<?> wildcardClass63 = timeSeriesDataItem62.getClass();
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date59, (java.lang.Class) wildcardClass63);
        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass63);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month50, "hi!", "Following", class65);
        java.lang.Comparable comparable67 = timeSeries66.getKey();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date70 = spreadsheetDate69.toDate();
        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long74 = month73.getFirstMillisecond();
        java.util.Date date75 = month73.getEnd();
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date75, timeZone76);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date70, timeZone76);
        int int79 = timeSeries66.getIndex((org.jfree.data.time.RegularTimePeriod) year78);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year78, (java.lang.Number) 2019L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = fixedMillisecond83.previous();
        timeSeries9.update(regularTimePeriod84, (java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = null;
        try {
            timeSeries9.add(regularTimePeriod87, (double) (-61835976000001L), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-61851744000000L) + "'", long51 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-61851744000000L) + "'", long58 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(class65);
        org.junit.Assert.assertNotNull(comparable67);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-61851744000000L) + "'", long74 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNull(timeSeriesDataItem81);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(3, serialDate7);
        boolean boolean9 = spreadsheetDate4.isBefore(serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        int int18 = day16.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) 5);
        int int24 = day16.compareTo((java.lang.Object) timeSeriesDataItem21);
        boolean boolean25 = spreadsheetDate11.equals((java.lang.Object) int24);
        boolean boolean26 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int27 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int28 = spreadsheetDate11.toSerial();
        int int29 = spreadsheetDate11.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1900 + "'", int29 == 1900);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        boolean boolean18 = timeSeries9.isEmpty();
        timeSeries9.setDescription("April");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long23 = fixedMillisecond22.getSerialIndex();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (-1.0f));
        java.lang.Class<?> wildcardClass27 = timeSeriesDataItem26.getClass();
        boolean boolean28 = fixedMillisecond22.equals((java.lang.Object) wildcardClass27);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond22.getMiddleMillisecond(calendar29);
        java.util.Date date31 = fixedMillisecond22.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
        timeSeries9.setKey((java.lang.Comparable) date31);
        try {
            timeSeries9.update(0, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 12L + "'", long23 == 12L);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 12L + "'", long30 == 12L);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate5);
        boolean boolean7 = spreadsheetDate1.isOnOrBefore(serialDate5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
        java.util.List list46 = timeSeries29.getItems();
        java.util.Collection collection47 = timeSeries29.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = timeSeries29.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(collection47);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries1.setMaximumItemCount(1900);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(9, 0);
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month6);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getSerialIndex();
        int int5 = day3.getDayOfMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day3.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43466L + "'", long4 == 43466L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 100);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.Object obj5 = null;
        boolean boolean6 = year0.equals(obj5);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        long long6 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.next();
        java.util.Date date8 = regularTimePeriod7.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        java.lang.String str11 = serialDate7.toString();
        int int12 = spreadsheetDate1.compareTo((java.lang.Object) serialDate7);
        java.lang.String str13 = spreadsheetDate1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        java.lang.String str11 = serialDate7.toString();
        int int12 = spreadsheetDate1.compareTo((java.lang.Object) serialDate7);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long16 = month15.getFirstMillisecond();
        int int17 = month15.getMonth();
        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) month15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        int int21 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(3, serialDate26);
        boolean boolean28 = spreadsheetDate23.isBefore(serialDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date31 = spreadsheetDate30.toDate();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date33, timeZone34);
        int int37 = day35.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (double) (-1.0f));
        boolean boolean42 = timeSeriesDataItem40.equals((java.lang.Object) 5);
        int int43 = day35.compareTo((java.lang.Object) timeSeriesDataItem40);
        boolean boolean44 = spreadsheetDate30.equals((java.lang.Object) int43);
        boolean boolean45 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int46 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate20.getNearestDayOfWeek(1);
        boolean boolean49 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int50 = spreadsheetDate20.getYYYY();
        int int51 = spreadsheetDate20.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851744000000L) + "'", long16 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1900 + "'", int51 == 1900);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        long long18 = day17.getFirstMillisecond();
        int int19 = day17.getDayOfMonth();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (-1));
        java.lang.Comparable comparable22 = timeSeries12.getKey();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getStart();
        long long25 = year23.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year23, (double) 11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 100 + "'", comparable22.equals(100));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate3.getMonth();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(6, serialDate8);
        boolean boolean10 = spreadsheetDate3.isAfter(serialDate8);
        int int11 = spreadsheetDate3.getYYYY();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(12);
        int int15 = spreadsheetDate14.getDayOfWeek();
        int int16 = spreadsheetDate14.getDayOfMonth();
        int int17 = spreadsheetDate14.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(3, serialDate22);
        boolean boolean24 = spreadsheetDate19.isBefore(serialDate22);
        boolean boolean26 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate19, 11);
        try {
            org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(8, 9, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long7 = fixedMillisecond6.getSerialIndex();
        int int8 = month2.compareTo((java.lang.Object) long7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 12L + "'", long7 == 12L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(30);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) (-1.0f));
        java.lang.Class<?> wildcardClass6 = timeSeriesDataItem5.getClass();
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) wildcardClass6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond1.getEnd();
        int int12 = fixedMillisecond1.compareTo((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String");
        long long13 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 12L + "'", long9 == 12L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 12L + "'", long13 == 12L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 1546415999999L);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month4.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "Following", class17);
        java.lang.Comparable comparable19 = timeSeries18.getKey();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date22 = spreadsheetDate21.toDate();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long26 = month25.getFirstMillisecond();
        java.util.Date date27 = month25.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date22, timeZone28);
        int int31 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year30);
        java.util.Collection collection32 = timeSeries18.getTimePeriods();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61851744000000L) + "'", long26 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(collection32);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (short) 100);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(2958465);
        int int16 = spreadsheetDate15.getMonth();
        spreadsheetDate15.setDescription("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date21 = spreadsheetDate20.toDate();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long25 = month24.getFirstMillisecond();
        java.util.Date date26 = month24.getEnd();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date26, timeZone27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date21, timeZone27);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date21);
        boolean boolean31 = spreadsheetDate15.isBefore(serialDate30);
        int int32 = day3.compareTo((java.lang.Object) spreadsheetDate15);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61851744000000L) + "'", long25 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        int int5 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        long long25 = day23.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) (short) -1);
        int int28 = day23.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43466L + "'", long25 == 43466L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        long long25 = day23.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) (short) -1);
        long long28 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.util.Date date30 = year29.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.util.Date date32 = year31.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        int int36 = day34.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year37, (double) (-1.0f));
        boolean boolean41 = timeSeriesDataItem39.equals((java.lang.Object) 5);
        int int42 = day34.compareTo((java.lang.Object) timeSeriesDataItem39);
        boolean boolean43 = year29.equals((java.lang.Object) timeSeriesDataItem39);
        timeSeriesDataItem39.setValue((java.lang.Number) 2147483647);
        try {
            timeSeries9.add(timeSeriesDataItem39);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43466L + "'", long25 == 43466L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(3, serialDate15);
        boolean boolean17 = spreadsheetDate12.isBefore(serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears(12, serialDate15);
        boolean boolean19 = spreadsheetDate9.isOn(serialDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(12);
        int int22 = spreadsheetDate21.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(3, serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        java.util.Date date30 = year29.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day32.previous();
        boolean boolean34 = spreadsheetDate28.equals((java.lang.Object) day32);
        boolean boolean35 = spreadsheetDate21.isInRange(serialDate25, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addYears(6, serialDate38);
        org.jfree.data.time.SerialDate serialDate41 = serialDate38.getFollowingDayOfWeek(1);
        java.lang.String str42 = serialDate38.toString();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        boolean boolean45 = spreadsheetDate28.isInRange(serialDate38, serialDate44);
        boolean boolean46 = spreadsheetDate9.isOnOrBefore(serialDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2958465);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(12);
        int int51 = spreadsheetDate50.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addMonths(3, serialDate56);
        boolean boolean58 = spreadsheetDate53.isBefore(serialDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date61 = spreadsheetDate60.toDate();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        java.util.Date date63 = year62.getStart();
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date63, timeZone64);
        int int67 = day65.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year68, (double) (-1.0f));
        boolean boolean72 = timeSeriesDataItem70.equals((java.lang.Object) 5);
        int int73 = day65.compareTo((java.lang.Object) timeSeriesDataItem70);
        boolean boolean74 = spreadsheetDate60.equals((java.lang.Object) int73);
        boolean boolean75 = spreadsheetDate53.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate60);
        int int76 = spreadsheetDate50.compare((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean77 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean78 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.addMonths(3, serialDate84);
        boolean boolean86 = spreadsheetDate81.isBefore(serialDate84);
        int int87 = spreadsheetDate50.compare(serialDate84);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5 + "'", int22 == 5);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-January-1900" + "'", str42.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 5 + "'", int51 == 5);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 2 + "'", int87 == 2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener11);
        java.lang.Comparable comparable13 = timeSeries9.getKey();
        timeSeries9.setDescription("");
        boolean boolean16 = timeSeries9.isEmpty();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(comparable13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        boolean boolean9 = spreadsheetDate2.isAfter(serialDate7);
        int int10 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(12);
        int int15 = spreadsheetDate14.getDayOfWeek();
        int int16 = spreadsheetDate14.getMonth();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears(6, serialDate19);
        boolean boolean21 = spreadsheetDate14.isAfter(serialDate19);
        int int22 = spreadsheetDate14.getYYYY();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(12);
        int int26 = spreadsheetDate25.getDayOfWeek();
        int int27 = spreadsheetDate25.getDayOfMonth();
        int int28 = spreadsheetDate25.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(3, serialDate33);
        boolean boolean35 = spreadsheetDate30.isBefore(serialDate33);
        boolean boolean37 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate30, 11);
        org.jfree.data.time.SerialDate serialDate38 = null;
        try {
            boolean boolean39 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, serialDate38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5 + "'", int26 == 5);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(6, serialDate6);
        boolean boolean8 = spreadsheetDate1.isAfter(serialDate6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond13.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.next();
        java.util.Date date16 = fixedMillisecond13.getTime();
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) (-61835976000001L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(3, serialDate8);
        boolean boolean10 = spreadsheetDate5.isBefore(serialDate8);
        int int11 = spreadsheetDate1.compare(serialDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(12);
        int int15 = spreadsheetDate14.getDayOfWeek();
        int int16 = spreadsheetDate14.getMonth();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears(6, serialDate19);
        boolean boolean21 = spreadsheetDate14.isAfter(serialDate19);
        int int22 = spreadsheetDate14.getYYYY();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(12);
        int int26 = spreadsheetDate25.getDayOfWeek();
        int int27 = spreadsheetDate25.getDayOfMonth();
        int int28 = spreadsheetDate25.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(3, serialDate33);
        boolean boolean35 = spreadsheetDate30.isBefore(serialDate33);
        boolean boolean37 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate30, 11);
        int int38 = spreadsheetDate25.getDayOfWeek();
        boolean boolean39 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5 + "'", int26 == 5);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 5 + "'", int38 == 5);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        java.util.Date date7 = month5.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        int int12 = year10.getYear();
        long long13 = year10.getSerialIndex();
        java.lang.String str14 = year10.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1900L + "'", long13 == 1900L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1900" + "'", str14.equals("1900"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        boolean boolean4 = fixedMillisecond1.equals((java.lang.Object) 520764324);
        long long5 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        int int13 = day11.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (-1.0f));
        boolean boolean18 = timeSeriesDataItem16.equals((java.lang.Object) 5);
        int int19 = day11.compareTo((java.lang.Object) timeSeriesDataItem16);
        boolean boolean20 = year6.equals((java.lang.Object) timeSeriesDataItem16);
        boolean boolean21 = fixedMillisecond1.equals((java.lang.Object) year6);
        java.lang.String str22 = fixedMillisecond1.toString();
        long long23 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str22.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 12L + "'", long23 == 12L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        long long5 = day3.getLastMillisecond();
        long long6 = day3.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546415999999L + "'", long5 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43466L + "'", long6 == 43466L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
        int int5 = spreadsheetDate4.getDayOfWeek();
        int int6 = spreadsheetDate4.getDayOfMonth();
        int int7 = spreadsheetDate4.getMonth();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(6, serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(12);
        int int16 = spreadsheetDate15.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths(3, serialDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getStart();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
        boolean boolean28 = spreadsheetDate22.equals((java.lang.Object) day26);
        boolean boolean29 = spreadsheetDate15.isInRange(serialDate19, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean31 = spreadsheetDate4.isInRange(serialDate13, (org.jfree.data.time.SerialDate) spreadsheetDate15, (int) (byte) -1);
        boolean boolean32 = spreadsheetDate1.isOnOrAfter(serialDate13);
        java.lang.String str33 = serialDate13.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "14-January-1900" + "'", str33.equals("14-January-1900"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        java.util.Date date7 = month5.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date2);
        try {
            org.jfree.data.time.SerialDate serialDate13 = serialDate11.getPreviousDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '#', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        java.lang.String str12 = day3.toString();
        long long13 = day3.getFirstMillisecond();
        long long14 = day3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1-January-2019" + "'", str12.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-61851744000000L));
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61851744000000L) + "'", long4 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year46);
        java.lang.String str48 = year46.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10" + "'", str48.equals("10"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long5 = fixedMillisecond4.getSerialIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        java.lang.Class<?> wildcardClass9 = timeSeriesDataItem8.getClass();
        boolean boolean10 = fixedMillisecond4.equals((java.lang.Object) wildcardClass9);
        boolean boolean11 = fixedMillisecond1.equals((java.lang.Object) wildcardClass9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1));
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries13.removeChangeListener(seriesChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year16.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (double) 9223372036854775807L);
        timeSeries13.removeAgedItems((long) 30, false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        timeSeries9.setMaximumItemAge((long) (short) 100);
        java.util.Collection collection19 = timeSeries9.getTimePeriods();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        int int37 = timeSeries29.getMaximumItemCount();
        java.lang.Object obj38 = timeSeries29.clone();
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        try {
            org.jfree.data.time.TimeSeries timeSeries42 = timeSeries29.createCopy((int) (byte) 100, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2147483647 + "'", int37 == 2147483647);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(collection39);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) (-1.0f));
        java.lang.Class<?> wildcardClass11 = timeSeriesDataItem10.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date7, (java.lang.Class) wildcardClass11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date16 = month15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone21);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date2, timeZone21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 31);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod23);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        boolean boolean19 = timeSeries9.getNotify();
        java.lang.String str20 = timeSeries9.getDomainDescription();
        timeSeries9.setDomainDescription("January");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 100.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        int int4 = year0.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(3, serialDate7);
        boolean boolean9 = spreadsheetDate4.isBefore(serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears(12, serialDate7);
        boolean boolean11 = spreadsheetDate1.isOn(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(12);
        int int14 = spreadsheetDate13.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(3, serialDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.previous();
        boolean boolean26 = spreadsheetDate20.equals((java.lang.Object) day24);
        boolean boolean27 = spreadsheetDate13.isInRange(serialDate17, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears(6, serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getFollowingDayOfWeek(1);
        java.lang.String str34 = serialDate30.toString();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        boolean boolean37 = spreadsheetDate20.isInRange(serialDate30, serialDate36);
        boolean boolean38 = spreadsheetDate1.isOnOrBefore(serialDate30);
        serialDate30.setDescription("April");
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "9-January-1900" + "'", str34.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(12);
        int int11 = spreadsheetDate10.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(3, serialDate16);
        boolean boolean18 = spreadsheetDate13.isBefore(serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date21 = spreadsheetDate20.toDate();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        java.util.Date date23 = year22.getStart();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23, timeZone24);
        int int27 = day25.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) (-1.0f));
        boolean boolean32 = timeSeriesDataItem30.equals((java.lang.Object) 5);
        int int33 = day25.compareTo((java.lang.Object) timeSeriesDataItem30);
        boolean boolean34 = spreadsheetDate20.equals((java.lang.Object) int33);
        boolean boolean35 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int36 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        int int37 = spreadsheetDate20.toSerial();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long41 = month40.getFirstMillisecond();
        java.util.Date date42 = month40.getEnd();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year43, (double) (-1.0f));
        java.lang.Class<?> wildcardClass46 = timeSeriesDataItem45.getClass();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date42, (java.lang.Class) wildcardClass46);
        int int48 = timeSeries47.getMaximumItemCount();
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addYears(6, serialDate51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(serialDate51);
        timeSeries47.setKey((java.lang.Comparable) serialDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addMonths(3, serialDate62);
        boolean boolean64 = spreadsheetDate59.isBefore(serialDate62);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addYears(12, serialDate62);
        boolean boolean66 = spreadsheetDate56.isOn(serialDate65);
        org.jfree.data.time.SerialDate serialDate67 = serialDate51.getEndOfCurrentMonth(serialDate65);
        boolean boolean68 = spreadsheetDate20.isOn(serialDate51);
        boolean boolean69 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        try {
            org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1900, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 12 + "'", int37 == 12);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61851744000000L) + "'", long41 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2147483647 + "'", int48 == 2147483647);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        java.lang.String str7 = year6.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries1.setMaximumItemCount(1900);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(9, 0);
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month6);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries1.getDataItem((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        java.lang.String str11 = serialDate7.toString();
        int int12 = spreadsheetDate1.compareTo((java.lang.Object) serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        boolean boolean15 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate16 = null;
        try {
            boolean boolean17 = spreadsheetDate1.isOn(serialDate16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean4 = month2.equals((java.lang.Object) year3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year3);
        java.lang.String str6 = seriesChangeEvent5.toString();
        java.lang.String str7 = seriesChangeEvent5.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        int int7 = year6.getYear();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("January 10");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        int int38 = timeSeries9.getMaximumItemCount();
        java.lang.String str39 = timeSeries9.getDescription();
        timeSeries9.setRangeDescription("1-January-2019");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2147483647 + "'", int38 == 2147483647);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
    }
}

