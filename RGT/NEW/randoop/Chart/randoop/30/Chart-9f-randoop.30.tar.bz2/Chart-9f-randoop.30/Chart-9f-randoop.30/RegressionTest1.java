import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        long long6 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date7 = spreadsheetDate6.toDate();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long11 = month10.getFirstMillisecond();
        java.util.Date date12 = month10.getEnd();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date7, timeZone13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date4, timeZone13);
        java.lang.Class class17 = null;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long21 = month20.getFirstMillisecond();
        java.util.Date date22 = month20.getEnd();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22, timeZone23);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long28 = month27.getFirstMillisecond();
        java.util.Date date29 = month27.getEnd();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date29, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date22, timeZone30);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date4, timeZone30);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61851744000000L) + "'", long11 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61851744000000L) + "'", long21 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-61851744000000L) + "'", long28 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod32);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.next();
        long long8 = day3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.lang.String str5 = year0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(12);
        int int13 = spreadsheetDate12.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(3, serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        boolean boolean25 = spreadsheetDate19.equals((java.lang.Object) day23);
        boolean boolean26 = spreadsheetDate12.isInRange(serialDate16, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean28 = spreadsheetDate1.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate12, (int) (byte) -1);
        java.lang.String str29 = spreadsheetDate1.toString();
        int int30 = spreadsheetDate1.getDayOfMonth();
        int int31 = spreadsheetDate1.getMonth();
        int int32 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "11-January-1900" + "'", str29.equals("11-January-1900"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1900 + "'", int32 == 1900);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Class<?> wildcardClass3 = timeSeriesDataItem2.getClass();
        java.lang.Object obj4 = timeSeriesDataItem2.clone();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
        long long9 = day8.getFirstMillisecond();
        long long10 = day8.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.next();
        boolean boolean12 = timeSeriesDataItem2.equals((java.lang.Object) regularTimePeriod11);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date16 = month15.getEnd();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date16);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date33 = month32.getEnd();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date33);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date33);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.util.Date date37 = year36.getStart();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date33, timeZone38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date43 = spreadsheetDate42.toDate();
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long47 = month46.getFirstMillisecond();
        java.util.Date date48 = month46.getEnd();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date48, timeZone49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date43, timeZone49);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date33, timeZone49);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date16, timeZone49);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date16);
        boolean boolean55 = timeSeriesDataItem2.equals((java.lang.Object) date16);
        int int57 = timeSeriesDataItem2.compareTo((java.lang.Object) "9-January-1900");
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546415999999L + "'", long10 == 1546415999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61851744000000L) + "'", long47 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day3.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date9 = month8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 1546415999999L);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long16 = month15.getFirstMillisecond();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (double) (-1.0f));
        java.lang.Class<?> wildcardClass21 = timeSeriesDataItem20.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date17, (java.lang.Class) wildcardClass21);
        int int23 = timeSeries22.getMaximumItemCount();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date27 = month26.getEnd();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) month28);
        int int30 = timeSeries22.getMaximumItemCount();
        java.lang.Object obj31 = timeSeries22.clone();
        java.lang.Comparable comparable32 = timeSeries22.getKey();
        long long33 = timeSeries22.getMaximumItemAge();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long37 = month36.getFirstMillisecond();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (double) (-1.0f));
        java.lang.Class<?> wildcardClass42 = timeSeriesDataItem41.getClass();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date38, (java.lang.Class) wildcardClass42);
        int int44 = timeSeries43.getMaximumItemCount();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date48 = month47.getEnd();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries43.getDataItem((org.jfree.data.time.RegularTimePeriod) month49);
        int int51 = timeSeries43.getMaximumItemCount();
        timeSeries43.setDescription("");
        java.lang.String str54 = timeSeries43.getDomainDescription();
        java.util.Collection collection55 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries43);
        boolean boolean56 = timeSeriesDataItem12.equals((java.lang.Object) timeSeries43);
        boolean boolean57 = month2.equals((java.lang.Object) timeSeriesDataItem12);
        int int58 = month2.getMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851744000000L) + "'", long16 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(comparable32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61851744000000L) + "'", long37 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2147483647 + "'", int44 == 2147483647);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2147483647 + "'", int51 == 2147483647);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Time" + "'", str54.equals("Time"));
        org.junit.Assert.assertNotNull(collection55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        java.util.Calendar calendar7 = null;
        try {
            year0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(12);
        int int13 = spreadsheetDate12.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(3, serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        boolean boolean25 = spreadsheetDate19.equals((java.lang.Object) day23);
        boolean boolean26 = spreadsheetDate12.isInRange(serialDate16, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean28 = spreadsheetDate1.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate12, (int) (byte) -1);
        java.lang.String str29 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(12);
        int int32 = spreadsheetDate31.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths(3, serialDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getStart();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.previous();
        boolean boolean44 = spreadsheetDate38.equals((java.lang.Object) day42);
        boolean boolean45 = spreadsheetDate31.isInRange(serialDate35, (org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        java.util.Date date47 = year46.getStart();
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date47);
        java.lang.Class<?> wildcardClass49 = date47.getClass();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate38, (java.lang.Class) wildcardClass49);
        boolean boolean51 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        spreadsheetDate38.setDescription("January 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "11-January-1900" + "'", str29.equals("11-January-1900"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 5 + "'", int32 == 5);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        java.util.Date date1 = year0.getStart();
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
//        long long4 = day3.getFirstMillisecond();
//        int int5 = day3.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        int int7 = day3.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond6.getMiddleMillisecond(calendar8);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560193338217L + "'", long9 == 1560193338217L);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(3, serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        long long25 = day23.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) (short) -1);
        int int28 = timeSeries9.getItemCount();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43466L + "'", long25 == 43466L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 8);
        long long3 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61901769600000L) + "'", long3 == (-61901769600000L));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        long long18 = day17.getFirstMillisecond();
        int int19 = day17.getDayOfMonth();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day17.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.util.Date date26 = year25.getStart();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
        boolean boolean30 = spreadsheetDate24.equals((java.lang.Object) day28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(12);
        int int33 = spreadsheetDate32.getDayOfWeek();
        int int34 = spreadsheetDate32.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths(3, serialDate39);
        boolean boolean41 = spreadsheetDate36.isBefore(serialDate39);
        int int42 = spreadsheetDate32.compare(serialDate39);
        boolean boolean43 = spreadsheetDate24.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int44 = spreadsheetDate24.getYYYY();
        boolean boolean45 = day17.equals((java.lang.Object) spreadsheetDate24);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1900 + "'", int44 == 1900);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        long long5 = day3.getLastMillisecond();
        long long6 = day3.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        int int17 = timeSeries16.getMaximumItemCount();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date21 = month20.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) month22);
        long long24 = month22.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long24);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries25.addChangeListener(seriesChangeListener26);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries25.addChangeListener(seriesChangeListener28);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries31.setMaximumItemCount(1900);
        java.util.Collection collection34 = timeSeries31.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries25.addAndOrUpdate(timeSeries31);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2);
        java.util.Collection collection38 = timeSeries35.getTimePeriodsUniqueToOtherSeries(timeSeries37);
        int int39 = day3.compareTo((java.lang.Object) timeSeries35);
        java.util.Calendar calendar40 = null;
        try {
            day3.peg(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546415999999L + "'", long5 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546415999999L + "'", long6 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61850404800001L) + "'", long24 == (-61850404800001L));
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 1, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) (-1.0f));
        java.lang.Class<?> wildcardClass6 = timeSeriesDataItem5.getClass();
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) wildcardClass6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long14 = month13.getFirstMillisecond();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (-1.0f));
        java.lang.Class<?> wildcardClass19 = timeSeriesDataItem18.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date15, (java.lang.Class) wildcardClass19);
        int int21 = timeSeries20.getMaximumItemCount();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date25 = month24.getEnd();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) month26);
        boolean boolean29 = timeSeries20.equals((java.lang.Object) ' ');
        int int30 = fixedMillisecond1.compareTo((java.lang.Object) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 12L + "'", long9 == 12L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61851744000000L) + "'", long14 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(1, 13, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(6, serialDate6);
        boolean boolean8 = spreadsheetDate1.isAfter(serialDate6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6);
        int int10 = timeSeries9.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getMonth();
        long long5 = month2.getLastMillisecond();
        long long6 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61849065600001L) + "'", long5 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61849065600001L) + "'", long6 == (-61849065600001L));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(6, serialDate6);
        boolean boolean8 = spreadsheetDate1.isAfter(serialDate6);
        int int9 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries1.setMaximumItemCount(1900);
        long long4 = timeSeries1.getMaximumItemAge();
        try {
            timeSeries1.setMaximumItemAge((-61850404800001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(13, 100, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("ERROR : Relative To String");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2958465, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2958465");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1);
        java.lang.Number number6 = null;
        try {
            timeSeries4.update(2, number6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        java.lang.Class<?> wildcardClass14 = timeSeriesDataItem13.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date10, (java.lang.Class) wildcardClass14);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, class16);
        java.util.List list18 = timeSeries17.getItems();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 0.0f);
        timeSeries17.setKey((java.lang.Comparable) 0.0f);
        int int26 = timeSeries17.getMaximumItemCount();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(12);
        int int29 = spreadsheetDate28.getDayOfWeek();
        int int30 = spreadsheetDate28.getMonth();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate28);
        long long32 = timeSeries31.getMaximumItemAge();
        java.util.Collection collection33 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        timeSeries17.fireSeriesChanged();
        timeSeries17.setMaximumItemCount(9);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 5 + "'", int29 == 5);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 9223372036854775807L + "'", long32 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection33);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) (-1.0f));
        java.lang.Class<?> wildcardClass6 = timeSeriesDataItem5.getClass();
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) wildcardClass6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long11 = month10.getFirstMillisecond();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) (-1.0f));
        java.lang.Class<?> wildcardClass16 = timeSeriesDataItem15.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date12, (java.lang.Class) wildcardClass16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date21 = month20.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date21);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone26);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, (java.lang.Class) wildcardClass16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        java.util.Calendar calendar32 = null;
        fixedMillisecond30.peg(calendar32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61851744000000L) + "'", long11 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod28);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        long long7 = day3.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        serialDate9.setDescription("");
        int int12 = day3.compareTo((java.lang.Object) serialDate9);
        long long13 = day3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day3.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546415999999L + "'", long7 == 1546415999999L);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        int int10 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(3, serialDate15);
        boolean boolean17 = spreadsheetDate12.isBefore(serialDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date20 = spreadsheetDate19.toDate();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        int int26 = day24.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (double) (-1.0f));
        boolean boolean31 = timeSeriesDataItem29.equals((java.lang.Object) 5);
        int int32 = day24.compareTo((java.lang.Object) timeSeriesDataItem29);
        boolean boolean33 = spreadsheetDate19.equals((java.lang.Object) int32);
        boolean boolean34 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int35 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int36 = spreadsheetDate19.toSerial();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long40 = month39.getFirstMillisecond();
        java.util.Date date41 = month39.getEnd();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year42, (double) (-1.0f));
        java.lang.Class<?> wildcardClass45 = timeSeriesDataItem44.getClass();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date41, (java.lang.Class) wildcardClass45);
        int int47 = timeSeries46.getMaximumItemCount();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addYears(6, serialDate50);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate50);
        timeSeries46.setKey((java.lang.Comparable) serialDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addMonths(3, serialDate61);
        boolean boolean63 = spreadsheetDate58.isBefore(serialDate61);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addYears(12, serialDate61);
        boolean boolean65 = spreadsheetDate55.isOn(serialDate64);
        org.jfree.data.time.SerialDate serialDate66 = serialDate50.getEndOfCurrentMonth(serialDate64);
        boolean boolean67 = spreadsheetDate19.isOn(serialDate50);
        boolean boolean68 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.lang.String str69 = spreadsheetDate1.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 12 + "'", int36 == 12);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-61851744000000L) + "'", long40 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2147483647 + "'", int47 == 2147483647);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "11-January-1900" + "'", str69.equals("11-January-1900"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2958465);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(12);
        int int16 = spreadsheetDate15.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(3, serialDate21);
        boolean boolean23 = spreadsheetDate18.isBefore(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date26 = spreadsheetDate25.toDate();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
        int int32 = day30.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year33, (double) (-1.0f));
        boolean boolean37 = timeSeriesDataItem35.equals((java.lang.Object) 5);
        int int38 = day30.compareTo((java.lang.Object) timeSeriesDataItem35);
        boolean boolean39 = spreadsheetDate25.equals((java.lang.Object) int38);
        boolean boolean40 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int41 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean42 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean43 = day3.equals((java.lang.Object) spreadsheetDate15);
        java.util.Calendar calendar44 = null;
        try {
            long long45 = day3.getFirstMillisecond(calendar44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5 + "'", int16 == 5);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        boolean boolean9 = spreadsheetDate2.isAfter(serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(12);
        int int13 = spreadsheetDate12.getDayOfWeek();
        int int14 = spreadsheetDate12.getMonth();
        int int15 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int16 = spreadsheetDate12.getYYYY();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.addChangeListener(seriesChangeListener19);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries18.addChangeListener(seriesChangeListener21);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries24.setMaximumItemCount(1900);
        java.util.Collection collection27 = timeSeries24.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries18.addAndOrUpdate(timeSeries24);
        timeSeries18.setDomainDescription("1900");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(timeSeries28);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        java.lang.String str11 = serialDate7.toString();
        int int12 = spreadsheetDate1.compareTo((java.lang.Object) serialDate7);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long16 = month15.getFirstMillisecond();
        int int17 = month15.getMonth();
        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) month15);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        java.lang.Class<?> wildcardClass22 = timeSeriesDataItem21.getClass();
        java.lang.Object obj23 = timeSeriesDataItem21.clone();
        int int24 = month15.compareTo((java.lang.Object) timeSeriesDataItem21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int24);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries25.createCopy(3, 11);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (double) (-1.0f));
        long long32 = year29.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year29.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year29.next();
        timeSeries25.delete(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851744000000L) + "'", long16 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        java.lang.String str11 = serialDate7.toString();
        int int12 = spreadsheetDate1.compareTo((java.lang.Object) serialDate7);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long16 = month15.getFirstMillisecond();
        int int17 = month15.getMonth();
        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) month15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        int int21 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(3, serialDate26);
        boolean boolean28 = spreadsheetDate23.isBefore(serialDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date31 = spreadsheetDate30.toDate();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date33, timeZone34);
        int int37 = day35.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (double) (-1.0f));
        boolean boolean42 = timeSeriesDataItem40.equals((java.lang.Object) 5);
        int int43 = day35.compareTo((java.lang.Object) timeSeriesDataItem40);
        boolean boolean44 = spreadsheetDate30.equals((java.lang.Object) int43);
        boolean boolean45 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int46 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate20.getNearestDayOfWeek(1);
        boolean boolean49 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        try {
            org.jfree.data.time.SerialDate serialDate51 = spreadsheetDate20.getFollowingDayOfWeek(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851744000000L) + "'", long16 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.String str19 = timeSeries9.getDescription();
        timeSeries9.setMaximumItemCount(10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2958465);
        int int3 = spreadsheetDate2.getMonth();
        spreadsheetDate2.setDescription("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(12);
        int int9 = spreadsheetDate8.getDayOfWeek();
        int int10 = spreadsheetDate8.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears(6, serialDate13);
        boolean boolean15 = spreadsheetDate8.isAfter(serialDate13);
        int int16 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(12);
        int int20 = spreadsheetDate19.getDayOfWeek();
        int int21 = spreadsheetDate19.getDayOfMonth();
        int int22 = spreadsheetDate19.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addMonths(3, serialDate27);
        boolean boolean29 = spreadsheetDate24.isBefore(serialDate27);
        boolean boolean31 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, (org.jfree.data.time.SerialDate) spreadsheetDate24, 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(12);
        int int34 = spreadsheetDate33.getDayOfWeek();
        int int35 = spreadsheetDate33.getDayOfMonth();
        int int36 = spreadsheetDate33.getMonth();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addYears(6, serialDate39);
        org.jfree.data.time.SerialDate serialDate42 = serialDate39.getFollowingDayOfWeek(1);
        java.lang.String str43 = serialDate39.toString();
        int int44 = spreadsheetDate33.compareTo((java.lang.Object) serialDate39);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long48 = month47.getFirstMillisecond();
        int int49 = month47.getMonth();
        boolean boolean50 = spreadsheetDate33.equals((java.lang.Object) month47);
        boolean boolean51 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        try {
            org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addDays((-458), (org.jfree.data.time.SerialDate) spreadsheetDate19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 5 + "'", int34 == 5);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 11 + "'", int35 == 11);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "9-January-1900" + "'", str43.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61851744000000L) + "'", long48 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.util.List list4 = timeSeries1.getItems();
        java.lang.Object obj5 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
        int int4 = spreadsheetDate3.getDayOfWeek();
        int int5 = spreadsheetDate3.getDayOfMonth();
        int int6 = spreadsheetDate3.getMonth();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears(6, serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate9.getFollowingDayOfWeek(1);
        java.lang.String str13 = serialDate9.toString();
        int int14 = spreadsheetDate3.compareTo((java.lang.Object) serialDate9);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears(3, serialDate9);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays((int) (short) -1, serialDate9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "9-January-1900" + "'", str13.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day3.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546415999999L + "'", long5 == 1546415999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(9, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
        spreadsheetDate1.setDescription("11-January-1900");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        int int6 = spreadsheetDate5.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths(3, serialDate11);
        boolean boolean13 = spreadsheetDate8.isBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date16 = spreadsheetDate15.toDate();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getStart();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18, timeZone19);
        int int22 = day20.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) (-1.0f));
        boolean boolean27 = timeSeriesDataItem25.equals((java.lang.Object) 5);
        int int28 = day20.compareTo((java.lang.Object) timeSeriesDataItem25);
        boolean boolean29 = spreadsheetDate15.equals((java.lang.Object) int28);
        boolean boolean30 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int31 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int32 = spreadsheetDate15.toSerial();
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears(6, serialDate35);
        org.jfree.data.time.SerialDate serialDate38 = serialDate35.getFollowingDayOfWeek(1);
        java.lang.String str39 = serialDate35.toString();
        boolean boolean41 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, serialDate35, 9);
        java.lang.Class<?> wildcardClass42 = spreadsheetDate15.getClass();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "9-January-1900" + "'", str39.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries1.setMaximumItemCount(1900);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(9, 0);
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month6);
        long long8 = month6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9L + "'", long8 == 9L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(comparable10);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        int int10 = spreadsheetDate9.getDayOfWeek();
        int int11 = spreadsheetDate9.getDayOfMonth();
        int int12 = spreadsheetDate9.getMonth();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears(6, serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = serialDate15.getFollowingDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        int int21 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths(3, serialDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date29, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.previous();
        boolean boolean33 = spreadsheetDate27.equals((java.lang.Object) day31);
        boolean boolean34 = spreadsheetDate20.isInRange(serialDate24, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean36 = spreadsheetDate9.isInRange(serialDate18, (org.jfree.data.time.SerialDate) spreadsheetDate20, (int) (byte) -1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(12);
        int int39 = spreadsheetDate38.getDayOfWeek();
        int int40 = spreadsheetDate38.getDayOfMonth();
        int int41 = spreadsheetDate38.getMonth();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears(6, serialDate44);
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getFollowingDayOfWeek(1);
        java.lang.String str48 = serialDate44.toString();
        int int49 = spreadsheetDate38.compareTo((java.lang.Object) serialDate44);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long53 = month52.getFirstMillisecond();
        int int54 = month52.getMonth();
        boolean boolean55 = spreadsheetDate38.equals((java.lang.Object) month52);
        int int56 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int57 = day5.compareTo((java.lang.Object) spreadsheetDate38);
        int int58 = day5.getMonth();
        int int59 = day5.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day5.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 11 + "'", int40 == 11);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-January-1900" + "'", str48.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2 + "'", int49 == 2);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-61851744000000L) + "'", long53 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
        java.util.List list46 = timeSeries29.getItems();
        java.lang.Class class47 = timeSeries29.getTimePeriodClass();
        java.lang.Comparable comparable48 = timeSeries29.getKey();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(class47);
        org.junit.Assert.assertNotNull(comparable48);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a', "1900", "9-January-1900", class3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        long long7 = day3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546415999999L + "'", long7 == 1546415999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str17 = month15.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "January 10" + "'", str17.equals("January 10"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(3, serialDate4);
        boolean boolean6 = spreadsheetDate1.isBefore(serialDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        int int15 = day13.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (-1.0f));
        boolean boolean20 = timeSeriesDataItem18.equals((java.lang.Object) 5);
        int int21 = day13.compareTo((java.lang.Object) timeSeriesDataItem18);
        boolean boolean22 = spreadsheetDate8.equals((java.lang.Object) int21);
        boolean boolean23 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int24 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 11 + "'", int24 == 11);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long9 = month8.getFirstMillisecond();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year11, (double) (-1.0f));
        java.lang.Class<?> wildcardClass14 = timeSeriesDataItem13.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date10, (java.lang.Class) wildcardClass14);
        int int16 = timeSeries15.getMaximumItemCount();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date20 = month19.getEnd();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) month21);
        int int23 = timeSeries15.getMaximumItemCount();
        timeSeries15.setDescription("");
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long29 = month28.getFirstMillisecond();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) (-1.0f));
        java.lang.Class<?> wildcardClass34 = timeSeriesDataItem33.getClass();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date30, (java.lang.Class) wildcardClass34);
        int int36 = timeSeries35.getMaximumItemCount();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        boolean boolean41 = month39.equals((java.lang.Object) year40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) month39);
        timeSeries35.setMaximumItemCount(0);
        java.util.Collection collection45 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries35);
        java.lang.Class<?> wildcardClass46 = collection45.getClass();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int3, "Value", "Wed Dec 31 16:00:00 PST 1969", (java.lang.Class) wildcardClass46);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61851744000000L) + "'", long29 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2147483647 + "'", int36 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertNotNull(collection45);
        org.junit.Assert.assertNotNull(wildcardClass46);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        int int4 = month2.getMonth();
        java.lang.String str5 = month2.toString();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        java.lang.Class<?> wildcardClass9 = timeSeriesDataItem8.getClass();
        java.lang.Object obj10 = timeSeriesDataItem8.clone();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date12, timeZone13);
        long long15 = day14.getFirstMillisecond();
        long long16 = day14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day14.next();
        boolean boolean18 = timeSeriesDataItem8.equals((java.lang.Object) regularTimePeriod17);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date22 = month21.getEnd();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date22);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long29 = month28.getFirstMillisecond();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) (-1.0f));
        java.lang.Class<?> wildcardClass34 = timeSeriesDataItem33.getClass();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date30, (java.lang.Class) wildcardClass34);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date39 = month38.getEnd();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date39);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        java.util.Date date43 = year42.getStart();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date43, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date39, timeZone44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date49 = spreadsheetDate48.toDate();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long53 = month52.getFirstMillisecond();
        java.util.Date date54 = month52.getEnd();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date54, timeZone55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date49, timeZone55);
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date39, timeZone55);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date22, timeZone55);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date22);
        boolean boolean61 = timeSeriesDataItem8.equals((java.lang.Object) date22);
        boolean boolean62 = month2.equals((java.lang.Object) boolean61);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January 10" + "'", str5.equals("January 10"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546415999999L + "'", long16 == 1546415999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61851744000000L) + "'", long29 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-61851744000000L) + "'", long53 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        long long18 = day17.getFirstMillisecond();
        int int19 = day17.getDayOfMonth();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (-1));
        int int22 = timeSeries12.getItemCount();
        boolean boolean23 = timeSeries12.getNotify();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        timeSeries18.setMaximumItemCount(100);
        java.lang.String str21 = timeSeries18.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        long long19 = timeSeries18.getMaximumItemAge();
        timeSeries18.setMaximumItemCount(8);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears(6, serialDate24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate24);
        try {
            timeSeries18.update((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("11-January-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        java.lang.String str12 = day3.toString();
        long long13 = day3.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(3, serialDate18);
        boolean boolean20 = spreadsheetDate15.isBefore(serialDate18);
        int int21 = day3.compareTo((java.lang.Object) spreadsheetDate15);
        java.lang.String str22 = spreadsheetDate15.getDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1-January-2019" + "'", str12.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long15 = month14.getFirstMillisecond();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem19.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date16, (java.lang.Class) wildcardClass20);
        int int22 = timeSeries21.getMaximumItemCount();
        int int23 = day3.compareTo((java.lang.Object) int22);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = day3.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61851744000000L) + "'", long15 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        java.lang.Class<?> wildcardClass9 = timeSeriesDataItem8.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5, (java.lang.Class) wildcardClass9);
        int int11 = timeSeries10.getMaximumItemCount();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date15 = month14.getEnd();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month16);
        boolean boolean19 = timeSeries10.equals((java.lang.Object) ' ');
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year20.previous();
        long long24 = year20.getLastMillisecond();
        java.lang.Number number25 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year20.previous();
        try {
            org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(0, year20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61851744000000L) + "'", long4 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        int int3 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        long long5 = day3.getLastMillisecond();
        int int6 = day3.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546415999999L + "'", long5 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        long long10 = day6.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        serialDate12.setDescription("");
        int int15 = day6.compareTo((java.lang.Object) serialDate12);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore(serialDate12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546415999999L + "'", long10 == 1546415999999L);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 2147483647, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getDayOfMonth();
        int int5 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(6, serialDate8);
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getFollowingDayOfWeek(1);
        java.lang.String str12 = serialDate8.toString();
        int int13 = spreadsheetDate2.compareTo((java.lang.Object) serialDate8);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(11, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate2.getNearestDayOfWeek(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 11 + "'", int4 == 11);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        int int12 = day3.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day3.next();
        boolean boolean15 = day3.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-61851744000000L));
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61851744000000L) + "'", long4 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61851744000000L) + "'", long5 == (-61851744000000L));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.lang.String str3 = month2.toString();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 10" + "'", str3.equals("January 10"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str17 = timeSeries9.getDomainDescription();
        java.lang.String str18 = timeSeries9.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond20.next();
        long long22 = fixedMillisecond20.getSerialIndex();
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond20.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 12L + "'", long22 == 12L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.util.Collection collection18 = timeSeries9.getTimePeriods();
        java.lang.String str19 = timeSeries9.getRangeDescription();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date23 = month22.getEnd();
        long long24 = month22.getLastMillisecond();
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month22, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61849065600001L) + "'", long24 == (-61849065600001L));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, class17);
        timeSeries18.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(12);
        int int9 = spreadsheetDate8.getDayOfWeek();
        int int10 = spreadsheetDate8.getDayOfMonth();
        int int11 = spreadsheetDate8.getMonth();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears(6, serialDate14);
        org.jfree.data.time.SerialDate serialDate17 = serialDate14.getFollowingDayOfWeek(1);
        java.lang.String str18 = serialDate14.toString();
        int int19 = spreadsheetDate8.compareTo((java.lang.Object) serialDate14);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths(11, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int21 = spreadsheetDate8.getDayOfMonth();
        int int22 = fixedMillisecond1.compareTo((java.lang.Object) spreadsheetDate8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 11 + "'", int10 == 11);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "9-January-1900" + "'", str18.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.addChangeListener(seriesChangeListener19);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries18.addChangeListener(seriesChangeListener21);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries24.setMaximumItemCount(1900);
        java.util.Collection collection27 = timeSeries24.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries18.addAndOrUpdate(timeSeries24);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2);
        java.util.Collection collection31 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        java.lang.Object obj32 = timeSeries28.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.util.Date date36 = year35.getStart();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.previous();
        boolean boolean40 = spreadsheetDate34.equals((java.lang.Object) day38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(12);
        int int43 = spreadsheetDate42.getDayOfWeek();
        int int44 = spreadsheetDate42.getDayOfMonth();
        int int45 = spreadsheetDate42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addYears(6, serialDate48);
        org.jfree.data.time.SerialDate serialDate51 = serialDate48.getFollowingDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(12);
        int int54 = spreadsheetDate53.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addMonths(3, serialDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        java.util.Date date62 = year61.getStart();
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date62, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = day64.previous();
        boolean boolean66 = spreadsheetDate60.equals((java.lang.Object) day64);
        boolean boolean67 = spreadsheetDate53.isInRange(serialDate57, (org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean69 = spreadsheetDate42.isInRange(serialDate51, (org.jfree.data.time.SerialDate) spreadsheetDate53, (int) (byte) -1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(12);
        int int72 = spreadsheetDate71.getDayOfWeek();
        int int73 = spreadsheetDate71.getDayOfMonth();
        int int74 = spreadsheetDate71.getMonth();
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addYears(6, serialDate77);
        org.jfree.data.time.SerialDate serialDate80 = serialDate77.getFollowingDayOfWeek(1);
        java.lang.String str81 = serialDate77.toString();
        int int82 = spreadsheetDate71.compareTo((java.lang.Object) serialDate77);
        org.jfree.data.time.Month month85 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long86 = month85.getFirstMillisecond();
        int int87 = month85.getMonth();
        boolean boolean88 = spreadsheetDate71.equals((java.lang.Object) month85);
        int int89 = spreadsheetDate53.compare((org.jfree.data.time.SerialDate) spreadsheetDate71);
        int int90 = day38.compareTo((java.lang.Object) spreadsheetDate71);
        int int91 = day38.getMonth();
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) day38, (double) (-1), true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 5 + "'", int43 == 5);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 11 + "'", int44 == 11);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 5 + "'", int54 == 5);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 5 + "'", int72 == 5);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 11 + "'", int73 == 11);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "9-January-1900" + "'", str81.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 2 + "'", int82 == 2);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + (-61851744000000L) + "'", long86 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 1 + "'", int90 == 1);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1 + "'", int91 == 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        boolean boolean2 = timeSeries1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timeSeries1.removeChangeListener(seriesChangeListener3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
        java.util.List list46 = timeSeries29.getItems();
        try {
            timeSeries29.update(0, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(list46);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.addChangeListener(seriesChangeListener19);
        try {
            timeSeries18.delete(4, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Class<?> wildcardClass3 = timeSeriesDataItem2.getClass();
        timeSeriesDataItem2.setValue((java.lang.Number) (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long15 = month14.getFirstMillisecond();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        java.lang.Class<?> wildcardClass20 = timeSeriesDataItem19.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date16, (java.lang.Class) wildcardClass20);
        int int22 = timeSeries21.getMaximumItemCount();
        int int23 = day3.compareTo((java.lang.Object) int22);
        long long24 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) 1900L);
        java.util.Calendar calendar27 = null;
        try {
            long long28 = day3.getFirstMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61851744000000L) + "'", long15 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 43466L + "'", long24 == 43466L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        java.util.Date date6 = year0.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths(3, serialDate9);
        boolean boolean11 = spreadsheetDate6.isBefore(serialDate9);
        int int12 = spreadsheetDate2.compare(serialDate9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(4, serialDate9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        long long6 = day3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        int int37 = timeSeries29.getMaximumItemCount();
        java.lang.Object obj38 = timeSeries29.clone();
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries29.clear();
        java.lang.Comparable comparable41 = timeSeries29.getKey();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2147483647 + "'", int37 == 2147483647);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(comparable41);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(6, serialDate6);
        boolean boolean8 = spreadsheetDate1.isAfter(serialDate6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(5, 8, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date13 = month12.getEnd();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone18);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long24 = month23.getFirstMillisecond();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        java.lang.Class<?> wildcardClass29 = timeSeriesDataItem28.getClass();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date25, (java.lang.Class) wildcardClass29);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date34);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        java.util.Date date38 = year37.getStart();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date34, timeZone39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date13, timeZone39);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date13);
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date13, "1-January-2019", "org.jfree.data.general.SeriesChangeEvent[source=Fri Jan 31 23:59:59 PST 10]", class46);
        java.lang.String str48 = timeSeries47.getDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61851744000000L) + "'", long24 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNull(str48);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) (-1.0f));
        java.lang.Class<?> wildcardClass6 = timeSeriesDataItem5.getClass();
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) wildcardClass6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long11 = month10.getFirstMillisecond();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) (-1.0f));
        java.lang.Class<?> wildcardClass16 = timeSeriesDataItem15.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date12, (java.lang.Class) wildcardClass16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date21 = month20.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date21);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone26);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, (java.lang.Class) wildcardClass16);
        java.lang.String str30 = timeSeries29.getDescription();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61851744000000L) + "'", long11 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2958465);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        java.lang.String str6 = year0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "Following", class17);
        java.lang.Comparable comparable19 = timeSeries18.getKey();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date22 = spreadsheetDate21.toDate();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long26 = month25.getFirstMillisecond();
        java.util.Date date27 = month25.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date22, timeZone28);
        int int31 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date33, timeZone34);
        int int37 = day35.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (double) (-1.0f));
        boolean boolean42 = timeSeriesDataItem40.equals((java.lang.Object) 5);
        int int43 = day35.compareTo((java.lang.Object) timeSeriesDataItem40);
        int int44 = day35.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 7);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long50 = month49.getFirstMillisecond();
        java.util.Date date51 = month49.getEnd();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year52, (double) (-1.0f));
        java.lang.Class<?> wildcardClass55 = timeSeriesDataItem54.getClass();
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date51, (java.lang.Class) wildcardClass55);
        int int57 = timeSeries56.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timeSeries56.removePropertyChangeListener(propertyChangeListener58);
        java.lang.Comparable comparable60 = timeSeries56.getKey();
        timeSeries56.setDescription("");
        java.util.Collection collection63 = timeSeries18.getTimePeriodsUniqueToOtherSeries(timeSeries56);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61851744000000L) + "'", long26 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61851744000000L) + "'", long50 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2147483647 + "'", int57 == 2147483647);
        org.junit.Assert.assertNotNull(comparable60);
        org.junit.Assert.assertNotNull(collection63);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long7 = month6.getFirstMillisecond();
        java.util.Date date8 = month6.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date3, timeZone9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, year11);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851744000000L) + "'", long7 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(3, serialDate5);
        boolean boolean7 = spreadsheetDate2.isBefore(serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date10 = spreadsheetDate9.toDate();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        java.util.Date date12 = year11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date12, timeZone13);
        int int16 = day14.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (double) (-1.0f));
        boolean boolean21 = timeSeriesDataItem19.equals((java.lang.Object) 5);
        int int22 = day14.compareTo((java.lang.Object) timeSeriesDataItem19);
        boolean boolean23 = spreadsheetDate9.equals((java.lang.Object) int22);
        boolean boolean24 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears(6, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(12);
        int int28 = spreadsheetDate27.getDayOfWeek();
        int int29 = spreadsheetDate27.getMonth();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addYears(6, serialDate32);
        boolean boolean34 = spreadsheetDate27.isAfter(serialDate32);
        java.lang.String str35 = serialDate32.getDescription();
        boolean boolean36 = spreadsheetDate2.isAfter(serialDate32);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5 + "'", int28 == 5);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(3, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        boolean boolean14 = spreadsheetDate8.equals((java.lang.Object) day12);
        boolean boolean15 = spreadsheetDate1.isInRange(serialDate5, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(6, serialDate18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getFollowingDayOfWeek(1);
        java.lang.String str22 = serialDate18.toString();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        boolean boolean25 = spreadsheetDate8.isInRange(serialDate18, serialDate24);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long29 = month28.getFirstMillisecond();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year31, (double) (-1.0f));
        java.lang.Class<?> wildcardClass34 = timeSeriesDataItem33.getClass();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date30, (java.lang.Class) wildcardClass34);
        int int36 = timeSeries35.getMaximumItemCount();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date40 = month39.getEnd();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) month41);
        long long43 = month41.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long43);
        long long45 = timeSeries44.getMaximumItemAge();
        timeSeries44.clear();
        try {
            int int47 = spreadsheetDate8.compareTo((java.lang.Object) timeSeries44);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-January-1900" + "'", str22.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61851744000000L) + "'", long29 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2147483647 + "'", int36 == 2147483647);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-61850404800001L) + "'", long43 == (-61850404800001L));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-61851744000000L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        java.lang.String str12 = day3.toString();
        long long13 = day3.getFirstMillisecond();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(3, serialDate18);
        boolean boolean20 = spreadsheetDate15.isBefore(serialDate18);
        int int21 = day3.compareTo((java.lang.Object) spreadsheetDate15);
        int int22 = day3.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1-January-2019" + "'", str12.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        java.lang.Class<?> wildcardClass19 = timeSeries18.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 12);
        java.util.Date date22 = fixedMillisecond21.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long25 = fixedMillisecond24.getSerialIndex();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        java.lang.Class<?> wildcardClass29 = timeSeriesDataItem28.getClass();
        boolean boolean30 = fixedMillisecond24.equals((java.lang.Object) wildcardClass29);
        boolean boolean31 = fixedMillisecond21.equals((java.lang.Object) wildcardClass29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, 0.0d);
        try {
            timeSeries18.add(timeSeriesDataItem33);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 12L + "'", long25 == 12L);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
        long long46 = day44.getFirstMillisecond();
        java.util.Calendar calendar47 = null;
        try {
            long long48 = day44.getLastMillisecond(calendar47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-2208268800000L) + "'", long46 == (-2208268800000L));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.lang.String str3 = month2.toString();
        java.lang.Object obj4 = null;
        int int5 = month2.compareTo(obj4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        int int8 = month2.compareTo((java.lang.Object) serialDate7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 10" + "'", str3.equals("January 10"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.lang.String str3 = month2.toString();
        int int4 = month2.getYearValue();
        java.lang.String str5 = month2.toString();
        try {
            org.jfree.data.time.Year year6 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 10" + "'", str3.equals("January 10"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January 10" + "'", str5.equals("January 10"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean4 = month2.equals((java.lang.Object) year3);
        int int5 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertNull(regularTimePeriod6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long4 = month3.getFirstMillisecond();
        java.util.Date date5 = month3.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        java.lang.Class<?> wildcardClass9 = timeSeriesDataItem8.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date5, (java.lang.Class) wildcardClass9);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getStart();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone19);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long25 = month24.getFirstMillisecond();
        java.util.Date date26 = month24.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year27, (double) (-1.0f));
        java.lang.Class<?> wildcardClass30 = timeSeriesDataItem29.getClass();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date26, (java.lang.Class) wildcardClass30);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date35 = month34.getEnd();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent37 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date35);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getStart();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date39, timeZone40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date35, timeZone40);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date14, timeZone40);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(8, year43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(12);
        int int48 = spreadsheetDate47.getDayOfWeek();
        int int49 = spreadsheetDate47.getDayOfMonth();
        int int50 = spreadsheetDate47.getMonth();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addYears(6, serialDate53);
        org.jfree.data.time.SerialDate serialDate56 = serialDate53.getFollowingDayOfWeek(1);
        java.lang.String str57 = serialDate53.toString();
        int int58 = spreadsheetDate47.compareTo((java.lang.Object) serialDate53);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long62 = month61.getFirstMillisecond();
        int int63 = month61.getMonth();
        boolean boolean64 = spreadsheetDate47.equals((java.lang.Object) month61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(12);
        int int67 = spreadsheetDate66.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addMonths(3, serialDate72);
        boolean boolean74 = spreadsheetDate69.isBefore(serialDate72);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date77 = spreadsheetDate76.toDate();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        java.util.Date date79 = year78.getStart();
        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date79, timeZone80);
        int int83 = day81.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year84, (double) (-1.0f));
        boolean boolean88 = timeSeriesDataItem86.equals((java.lang.Object) 5);
        int int89 = day81.compareTo((java.lang.Object) timeSeriesDataItem86);
        boolean boolean90 = spreadsheetDate76.equals((java.lang.Object) int89);
        boolean boolean91 = spreadsheetDate69.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int92 = spreadsheetDate66.compare((org.jfree.data.time.SerialDate) spreadsheetDate76);
        org.jfree.data.time.SerialDate serialDate94 = spreadsheetDate66.getNearestDayOfWeek(1);
        boolean boolean95 = spreadsheetDate47.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate66);
        int int96 = spreadsheetDate66.getYYYY();
        org.jfree.data.time.SerialDate serialDate97 = org.jfree.data.time.SerialDate.addDays((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate66);
        int int98 = year43.compareTo((java.lang.Object) 'a');
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61851744000000L) + "'", long4 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61851744000000L) + "'", long25 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 5 + "'", int48 == 5);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 11 + "'", int49 == 11);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "9-January-1900" + "'", str57.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2 + "'", int58 == 2);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-61851744000000L) + "'", long62 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 5 + "'", int67 == 5);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(timeZone80);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertNotNull(serialDate94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1900 + "'", int96 == 1900);
        org.junit.Assert.assertNotNull(serialDate97);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 1 + "'", int98 == 1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int4 = month2.compareTo((java.lang.Object) 2);
        java.lang.String str5 = month2.toString();
        java.lang.Class<?> wildcardClass6 = month2.getClass();
        java.util.Date date7 = null;
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long11 = month10.getFirstMillisecond();
        java.util.Date date12 = month10.getEnd();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12, timeZone13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date7, timeZone13);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January 10" + "'", str5.equals("January 10"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61851744000000L) + "'", long11 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(class16);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0, (int) (short) -1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (short) 100);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (-1.0f));
        boolean boolean18 = timeSeriesDataItem16.equals((java.lang.Object) 5);
        java.lang.Object obj19 = timeSeriesDataItem16.clone();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (double) (-1.0f));
        java.lang.Class<?> wildcardClass23 = timeSeriesDataItem22.getClass();
        boolean boolean24 = timeSeriesDataItem16.equals((java.lang.Object) timeSeriesDataItem22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeriesDataItem16.getPeriod();
        int int26 = timeSeriesDataItem13.compareTo((java.lang.Object) regularTimePeriod25);
        java.util.Date date27 = regularTimePeriod25.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date27);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        java.lang.String str17 = timeSeries9.getDomainDescription();
        java.lang.String str18 = timeSeries9.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond20.next();
        long long22 = fixedMillisecond20.getSerialIndex();
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        long long24 = fixedMillisecond20.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 12L + "'", long22 == 12L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 12L + "'", long24 == 12L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day5.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) (-1.0f));
        boolean boolean12 = timeSeriesDataItem10.equals((java.lang.Object) 5);
        int int13 = day5.compareTo((java.lang.Object) timeSeriesDataItem10);
        boolean boolean14 = year0.equals((java.lang.Object) timeSeriesDataItem10);
        timeSeriesDataItem10.setValue((java.lang.Number) (-61851744000000L));
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        boolean boolean4 = fixedMillisecond1.equals((java.lang.Object) 520764324);
        long long5 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        int int13 = day11.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (-1.0f));
        boolean boolean18 = timeSeriesDataItem16.equals((java.lang.Object) 5);
        int int19 = day11.compareTo((java.lang.Object) timeSeriesDataItem16);
        boolean boolean20 = year6.equals((java.lang.Object) timeSeriesDataItem16);
        boolean boolean21 = fixedMillisecond1.equals((java.lang.Object) year6);
        java.lang.String str22 = fixedMillisecond1.toString();
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond1.getLastMillisecond(calendar23);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str22.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 12L + "'", long24 == 12L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        long long6 = year0.getLastMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date10 = month9.getEnd();
        long long11 = month9.getLastMillisecond();
        boolean boolean12 = year0.equals((java.lang.Object) month9);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61849065600001L) + "'", long11 == (-61849065600001L));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(12);
        int int11 = spreadsheetDate10.getDayOfWeek();
        int int12 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(3, serialDate17);
        boolean boolean19 = spreadsheetDate14.isBefore(serialDate17);
        int int20 = spreadsheetDate10.compare(serialDate17);
        boolean boolean21 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int22 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(5, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
        org.junit.Assert.assertNotNull(serialDate23);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        int int7 = day5.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, (double) (-1.0f));
        boolean boolean12 = timeSeriesDataItem10.equals((java.lang.Object) 5);
        int int13 = day5.compareTo((java.lang.Object) timeSeriesDataItem10);
        boolean boolean14 = year0.equals((java.lang.Object) timeSeriesDataItem10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeriesDataItem10.getPeriod();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year46);
        java.util.List list48 = timeSeries9.getItems();
        boolean boolean49 = timeSeries9.getNotify();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        long long25 = day23.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day23.previous();
        long long29 = day23.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43466L + "'", long25 == 43466L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, class17);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.lang.String str22 = month21.toString();
        int int23 = month21.getYearValue();
        long long24 = month21.getFirstMillisecond();
        int int25 = year0.compareTo((java.lang.Object) month21);
        long long26 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "January 10" + "'", str22.equals("January 10"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61851744000000L) + "'", long24 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) (-1.0f));
        java.lang.Class<?> wildcardClass6 = timeSeriesDataItem5.getClass();
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) wildcardClass6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 12L + "'", long9 == 12L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 12L + "'", long12 == 12L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(3, serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        boolean boolean15 = spreadsheetDate9.equals((java.lang.Object) day13);
        boolean boolean16 = spreadsheetDate2.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears(6, serialDate19);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getFollowingDayOfWeek(1);
        java.lang.String str23 = serialDate19.toString();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        boolean boolean26 = spreadsheetDate9.isInRange(serialDate19, serialDate25);
        int int27 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-January-1900" + "'", str23.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5 + "'", int27 == 5);
        org.junit.Assert.assertNotNull(serialDate28);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date5 = month4.getEnd();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date5);
        try {
            int int9 = spreadsheetDate1.compareTo((java.lang.Object) date5);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year46);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
        timeSeries9.addChangeListener(seriesChangeListener48);
        boolean boolean50 = timeSeries9.getNotify();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
        int int2 = spreadsheetDate1.getMonth();
        int int3 = spreadsheetDate1.getDayOfWeek();
        try {
            org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getPreviousDayOfWeek((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "Following", class17);
        java.lang.Comparable comparable19 = timeSeries18.getKey();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date22 = spreadsheetDate21.toDate();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long26 = month25.getFirstMillisecond();
        java.util.Date date27 = month25.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date22, timeZone28);
        int int31 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date33, timeZone34);
        int int37 = day35.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (double) (-1.0f));
        boolean boolean42 = timeSeriesDataItem40.equals((java.lang.Object) 5);
        int int43 = day35.compareTo((java.lang.Object) timeSeriesDataItem40);
        int int44 = day35.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 7);
        java.lang.String str47 = timeSeries18.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
        timeSeries18.removeChangeListener(seriesChangeListener48);
        timeSeries18.setKey((java.lang.Comparable) "Following");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61851744000000L) + "'", long26 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNull(str47);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Year outside valid range.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        java.lang.Object obj11 = timeSeries9.clone();
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries9.createCopy((int) (short) 0, (int) '#');
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long18 = month17.getFirstMillisecond();
        java.util.Date date19 = month17.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (double) (-1.0f));
        java.lang.Class<?> wildcardClass23 = timeSeriesDataItem22.getClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date19, (java.lang.Class) wildcardClass23);
        int int25 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date29 = month28.getEnd();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) month30);
        int int32 = timeSeries24.getMaximumItemCount();
        java.util.Collection collection33 = timeSeries24.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries14.addAndOrUpdate(timeSeries24);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(timeSeries14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61851744000000L) + "'", long18 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2147483647 + "'", int32 == 2147483647);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        java.util.Date date7 = day3.getStart();
        long long8 = day3.getLastMillisecond();
        java.util.Date date9 = day3.getStart();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long13 = month12.getFirstMillisecond();
        java.util.Date date14 = month12.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) (-1.0f));
        java.lang.Class<?> wildcardClass18 = timeSeriesDataItem17.getClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date14, (java.lang.Class) wildcardClass18);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date23 = month22.getEnd();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getStart();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date23, timeZone28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date33 = spreadsheetDate32.toDate();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long37 = month36.getFirstMillisecond();
        java.util.Date date38 = month36.getEnd();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date38, timeZone39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date33, timeZone39);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date23, timeZone39);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date9, timeZone39);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546415999999L + "'", long8 == 1546415999999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61851744000000L) + "'", long13 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61851744000000L) + "'", long37 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) (-1.0f));
        java.lang.Class<?> wildcardClass6 = timeSeriesDataItem5.getClass();
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) wildcardClass6);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long11 = month10.getFirstMillisecond();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) (-1.0f));
        java.lang.Class<?> wildcardClass16 = timeSeriesDataItem15.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date12, (java.lang.Class) wildcardClass16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date21 = month20.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date21);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone26);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean7, (java.lang.Class) wildcardClass16);
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61851744000000L) + "'", long11 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(class30);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        long long4 = month2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61849065600001L) + "'", long4 == (-61849065600001L));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        java.util.Calendar calendar6 = null;
        try {
            month4.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "Following", class17);
        java.lang.Comparable comparable19 = timeSeries18.getKey();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date22 = spreadsheetDate21.toDate();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long26 = month25.getFirstMillisecond();
        java.util.Date date27 = month25.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date22, timeZone28);
        int int31 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date33, timeZone34);
        int int37 = day35.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (double) (-1.0f));
        boolean boolean42 = timeSeriesDataItem40.equals((java.lang.Object) 5);
        int int43 = day35.compareTo((java.lang.Object) timeSeriesDataItem40);
        int int44 = day35.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 7);
        java.util.Calendar calendar47 = null;
        try {
            long long48 = day35.getMiddleMillisecond(calendar47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61851744000000L) + "'", long26 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        int int5 = day3.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = day3.compareTo((java.lang.Object) fixedMillisecond6);
        long long8 = day3.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate9 = day3.getSerialDate();
        java.util.Calendar calendar10 = null;
        try {
            day3.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546415999999L + "'", long8 == 1546415999999L);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths(3, serialDate9);
        boolean boolean11 = spreadsheetDate6.isBefore(serialDate9);
        int int12 = spreadsheetDate2.compare(serialDate9);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(0, serialDate9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.lang.String str3 = month2.toString();
        java.lang.Object obj4 = null;
        int int5 = month2.compareTo(obj4);
        int int6 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 10" + "'", str3.equals("January 10"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.next();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date9 = month8.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 1546415999999L);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long16 = month15.getFirstMillisecond();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year18, (double) (-1.0f));
        java.lang.Class<?> wildcardClass21 = timeSeriesDataItem20.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date17, (java.lang.Class) wildcardClass21);
        int int23 = timeSeries22.getMaximumItemCount();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date27 = month26.getEnd();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries22.getDataItem((org.jfree.data.time.RegularTimePeriod) month28);
        int int30 = timeSeries22.getMaximumItemCount();
        java.lang.Object obj31 = timeSeries22.clone();
        java.lang.Comparable comparable32 = timeSeries22.getKey();
        long long33 = timeSeries22.getMaximumItemAge();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long37 = month36.getFirstMillisecond();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (double) (-1.0f));
        java.lang.Class<?> wildcardClass42 = timeSeriesDataItem41.getClass();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date38, (java.lang.Class) wildcardClass42);
        int int44 = timeSeries43.getMaximumItemCount();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date48 = month47.getEnd();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries43.getDataItem((org.jfree.data.time.RegularTimePeriod) month49);
        int int51 = timeSeries43.getMaximumItemCount();
        timeSeries43.setDescription("");
        java.lang.String str54 = timeSeries43.getDomainDescription();
        java.util.Collection collection55 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries43);
        boolean boolean56 = timeSeriesDataItem12.equals((java.lang.Object) timeSeries43);
        boolean boolean57 = month2.equals((java.lang.Object) timeSeriesDataItem12);
        long long58 = month2.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851744000000L) + "'", long16 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(comparable32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61851744000000L) + "'", long37 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2147483647 + "'", int44 == 2147483647);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2147483647 + "'", int51 == 2147483647);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Time" + "'", str54.equals("Time"));
        org.junit.Assert.assertNotNull(collection55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-61849065600001L) + "'", long58 == (-61849065600001L));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears(6, serialDate6);
        boolean boolean8 = spreadsheetDate1.isAfter(serialDate6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            timeSeries9.delete(regularTimePeriod12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        boolean boolean18 = timeSeries9.equals((java.lang.Object) ' ');
        int int19 = timeSeries9.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.Class<?> wildcardClass3 = date1.getClass();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date1);
        java.lang.String str5 = serialDate4.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1-January-2019" + "'", str5.equals("1-January-2019"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
        java.util.List list46 = timeSeries29.getItems();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(9, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = month49.previous();
        timeSeries29.setKey((java.lang.Comparable) regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(2958465);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(12);
        int int23 = spreadsheetDate22.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(3, serialDate28);
        boolean boolean30 = spreadsheetDate25.isBefore(serialDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date33 = spreadsheetDate32.toDate();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        java.util.Date date35 = year34.getStart();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date35, timeZone36);
        int int39 = day37.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year40, (double) (-1.0f));
        boolean boolean44 = timeSeriesDataItem42.equals((java.lang.Object) 5);
        int int45 = day37.compareTo((java.lang.Object) timeSeriesDataItem42);
        boolean boolean46 = spreadsheetDate32.equals((java.lang.Object) int45);
        boolean boolean47 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int48 = spreadsheetDate22.compare((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean49 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean50 = timeSeries9.equals((java.lang.Object) boolean49);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date13 = month12.getEnd();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone18);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long24 = month23.getFirstMillisecond();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        java.lang.Class<?> wildcardClass29 = timeSeriesDataItem28.getClass();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date25, (java.lang.Class) wildcardClass29);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date34);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        java.util.Date date38 = year37.getStart();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date34, timeZone39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date13, timeZone39);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date13);
        try {
            org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61851744000000L) + "'", long24 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod41);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        boolean boolean10 = month8.equals((java.lang.Object) year9);
        boolean boolean11 = year5.equals((java.lang.Object) month8);
        int int12 = day3.compareTo((java.lang.Object) boolean11);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43466L + "'", long4 == 43466L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.util.Date date21 = year20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        long long25 = day23.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) (short) -1);
        timeSeries9.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43466L + "'", long25 == 43466L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
        int int2 = spreadsheetDate1.getMonth();
        spreadsheetDate1.setDescription("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(12);
        int int8 = spreadsheetDate7.getDayOfWeek();
        int int9 = spreadsheetDate7.getMonth();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(6, serialDate12);
        boolean boolean14 = spreadsheetDate7.isAfter(serialDate12);
        int int15 = spreadsheetDate7.getYYYY();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(12);
        int int19 = spreadsheetDate18.getDayOfWeek();
        int int20 = spreadsheetDate18.getDayOfMonth();
        int int21 = spreadsheetDate18.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(3, serialDate26);
        boolean boolean28 = spreadsheetDate23.isBefore(serialDate26);
        boolean boolean30 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, (org.jfree.data.time.SerialDate) spreadsheetDate23, 11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(12);
        int int33 = spreadsheetDate32.getDayOfWeek();
        int int34 = spreadsheetDate32.getDayOfMonth();
        int int35 = spreadsheetDate32.getMonth();
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addYears(6, serialDate38);
        org.jfree.data.time.SerialDate serialDate41 = serialDate38.getFollowingDayOfWeek(1);
        java.lang.String str42 = serialDate38.toString();
        int int43 = spreadsheetDate32.compareTo((java.lang.Object) serialDate38);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long47 = month46.getFirstMillisecond();
        int int48 = month46.getMonth();
        boolean boolean49 = spreadsheetDate32.equals((java.lang.Object) month46);
        boolean boolean50 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int51 = spreadsheetDate18.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 11 + "'", int20 == 11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 11 + "'", int34 == 11);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-January-1900" + "'", str42.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61851744000000L) + "'", long47 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-61851744000000L));
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61851744000000L) + "'", long4 == (-61851744000000L));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        long long6 = year0.getFirstMillisecond();
        long long7 = year0.getSerialIndex();
        int int8 = year0.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.next();
        int int12 = year0.compareTo((java.lang.Object) fixedMillisecond10);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getDayOfMonth();
        int int5 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(6, serialDate8);
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getFollowingDayOfWeek(1);
        java.lang.String str12 = serialDate8.toString();
        int int13 = spreadsheetDate2.compareTo((java.lang.Object) serialDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(2);
        boolean boolean16 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(12);
        int int19 = spreadsheetDate18.getDayOfWeek();
        int int20 = spreadsheetDate18.getMonth();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears(6, serialDate23);
        boolean boolean25 = spreadsheetDate18.isAfter(serialDate23);
        int int26 = spreadsheetDate18.getYYYY();
        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        try {
            org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-458), (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 11 + "'", int4 == 11);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertNotNull(serialDate27);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int4 = month2.compareTo((java.lang.Object) 2);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date8 = month7.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date8);
        java.lang.Object obj11 = seriesChangeEvent10.getSource();
        int int12 = month2.compareTo(obj11);
        java.lang.String str13 = month2.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "January 10" + "'", str13.equals("January 10"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        java.util.Date date15 = year14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15, timeZone16);
        long long18 = day17.getFirstMillisecond();
        int int19 = day17.getDayOfMonth();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (-1));
        long long22 = day17.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(3, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        boolean boolean14 = spreadsheetDate8.equals((java.lang.Object) day12);
        boolean boolean15 = spreadsheetDate1.isInRange(serialDate5, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(6, serialDate18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getFollowingDayOfWeek(1);
        java.lang.String str22 = serialDate18.toString();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        boolean boolean25 = spreadsheetDate8.isInRange(serialDate18, serialDate24);
        try {
            org.jfree.data.time.SerialDate serialDate27 = serialDate24.getPreviousDayOfWeek(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-January-1900" + "'", str22.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        int int38 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long42 = month41.getFirstMillisecond();
        java.util.Date date43 = month41.getEnd();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, (double) (-1.0f));
        java.lang.Class<?> wildcardClass47 = timeSeriesDataItem46.getClass();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date43, (java.lang.Class) wildcardClass47);
        int int49 = timeSeries48.getMaximumItemCount();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date53 = month52.getEnd();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) month54);
        long long56 = month54.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries58 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) month54, regularTimePeriod57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2147483647 + "'", int38 == 2147483647);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-61851744000000L) + "'", long42 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2147483647 + "'", int49 == 2147483647);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-61850404800001L) + "'", long56 == (-61850404800001L));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        int int5 = day3.getDayOfMonth();
        long long6 = day3.getSerialIndex();
        java.util.Date date7 = day3.getStart();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long11 = month10.getFirstMillisecond();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) (-1.0f));
        java.lang.Class<?> wildcardClass16 = timeSeriesDataItem15.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date12, (java.lang.Class) wildcardClass16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date21 = month20.getEnd();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date21);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.util.Date date25 = year24.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone26);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date7, timeZone26);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43466L + "'", long6 == 43466L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61851744000000L) + "'", long11 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod28);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        boolean boolean15 = month13.equals((java.lang.Object) year14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries9.clear();
        timeSeries9.setDomainDescription("11-January-1900");
        java.lang.Class<?> wildcardClass20 = timeSeries9.getClass();
        timeSeries9.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "hi!", "Following", class17);
        java.lang.Comparable comparable19 = timeSeries18.getKey();
        timeSeries18.setMaximumItemCount(0);
        timeSeries18.setMaximumItemCount(2019);
        java.lang.Comparable comparable24 = timeSeries18.getKey();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(comparable24);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        boolean boolean18 = timeSeries9.isEmpty();
        timeSeries9.setDescription("April");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int25 = month23.compareTo((java.lang.Object) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month23.next();
        java.lang.Number number27 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        timeSeries9.setRangeDescription("14-January-1900");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(number27);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("14-January-1900");
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        int int37 = timeSeries29.getMaximumItemCount();
        java.lang.Object obj38 = timeSeries29.clone();
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries29.setNotify(false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2147483647 + "'", int37 == 2147483647);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(collection39);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        int int5 = day3.getDayOfMonth();
        long long6 = day3.getSerialIndex();
        long long7 = day3.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43466L + "'", long6 == 43466L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43466L + "'", long7 == 43466L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        boolean boolean4 = fixedMillisecond1.equals((java.lang.Object) 520764324);
        long long5 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.util.Date date9 = year8.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        int int13 = day11.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year14, (double) (-1.0f));
        boolean boolean18 = timeSeriesDataItem16.equals((java.lang.Object) 5);
        int int19 = day11.compareTo((java.lang.Object) timeSeriesDataItem16);
        boolean boolean20 = year6.equals((java.lang.Object) timeSeriesDataItem16);
        boolean boolean21 = fixedMillisecond1.equals((java.lang.Object) year6);
        long long22 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 12L + "'", long22 == 12L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year46);
        int int48 = timeSeries9.getItemCount();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        boolean boolean54 = month52.equals((java.lang.Object) year53);
        boolean boolean55 = year49.equals((java.lang.Object) month52);
        timeSeries9.setKey((java.lang.Comparable) month52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timePeriodFormatException9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        java.lang.String str6 = day3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1-January-2019" + "'", str6.equals("1-January-2019"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getDayOfMonth();
        int int5 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears(6, serialDate8);
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getFollowingDayOfWeek(1);
        java.lang.String str12 = serialDate8.toString();
        int int13 = spreadsheetDate2.compareTo((java.lang.Object) serialDate8);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(13, serialDate8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 11 + "'", int4 == 11);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Class<?> wildcardClass3 = timeSeriesDataItem2.getClass();
        java.lang.Object obj4 = timeSeriesDataItem2.clone();
        java.lang.Object obj5 = timeSeriesDataItem2.clone();
        timeSeriesDataItem2.setValue((java.lang.Number) (byte) -1);
        java.lang.Object obj8 = timeSeriesDataItem2.clone();
        java.lang.Number number9 = timeSeriesDataItem2.getValue();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (byte) -1 + "'", number9.equals((byte) -1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10, 5, 520764324);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, 8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) '4');
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long8 = month7.getFirstMillisecond();
        java.util.Date date9 = month7.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        java.lang.Class<?> wildcardClass13 = timeSeriesDataItem12.getClass();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date9, (java.lang.Class) wildcardClass13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        boolean boolean16 = timeSeriesDataItem4.equals((java.lang.Object) class15);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths(3, serialDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(12);
        int int24 = spreadsheetDate23.getDayOfWeek();
        int int25 = spreadsheetDate23.getMonth();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears(6, serialDate28);
        boolean boolean30 = spreadsheetDate23.isAfter(serialDate28);
        int int31 = spreadsheetDate23.getYYYY();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SerialDate serialDate33 = serialDate19.getEndOfCurrentMonth(serialDate32);
        int int34 = timeSeriesDataItem4.compareTo((java.lang.Object) serialDate32);
        try {
            org.jfree.data.time.SerialDate serialDate36 = serialDate32.getFollowingDayOfWeek(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61851744000000L) + "'", long8 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries9.setKey((java.lang.Comparable) (byte) 0);
        int int42 = timeSeries9.getItemCount();
        java.lang.String str43 = timeSeries9.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Value" + "'", str43.equals("Value"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year46);
        timeSeries9.setMaximumItemCount(100);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year50, (double) (-1.0f));
        java.lang.Class<?> wildcardClass53 = timeSeriesDataItem52.getClass();
        java.lang.Object obj54 = timeSeriesDataItem52.clone();
        java.lang.Object obj55 = timeSeriesDataItem52.clone();
        timeSeriesDataItem52.setValue((java.lang.Number) (byte) -1);
        try {
            timeSeries9.add(timeSeriesDataItem52, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertNotNull(obj55);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Class<?> wildcardClass3 = timeSeriesDataItem2.getClass();
        java.lang.Object obj4 = timeSeriesDataItem2.clone();
        boolean boolean6 = timeSeriesDataItem2.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem2.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries10.setMaximumItemCount(1900);
        java.util.Collection collection13 = timeSeries10.getTimePeriods();
        java.lang.Class class14 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class14);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, class14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getStart();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long22 = month21.getFirstMillisecond();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (double) (-1.0f));
        java.lang.Class<?> wildcardClass27 = timeSeriesDataItem26.getClass();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date23, (java.lang.Class) wildcardClass27);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date32 = month31.getEnd();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date32);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date32);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        java.util.Date date36 = year35.getStart();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date32, timeZone37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date42 = spreadsheetDate41.toDate();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long46 = month45.getFirstMillisecond();
        java.util.Date date47 = month45.getEnd();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47, timeZone48);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date42, timeZone48);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date32, timeZone48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date18, timeZone48);
        long long53 = regularTimePeriod52.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61851744000000L) + "'", long22 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-61851744000000L) + "'", long46 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1546372799999L + "'", long53 == 1546372799999L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date3);
        java.lang.String str6 = seriesChangeEvent5.toString();
        java.lang.Object obj7 = seriesChangeEvent5.getSource();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Fri Jan 31 23:59:59 PST 10]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=Fri Jan 31 23:59:59 PST 10]"));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.addChangeListener(seriesChangeListener19);
        timeSeries9.clear();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int26 = month24.compareTo((java.lang.Object) 2);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date30 = month29.getEnd();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date30);
        java.lang.Object obj33 = seriesChangeEvent32.getSource();
        int int34 = month24.compareTo(obj33);
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month24.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNull(regularTimePeriod36);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        boolean boolean18 = timeSeries9.isEmpty();
        timeSeries9.setDescription("April");
        timeSeries9.setRangeDescription("Following");
        try {
            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries9.createCopy((int) (short) -1, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) (-1.0f));
        java.lang.Class<?> wildcardClass6 = timeSeriesDataItem5.getClass();
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) wildcardClass6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date10 = spreadsheetDate9.toDate();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long14 = month13.getFirstMillisecond();
        java.util.Date date15 = month13.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15, timeZone16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date10, timeZone16);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year20, (double) (-1.0f));
        java.lang.Class<?> wildcardClass23 = timeSeriesDataItem22.getClass();
        java.lang.Object obj24 = timeSeriesDataItem22.clone();
        boolean boolean26 = timeSeriesDataItem22.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem22.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries30.setMaximumItemCount(1900);
        java.util.Collection collection33 = timeSeries30.getTimePeriods();
        java.lang.Class class34 = timeSeries30.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class34);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem22, class34);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        java.util.Date date38 = year37.getStart();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long42 = month41.getFirstMillisecond();
        java.util.Date date43 = month41.getEnd();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, (double) (-1.0f));
        java.lang.Class<?> wildcardClass47 = timeSeriesDataItem46.getClass();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date43, (java.lang.Class) wildcardClass47);
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date52 = month51.getEnd();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month(date52);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent54 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date52);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        java.util.Date date56 = year55.getStart();
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56, timeZone57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date52, timeZone57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date62 = spreadsheetDate61.toDate();
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long66 = month65.getFirstMillisecond();
        java.util.Date date67 = month65.getEnd();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date67, timeZone68);
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date62, timeZone68);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(date52, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date38, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone68);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
        java.util.Date date75 = year74.getStart();
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date75, timeZone76);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date10, timeZone76);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61851744000000L) + "'", long14 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(collection33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-61851744000000L) + "'", long42 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-61851744000000L) + "'", long66 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone76);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        int int5 = day3.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = day3.compareTo((java.lang.Object) fixedMillisecond6);
        long long8 = day3.getLastMillisecond();
        int int9 = day3.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546415999999L + "'", long8 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long7 = month6.getFirstMillisecond();
        java.util.Date date8 = month6.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) (-1.0f));
        java.lang.Class<?> wildcardClass12 = timeSeriesDataItem11.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date8, (java.lang.Class) wildcardClass12);
        int int14 = timeSeries13.getMaximumItemCount();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears(6, serialDate17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate17);
        timeSeries13.setKey((java.lang.Comparable) serialDate17);
        int int21 = year0.compareTo((java.lang.Object) timeSeries13);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851744000000L) + "'", long7 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.util.Collection collection18 = timeSeries9.getTimePeriods();
        java.lang.String str19 = timeSeries9.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries9.removeChangeListener(seriesChangeListener20);
        timeSeries9.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long5 = fixedMillisecond4.getSerialIndex();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        java.lang.Class<?> wildcardClass9 = timeSeriesDataItem8.getClass();
        boolean boolean10 = fixedMillisecond4.equals((java.lang.Object) wildcardClass9);
        boolean boolean11 = fixedMillisecond1.equals((java.lang.Object) wildcardClass9);
        long long12 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 12L + "'", long12 == 12L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        long long20 = timeSeries9.getMaximumItemAge();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long24 = month23.getFirstMillisecond();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        java.lang.Class<?> wildcardClass29 = timeSeriesDataItem28.getClass();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date25, (java.lang.Class) wildcardClass29);
        int int31 = timeSeries30.getMaximumItemCount();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date35 = month34.getEnd();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries30.getDataItem((org.jfree.data.time.RegularTimePeriod) month36);
        int int38 = timeSeries30.getMaximumItemCount();
        timeSeries30.setDescription("");
        java.lang.String str41 = timeSeries30.getDomainDescription();
        java.util.Collection collection42 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date46 = month45.getEnd();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date46);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent48 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date46);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date46);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long53 = month52.getFirstMillisecond();
        java.util.Date date54 = month52.getEnd();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year55, (double) (-1.0f));
        java.lang.Class<?> wildcardClass58 = timeSeriesDataItem57.getClass();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date54, (java.lang.Class) wildcardClass58);
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date63 = month62.getEnd();
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(date63);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date63);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        java.util.Date date67 = year66.getStart();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date67, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date63, timeZone68);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date73 = spreadsheetDate72.toDate();
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long77 = month76.getFirstMillisecond();
        java.util.Date date78 = month76.getEnd();
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date78, timeZone79);
        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year(date73, timeZone79);
        org.jfree.data.time.Month month82 = new org.jfree.data.time.Month(date63, timeZone79);
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date46, timeZone79);
        long long84 = year83.getFirstMillisecond();
        int int85 = year83.getYear();
        long long86 = year83.getFirstMillisecond();
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year83, (java.lang.Number) (byte) 100, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61851744000000L) + "'", long24 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2147483647 + "'", int31 == 2147483647);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2147483647 + "'", int38 == 2147483647);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Time" + "'", str41.equals("Time"));
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-61851744000000L) + "'", long53 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-61851744000000L) + "'", long77 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + (-61851744000000L) + "'", long84 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 10 + "'", int85 == 10);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + (-61851744000000L) + "'", long86 == (-61851744000000L));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long8 = month7.getFirstMillisecond();
        java.util.Date date9 = month7.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year10, (double) (-1.0f));
        java.lang.Class<?> wildcardClass13 = timeSeriesDataItem12.getClass();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date9, (java.lang.Class) wildcardClass13);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date18 = month17.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date18, timeZone23);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date3, timeZone23);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61851744000000L) + "'", long8 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod25);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        int int5 = day3.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = day3.compareTo((java.lang.Object) fixedMillisecond6);
        long long8 = day3.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate9 = day3.getSerialDate();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.previous();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long19 = month18.getFirstMillisecond();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (-1.0f));
        java.lang.Class<?> wildcardClass24 = timeSeriesDataItem23.getClass();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date20, (java.lang.Class) wildcardClass24);
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod15, class26);
        java.util.List list28 = timeSeries27.getItems();
        boolean boolean29 = day3.equals((java.lang.Object) timeSeries27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(12);
        int int33 = spreadsheetDate32.getDayOfWeek();
        int int34 = spreadsheetDate32.getDayOfMonth();
        int int35 = spreadsheetDate32.getMonth();
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addYears(6, serialDate38);
        org.jfree.data.time.SerialDate serialDate41 = serialDate38.getFollowingDayOfWeek(1);
        java.lang.String str42 = serialDate38.toString();
        int int43 = spreadsheetDate32.compareTo((java.lang.Object) serialDate38);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(11, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int45 = spreadsheetDate32.getDayOfMonth();
        int int46 = day3.compareTo((java.lang.Object) int45);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546415999999L + "'", long8 == 1546415999999L);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61851744000000L) + "'", long19 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 11 + "'", int34 == 11);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "9-January-1900" + "'", str42.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 11 + "'", int45 == 11);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        boolean boolean18 = timeSeries9.equals((java.lang.Object) ' ');
        java.lang.Comparable comparable19 = timeSeries9.getKey();
        boolean boolean20 = timeSeries9.isEmpty();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(9);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "September" + "'", str1.equals("September"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        timeSeries18.setMaximumItemCount(100);
        java.util.Collection collection21 = timeSeries18.getTimePeriods();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long25 = month24.getFirstMillisecond();
        java.util.Date date26 = month24.getEnd();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date26, timeZone27);
        long long29 = year28.getSerialIndex();
        timeSeries18.delete((org.jfree.data.time.RegularTimePeriod) year28);
        timeSeries18.setDomainDescription("11-January-1900");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61851744000000L) + "'", long25 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(3, serialDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        boolean boolean15 = spreadsheetDate9.equals((java.lang.Object) day13);
        boolean boolean16 = spreadsheetDate2.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears(6, serialDate19);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getFollowingDayOfWeek(1);
        java.lang.String str23 = serialDate19.toString();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        boolean boolean26 = spreadsheetDate9.isInRange(serialDate19, serialDate25);
        int int27 = spreadsheetDate9.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        boolean boolean31 = spreadsheetDate9.isOn(serialDate30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "9-January-1900" + "'", str23.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5 + "'", int27 == 5);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        long long19 = timeSeries18.getMaximumItemAge();
        timeSeries18.setMaximumItemCount(0);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (double) (-1.0f));
        boolean boolean26 = timeSeriesDataItem24.equals((java.lang.Object) 5);
        java.lang.Object obj27 = timeSeriesDataItem24.clone();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) (-1.0f));
        java.lang.Class<?> wildcardClass31 = timeSeriesDataItem30.getClass();
        boolean boolean32 = timeSeriesDataItem24.equals((java.lang.Object) timeSeriesDataItem30);
        boolean boolean33 = timeSeries18.equals((java.lang.Object) timeSeriesDataItem30);
        try {
            org.jfree.data.time.TimeSeries timeSeries36 = timeSeries18.createCopy((int) (short) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        java.lang.String str20 = timeSeries9.getDomainDescription();
        timeSeries9.clear();
        boolean boolean22 = timeSeries9.getNotify();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2958465);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
        int int4 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths(3, serialDate9);
        boolean boolean11 = spreadsheetDate6.isBefore(serialDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date14 = spreadsheetDate13.toDate();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        java.util.Date date16 = year15.getStart();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date16, timeZone17);
        int int20 = day18.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (-1.0f));
        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) 5);
        int int26 = day18.compareTo((java.lang.Object) timeSeriesDataItem23);
        boolean boolean27 = spreadsheetDate13.equals((java.lang.Object) int26);
        boolean boolean28 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int29 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean30 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(2958465);
        int int33 = spreadsheetDate32.getMonth();
        int int34 = spreadsheetDate32.getDayOfWeek();
        boolean boolean35 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        java.lang.Object obj36 = null;
        boolean boolean37 = spreadsheetDate32.equals(obj36);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        boolean boolean18 = timeSeries9.isEmpty();
        timeSeries9.setDescription("April");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int25 = month23.compareTo((java.lang.Object) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month23.next();
        java.lang.Number number27 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) month23);
        boolean boolean28 = timeSeries9.isEmpty();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        long long19 = timeSeries18.getMaximumItemAge();
        timeSeries18.setMaximumItemCount(0);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year22, (double) (-1.0f));
        boolean boolean26 = timeSeriesDataItem24.equals((java.lang.Object) 5);
        java.lang.Object obj27 = timeSeriesDataItem24.clone();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (double) (-1.0f));
        java.lang.Class<?> wildcardClass31 = timeSeriesDataItem30.getClass();
        boolean boolean32 = timeSeriesDataItem24.equals((java.lang.Object) timeSeriesDataItem30);
        boolean boolean33 = timeSeries18.equals((java.lang.Object) timeSeriesDataItem30);
        timeSeriesDataItem30.setValue((java.lang.Number) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        long long5 = day3.getLastMillisecond();
        long long6 = day3.getLastMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) (-1.0f));
        long long10 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.next();
        int int13 = day3.compareTo((java.lang.Object) regularTimePeriod12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546415999999L + "'", long5 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546415999999L + "'", long6 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("11-January-1900");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        java.lang.Comparable comparable11 = timeSeries9.getKey();
        int int12 = timeSeries9.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(comparable11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) 5);
        int int11 = day3.compareTo((java.lang.Object) timeSeriesDataItem8);
        int int12 = day3.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(12);
        int int15 = spreadsheetDate14.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(3, serialDate20);
        boolean boolean22 = spreadsheetDate17.isBefore(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date25 = spreadsheetDate24.toDate();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        java.util.Date date27 = year26.getStart();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27, timeZone28);
        int int31 = day29.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (double) (-1.0f));
        boolean boolean36 = timeSeriesDataItem34.equals((java.lang.Object) 5);
        int int37 = day29.compareTo((java.lang.Object) timeSeriesDataItem34);
        boolean boolean38 = spreadsheetDate24.equals((java.lang.Object) int37);
        boolean boolean39 = spreadsheetDate17.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int40 = spreadsheetDate14.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate14.getNearestDayOfWeek(1);
        boolean boolean43 = day3.equals((java.lang.Object) spreadsheetDate14);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        java.util.Date date7 = month5.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        long long12 = year10.getSerialIndex();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        java.util.Date date14 = year13.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day16.next();
        java.util.Date date20 = day16.getStart();
        long long21 = day16.getLastMillisecond();
        java.util.Date date22 = day16.getStart();
        boolean boolean23 = year10.equals((java.lang.Object) date22);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1900L + "'", long12 == 1900L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546415999999L + "'", long21 == 1546415999999L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        timeSeries18.setMaximumItemCount(100);
        java.util.Collection collection21 = timeSeries18.getTimePeriods();
        timeSeries18.setDomainDescription("1-January-2019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = null;
        try {
            timeSeries18.delete(regularTimePeriod24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertNotNull(collection21);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("First");
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.previous();
        boolean boolean8 = spreadsheetDate2.equals((java.lang.Object) day6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(12);
        int int11 = spreadsheetDate10.getDayOfWeek();
        int int12 = spreadsheetDate10.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(3, serialDate17);
        boolean boolean19 = spreadsheetDate14.isBefore(serialDate17);
        int int20 = spreadsheetDate10.compare(serialDate17);
        boolean boolean21 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate24);
        boolean boolean26 = spreadsheetDate2.isBefore(serialDate25);
        try {
            org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(13, serialDate25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(12);
        boolean boolean6 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int7 = spreadsheetDate5.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long10 = month9.getFirstMillisecond();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) (-1.0f));
        java.lang.Class<?> wildcardClass15 = timeSeriesDataItem14.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year0, class17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long21 = fixedMillisecond20.getSerialIndex();
        long long22 = fixedMillisecond20.getMiddleMillisecond();
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond20.getLastMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond20.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 1560193338217L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61851744000000L) + "'", long10 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 12L + "'", long21 == 12L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 12L + "'", long22 == 12L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 12L + "'", long24 == 12L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries1.setMaximumItemCount(1900);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries1.setMaximumItemAge((long) 9);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        boolean boolean16 = month14.equals((java.lang.Object) year15);
        int int17 = month14.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month14.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long21 = fixedMillisecond20.getSerialIndex();
        boolean boolean23 = fixedMillisecond20.equals((java.lang.Object) 520764324);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timeSeries24.removePropertyChangeListener(propertyChangeListener25);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 12L + "'", long21 == 12L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long14 = month13.getFirstMillisecond();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year16, (double) (-1.0f));
        java.lang.Class<?> wildcardClass19 = timeSeriesDataItem18.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date15, (java.lang.Class) wildcardClass19);
        int int21 = timeSeries20.getMaximumItemCount();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date25 = month24.getEnd();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) month26);
        int int28 = timeSeries20.getMaximumItemCount();
        timeSeries20.setDescription("");
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long34 = month33.getFirstMillisecond();
        java.util.Date date35 = month33.getEnd();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, (double) (-1.0f));
        java.lang.Class<?> wildcardClass39 = timeSeriesDataItem38.getClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date35, (java.lang.Class) wildcardClass39);
        int int41 = timeSeries40.getMaximumItemCount();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        boolean boolean46 = month44.equals((java.lang.Object) year45);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries40.getDataItem((org.jfree.data.time.RegularTimePeriod) month44);
        timeSeries40.setMaximumItemCount(0);
        java.util.Collection collection50 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date54 = month53.getEnd();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date54);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent56 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date54);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date54);
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) year57);
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year57, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61851744000000L) + "'", long14 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2147483647 + "'", int28 == 2147483647);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-61851744000000L) + "'", long34 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2147483647 + "'", int41 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(date54);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries1.setMaximumItemCount(1900);
        java.util.Collection collection4 = timeSeries1.getTimePeriods();
        java.lang.Class class5 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long8 = fixedMillisecond7.getSerialIndex();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond7.getMiddleMillisecond(calendar9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long13 = fixedMillisecond12.getSerialIndex();
        boolean boolean15 = fixedMillisecond12.equals((java.lang.Object) 520764324);
        long long16 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        java.util.Date date18 = year17.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        java.util.Date date20 = year19.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        int int24 = day22.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        boolean boolean29 = timeSeriesDataItem27.equals((java.lang.Object) 5);
        int int30 = day22.compareTo((java.lang.Object) timeSeriesDataItem27);
        boolean boolean31 = year17.equals((java.lang.Object) timeSeriesDataItem27);
        boolean boolean32 = fixedMillisecond12.equals((java.lang.Object) year17);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond7.getMiddleMillisecond(calendar34);
        java.util.Calendar calendar36 = null;
        fixedMillisecond7.peg(calendar36);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 12L + "'", long10 == 12L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 12L + "'", long13 == 12L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 12L + "'", long16 == 12L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 12L + "'", long35 == 12L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) class10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        boolean boolean18 = timeSeries9.isEmpty();
        timeSeries9.setDescription("April");
        timeSeries9.setRangeDescription("Following");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getStart();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
        int int28 = day26.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (double) (-1.0f));
        boolean boolean33 = timeSeriesDataItem31.equals((java.lang.Object) 5);
        int int34 = day26.compareTo((java.lang.Object) timeSeriesDataItem31);
        int int35 = day26.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day26.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) day26);
        java.lang.String str38 = day26.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1-January-2019" + "'", str38.equals("1-January-2019"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(3, serialDate4);
        boolean boolean6 = spreadsheetDate1.isBefore(serialDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(12);
        int int9 = spreadsheetDate8.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(3, serialDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.util.Date date17 = year16.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        boolean boolean21 = spreadsheetDate15.equals((java.lang.Object) day19);
        boolean boolean22 = spreadsheetDate8.isInRange(serialDate12, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears(6, serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getFollowingDayOfWeek(1);
        java.lang.String str29 = serialDate25.toString();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        boolean boolean32 = spreadsheetDate15.isInRange(serialDate25, serialDate31);
        int int33 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        try {
            org.jfree.data.time.SerialDate serialDate35 = spreadsheetDate15.getPreviousDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "9-January-1900" + "'", str29.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        long long17 = month15.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long17);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.addChangeListener(seriesChangeListener19);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries18.addChangeListener(seriesChangeListener21);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries24.setMaximumItemCount(1900);
        java.util.Collection collection27 = timeSeries24.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries18.addAndOrUpdate(timeSeries24);
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2);
        java.util.Collection collection31 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        java.util.Collection collection32 = timeSeries30.getTimePeriods();
        timeSeries30.setMaximumItemCount(11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61850404800001L) + "'", long17 == (-61850404800001L));
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(timeSeries28);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(collection32);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries1.setMaximumItemCount(1900);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((-61851744000000L));
        java.util.Calendar calendar7 = null;
        fixedMillisecond6.peg(calendar7);
        long long9 = fixedMillisecond6.getMiddleMillisecond();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond6.getMiddleMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        java.util.Calendar calendar13 = null;
        fixedMillisecond6.peg(calendar13);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61851744000000L) + "'", long9 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61851744000000L) + "'", long11 == (-61851744000000L));
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        int int5 = day3.getDayOfMonth();
        long long6 = day3.getSerialIndex();
        java.lang.String str7 = day3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43466L + "'", long6 == 43466L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1-January-2019" + "'", str7.equals("1-January-2019"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries1.setMaximumItemCount(1900);
        java.util.List list4 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries6.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries1.addAndOrUpdate(timeSeries6);
        timeSeries1.setMaximumItemAge((long) 9);
        timeSeries1.clear();
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(timeSeries9);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        int int5 = day3.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        int int9 = day3.compareTo((java.lang.Object) regularTimePeriod8);
        boolean boolean11 = day3.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date34 = month33.getEnd();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month35);
        timeSeries9.removeAgedItems(false);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year40, (double) (-1.0f));
        java.lang.Class<?> wildcardClass43 = timeSeriesDataItem42.getClass();
        java.lang.Object obj44 = timeSeriesDataItem42.clone();
        boolean boolean46 = timeSeriesDataItem42.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = timeSeriesDataItem42.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries50.setMaximumItemCount(1900);
        java.util.Collection collection53 = timeSeries50.getTimePeriods();
        java.lang.Class class54 = timeSeries50.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class54);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem42, class54);
        try {
            timeSeries9.add(timeSeriesDataItem42, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(collection53);
        org.junit.Assert.assertNotNull(class54);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-458));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-571) + "'", int1 == (-571));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        java.lang.String str11 = serialDate7.toString();
        int int12 = spreadsheetDate1.compareTo((java.lang.Object) serialDate7);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long16 = month15.getFirstMillisecond();
        int int17 = month15.getMonth();
        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) month15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        int int21 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(3, serialDate26);
        boolean boolean28 = spreadsheetDate23.isBefore(serialDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date31 = spreadsheetDate30.toDate();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        java.util.Date date33 = year32.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date33, timeZone34);
        int int37 = day35.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year38, (double) (-1.0f));
        boolean boolean42 = timeSeriesDataItem40.equals((java.lang.Object) 5);
        int int43 = day35.compareTo((java.lang.Object) timeSeriesDataItem40);
        boolean boolean44 = spreadsheetDate30.equals((java.lang.Object) int43);
        boolean boolean45 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int46 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate20.getNearestDayOfWeek(1);
        boolean boolean49 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(12);
        int int53 = spreadsheetDate52.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addMonths(3, serialDate58);
        boolean boolean60 = spreadsheetDate55.isBefore(serialDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date63 = spreadsheetDate62.toDate();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        java.util.Date date65 = year64.getStart();
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date65, timeZone66);
        int int69 = day67.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year70, (double) (-1.0f));
        boolean boolean74 = timeSeriesDataItem72.equals((java.lang.Object) 5);
        int int75 = day67.compareTo((java.lang.Object) timeSeriesDataItem72);
        boolean boolean76 = spreadsheetDate62.equals((java.lang.Object) int75);
        boolean boolean77 = spreadsheetDate55.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate62);
        int int78 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate62);
        int int79 = spreadsheetDate62.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate(2958465);
        boolean boolean82 = spreadsheetDate62.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate81);
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate81);
        boolean boolean84 = spreadsheetDate1.isOnOrBefore(serialDate83);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851744000000L) + "'", long16 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 5 + "'", int53 == 5);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 12 + "'", int79 == 12);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (int) (short) 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date3 = month2.getEnd();
        long long4 = month2.getLastMillisecond();
        try {
            org.jfree.data.time.Year year5 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61849065600001L) + "'", long4 == (-61849065600001L));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        java.util.Date date3 = year2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        boolean boolean7 = spreadsheetDate1.equals((java.lang.Object) day5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        int int10 = spreadsheetDate9.getDayOfWeek();
        int int11 = spreadsheetDate9.getDayOfMonth();
        int int12 = spreadsheetDate9.getMonth();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears(6, serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = serialDate15.getFollowingDayOfWeek(1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(12);
        int int21 = spreadsheetDate20.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths(3, serialDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        java.util.Date date29 = year28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date29, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.previous();
        boolean boolean33 = spreadsheetDate27.equals((java.lang.Object) day31);
        boolean boolean34 = spreadsheetDate20.isInRange(serialDate24, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean36 = spreadsheetDate9.isInRange(serialDate18, (org.jfree.data.time.SerialDate) spreadsheetDate20, (int) (byte) -1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(12);
        int int39 = spreadsheetDate38.getDayOfWeek();
        int int40 = spreadsheetDate38.getDayOfMonth();
        int int41 = spreadsheetDate38.getMonth();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears(6, serialDate44);
        org.jfree.data.time.SerialDate serialDate47 = serialDate44.getFollowingDayOfWeek(1);
        java.lang.String str48 = serialDate44.toString();
        int int49 = spreadsheetDate38.compareTo((java.lang.Object) serialDate44);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long53 = month52.getFirstMillisecond();
        int int54 = month52.getMonth();
        boolean boolean55 = spreadsheetDate38.equals((java.lang.Object) month52);
        int int56 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate38);
        int int57 = day5.compareTo((java.lang.Object) spreadsheetDate38);
        int int58 = day5.getMonth();
        int int59 = day5.getDayOfMonth();
        int int60 = day5.getYear();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 5 + "'", int21 == 5);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 11 + "'", int40 == 11);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "9-January-1900" + "'", str48.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2 + "'", int49 == 2);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-61851744000000L) + "'", long53 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries9.setKey((java.lang.Comparable) (byte) 0);
        long long42 = timeSeries9.getMaximumItemAge();
        boolean boolean43 = timeSeries9.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
        timeSeries9.addChangeListener(seriesChangeListener44);
        java.lang.String str46 = timeSeries9.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Time" + "'", str46.equals("Time"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long6 = month5.getFirstMillisecond();
        java.util.Date date7 = month5.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date2);
        java.util.TimeZone timeZone12 = null;
        try {
            org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date2, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        java.lang.Number number3 = timeSeriesDataItem2.getValue();
        java.lang.Number number4 = timeSeriesDataItem2.getValue();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        java.lang.String str11 = serialDate7.toString();
        int int12 = spreadsheetDate1.compareTo((java.lang.Object) serialDate7);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long16 = month15.getFirstMillisecond();
        int int17 = month15.getMonth();
        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) month15);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        java.lang.Class<?> wildcardClass22 = timeSeriesDataItem21.getClass();
        java.lang.Object obj23 = timeSeriesDataItem21.clone();
        int int24 = month15.compareTo((java.lang.Object) timeSeriesDataItem21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int24);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries25.createCopy(3, 11);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timeSeries28.removePropertyChangeListener(propertyChangeListener29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851744000000L) + "'", long16 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(timeSeries28);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        long long4 = day3.getFirstMillisecond();
        int int5 = day3.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        int int7 = day3.compareTo((java.lang.Object) fixedMillisecond6);
        long long8 = day3.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate9 = day3.getSerialDate();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.util.Date date11 = year10.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.previous();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long19 = month18.getFirstMillisecond();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, (double) (-1.0f));
        java.lang.Class<?> wildcardClass24 = timeSeriesDataItem23.getClass();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date20, (java.lang.Class) wildcardClass24);
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod15, class26);
        java.util.List list28 = timeSeries27.getItems();
        boolean boolean29 = day3.equals((java.lang.Object) timeSeries27);
        java.lang.String str30 = timeSeries27.getDomainDescription();
        timeSeries27.fireSeriesChanged();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546415999999L + "'", long8 == 1546415999999L);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61851744000000L) + "'", long19 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Time" + "'", str30.equals("Time"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (double) (-1.0f));
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) 5);
        java.lang.Object obj5 = timeSeriesDataItem2.clone();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year6, (double) (-1.0f));
        java.lang.Class<?> wildcardClass9 = timeSeriesDataItem8.getClass();
        boolean boolean10 = timeSeriesDataItem2.equals((java.lang.Object) timeSeriesDataItem8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem8.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.addChangeListener(seriesChangeListener19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.util.Date date22 = year21.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        long long25 = day24.getFirstMillisecond();
        long long26 = day24.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day24.next();
        timeSeries9.setKey((java.lang.Comparable) day24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1546329600000L + "'", long25 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546415999999L + "'", long26 == 1546415999999L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        int int3 = spreadsheetDate1.getDayOfMonth();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate7.getFollowingDayOfWeek(1);
        java.lang.String str11 = serialDate7.toString();
        int int12 = spreadsheetDate1.compareTo((java.lang.Object) serialDate7);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long16 = month15.getFirstMillisecond();
        int int17 = month15.getMonth();
        boolean boolean18 = spreadsheetDate1.equals((java.lang.Object) month15);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year19, (double) (-1.0f));
        java.lang.Class<?> wildcardClass22 = timeSeriesDataItem21.getClass();
        java.lang.Object obj23 = timeSeriesDataItem21.clone();
        int int24 = month15.compareTo((java.lang.Object) timeSeriesDataItem21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (double) (byte) 0);
        java.util.Calendar calendar27 = null;
        try {
            long long28 = month15.getMiddleMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "9-January-1900" + "'", str11.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61851744000000L) + "'", long16 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) day44);
        java.util.List list46 = timeSeries29.getItems();
        java.lang.Class class47 = timeSeries29.getTimePeriodClass();
        try {
            java.lang.Number number49 = timeSeries29.getValue(30);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 30, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(class47);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.next();
        long long6 = fixedMillisecond4.getSerialIndex();
        int int7 = month2.compareTo((java.lang.Object) fixedMillisecond4);
        long long8 = month2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 12L + "'", long6 == 12L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61849065600001L) + "'", long8 == (-61849065600001L));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        int int3 = spreadsheetDate2.getDayOfWeek();
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(6, serialDate7);
        boolean boolean9 = spreadsheetDate2.isAfter(serialDate7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate7);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays(1900, serialDate7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        java.lang.String str20 = timeSeries9.getDomainDescription();
        timeSeries9.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        timeSeries9.setKey((java.lang.Comparable) (byte) 0);
        timeSeries9.setDomainDescription("");
        timeSeries9.setNotify(false);
        timeSeries9.setDomainDescription("hi!");
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year48, (double) (-1.0f));
        java.lang.Class<?> wildcardClass51 = timeSeriesDataItem50.getClass();
        java.lang.Object obj52 = timeSeriesDataItem50.clone();
        boolean boolean54 = timeSeriesDataItem50.equals((java.lang.Object) 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = timeSeriesDataItem50.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        timeSeries58.setMaximumItemCount(1900);
        java.util.Collection collection61 = timeSeries58.getTimePeriods();
        java.lang.Class class62 = timeSeries58.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', class62);
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem50, class62);
        boolean boolean65 = timeSeries9.equals((java.lang.Object) class62);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(collection61);
        org.junit.Assert.assertNotNull(class62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        java.lang.Object obj18 = timeSeries9.clone();
        java.lang.String str19 = timeSeries9.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.next();
        long long23 = fixedMillisecond21.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long27 = month26.getFirstMillisecond();
        java.util.Date date28 = month26.getEnd();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (double) (-1.0f));
        java.lang.Class<?> wildcardClass32 = timeSeriesDataItem31.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date28, (java.lang.Class) wildcardClass32);
        int int34 = timeSeries33.getMaximumItemCount();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date38 = month37.getEnd();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) month39);
        int int41 = timeSeries33.getMaximumItemCount();
        timeSeries33.setDescription("");
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long47 = month46.getFirstMillisecond();
        java.util.Date date48 = month46.getEnd();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year49, (double) (-1.0f));
        java.lang.Class<?> wildcardClass52 = timeSeriesDataItem51.getClass();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date48, (java.lang.Class) wildcardClass52);
        int int54 = timeSeries53.getMaximumItemCount();
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        boolean boolean59 = month57.equals((java.lang.Object) year58);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries53.getDataItem((org.jfree.data.time.RegularTimePeriod) month57);
        timeSeries53.setMaximumItemCount(0);
        java.util.Collection collection63 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries53);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addYears(6, serialDate66);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(serialDate66);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries53.getDataItem((org.jfree.data.time.RegularTimePeriod) day68);
        java.util.List list70 = timeSeries53.getItems();
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.addYears(6, serialDate73);
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(serialDate73);
        timeSeries53.setKey((java.lang.Comparable) serialDate73);
        org.jfree.data.time.Month month79 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        int int81 = month79.compareTo((java.lang.Object) 2);
        org.jfree.data.time.Month month84 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date85 = month84.getEnd();
        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month(date85);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent87 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date85);
        java.lang.Object obj88 = seriesChangeEvent87.getSource();
        int int89 = month79.compareTo(obj88);
        timeSeries53.delete((org.jfree.data.time.RegularTimePeriod) month79);
        org.jfree.data.time.TimeSeries timeSeries91 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (org.jfree.data.time.RegularTimePeriod) month79);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 12L + "'", long23 == 12L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-61851744000000L) + "'", long27 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2147483647 + "'", int34 == 2147483647);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2147483647 + "'", int41 == 2147483647);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61851744000000L) + "'", long47 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2147483647 + "'", int54 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertNotNull(collection63);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNull(timeSeriesDataItem69);
        org.junit.Assert.assertNotNull(list70);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(obj88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertNotNull(timeSeries91);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ERROR : Relative To String");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        java.util.Date date19 = year18.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day21.previous();
        int int24 = timeSeries9.getIndex(regularTimePeriod23);
        int int25 = timeSeries9.getMaximumItemCount();
        java.lang.Class class26 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long30 = month29.getFirstMillisecond();
        java.util.Date date31 = month29.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year32, (double) (-1.0f));
        java.lang.Class<?> wildcardClass35 = timeSeriesDataItem34.getClass();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date31, (java.lang.Class) wildcardClass35);
        int int37 = timeSeries36.getMaximumItemCount();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date41 = month40.getEnd();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date41);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) month42);
        int int44 = timeSeries36.getMaximumItemCount();
        timeSeries36.setDescription("");
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long50 = month49.getFirstMillisecond();
        java.util.Date date51 = month49.getEnd();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year52, (double) (-1.0f));
        java.lang.Class<?> wildcardClass55 = timeSeriesDataItem54.getClass();
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date51, (java.lang.Class) wildcardClass55);
        int int57 = timeSeries56.getMaximumItemCount();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        boolean boolean62 = month60.equals((java.lang.Object) year61);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries56.getDataItem((org.jfree.data.time.RegularTimePeriod) month60);
        timeSeries56.setMaximumItemCount(0);
        java.util.Collection collection66 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries56);
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date70 = month69.getEnd();
        int int71 = month69.getYearValue();
        int int72 = timeSeries36.getIndex((org.jfree.data.time.RegularTimePeriod) month69);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month69, (double) 31);
        try {
            timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month69, (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeriesDataItem.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61851744000000L) + "'", long30 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2147483647 + "'", int37 == 2147483647);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2147483647 + "'", int44 == 2147483647);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61851744000000L) + "'", long50 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2147483647 + "'", int57 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem63);
        org.junit.Assert.assertNotNull(collection66);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 10 + "'", int71 == 10);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries9.addAndOrUpdate(timeSeries12);
        timeSeries12.setDescription("org.jfree.data.general.SeriesChangeEvent[source=Fri Jan 31 23:59:59 PST 10]");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(12);
        int int18 = spreadsheetDate17.getDayOfWeek();
        int int19 = spreadsheetDate17.getMonth();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears(6, serialDate22);
        boolean boolean24 = spreadsheetDate17.isAfter(serialDate22);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate22);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) (-1.0f));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year26.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 0.0f);
        long long32 = year26.getFirstMillisecond();
        long long33 = year26.getSerialIndex();
        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(12);
        int int38 = spreadsheetDate37.getDayOfWeek();
        int int39 = spreadsheetDate37.getMonth();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addYears(6, serialDate42);
        boolean boolean44 = spreadsheetDate37.isAfter(serialDate42);
        int int45 = spreadsheetDate37.getYYYY();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(12);
        int int49 = spreadsheetDate48.getDayOfWeek();
        int int50 = spreadsheetDate48.getDayOfMonth();
        int int51 = spreadsheetDate48.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addMonths(3, serialDate56);
        boolean boolean58 = spreadsheetDate53.isBefore(serialDate56);
        boolean boolean60 = spreadsheetDate37.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate48, (org.jfree.data.time.SerialDate) spreadsheetDate53, 11);
        int int61 = spreadsheetDate48.getDayOfWeek();
        boolean boolean62 = timeSeries25.equals((java.lang.Object) spreadsheetDate48);
        int int63 = timeSeries25.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries12.addAndOrUpdate(timeSeries25);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 5 + "'", int38 == 5);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1900 + "'", int45 == 1900);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 5 + "'", int49 == 5);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 11 + "'", int50 == 11);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 5 + "'", int61 == 5);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(timeSeries64);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod5, (double) 1546329600000L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        timeSeries9.setDescription("");
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long23 = month22.getFirstMillisecond();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (double) (-1.0f));
        java.lang.Class<?> wildcardClass28 = timeSeriesDataItem27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass28);
        int int30 = timeSeries29.getMaximumItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        boolean boolean35 = month33.equals((java.lang.Object) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        timeSeries29.setMaximumItemCount(0);
        java.util.Collection collection39 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date43 = month42.getEnd();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year46);
        int int48 = timeSeries9.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries9.addChangeListener(seriesChangeListener49);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61851744000000L) + "'", long23 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2147483647 + "'", int30 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean4 = month2.equals((java.lang.Object) year3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year3.next();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (double) (-1.0f));
        java.lang.Class<?> wildcardClass8 = timeSeriesDataItem7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, (java.lang.Class) wildcardClass8);
        int int10 = timeSeries9.getMaximumItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 1, 10);
        java.util.Date date14 = month13.getEnd();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) month15);
        int int17 = timeSeries9.getMaximumItemCount();
        boolean boolean18 = timeSeries9.isEmpty();
        timeSeries9.setDescription("April");
        timeSeries9.setRangeDescription("Following");
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.util.Date date24 = year23.getStart();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
        int int28 = day26.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year29, (double) (-1.0f));
        boolean boolean33 = timeSeriesDataItem31.equals((java.lang.Object) 5);
        int int34 = day26.compareTo((java.lang.Object) timeSeriesDataItem31);
        int int35 = day26.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day26.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) day26);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.util.Date date39 = year38.getStart();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date39, timeZone40);
        int int43 = day41.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, (double) (-1.0f));
        boolean boolean48 = timeSeriesDataItem46.equals((java.lang.Object) 5);
        int int49 = day41.compareTo((java.lang.Object) timeSeriesDataItem46);
        int int50 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.time.SerialDate serialDate51 = day41.getSerialDate();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61851744000000L) + "'", long3 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(serialDate51);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(3, serialDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        java.util.Date date10 = year9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
        boolean boolean14 = spreadsheetDate8.equals((java.lang.Object) day12);
        boolean boolean15 = spreadsheetDate1.isInRange(serialDate5, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears(6, serialDate18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getFollowingDayOfWeek(1);
        java.lang.String str22 = serialDate18.toString();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        boolean boolean25 = spreadsheetDate8.isInRange(serialDate18, serialDate24);
        int int26 = spreadsheetDate8.getDayOfWeek();
        java.lang.String str27 = spreadsheetDate8.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(12);
        int int31 = spreadsheetDate30.getDayOfWeek();
        int int32 = spreadsheetDate30.getDayOfMonth();
        int int33 = spreadsheetDate30.getMonth();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addYears(6, serialDate36);
        org.jfree.data.time.SerialDate serialDate39 = serialDate36.getFollowingDayOfWeek(1);
        java.lang.String str40 = serialDate36.toString();
        int int41 = spreadsheetDate30.compareTo((java.lang.Object) serialDate36);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addYears(3, serialDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(12);
        int int48 = spreadsheetDate47.getDayOfWeek();
        int int49 = spreadsheetDate47.getMonth();
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addYears(6, serialDate52);
        boolean boolean54 = spreadsheetDate47.isAfter(serialDate52);
        int int55 = spreadsheetDate47.getYYYY();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addMonths((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate47);
        int int57 = spreadsheetDate44.compare(serialDate56);
        boolean boolean58 = spreadsheetDate8.isInRange(serialDate42, serialDate56);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "9-January-1900" + "'", str22.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5 + "'", int26 == 5);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 5 + "'", int31 == 5);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 11 + "'", int32 == 11);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "9-January-1900" + "'", str40.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 5 + "'", int48 == 5);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1900 + "'", int55 == 1900);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }
}

