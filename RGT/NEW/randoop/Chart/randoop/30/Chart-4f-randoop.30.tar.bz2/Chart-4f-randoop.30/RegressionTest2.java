import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("VerticalAlignment.TOP");
        org.jfree.chart.axis.NumberAxis numberAxis3 = null;
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis3, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font8);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = combinedRangeXYPlot10.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { valueAxis15 };
        combinedRangeXYPlot10.setDomainAxes(valueAxisArray16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot10.setDomainTickBandPaint((java.awt.Paint) color18);
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("hi!", paint21);
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem22.setLabelPaint(paint23);
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem22.setFillPaint(paint25);
        boolean boolean27 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color18, paint25);
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("hi!", font8, (java.awt.Paint) color18);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor29 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        labelBlock28.setContentAlignmentPoint(textBlockAnchor29);
        java.awt.Font font31 = labelBlock28.getFont();
        categoryAxis1.setTickLabelFont(font31);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor29);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        java.text.NumberFormat numberFormat5 = logFormat4.getExponentFormat();
        java.text.NumberFormat numberFormat6 = java.text.NumberFormat.getIntegerInstance();
        logFormat4.setExponentFormat(numberFormat6);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertNotNull(numberFormat6);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        java.awt.Stroke stroke10 = categoryPlot5.getRangeMinorGridlineStroke();
        boolean boolean11 = categoryPlot5.isDomainPannable();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot5.setNoDataMessageFont(font12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke16 = combinedRangeXYPlot15.getRangeCrosshairStroke();
        java.awt.Paint paint17 = combinedRangeXYPlot15.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = combinedRangeXYPlot15.getAxisOffset();
        org.jfree.chart.axis.NumberAxis numberAxis20 = null;
        java.awt.Font font25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis20, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font25);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot27.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection31 = combinedRangeXYPlot27.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray33 = new org.jfree.chart.axis.ValueAxis[] { valueAxis32 };
        combinedRangeXYPlot27.setDomainAxes(valueAxisArray33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot27.setDomainTickBandPaint((java.awt.Paint) color35);
        java.awt.Paint paint38 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("hi!", paint38);
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem39.setLabelPaint(paint40);
        java.awt.Paint paint42 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem39.setFillPaint(paint42);
        boolean boolean44 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color35, paint42);
        org.jfree.chart.block.LabelBlock labelBlock45 = new org.jfree.chart.block.LabelBlock("hi!", font25, (java.awt.Paint) color35);
        java.awt.geom.Rectangle2D rectangle2D46 = labelBlock45.getBounds();
        java.awt.Shape shape47 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D46);
        rectangleInsets18.trim(rectangle2D46);
        categoryPlot5.drawBackgroundImage(graphics2D14, rectangle2D46);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(legendItemCollection31);
        org.junit.Assert.assertNotNull(valueAxisArray33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(shape47);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setCopyright("");
        basicProjectInfo0.setInfo("ItemLabelAnchor.OUTSIDE3");
        java.lang.String str5 = basicProjectInfo0.getName();
        basicProjectInfo0.setInfo("item");
        java.lang.String str8 = basicProjectInfo0.getCopyright();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray24);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "HorizontalAlignment.CENTER", "January 13", categoryDataset25, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        try {
            org.jfree.data.general.PieDataset pieDataset30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset25, (java.lang.Comparable) 86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        boolean boolean7 = ringPlot6.getSimpleLabels();
        double double8 = ringPlot6.getOuterSeparatorExtension();
        boolean boolean9 = ringPlot6.getSeparatorsVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = ringPlot6.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range7 = barRenderer4.findRangeBounds(categoryDataset6);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        barRenderer4.setSeriesToolTipGenerator(96, categoryToolTipGenerator9, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = null;
        try {
            barRenderer4.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JFreeChart" + "'", str1.equals("JFreeChart"));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        timeSeriesCollection0.removeAllSeries();
        java.util.List list2 = timeSeriesCollection0.getSeries();
        try {
            double double5 = timeSeriesCollection0.getEndYValue((int) '4', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getCategoryMargin();
        categoryPlot5.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        boolean boolean12 = categoryPlot5.isDomainPannable();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        try {
            double double23 = defaultXYDataset19.getXValue(1964, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1964, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1, (double) 100.0f, (double) 13);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        double double9 = rectangleInsets7.trimWidth(0.05d);
        double double11 = rectangleInsets7.trimHeight((double) 0.0f);
        org.jfree.chart.axis.NumberAxis numberAxis13 = null;
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis13, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font18);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot20.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection24 = combinedRangeXYPlot20.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray26 = new org.jfree.chart.axis.ValueAxis[] { valueAxis25 };
        combinedRangeXYPlot20.setDomainAxes(valueAxisArray26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot20.setDomainTickBandPaint((java.awt.Paint) color28);
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!", paint31);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem32.setLabelPaint(paint33);
        java.awt.Paint paint35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem32.setFillPaint(paint35);
        boolean boolean37 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, paint35);
        org.jfree.chart.block.LabelBlock labelBlock38 = new org.jfree.chart.block.LabelBlock("hi!", font18, (java.awt.Paint) color28);
        java.awt.geom.Rectangle2D rectangle2D39 = labelBlock38.getBounds();
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets7.createInsetRectangle(rectangle2D39);
        boolean boolean41 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) (-61755710400001L), (double) 3, rectangle2D39);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-13.95d) + "'", double9 == (-13.95d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-135.0d) + "'", double11 == (-135.0d));
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(valueAxisArray26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot5.getDomainMarkers(layer6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11, true);
        java.awt.Paint paint14 = categoryPlot5.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        int int21 = defaultXYDataset19.getSeriesCount();
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset19, true);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset19, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate26 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset19);
        double double28 = intervalXYDelegate26.getDomainUpperBound(false);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(6, layer5);
        combinedRangeXYPlot0.setDomainCrosshairLockedOnData(false);
        java.awt.Stroke stroke9 = combinedRangeXYPlot0.getOutlineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedRangeXYPlot10.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        combinedRangeXYPlot10.setFixedRangeAxisSpace(axisSpace13, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = combinedRangeXYPlot16.getDomainMarkers(6, layer21);
        combinedRangeXYPlot16.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot10.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot16);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = combinedRangeXYPlot16.getLegendItems();
        combinedRangeXYPlot0.setFixedLegendItems(legendItemCollection26);
        java.awt.Paint paint29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("hi!", paint29);
        legendItem30.setShapeVisible(true);
        java.text.AttributedString attributedString33 = legendItem30.getAttributedLabel();
        java.awt.Paint paint34 = legendItem30.getLabelPaint();
        legendItemCollection26.add(legendItem30);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(attributedString33);
        org.junit.Assert.assertNull(paint34);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font5);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        java.awt.Font font16 = categoryAxis3D12.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot17.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection21 = combinedRangeXYPlot17.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { valueAxis22 };
        combinedRangeXYPlot17.setDomainAxes(valueAxisArray23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot17.setDomainTickBandPaint((java.awt.Paint) color25);
        java.awt.Stroke stroke27 = combinedRangeXYPlot17.getRangeCrosshairStroke();
        categoryAxis3D12.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot17);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot17);
        java.awt.Paint paint30 = jFreeChart29.getBorderPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, 0.0d, paint30);
        markerAxisBand6.addMarker(intervalMarker31);
        intervalMarker31.setEndValue((double) 6);
        java.lang.Object obj35 = intervalMarker31.clone();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", paint19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem20.setLabelPaint(paint21);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem20.setFillPaint(paint23);
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color16, paint23);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("hi!", font6, (java.awt.Paint) color16);
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock26.getBounds();
        org.jfree.chart.axis.NumberAxis numberAxis28 = null;
        java.awt.Font font33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis28, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font33);
        labelBlock26.setFont(font33);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint37 = xYBarRenderer36.getBasePaint();
        xYBarRenderer36.setShadowXOffset((double) 4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator41 = xYBarRenderer36.getSeriesToolTipGenerator(10);
        java.awt.Paint paint42 = xYBarRenderer36.getBasePaint();
        boolean boolean43 = labelBlock26.equals((java.lang.Object) paint42);
        java.lang.String str44 = labelBlock26.getToolTipText();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(xYToolTipGenerator41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(str44);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        piePlot3D1.setMaximumLabelWidth((double) ' ');
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator6 = new org.jfree.chart.urls.StandardXYURLGenerator();
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) standardXYURLGenerator6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = combinedRangeXYPlot0.getDataRange(valueAxis18);
        java.awt.Stroke stroke20 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot21.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation26 = combinedRangeXYPlot21.getRangeAxisLocation(15);
        boolean boolean27 = combinedRangeXYPlot21.isNotify();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer28 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator30 = null;
        xYBarRenderer28.setSeriesURLGenerator(6, xYURLGenerator30);
        xYBarRenderer28.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        int int35 = combinedRangeXYPlot21.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer28);
        boolean boolean36 = combinedRangeXYPlot21.isRangePannable();
        combinedRangeXYPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot21);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("NO_CHANGE");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range5 = rectangleConstraint4.getHeightRange();
        boolean boolean6 = textFragment1.equals((java.lang.Object) range5);
        java.awt.Font font7 = textFragment1.getFont();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = barRenderer0.getItemLabelGenerator((-1), 0, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!", paint25);
        legendItem26.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset29 = null;
        legendItem26.setDataset(dataset29);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator33 = null;
        xYBarRenderer31.setSeriesURLGenerator(6, xYURLGenerator33);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer31.setSeriesStroke((int) (byte) 100, stroke36);
        legendItem26.setOutlineStroke(stroke36);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color23, stroke36);
        barRenderer0.setSeriesStroke(5, stroke36);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation41 = null;
        boolean boolean42 = barRenderer0.removeAnnotation(categoryAnnotation41);
        java.awt.Paint paint43 = barRenderer0.getBaseItemLabelPaint();
        barRenderer0.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean2 = numberAxis1.isInverted();
        numberAxis1.setAutoTickUnitSelection(false);
        org.jfree.data.Range range5 = numberAxis1.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("VerticalAlignment.TOP");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        double double4 = xYSeriesCollection2.getRangeUpperBound(true);
        int int5 = xYSeriesCollection2.getSeriesCount();
        xYSeriesCollection2.setIntervalWidth(0.08d);
        boolean boolean8 = standardChartTheme1.equals((java.lang.Object) xYSeriesCollection2);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D9 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean11 = barRenderer3D9.equals((java.lang.Object) 10.0f);
        java.awt.Paint paint12 = barRenderer3D9.getBaseFillPaint();
        java.awt.Paint paint14 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer3D9.setSeriesItemLabelPaint(0, paint14, false);
        standardChartTheme1.setWallPaint(paint14);
        java.awt.Paint paint18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        standardChartTheme1.setItemLabelPaint(paint18);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        boolean boolean7 = ringPlot6.getSimpleLabels();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = ringPlot6.getURLGenerator();
        java.awt.Paint paint9 = ringPlot6.getNoDataMessagePaint();
        boolean boolean10 = ringPlot6.getSimpleLabels();
        java.awt.Font font11 = ringPlot6.getLabelFont();
        ringPlot6.setInnerSeparatorExtension(3.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("VerticalAlignment.TOP");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = standardChartTheme1.getAxisOffset();
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.addBaseTimelineExclusions(0L, (long) 15);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        segmentedTimeline0.addException(date4);
        long long6 = segmentedTimeline0.getStartTime();
        segmentedTimeline0.addBaseTimelineExclusions((long) (short) 10, 1560458003853L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2208927600000L) + "'", long6 == (-2208927600000L));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer0.setSeriesStroke((int) (byte) 100, stroke5);
        boolean boolean7 = xYBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        boolean boolean2 = xYBarRenderer0.getAutoPopulateSeriesShape();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot8.getDomainAxisEdge((int) (byte) 1);
        java.awt.Paint paint11 = categoryPlot8.getRangeZeroBaselinePaint();
        xYBarRenderer0.setBaseItemLabelPaint(paint11, true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle2.addChangeListener(titleChangeListener3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle2.setLegendItemGraphicLocation(rectangleAnchor5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        legendTitle2.setLegendItemGraphicEdge(rectangleEdge8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = legendTitle2.getHorizontalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = legendTitle2.getHorizontalAlignment();
        legendTitle2.visible = true;
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        java.lang.StringBuffer stringBuffer12 = null;
        java.text.FieldPosition fieldPosition13 = null;
        java.lang.StringBuffer stringBuffer14 = logFormat10.format((double) 0, stringBuffer12, fieldPosition13);
        java.text.FieldPosition fieldPosition15 = null;
        java.lang.StringBuffer stringBuffer16 = logFormat4.format((long) 1, stringBuffer14, fieldPosition15);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        serialDate19.setDescription("TitleEntity: tooltip = January 13");
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(3, serialDate19);
        boolean boolean23 = logFormat4.equals((java.lang.Object) 3);
        org.junit.Assert.assertNotNull(stringBuffer14);
        org.junit.Assert.assertNotNull(stringBuffer16);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

//    @Test
//    public void test34() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test34");
//        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
//        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType1, 5);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone6 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
//        long long8 = segmentedTimeline4.getTime(date5);
//        java.util.TimeZone timeZone9 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        java.util.Date date10 = dateTickUnit3.rollDate(date5, timeZone9);
//        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("SeriesRenderingOrder.REVERSE", timeZone9);
//        java.util.Locale locale12 = null;
//        try {
//            org.jfree.chart.axis.TickUnitSource tickUnitSource13 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone9, locale12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTickUnitType1);
//        org.junit.Assert.assertNotNull(segmentedTimeline4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560458003853L + "'", long8 == 1560458003853L);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(date10);
//    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer0.setSeriesStroke((int) (byte) 100, stroke5);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesOutlinePaint((int) (byte) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYBarRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = itemLabelPosition9.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor11 = itemLabelPosition9.getRotationAnchor();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        jFreeChart20.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart20.getTitle();
        textTitle23.setText("item");
        java.awt.Paint paint26 = textTitle23.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = textTitle23.getTextAlignment();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double2 = xYSeriesCollection0.getRangeUpperBound(true);
        int int3 = xYSeriesCollection0.getSeriesCount();
        xYSeriesCollection0.setIntervalWidth(0.08d);
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        xYSeries9.addPropertyChangeListener(propertyChangeListener10);
        java.lang.String str12 = xYSeries9.getDescription();
        int int13 = xYSeriesCollection0.indexOf(xYSeries9);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, 0.0d, 100.0f, (float) 'a');
        boolean boolean7 = numberTickUnit1.equals((java.lang.Object) 100.0f);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) boolean7, false);
        java.lang.String str10 = rendererChangeEvent9.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.chart.event.RendererChangeEvent[source=false]" + "'", str10.equals("org.jfree.chart.event.RendererChangeEvent[source=false]"));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        java.lang.Comparable comparable3 = legendItem2.getSeriesKey();
        java.awt.Font font4 = legendItem2.getLabelFont();
        java.lang.String str5 = legendItem2.getLabel();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(comparable3);
        org.junit.Assert.assertNull(font4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange1);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        double double4 = range3.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range3, (-135.0d));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range3, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toFixedWidth((double) 61200000L);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getRangeAxisLocation(0);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot9.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot9.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation3, plotOrientation12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation12);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray24);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "HorizontalAlignment.CENTER", "January 13", categoryDataset25, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double31 = categoryAxis3D30.getCategoryMargin();
        boolean boolean32 = categoryAxis3D30.isTickLabelsVisible();
        float float33 = categoryAxis3D30.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D(pieDataset34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        piePlot3D35.datasetChanged(datasetChangeEvent36);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke39 = combinedRangeXYPlot38.getRangeCrosshairStroke();
        java.awt.Paint paint40 = combinedRangeXYPlot38.getRangeCrosshairPaint();
        boolean boolean41 = piePlot3D35.equals((java.lang.Object) combinedRangeXYPlot38);
        piePlot3D35.setLabelLinkMargin((double) 15);
        java.awt.Paint paint44 = piePlot3D35.getBaseSectionOutlinePaint();
        categoryAxis3D30.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D35);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        java.lang.String str52 = categoryPlot51.getPlotType();
        org.jfree.chart.plot.Marker marker53 = null;
        boolean boolean54 = categoryPlot51.removeDomainMarker(marker53);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = categoryPlot51.getAxisOffset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot56.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection60 = combinedRangeXYPlot56.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { valueAxis61 };
        combinedRangeXYPlot56.setDomainAxes(valueAxisArray62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot56.setDomainTickBandPaint((java.awt.Paint) color64);
        java.awt.Stroke stroke66 = combinedRangeXYPlot56.getRangeCrosshairStroke();
        boolean boolean67 = rectangleInsets55.equals((java.lang.Object) stroke66);
        categoryAxis3D30.setLabelInsets(rectangleInsets55, false);
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D72 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D72.setIncludeBaseInRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis71, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D72);
        boolean boolean76 = numberAxis71.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange77 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange78 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint79 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange77, (org.jfree.data.Range) dateRange78);
        org.jfree.data.Range range80 = rectangleConstraint79.getHeightRange();
        numberAxis71.setDefaultAutoRange(range80);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand82 = numberAxis71.getMarkerBand();
        try {
            numberAxis71.setRangeWithMargins((double) 100, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Category Plot" + "'", str52.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(range80);
        org.junit.Assert.assertNull(markerAxisBand82);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = barRenderer0.getItemLabelGenerator((-1), 0, true);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D21, valueAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer23);
        java.lang.String str25 = categoryPlot24.getPlotType();
        org.jfree.chart.plot.Marker marker26 = null;
        boolean boolean27 = categoryPlot24.removeDomainMarker(marker26);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot24.setRangeMinorGridlineStroke(stroke28);
        barRenderer0.setBaseOutlineStroke(stroke28);
        java.awt.Stroke stroke31 = barRenderer0.getBaseStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Category Plot" + "'", str25.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = null;
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis4, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font9);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection15 = combinedRangeXYPlot11.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] { valueAxis16 };
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot11.setDomainTickBandPaint((java.awt.Paint) color19);
        java.awt.Paint paint22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("hi!", paint22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem23.setLabelPaint(paint24);
        java.awt.Paint paint26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem23.setFillPaint(paint26);
        boolean boolean28 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color19, paint26);
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("hi!", font9, (java.awt.Paint) color19);
        java.awt.geom.Rectangle2D rectangle2D30 = labelBlock29.getBounds();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D30);
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D(pieDataset32);
        piePlot3D33.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot36 = piePlot3D33.getRootPlot();
        java.awt.Paint paint37 = piePlot3D33.getBaseSectionPaint();
        java.awt.Paint paint40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("hi!", paint40);
        legendItem41.setShapeVisible(true);
        java.text.AttributedString attributedString44 = legendItem41.getAttributedLabel();
        legendItem41.setDescription("ItemLabelAnchor.OUTSIDE3");
        boolean boolean47 = legendItem41.isShapeOutlineVisible();
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        legendItem41.setOutlinePaint((java.awt.Paint) color48);
        piePlot3D33.setSectionOutlinePaint((java.lang.Comparable) "ItemLabelAnchor.OUTSIDE3", (java.awt.Paint) color48);
        org.jfree.data.category.CategoryDataset categoryDataset52 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D54 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer56 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset52, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D54, valueAxis55, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer56);
        org.jfree.chart.util.Layer layer58 = null;
        java.util.Collection collection59 = categoryPlot57.getDomainMarkers(layer58);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo61 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo61);
        java.awt.geom.Point2D point2D63 = null;
        categoryPlot57.zoomRangeAxes(0.0d, plotRenderingInfo62, point2D63, true);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState66 = ringPlot1.initialise(graphics2D2, rectangle2D30, (org.jfree.chart.plot.PiePlot) piePlot3D33, (java.lang.Integer) 2147483647, plotRenderingInfo62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(plot36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(attributedString44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNull(collection59);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        float float7 = ringPlot6.getForegroundAlpha();
        boolean boolean8 = ringPlot6.isCircular();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("");
        boolean boolean7 = logFormat4.equals((java.lang.Object) "");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues8 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues8.addValue((java.lang.Comparable) (short) 10, (double) 1L);
        defaultKeyedValues8.addValue((java.lang.Comparable) 1964, (java.lang.Number) 100.0d);
        boolean boolean15 = logFormat4.equals((java.lang.Object) 100.0d);
        java.text.NumberFormat numberFormat16 = logFormat4.getExponentFormat();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(numberFormat16);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        ringPlot1.setOuterSeparatorExtension(0.05d);
        ringPlot1.setAutoPopulateSectionOutlinePaint(false);
        java.awt.Paint paint6 = ringPlot1.getShadowPaint();
        ringPlot1.setOuterSeparatorExtension(0.5d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        xYSeriesCollection0.clearSelection();
        boolean boolean2 = xYSeriesCollection0.isAutoWidth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        java.awt.Stroke stroke8 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer4 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator6 = null;
        xYBarRenderer4.setSeriesURLGenerator(6, xYURLGenerator6);
        java.lang.Object obj8 = xYBarRenderer4.clone();
        java.awt.Stroke stroke10 = xYBarRenderer4.getSeriesOutlineStroke((int) (short) 0);
        java.awt.Stroke stroke11 = xYBarRenderer4.getBaseStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator13 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer4.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator13);
        xYBarRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator13);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean2 = numberAxis1.isInverted();
        numberAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis1);
        org.jfree.data.RangeType rangeType6 = org.jfree.data.RangeType.NEGATIVE;
        numberAxis1.setRangeType(rangeType6);
        java.lang.String str8 = rangeType6.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rangeType6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RangeType.NEGATIVE" + "'", str8.equals("RangeType.NEGATIVE"));
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 10);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot5.getDomainMarkers(layer6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot14.getDomainAxisEdge((int) (byte) 1);
        float float17 = categoryPlot14.getBackgroundImageAlpha();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("hi!", paint21);
        legendItem22.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset25 = null;
        legendItem22.setDataset(dataset25);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = null;
        xYBarRenderer27.setSeriesURLGenerator(6, xYURLGenerator29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer27.setSeriesStroke((int) (byte) 100, stroke32);
        legendItem22.setOutlineStroke(stroke32);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color19, stroke32);
        org.jfree.chart.util.Layer layer36 = null;
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker35, layer36);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker35.setLabelAnchor(rectangleAnchor38);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot5.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker35, layer40);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(layer40);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint8 = xYBarRenderer7.getBasePaint();
        barRenderer4.setSeriesFillPaint(3, paint8, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        java.lang.String str18 = categoryPlot17.getPlotType();
        org.jfree.chart.plot.Marker marker19 = null;
        boolean boolean20 = categoryPlot17.removeDomainMarker(marker19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            barRenderer4.drawOutline(graphics2D11, categoryPlot17, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Category Plot" + "'", str18.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("hi!", paint12);
        legendItem13.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset16 = null;
        legendItem13.setDataset(dataset16);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        xYBarRenderer18.setSeriesURLGenerator(6, xYURLGenerator20);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer18.setSeriesStroke((int) (byte) 100, stroke23);
        legendItem13.setOutlineStroke(stroke23);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke23);
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = combinedRangeXYPlot0.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27, true);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder30 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        java.awt.Paint paint31 = combinedRangeXYPlot0.getDomainMinorGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace32 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace32);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder30);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("January 13");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = xYBarRenderer2.getBasePaint();
        xYBarRenderer2.setShadowXOffset((double) 4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYBarRenderer2.getSeriesToolTipGenerator(10);
        java.awt.Paint paint8 = xYBarRenderer2.getBasePaint();
        xYBarRenderer2.setBarAlignmentFactor(0.05d);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator14 = xYBarRenderer2.getItemLabelGenerator(12, 2019, true);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D16 = new org.jfree.chart.plot.PiePlot3D(pieDataset15);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        piePlot3D16.datasetChanged(datasetChangeEvent17);
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        piePlot3D16.setLegendItemShape(shape19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D23 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D23, valueAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot26.getDomainAxisEdge((int) (byte) 1);
        float float29 = categoryPlot26.getBackgroundImageAlpha();
        categoryPlot26.setNoDataMessage("item");
        org.jfree.chart.entity.PlotEntity plotEntity32 = new org.jfree.chart.entity.PlotEntity(shape19, (org.jfree.chart.plot.Plot) categoryPlot26);
        java.awt.Shape shape33 = plotEntity32.getArea();
        xYBarRenderer2.setBaseShape(shape33, false);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity38 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) logAxis1, shape33, "Nearest", "poly");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(xYToolTipGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(xYItemLabelGenerator14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) (short) 10, (double) 1L);
        defaultKeyedValues0.addValue((java.lang.Comparable) 1964, (java.lang.Number) 100.0d);
        java.lang.Object obj7 = defaultKeyedValues0.clone();
        java.util.List list8 = defaultKeyedValues0.getKeys();
        try {
            defaultKeyedValues0.insertValue(1964, (java.lang.Comparable) "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=-135.0]", (java.lang.Number) 0.5d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(list8);
    }

//    @Test
//    public void test58() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test58");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment(date1);
//        long long3 = segmentedTimeline0.getSegmentsExcludedSize();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        segmentedTimeline4.addBaseTimelineExclusions(0L, (long) 15);
//        java.util.Date date8 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        segmentedTimeline4.addException(date8);
//        org.jfree.chart.axis.DateTickUnitType dateTickUnitType10 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
//        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType10, 5);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline13 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone15 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
//        long long17 = segmentedTimeline13.getTime(date14);
//        java.util.TimeZone timeZone18 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
//        java.util.Date date19 = dateTickUnit12.rollDate(date14, timeZone18);
//        boolean boolean20 = segmentedTimeline0.containsDomainRange(date8, date14);
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(segment2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 61200000L + "'", long3 == 61200000L);
//        org.junit.Assert.assertNotNull(segmentedTimeline4);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(dateTickUnitType10);
//        org.junit.Assert.assertNotNull(segmentedTimeline13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560458003853L + "'", long17 == 1560458003853L);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator3);
        boolean boolean5 = piePlot3D1.getSimpleLabels();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYBarRenderer6.setSeriesURLGenerator(6, xYURLGenerator8);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer6.setSeriesStroke((int) (byte) 100, stroke11);
        java.awt.Paint paint14 = xYBarRenderer6.lookupSeriesOutlinePaint((int) (byte) 1);
        piePlot3D1.setShadowPaint(paint14);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        timeSeriesCollection0.removeAllSeries();
        java.util.List list2 = timeSeriesCollection0.getSeries();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        timeSeriesCollection0.removeSeries(timeSeries4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = null;
        try {
            timeSeries4.add(timeSeriesDataItem6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot4 = piePlot3D1.getRootPlot();
        java.awt.Paint paint5 = piePlot3D1.getBaseSectionPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3D1.getLegendLabelGenerator();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = null;
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis9, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font14);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection20 = combinedRangeXYPlot16.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        combinedRangeXYPlot16.setDomainAxes(valueAxisArray22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot16.setDomainTickBandPaint((java.awt.Paint) color24);
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("hi!", paint27);
        java.awt.Paint paint29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem28.setLabelPaint(paint29);
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem28.setFillPaint(paint31);
        boolean boolean33 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color24, paint31);
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("hi!", font14, (java.awt.Paint) color24);
        java.awt.geom.Rectangle2D rectangle2D35 = labelBlock34.getBounds();
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D35);
        org.jfree.data.general.PieDataset pieDataset37 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D38 = new org.jfree.chart.plot.PiePlot3D(pieDataset37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        piePlot3D38.datasetChanged(datasetChangeEvent39);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke42 = combinedRangeXYPlot41.getRangeCrosshairStroke();
        java.awt.Paint paint43 = combinedRangeXYPlot41.getRangeCrosshairPaint();
        boolean boolean44 = piePlot3D38.equals((java.lang.Object) combinedRangeXYPlot41);
        piePlot3D38.setLabelLinkMargin((double) 15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
        org.jfree.chart.plot.PiePlotState piePlotState50 = piePlot3D1.initialise(graphics2D7, rectangle2D35, (org.jfree.chart.plot.PiePlot) piePlot3D38, (java.lang.Integer) 0, plotRenderingInfo49);
        piePlot3D1.clearSectionOutlinePaints(true);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(piePlotState50);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        timeSeriesCollection0.removeAllSeries();
        java.util.List list2 = timeSeriesCollection0.getSeries();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        timeSeriesCollection0.removeSeries(timeSeries4);
        try {
            java.lang.Number number8 = timeSeriesCollection0.getY(2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        xYBarRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYBarRenderer0.getSeriesURLGenerator((int) 'a');
        xYBarRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(xYURLGenerator8);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        legendItem2.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        xYBarRenderer7.setSeriesURLGenerator(6, xYURLGenerator9);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer7.setSeriesStroke((int) (byte) 100, stroke12);
        legendItem2.setOutlineStroke(stroke12);
        java.lang.Comparable comparable15 = legendItem2.getSeriesKey();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(comparable15);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray24);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "HorizontalAlignment.CENTER", "January 13", categoryDataset25, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double31 = categoryAxis3D30.getCategoryMargin();
        boolean boolean32 = categoryAxis3D30.isTickLabelsVisible();
        float float33 = categoryAxis3D30.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D(pieDataset34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        piePlot3D35.datasetChanged(datasetChangeEvent36);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke39 = combinedRangeXYPlot38.getRangeCrosshairStroke();
        java.awt.Paint paint40 = combinedRangeXYPlot38.getRangeCrosshairPaint();
        boolean boolean41 = piePlot3D35.equals((java.lang.Object) combinedRangeXYPlot38);
        piePlot3D35.setLabelLinkMargin((double) 15);
        java.awt.Paint paint44 = piePlot3D35.getBaseSectionOutlinePaint();
        categoryAxis3D30.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D35);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        java.lang.String str52 = categoryPlot51.getPlotType();
        org.jfree.chart.plot.Marker marker53 = null;
        boolean boolean54 = categoryPlot51.removeDomainMarker(marker53);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = categoryPlot51.getAxisOffset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot56.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection60 = combinedRangeXYPlot56.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { valueAxis61 };
        combinedRangeXYPlot56.setDomainAxes(valueAxisArray62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot56.setDomainTickBandPaint((java.awt.Paint) color64);
        java.awt.Stroke stroke66 = combinedRangeXYPlot56.getRangeCrosshairStroke();
        boolean boolean67 = rectangleInsets55.equals((java.lang.Object) stroke66);
        categoryAxis3D30.setLabelInsets(rectangleInsets55, false);
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D72 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D72.setIncludeBaseInRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis71, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D72);
        boolean boolean76 = numberAxis71.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange77 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange78 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint79 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange77, (org.jfree.data.Range) dateRange78);
        org.jfree.data.Range range80 = rectangleConstraint79.getHeightRange();
        numberAxis71.setDefaultAutoRange(range80);
        int int82 = numberAxis71.getMinorTickCount();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Category Plot" + "'", str52.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(range80);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle2.addChangeListener(titleChangeListener3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle2.setLegendItemGraphicLocation(rectangleAnchor5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        legendTitle2.setLegendItemGraphicEdge(rectangleEdge8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = legendTitle2.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle2.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test68");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test69");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        legendItem2.setShapeVisible(true);
        java.text.AttributedString attributedString5 = legendItem2.getAttributedLabel();
        java.awt.Paint paint6 = legendItem2.getLabelPaint();
        java.lang.String str7 = legendItem2.getToolTipText();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(attributedString5);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test70");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeMinorGridlineStroke(stroke9);
        categoryPlot5.clearRangeAxes();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot12.getRangeAxisLocation(15);
        categoryPlot5.setRangeAxisLocation(axisLocation17, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        double double22 = barRenderer21.getMinimumBarLength();
        java.awt.Paint paint24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("hi!", paint24);
        legendItem25.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset28 = null;
        legendItem25.setDataset(dataset28);
        java.awt.Paint paint30 = legendItem25.getOutlinePaint();
        barRenderer21.setShadowPaint(paint30);
        java.awt.Paint paint32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        barRenderer21.setBaseOutlinePaint(paint32);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot34 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation36 = combinedRangeXYPlot34.getRangeAxisLocation(0);
        java.awt.Paint paint37 = combinedRangeXYPlot34.getRangeGridlinePaint();
        barRenderer21.setBaseOutlinePaint(paint37);
        categoryPlot5.setRenderer(100, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer21, false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test71");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        int int21 = defaultXYDataset19.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset19, valueAxis22, polarItemRenderer23);
        int int25 = polarPlot24.getSeriesCount();
        org.jfree.chart.axis.TickUnit tickUnit26 = polarPlot24.getAngleTickUnit();
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        double double28 = barRenderer27.getMinimumBarLength();
        java.awt.Paint paint30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", paint30);
        legendItem31.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset34 = null;
        legendItem31.setDataset(dataset34);
        java.awt.Paint paint36 = legendItem31.getOutlinePaint();
        barRenderer27.setShadowPaint(paint36);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = barRenderer27.getItemLabelGenerator(2, 9999, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator45 = barRenderer27.getItemLabelGenerator((-1), 0, true);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        java.lang.String str52 = categoryPlot51.getPlotType();
        org.jfree.chart.plot.Marker marker53 = null;
        boolean boolean54 = categoryPlot51.removeDomainMarker(marker53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot51.setRangeMinorGridlineStroke(stroke55);
        barRenderer27.setBaseOutlineStroke(stroke55);
        polarPlot24.setAngleGridlineStroke(stroke55);
        java.awt.Paint paint59 = polarPlot24.getAngleGridlinePaint();
        try {
            polarPlot24.zoom(10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(tickUnit26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(categoryItemLabelGenerator41);
        org.junit.Assert.assertNull(categoryItemLabelGenerator45);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Category Plot" + "'", str52.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint59);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test72");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("HorizontalAlignment.LEFT", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test73");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test74");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.addException((long) 8);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test75");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 5);
        int int3 = dateTickUnitType0.getCalendarField();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 14 + "'", int3 == 14);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test76");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("hi!", paint12);
        legendItem13.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset16 = null;
        legendItem13.setDataset(dataset16);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        xYBarRenderer18.setSeriesURLGenerator(6, xYURLGenerator20);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer18.setSeriesStroke((int) (byte) 100, stroke23);
        legendItem13.setOutlineStroke(stroke23);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke23);
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = combinedRangeXYPlot0.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27, true);
        java.awt.Stroke stroke30 = combinedRangeXYPlot0.getDomainMinorGridlineStroke();
        combinedRangeXYPlot0.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) (byte) 1, 0.4d, plotRenderingInfo34, point2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test77");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.lang.String str7 = categoryPlot6.getPlotType();
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = categoryPlot6.removeDomainMarker(marker8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot6.getAxisOffset();
        boolean boolean11 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot6);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        categoryPlot6.setRangePannable(false);
        boolean boolean16 = categoryPlot6.getDrawSharedDomainAxis();
        java.lang.Object obj17 = categoryPlot6.clone();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test78");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test79");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getDrawOutlines();
        java.awt.Shape shape2 = xYLineAndShapeRenderer0.getLegendLine();
        boolean boolean3 = xYLineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test80");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart20.getLegend(0);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(legendTitle22);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test81");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(6, layer5);
        combinedRangeXYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getRangeAxisLocation(0);
        java.awt.Paint paint12 = combinedRangeXYPlot9.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.util.List list15 = null;
        combinedRangeXYPlot9.drawDomainTickBands(graphics2D13, rectangle2D14, list15);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("hi!", paint21);
        legendItem22.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset25 = null;
        legendItem22.setDataset(dataset25);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = null;
        xYBarRenderer27.setSeriesURLGenerator(6, xYURLGenerator29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer27.setSeriesStroke((int) (byte) 100, stroke32);
        legendItem22.setOutlineStroke(stroke32);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color19, stroke32);
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean38 = combinedRangeXYPlot9.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker35, layer36, true);
        boolean boolean39 = combinedRangeXYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker35);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot40.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection44 = combinedRangeXYPlot40.getLegendItems();
        boolean boolean45 = valueMarker35.equals((java.lang.Object) legendItemCollection44);
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean48 = numberAxis47.isInverted();
        numberAxis47.setAutoTickUnitSelection(false);
        java.lang.Object obj51 = numberAxis47.clone();
        boolean boolean52 = legendItemCollection44.equals(obj51);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }
}

